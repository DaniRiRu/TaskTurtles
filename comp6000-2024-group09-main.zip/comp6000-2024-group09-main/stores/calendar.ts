import { defineStore } from "pinia";
import { CalendarView } from "~/types/calendar/views";

interface CalendarState {
	currentDate: Date;
	selectedDate: Date | null;
	view: CalendarView;
}

export const useCalendarStore = defineStore("calendar", {
	state: (): CalendarState => ({
		currentDate: new Date(),
		selectedDate: null,
		view: CalendarView.MONTHLY,
	}),

	getters: {
		currentMonth(): number {
			return this.currentDate.getMonth();
		},
		currentYear(): number {
			return this.currentDate.getFullYear();
		},
		currentHour(): number {
			return this.currentDate.getHours();
		},
		currentDay(): number {
			return this.currentDate.getDate();
		},
	},

	actions: {
		setCurrentDate(date: Date) {
			this.currentDate = date;
		},

		setSelectedDate(date: Date | null) {
			this.selectedDate = date;
		},

		setView(view: CalendarView) {
			this.view = view;
		},

		navigate(direction: "prev" | "next" | "today") {
			if (direction === "today") {
				this.currentDate = new Date();
				return;
			}

			const offset = direction === "next" ? 1 : -1;
			const newDate = new Date(this.currentDate);

			switch (this.view) {
				case CalendarView.DAILY:
					newDate.setDate(newDate.getDate() + offset);
					break;
				case CalendarView.WEEKLY:
					newDate.setDate(newDate.getDate() + offset * 7);
					break;
				default:
					newDate.setMonth(newDate.getMonth() + offset);
					break;
			}

			this.currentDate = newDate;
		},
	},
});
