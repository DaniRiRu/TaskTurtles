import { defineStore } from "pinia";
import type { StoredUser } from "~/types/core/user";

interface AccountState {
	data: StoredUser | null;
	isLoading: boolean;
	error: Error | null;
}

export const useAccountStore = defineStore("account", {
	state: (): AccountState => ({
		data: null,
		isLoading: true,
		error: null,
	}),

	actions: {
		async fetchAccountData() {
			const backend = useBackend();
			this.isLoading = true;
			this.error = null;

			try {
				const accountData = await backend.account.get();
				if ("error" in accountData) {
					throw new Error(accountData.error);
				}
				this.data = accountData;
			} catch (error) {
				this.error = error as Error;
				throw error;
			} finally {
				this.isLoading = false;
			}
		},

		reset() {
			this.data = null;
			this.isLoading = true;
			this.error = null;
		},
	},

	getters: {
		isInitialized: (state) => state.data !== null,
	},
});
