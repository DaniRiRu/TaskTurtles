import { defineStore } from "pinia";
import type { SkillTreeData } from "~/types/skills/skill";
import type { ViewType } from "~/types/skills/views";

interface SkillState {
	isCreateModalOpen: boolean;
	currentTree: SkillTreeData | null;
	trees: Record<string, SkillTreeData>;
	isLoading: boolean;
	currentView: ViewType;
}

export const useSkillTreeStore = defineStore("skillTree", {
	state: (): SkillState => ({
		isCreateModalOpen: false,
		currentTree: null,
		trees: {},
		isLoading: true,
		currentView: "grid",
	}),

	actions: {
		setCreateModalOpen(value: boolean) {
			this.isCreateModalOpen = value;
		},

		setCurrentTree(tree: SkillTreeData | null) {
			this.currentTree = tree;
		},

		setTrees(newTrees: Record<string, SkillTreeData>) {
			this.trees = newTrees;
		},

		setLoading(value: boolean) {
			this.isLoading = value;
		},

		setCurrentView(view: ViewType) {
			this.currentView = view;
		},

		async createNewTree(treeName: string) {
			try {
				this.setCreateModalOpen(false);
				await navigateTo(`/skills/${treeName}`);
			} catch (error) {
				console.error("Error creating tree:", error);
			}
		},
	},
});
