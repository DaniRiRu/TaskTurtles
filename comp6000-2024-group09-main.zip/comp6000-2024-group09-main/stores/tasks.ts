import { defineStore } from "pinia";
import type { TTBackend } from "~/api";
import { ModalType } from "~/enums/frontend/tasks/ModalType";
import { SortOptions } from "~/enums/frontend/tasks/SortOptions";
import { SortType } from "~/enums/frontend/tasks/SortType";
import { ViewMode } from "~/enums/frontend/tasks/ViewMode";
import type { Priority } from "~/types/core/priority";
import type { Tag } from "~/types/core/tag";
import type { Task } from "~/types/core/task";

enum BadgeColor {
	Default = "bg-secondary/10 text-primary",
}

interface TaskColumn {
	id: string;
	title: string;
	tasks: Task[];
	badgeColor: BadgeColor;
}

interface TaskState {
	tasks: Task[];
	tags: Tag[];
	priorities: Priority[];
	selectedTask: Task | null;
	isAddMode: boolean;
	modalType: ModalType;
	viewMode: ViewMode;
	sortType: SortOptions;
	sortOrder: SortType;
}

export const useTaskStore = defineStore("task", {
	state: (): TaskState => ({
		tasks: [],
		tags: [],
		priorities: [],
		selectedTask: null,
		isAddMode: false,
		modalType: ModalType.None,
		viewMode: ViewMode.Horizontal,
		sortType: SortOptions.Status,
		sortOrder: SortType.Ascending,
	}),

	getters: {
		sortedTasks(state): Task[] {
			return [...state.tasks].sort((a, b) => {
				const sortValue = getSortValue(a, b, state.sortType);
				return applySortOrder(sortValue, state.sortOrder);
			});
		},

		taskColumns(state): TaskColumn[] {
			const groupedTasks = this.sortedTasks.reduce(
				(groups: Record<string, Task[]>, task) => {
					const key = getGroupKey(task, state.sortType);
					if (!groups[key]) groups[key] = [];
					groups[key].push(task);
					return groups;
				},
				{},
			);

			return Object.entries(groupedTasks).map(([key, tasks]) => ({
				id: key,
				title: key,
				tasks,
				badgeColor: BadgeColor.Default,
			}));
		},
	},

	actions: {
		setTasks(tasks: Task[]) {
			this.tasks = tasks;
		},
		setTags(tags: Tag[]) {
			this.tags = tags;
		},
		setPriorities(priorities: Priority[]) {
			this.priorities = priorities;
		},
		setSelectedTask(task: Task | null) {
			this.selectedTask = task;
			this.isAddMode = false;
		},
		setAddMode(value: boolean) {
			this.isAddMode = value;
			this.selectedTask = null;
		},
		setModalType(type: ModalType) {
			this.modalType = type;
		},
		setViewMode(mode: ViewMode) {
			this.viewMode = mode;
		},
		setSortType(type: SortOptions) {
			this.sortType = type;
		},
		setSortOrder(order: SortType) {
			this.sortOrder = order;
		},

		async fetchTags(backend: TTBackend) {
			try {
				const response = await backend.tags.list();
				if (!("error" in response)) {
					this.setTags(response.tags);
				}
			} catch (error) {
				console.error("Error fetching tags:", error);
			}
		},

		async fetchPriorities(backend: TTBackend) {
			try {
				const response = await backend.priorities.list();
				if (!("error" in response)) {
					this.setPriorities(response.priorities);
				}
			} catch (error) {
				console.error("Error fetching priorities:", error);
			}
		},

		async fetchData(backend: TTBackend) {
			try {
				const tasksRes = await backend.tasks.list();
				if (!("error" in tasksRes)) {
					this.setTasks(tasksRes.tasks);
				}
				await Promise.all([
					this.fetchTags(backend),
					this.fetchPriorities(backend),
				]);
				// await this.fetchTags(backend);
				// await this.fetchPriorities(backend);
			} catch (error) {
				console.error("Error fetching data:", error);
			}
		},
	},
});

function getSortValue(
	a: Task,
	b: Task,
	sortType: SortOptions,
): [string | number, string | number] {
	switch (sortType) {
		case SortOptions.Status:
			return [a.status.toLowerCase(), b.status.toLowerCase()];
		case SortOptions.Tag:
			return [
				a.tags[0]?.title?.toLowerCase() || "",
				b.tags[0]?.title?.toLowerCase() || "",
			];
		case SortOptions.Priority:
			return [
				(a.priority?.toString() ?? "").toLowerCase(),
				(b.priority?.toString() ?? "").toLowerCase(),
			];
		case SortOptions.DueDate:
			return [new Date(a.dueDate).getTime(), new Date(b.dueDate).getTime()];
		case SortOptions.Title:
			return [a.title.toLowerCase(), b.title.toLowerCase()];
		default:
			return [a.status.toLowerCase(), b.status.toLowerCase()];
	}
}

function applySortOrder(
	[aVal, bVal]: [string | number, string | number],
	sortOrder: SortType,
): number {
	if (aVal === bVal) return 0;
	const comparison = aVal < bVal ? -1 : 1;
	return sortOrder === SortType.Ascending ? comparison : -comparison;
}

function getGroupKey(task: Task, sortType: SortOptions): string {
	switch (sortType) {
		case SortOptions.Status:
			return task.status
				.replace(/-/g, " ")
				.replace(/\b\w/g, (letter) => letter.toUpperCase());
		case SortOptions.Tag:
			return task.tags.map((tag) => tag.title).join(", ") || "Untagged";
		case SortOptions.Priority:
			return (task.priority as Priority)?.title || "No Priority";
		case SortOptions.DueDate:
			return task.dueDate ? new Date(task.dueDate).toDateString() : "Undated";
		case SortOptions.Title:
			return task.title.charAt(0).toUpperCase();
		default:
			return task.status;
	}
}
