
echo "Starting deploy script"

while true
do
  echo "$(date) - Deploying application"

  git pull
  
  if [ $? -eq 0 ]
  then
    docker compose up --build -d
  fi

  sleep 10
done