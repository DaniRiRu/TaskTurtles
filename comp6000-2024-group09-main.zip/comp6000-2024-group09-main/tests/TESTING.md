# Testing Guidelines for TaskTurtles

This document provides guidelines and best practices for writing and maintaining tests for the TaskTurtles application.

## Table of Contents
- [Test Structure](#test-structure)
- [Test File Organization](#test-file-organization)
- [Setting Up Tests](#setting-up-tests)
- [Writing Effective Tests](#writing-effective-tests)
- [Testing UI Components](#testing-ui-components)
- [Test Selectors](#test-selectors)
- [Environment Variables](#environment-variables)
- [Working with Authentication](#working-with-authentication)
- [Best Practices](#best-practices)
- [Common Patterns](#common-patterns)

## Test Structure

Each test file should follow this structure:

```typescript
// Imports
import { describe, expect, it, beforeAll } from "vitest";
import { createPage, setup } from "../setup";
import type { NuxtPage } from "@nuxt/test-utils";

// Test suite description
describe("component or page name", async () => {
  // Global setup
  await setup();
  
  // Shared variables
  let page: NuxtPage;
  
  // Before hooks
  beforeAll(async () => {
    page = await createPage("/route");
  });
  
  // Individual tests
  it("describes expected behavior", async () => {
    // Arrange
    // Act
    // Assert
  });
});
```

## Test File Organization

Tests should be organized to mirror the application structure:

```
tests/
├── setup.ts             // Common setup logic
├── TESTING.md           // This documentation
├── home/                // Tests for the home page
│   └── page.test.ts     
├── login/               // Tests for the login functionality
│   └── page.test.ts
├── components/          // Tests for reusable components
│   └── component-name.test.ts
└── utils/               // Tests for utility functions
    └── util-name.test.ts
```

## Setting Up Tests

All tests should use the common setup mechanism:

```typescript
import { setup } from "../setup";

describe("test suite", async () => {
  await setup();
  
  // Tests...
});
```

For page tests, create a page instance in a `beforeAll` hook:

```typescript
let page: NuxtPage;

beforeAll(async () => {
  page = await createPage("/route");
});
```

## Writing Effective Tests

### Test Naming

Test names should clearly describe the expected behavior:

```typescript
it("displays error message when login fails", async () => {
  // Test code
});
```

### Arrange-Act-Assert Pattern

Structure test logic in this order:
1. **Arrange**: Set up the test conditions
2. **Act**: Perform the action being tested
3. **Assert**: Verify the expected outcome

```typescript
it("enables button when form is valid", async () => {
  // Arrange
  const emailInput = await page.locator("input[type='email']");
  const passwordInput = await page.locator("input[type='password']");
  
  // Act
  await emailInput.fill("test@example.com");
  await passwordInput.fill("password123");
  
  // Assert
  const submitButton = await page.locator("button[type='submit']");
  expect(await submitButton.isDisabled()).toBe(false);
});
```

## Testing UI Components

### Page Elements

Use locators to find elements on the page:

```typescript
const heading = await page.locator("h1").textContent();
expect(heading).toContain("Expected Text");
```

### Interactions

Simulate user interactions:

```typescript
// Click a button
await page.locator("button.login-btn").click();

// Fill a form
await page.locator("input[name='email']").fill("user@example.com");

// Navigate
await page.goto("/dashboard");
```

### Waiting for Changes

Wait for UI changes after interactions:

```typescript
// Wait for URL change
await page.waitForURL("/dashboard");

// Wait for element to appear
await page.waitForSelector(".success-message");

// Use explicit timeout for animations
await page.waitForTimeout(500);
```

## Test Selectors

### Selector Priority

Use selectors in this order of preference:
1. Dedicated test IDs (e.g., `data-testid="login-form"`)
2. Semantic HTML elements (e.g., `button[type="submit"]`)
3. CSS classes that are unlikely to change (e.g., `.btn-primary`)
4. Text content as a last resort (e.g., `:text("Sign in")`)

### Handling Complex Selectors

For complex UI elements, use multiple selector approaches:

```typescript
// For classes with special characters
await page.locator(".text-secondary\\:60, [class*='text-secondary']").textContent();

// For elements with specific text
await page.locator("h2:text('Frequently Asked Questions')").isVisible();
```

## Environment Variables

Use environment variables for sensitive data and configuration:

```typescript
// Access environmental variables
const email = process.env.TEST_EMAIL;
const password = process.env.TEST_PASSWORD;

// Skip tests conditionally
it.skipIf(!process.env.TEST_EMAIL)("logs in with valid credentials", async () => {
  // Test code
});
```

## Working with Authentication

### Testing Login

```typescript
it("can log in with valid credentials", async () => {
  if (!process.env.TEST_EMAIL || !process.env.TEST_PASSWORD) {
    console.warn("TEST_EMAIL or TEST_PASSWORD not set, skipping login test");
    return;
  }
  
  await page.locator("input[type='email']").fill(process.env.TEST_EMAIL);
  await page.locator("input[type='password']").fill(process.env.TEST_PASSWORD);
  await page.locator("button[type='submit']").click();
  
  await page.waitForURL("/dashboard");
  expect(page.url()).toContain("/dashboard");
});
```

### Testing Protected Routes

For testing routes that require authentication, make sure to log in first:

```typescript
beforeAll(async () => {
  // Log in before testing protected routes
  page = await createPage("/login");
  await loginWithTestCredentials(page);
  
  // Navigate to the protected route
  await page.goto("/dashboard");
});
```

## Best Practices

1. **Isolation**: Each test should be independent of others
2. **Specificity**: Test one thing per test case
3. **Reliability**: Avoid timing issues with proper waits
4. **Readability**: Use clear variable names and comments
5. **Maintainability**: Use helper functions for common actions

### Avoiding Flaky Tests

- Use proper waiting mechanisms instead of fixed timeouts when possible
- Add scroll commands before clicking elements: `await element.scrollIntoViewIfNeeded()`
- Check element visibility before interaction: `if (await element.isVisible())`
- Use adequate timeouts for network operations

## Common Patterns

### Testing Form Submission

```typescript
it("submits form with valid data", async () => {
  // Fill form fields
  await page.locator("#name").fill("John Doe");
  await page.locator("#email").fill("john@example.com");
  
  // Submit form
  await page.locator("form").evaluate(form => form.submit());
  
  // Check for success
  await page.waitForSelector(".success-message");
  expect(await page.locator(".success-message").isVisible()).toBe(true);
});
```

### Testing Navigation

```typescript
it("navigates to about page when clicking About link", async () => {
  await page.locator("nav a:text('About')").click();
  await page.waitForURL("/about");
  expect(page.url()).toContain("/about");
});
```

### Testing Error States

```typescript
it("displays validation errors for empty fields", async () => {
  await page.locator("button[type='submit']").click();
  
  const errorMessages = await page.locator(".error-message").allTextContents();
  expect(errorMessages).toContain("Email is required");
});
```
