import { createPage, setup as nuxtSetup } from "@nuxt/test-utils/e2e";

let alreadySetup = false;

const setup = () => {
	if (alreadySetup) {
		return;
	}

	alreadySetup = true;

	return nuxtSetup({
		build: false,
		buildDir: ".output",
		nuxtConfig: {
			nitro: {
				output: {
					dir: ".output",
				},
			},
		},
	});
};

export { createPage, setup };
