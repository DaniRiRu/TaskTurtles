import type { NuxtPage } from "@nuxt/test-utils";
import { beforeAll, describe, expect, it } from "vitest";
import { createPage, setup } from "../setup";

describe("pages/index.vue - Home page", async () => {
	await setup();

	let page: NuxtPage;

	beforeAll(async () => {
		page = await createPage("/");
	});

	it("loads the home page", async () => {
		expect(page).toBeDefined();
	});

	it("displays the logo and brand name", async () => {
		const brandName = await page
			.locator("nav .text-base-content.font-semibold")
			.textContent();
		expect(brandName).toContain("TaskTurtles");
	});

	it("shows main navigation links", async () => {
		const navLinks = await page.locator("nav a.text-sm").allTextContents();
		expect(navLinks).toContain("Features");
		expect(navLinks).toContain("How it Works");
		expect(navLinks).toContain("Pricing");
		expect(navLinks).toContain("FAQ");
	});

	it("has a call-to-action button", async () => {
		const ctaButton = await page.locator("nav a.btn.btn-primary").textContent();
		expect(ctaButton).toContain("Get Started");
	});

	it("displays the screenshot tabs navigation", async () => {
		const tabButtons = await page
			.locator("nav[role='tablist'] button")
			.allTextContents();
		expect(tabButtons).toContain("Dashboard");
		expect(tabButtons).toContain("Tasks");
		expect(tabButtons).toContain("Calendar");
	});

	it("changes the displayed screenshot when clicking tabs", async () => {
		const firstTabActive = await page
			.locator("nav[role='tablist'] button")
			.first()
			.getAttribute("class");
		expect(firstTabActive).toContain("!bg-primary");

		await page.locator("nav[role='tablist'] button").nth(1).click();

		await page.waitForTimeout(600);
		const secondTabActive = await page
			.locator("nav[role='tablist'] button")
			.nth(1)
			.getAttribute("class");
		expect(secondTabActive).toContain("!bg-primary");
	});

	it("shows 'How It Works' section with numbered steps", async () => {
		const howItWorksTitle = await page
			.locator("h2:text('How It Works')")
			.isVisible();
		expect(howItWorksTitle).toBe(true);

		const stepNumbers = await page
			.locator(
				".text-secondary\\:60.font-bold.text-5xl, div[class*='text-secondary'].font-bold.text-5xl",
			)
			.allTextContents();
		expect(stepNumbers).toContain("01");
		expect(stepNumbers).toContain("02");
		expect(stepNumbers).toContain("03");
	});

	it("displays pricing plans", async () => {
		const pricingTitle = await page.locator("h2:text('Pricing')").isVisible();
		expect(pricingTitle).toBe(true);

		const planTitles = await page.locator(".card-body h4").allTextContents();
		expect(planTitles).toContain("Starter Plan");
		expect(planTitles).toContain("Pro Plan");
		expect(planTitles).toContain("Team Plan");

		const planPrices = await page
			.locator(".card-body .text-4xl.font-black")
			.allTextContents();
		expect(planPrices).toContain("$0");
		expect(planPrices).toContain("$9.99");
		expect(planPrices).toContain("$29.99");
	});

	it("shows FAQ section with expandable items", async () => {
		const faqTitle = await page
			.locator("h2:text('Frequently Asked Questions')")
			.isVisible();
		expect(faqTitle).toBe(true);

		const faqItems = await page
			.locator(
				".collapse-arrow.bg-secondary\\:5, .collapse-arrow[class*='bg-secondary']",
			)
			.count();
		expect(faqItems).toBeGreaterThan(0);

		const firstFaqItem = await page.locator(".collapse-arrow").first();

		await firstFaqItem.scrollIntoViewIfNeeded();
		await page.waitForTimeout(500);

		const collapseInput = await firstFaqItem.locator("input[type='radio']");
		await collapseInput.click();

		await page.waitForTimeout(1000);
		const contentVisible = await firstFaqItem
			.locator(".collapse-content")
			.isVisible();
		expect(contentVisible).toBe(true);
	});

	it("includes footer with company information", async () => {
		const footer = await page.locator("footer").isVisible();
		expect(footer).toBe(true);

		const footerSections = await page
			.locator("footer .footer-title")
			.allTextContents();
		expect(footerSections).toContain("Services");
		expect(footerSections).toContain("Company");
		expect(footerSections).toContain("Legal");
	});
});
