import type { NuxtPage } from "@nuxt/test-utils";
import { beforeAll, describe, expect, it } from "vitest";
import { createPage, setup } from "../setup";

describe("pages/login/index.vue - Login page", async () => {
	await setup();

	let page: NuxtPage;

	beforeAll(async () => {
		page = await createPage("/login");
	});

	it("loads the login page", async () => {
		expect(page).toBeDefined();
		const pageTitle = await page.locator("h2.text-3xl").textContent();
		expect(pageTitle).toContain("Welcome Back");
	});

	it("displays the brand name", async () => {
		const brandName = await page
			.locator(".text-2xl.font-bold.tracking-tight")
			.first()
			.textContent();
		expect(brandName).toContain("TaskTurtles");
	});

	it("has a login form with email and password fields", async () => {
		const emailInput = await page.locator("input[type='email']");
		const passwordInput = await page.locator("input[type='password']");

		expect(await emailInput.getAttribute("placeholder")).toBe("Email");
		expect(await passwordInput.getAttribute("placeholder")).toBe("Password");
	});

	it("has social login options", async () => {
		const socialButtons = (
			await page.locator(".grid-cols-3 .btn").allTextContents()
		).map((x) => x.trim());
		expect(socialButtons).toContain("Google");
		expect(socialButtons).toContain("GitHub");
		expect(socialButtons).toContain("Apple");
	});

	it("has a sign up link", async () => {
		const signUpLink = await page.locator("a[href='/signup']");
		expect(await signUpLink.isVisible()).toBe(true);
		expect(await signUpLink.textContent()).toContain("Don't have an account?");
		expect(await signUpLink.textContent()).toContain("Sign up");
	});

	it("enables login button when email and password are entered", async () => {
		// Initially button should be disabled
		const loginButton = await page.locator("button[type='submit']");
		expect(await loginButton.isDisabled()).toBe(true);

		// Enter email and password
		await page.locator("input[type='email']").fill("test@example.com");
		await page.locator("input[type='password']").fill("password");

		// Button should now be enabled
		await page.waitForTimeout(100); // Allow time for validation
		expect(await loginButton.isDisabled()).toBe(false);
	});

	it("shows terms and privacy info", async () => {
		const termsText = await page
			.locator(".text-xs.text-base-content\\/60")
			.first()
			.textContent();
		expect(termsText).toContain("terms and privacy policy");
	});

	it("can log in with valid credentials", async () => {
		if (!process.env.TEST_EMAIL || !process.env.TEST_PASSWORD) {
			throw new Error(
				"TEST_EMAIL and TEST_PASSWORD must be set in the environment variables",
			);
		}

		// Fill in credentials
		await page
			.locator("input[type='email']")
			.fill(process.env.TEST_EMAIL || "");
		await page
			.locator("input[type='password']")
			.fill(process.env.TEST_PASSWORD || "");

		// Click login button
		await page.locator("button[type='submit']").click();

		await page.waitForTimeout(3000); // Allow time for any additional loading
		// Verify we're on the dashboard page
		expect(page.url()).toContain("/dashboard");
	});
});
