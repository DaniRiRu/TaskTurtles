import { defineVitestConfig } from "@nuxt/test-utils/config";
import { config } from "dotenv";

export default defineVitestConfig({
	// any custom Vitest config you require
	test: {
		environment: "nuxt",
		setupFiles: ["dotenv/config"],
		testTimeout: 10000,
		env: {
			...config().parsed,
		},
	},
});
