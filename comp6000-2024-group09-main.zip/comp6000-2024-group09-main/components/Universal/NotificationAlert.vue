<script setup lang="ts">
const { notification } = useNotification();

const alertClass = computed(() => ({
	"alert-error": notification.value.type === "error",
	"alert-success": notification.value.type === "success",
	"alert-warning": notification.value.type === "warning",
	"alert-info": notification.value.type === "info",
}));
</script>

<template>
  <div
    class="fixed top-4 right-4 z-50 transition-all duration-300 transform"
    :class="{
      'translate-x-0 opacity-100': notification.visible,
      'translate-x-full opacity-0': !notification.visible,
    }"
  >
    <div
      role="alert"
      class="alert shadow-lg w-96"
      :class="alertClass"
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        class="h-6 w-6 shrink-0"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
      >
        <path
          stroke-linecap="round"
          stroke-linejoin="round"
          stroke-width="2"
          d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
        />
      </svg>
      <span>{{ notification.message }}</span>
    </div>
  </div>
</template>