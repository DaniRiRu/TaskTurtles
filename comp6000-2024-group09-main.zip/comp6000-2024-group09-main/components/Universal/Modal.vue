<script lang="ts" setup>
import { breakpointsTailwind, useBreakpoints } from "@vueuse/core";
import { ModalPosition } from "~/enums/frontend/modal/ModalPosition";

const props = defineProps<{
	isOpen: boolean;
	position: ModalPosition;
}>();

const emit = defineEmits(["close"]);

const breakpoints = useBreakpoints(breakpointsTailwind);
const position = computed(() => {
	return breakpoints.smallerOrEqual("md").value
		? ModalPosition.Bottom
		: props.position;
});

const transitions = {
	fadeScale: {
		enterActive: "transition-all duration-300 ease-in-out",
		leaveActive: "transition-all duration-300 ease-in-out",
		enterFrom: "opacity-0 scale-95",
		enterTo: "opacity-100 scale-100",
		leaveFrom: "opacity-100 scale-100",
		leaveTo: "opacity-0 scale-95",
	},
	slideBottom: {
		enterActive: "transition-all duration-300 ease-in-out",
		leaveActive: "transition-all duration-300 ease-in-out",
		enterFrom: "translate-y-full opacity-0 scale-105",
		enterTo: "translate-y-0 opacity-100",
		leaveFrom: "translate-y-0 opacity-100",
		leaveTo: "translate-y-full opacity-0 scale-105",
	},
};

function closeModal() {
	emit("close");
}

useEscapeKey(closeModal);
</script>

<template>
    <Teleport to="body">
        <div class="fixed inset-0 z-50 bg-black/40 backdrop-blur transition-all duration-300 ease-in-out"
            :class="{ 'opacity-100 pointer-events-auto': isOpen, 'opacity-0 pointer-events-none': !isOpen }"
            @click="closeModal">
            <transition v-if="position === ModalPosition.Middle" :enter-active-class="transitions.fadeScale.enterActive"
                :leave-active-class="transitions.fadeScale.leaveActive"
                :enter-from-class="transitions.fadeScale.enterFrom" :enter-to-class="transitions.fadeScale.enterTo"
                :leave-from-class="transitions.fadeScale.leaveFrom" :leave-to-class="transitions.fadeScale.leaveTo">
                <div v-show="isOpen" class="flex items-center justify-center h-full">
                    <div class="relative w-full max-w-lg p-6 bg-base-100/90 rounded-box shadow-2xl" @click.stop>
                        <button @click="closeModal"
                            class="absolute top-4 right-4 btn btn-md outline-none border-none btn-circle min-h-10 h-10 min-w-10 w-10 p-0 btn-ghost">
                            <MaterialSymbolsClose class="w-6 h-6" />
                        </button>
                        <slot name="title" />
                        <slot />
                    </div>
                </div>
            </transition>

            <transition v-if="position === ModalPosition.Bottom"
                :enter-active-class="transitions.slideBottom.enterActive"
                :leave-active-class="transitions.slideBottom.leaveActive"
                :enter-from-class="transitions.slideBottom.enterFrom" :enter-to-class="transitions.slideBottom.enterTo"
                :leave-from-class="transitions.slideBottom.leaveFrom" :leave-to-class="transitions.slideBottom.leaveTo">
                <div v-show="isOpen"
                    class="fixed bottom-0 inset-x-0 bg-base-100/90 backdrop-blur-2xl rounded-t-box shadow-2xl max-w-xl mx-auto"
                    @click.stop>
                    <div class="relative w-full p-6">
                        <button @click="closeModal"
                            class="absolute top-4 right-4 btn btn-md outline-none border-none btn-circle min-h-10 h-10 min-w-10 w-10 p-0 btn-ghost">
                            <MaterialSymbolsClose class="w-6 h-6" />
                        </button>
                        <slot name="title" />
                        <slot />
                    </div>
                </div>
            </transition>
        </div>
    </Teleport>
</template>