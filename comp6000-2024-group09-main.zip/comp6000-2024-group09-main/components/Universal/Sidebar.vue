<script lang="ts" setup>
defineProps<{
	isOpen: boolean;
}>();

const emit = defineEmits(["close"]);

function closeSidebar() {
	emit("close");
}

useEscapeKey(closeSidebar);
</script>

<template>
  <Teleport to="body">
    <div class="fixed inset-0 transition-all duration-300 ease-in-out bg-black z-40" :class="{
    'bg-opacity-40 pointer-events-auto': isOpen,
    'pointer-events-none bg-opacity-0': !isOpen
  }" @click="closeSidebar" />

  <div
    class="fixed top-0 right-0 h-full z-50 flex items-start justify-end p-4 transition-all duration-300 ease-in-out transform"
    :class="{
      'pointer-events-none translate-x-full': !isOpen,
      'translate-x-0': isOpen
    }">
    <div
      class="w-[calc(100vw-2rem)] md:w-xl flex flex-col h-full bg-base-100/90 backdrop-blur-3xl shadow-xl overflow-auto rounded-box z-20">
      <div class="flex flex-row justify-between mb-2 items-center px-4 pt-6">
        <button @click="closeSidebar"
          class="btn btn-ghost btn-square border-none min-w-auto min-h-auto max-h-6 max-w-6 -mr-1">
          <MaterialSymbolsCloseRounded class="h-5 w-5" />
        </button>

        <slot name="header">
        </slot>
      </div>

      <div class="divider my-2 mx-4 h-1"></div>

      <div class="flex-grow overflow-auto pb-6">
        <slot />
      </div>
    </div>
  </div>
  </Teleport>
</template>