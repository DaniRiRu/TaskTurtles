<script lang="ts" setup>
import IcOutlineSearch from "~icons/ic/outline-search";

defineProps<{
	show: boolean;
	iconCategories: Record<string, string[]>;
}>();

defineEmits<{
	(e: "close"): void;
	(e: "select", icon: string): void;
}>();

const emojiList = ref<Record<string, string[]>>({});
const searchQuery = ref("");
const activeTab = ref("");

const loadEmojis = async () => {
	try {
		// Common emoji categories
		const categories = {
			smileys: [0x1f600, 0x1f64f],
			people: [0x1f466, 0x1f4ff],
			animals: [0x1f400, 0x1f43f],
			food: [0x1f32d, 0x1f37f],
			activities: [0x1f380, 0x1f3ff],
			travel: [0x1f3d4, 0x1f3e0],
			objects: [0x1f452, 0x1f6d2],
			symbols: [0x2700, 0x27bf],
			flags: [0x1f1e6, 0x1f1ff],
		};

		const result: Record<string, string[]> = {};

		for (const [category, [start, end]] of Object.entries(categories)) {
			const emojis: string[] = [];
			for (let i = start; i <= end; i++) {
				try {
					const emoji = String.fromCodePoint(i);
					// Filter out invisible or non-emoji characters
					if (emoji?.trim() && emoji !== "�") {
						emojis.push(emoji);
					}
				} catch (e) {
					// Skip invalid code points
				}
			}

			// Only add categories that have actual emojis
			if (emojis.length > 0) {
				result[category] = emojis;
			}
		}

		emojiList.value = result;
		if (Object.keys(result).length > 0) {
			activeTab.value = Object.keys(result)[0];
		}
	} catch (error) {
		console.error("Error loading emojis:", error);

		// Fallback to basic emojis if loading fails
		emojiList.value = {
			basic: [
				"📋",
				"✓",
				"📌",
				"⭐",
				"🔔",
				"📊",
				"📈",
				"📝",
				"⏰",
				"📅",
				"💼",
				"💻",
				"📱",
				"📁",
				"✉️",
				"📑",
				"🗃️",
				"📎",
				"🔍",
				"🔖",
				"💧",
				"🍎",
				"🥗",
				"🏃",
				"💊",
				"😴",
				"🧘",
				"🌱",
				"❤️",
				"🥦",
			],
		};
		activeTab.value = "basic";
	}
};

const filteredEmojis = computed(() => {
	if (!searchQuery.value.trim()) {
		return emojiList.value;
	}

	const query = searchQuery.value.toLowerCase();
	const result: Record<string, string[]> = {};

	for (const [category, emojis] of Object.entries(emojiList.value)) {
		const filtered = emojis.filter((emoji) => {
			return (
				emoji.toLowerCase().includes(query) ||
				category.toLowerCase().includes(query) ||
				getEmojiDescription(emoji).toLowerCase().includes(query)
			);
		});

		if (filtered.length > 0) {
			result[category] = filtered;
		}
	}

	return result;
});

const getEmojiDescription = (emoji: string) => {
	const descriptions: Record<string, string> = {
		"📋": "clipboard list check task",
		"✓": "check mark tick complete done",
		"📌": "pin pushpin attach",
		"⭐": "star favorite important",
		"🔔": "bell notification alert",
		"📊": "chart bar graph statistics data",
		"📈": "chart increasing graph growth",
		"📝": "memo note write",
		"⏰": "alarm clock time",
		"📅": "calendar date schedule",
		"💼": "briefcase work job business",
		"💻": "laptop computer work",
		"📱": "mobile phone smartphone",
		"📁": "folder file document",
		"✉️": "envelope mail email message",
		"📑": "bookmark tabs organize",
		"🗃️": "card file box archive storage",
		"📎": "paperclip attachment",
		"🔍": "magnifying glass search find",
		"🔖": "bookmark save",
		"💧": "droplet water hydrate",
		"🍎": "apple fruit health",
		"🥗": "green salad healthy food",
		"🏃": "runner running exercise fitness",
		"💊": "pill medication medicine health",
		"😴": "sleeping face sleep rest",
		"🧘": "person in lotus position meditation yoga",
		"🌱": "seedling plant growth",
		"❤️": "red heart love favorite",
		"🥦": "broccoli vegetable health",
	};

	return descriptions[emoji] || "";
};

const categoryIcons = {
	smileys: "😀",
	people: "👪",
	animals: "🐱",
	food: "🍕",
	activities: "⚽",
	travel: "✈️",
	objects: "💡",
	symbols: "⚠️",
	flags: "🏁",
	basic: "📌",
};

const categoryNames = {
	smileys: "Smileys & Emotions",
	people: "People & Body",
	animals: "Animals & Nature",
	food: "Food & Drink",
	activities: "Activities",
	travel: "Travel & Places",
	objects: "Objects",
	symbols: "Symbols",
	flags: "Flags",
	basic: "Basic",
};

const selectTab = (category: string) => {
	activeTab.value = category;
	searchQuery.value = "";
};

onMounted(() => {
	loadEmojis();
});
</script>

<template>
  <dialog :class="{ 'modal-open': show }" class="modal">
    <div class="modal-box max-w-4xl p-0 bg-base-100 shadow-lg rounded-xl overflow-hidden">
      <div class="flex justify-between items-center px-6 py-4 border-b border-base-200">
        <div class="w-full flex items-center pr-2">
          <div class="relative flex-1">
            <input 
              v-model="searchQuery"
              type="text" 
              placeholder="Search icons..." 
              class="input input-bordered w-full pl-10 pr-4 py-2 focus:outline-primary bg-base-200 border-0 focus:ring-2 ring-offset-2 ring-primary/20"
            />
            <span class="absolute left-3 top-1/2 -translate-y-1/2 text-base-content text-opacity-60">
              <IcOutlineSearch class="w-5 h-5" />
            </span>
          </div>
        </div>
        <button class="btn btn-sm btn-circle btn-ghost text-lg ml-2" @click="$emit('close')">✕</button>
      </div>
      
      <div class="flex h-[70vh]">
        <div class="w-20 md:w-48 border-r border-base-200 overflow-y-auto flex-shrink-0">
          <div class="py-2">
            <button 
              v-for="(icons, category) in emojiList" 
              :key="category"
              :data-category="category"
              :class="[
                'w-full flex items-center gap-2 px-3 py-3 transition-all duration-200 border-l-4 bg-base-100 ',
                activeTab === category 
                  ? 'border-primary font-medium' 
                  : 'hover:bg-base-200 border-transparent'
              ]"
              @click="selectTab(category)"
            >
              <span class="text-xl flex-shrink-0">{{ categoryIcons[category as keyof typeof categoryIcons] || '📌' }}</span>
              <span class="text-sm capitalize hidden md:inline">{{ categoryNames[category as keyof typeof categoryNames] || category }}</span>
            </button>
          </div>
        </div>
        <div class="flex-1 flex flex-col">          
          <div class="flex-1 overflow-y-auto p-4">
            <div v-if="searchQuery" class="space-y-6">
              <div v-for="(icons, category) in filteredEmojis" :key="category" class="space-y-3">
                <h4 class="text-sm font-semibold opacity-80 capitalize flex items-center gap-1.5 px-2">
                  <span>{{ categoryIcons[category as keyof typeof categoryIcons] || '📌' }}</span>
                  {{ categoryNames[category as keyof typeof categoryNames] || category }}
                  <span class="text-xs opacity-70 ml-1">({{ icons.length }})</span>
                </h4>
                <div class="grid grid-cols-6 sm:grid-cols-8 lg:grid-cols-10 gap-2">
                  <button
                    v-for="icon in icons"
                    :key="icon"
                    class="aspect-square flex items-center justify-center text-xl rounded-xl hover:bg-primary/10 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary/40 active:scale-95 bg-base-200/50 shadow-sm border border-base-300"
                    @click="$emit('select', icon)"
                  >
                    {{ icon }}
                  </button>
                </div>
              </div>
              
              <div v-if="Object.keys(filteredEmojis).length === 0" class="py-10 text-center text-base-content text-opacity-60">
                <div class="text-4xl mb-3">🔍</div>
                <p class="text-sm font-medium">No matching icons found</p>
                <p class="text-xs mt-1 text-base-content/50">Try another search term</p>
              </div>
            </div>
            
            <div v-else-if="activeTab && emojiList[activeTab]" class="pt-2">
              <div class="grid grid-cols-6 sm:grid-cols-8 lg:grid-cols-10 gap-2">
                <button
                  v-for="icon in emojiList[activeTab]"
                  :key="icon"
                  class="aspect-square flex items-center justify-center text-xl rounded-xl hover:bg-primary/10 hover:border-primary/30 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary/40 active:scale-95 bg-base-200/50 shadow-sm border border-base-300"
                  @click="$emit('select', icon)"
                >
                  {{ icon }}
                </button>
              </div>
            </div>
            
            <div v-else class="py-10 text-center text-base-content text-opacity-60">
              <div class="text-4xl mb-3">🤔</div>
              <p class="text-sm font-medium">No icons available</p>
              <p class="text-xs mt-1 text-base-content/50">Try refreshing the page</p>
            </div>
          </div>
          
          <div class="p-4 border-t border-base-200 flex justify-end">
            <button 
              class="btn btn-outline border-base-300 hover:bg-base-200 hover:border-base-300 text-base-content"
              @click="$emit('close')"
            >
              Cancel
            </button>
          </div>
        </div>
      </div>
    </div>
    <div class="modal-backdrop bg-base-300 bg-opacity-80 backdrop-blur-sm" @click="$emit('close')"></div>
  </dialog>
</template>