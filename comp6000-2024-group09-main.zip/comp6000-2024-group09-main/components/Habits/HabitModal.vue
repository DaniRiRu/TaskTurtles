<script lang="ts" setup>
import { useHabits } from "~/composables/habits/useHabits";
import { ModalPosition } from "~/enums/frontend/modal/ModalPosition";
import type { FrequencyPeriod, HabitData } from "~/types/habits/habits";
import HabitModalBasicInfo from "./HabitModalBasicInfo.vue";
import HabitModalFrequency from "./HabitModalFrequency.vue";
import HabitModalIconPicker from "./HabitModalIconPicker.vue";
import HabitModalTabs from "./HabitModalTabs.vue";
import HabitModalTags from "./HabitModalTags.vue";

defineProps<{
	showModal: boolean;
	newHabitName: string;
}>();

const showModal = defineModel<boolean>("showModal", { default: false });
const newHabitName = defineModel<string>("newHabitName");
const showIconPicker = ref(false);
const createdHabitId = ref<string | null>(null);
const isCreatingHabit = ref(false);

const habit = ref<Partial<HabitData>>({
	name: "",
	description: "",
	icon: "📋",
	frequency: {
		type: "recurring",
		recurring: {
			every: 1,
			period: "day",
		},
	},
	difficulty: 1,
	tags: [],
	isArchived: false,
	totalCompletions: 0,
	completionHistory: [],
	color: "#3B82F6",
});

const iconCategories = {
	general: ["📋", "✓", "📌", "⭐", "🔔", "📊", "📈", "📝", "⏰", "📅"],
	productivity: ["💼", "💻", "📱", "📁", "✉️", "📑", "🗃️", "📎", "🔍", "🔖"],
	health: ["💧", "🍎", "🥗", "🏃", "💊", "😴", "🧘", "🌱", "❤️", "🥦"],
	finance: ["💰", "💳", "💵", "📊", "💹", "🏦", "💲", "💸", "📉", "📈"],
	learning: ["📚", "🎓", "✏️", "🔬", "🧮", "🧠", "📔", "🔤", "🌎", "🧩"],
};

const frequencyType = ref<"recurring" | "flexible">("recurring");
const selectedPeriod = ref<FrequencyPeriod>("day");
const frequencyCount = ref(1);
const flexibleTimes = ref(1);
const flexibleWithin = ref(1);
const specificDays = ref<number[]>([]);
const specificMonths = ref<number[]>([]);
const selectedTab = ref("basic");

const daysOfWeek = [
	"Sunday",
	"Monday",
	"Tuesday",
	"Wednesday",
	"Thursday",
	"Friday",
	"Saturday",
];

const difficultyLevels = [
	{ value: 1, label: "Very Easy", icon: "●", color: "bg-green-500" },
	{ value: 2, label: "Easy", icon: "●", color: "bg-emerald-400" },
	{ value: 3, label: "Medium", icon: "●", color: "bg-yellow-400" },
	{ value: 4, label: "Hard", icon: "●", color: "bg-orange-500" },
	{ value: 5, label: "Very Hard", icon: "●", color: "bg-red-500" },
];

const newTag = ref("");

const addTag = () => {
	if (newTag.value.trim() && !habit.value.tags?.includes(newTag.value)) {
		habit.value.tags = [...(habit.value.tags || []), newTag.value.trim()];
		newTag.value = "";
	}
};

const removeTag = (tag: string) => {
	habit.value.tags = (habit.value.tags ?? []).filter(
		(t: string): boolean => t !== tag,
	);
};

const resetForm = () => {
	habit.value = {
		name: "",
		description: "",
		icon: "📋",
		frequency: {
			type: "recurring",
			recurring: {
				every: 1,
				period: "day",
			},
		},
		difficulty: 1,
		tags: [],
		isArchived: false,
		totalCompletions: 0,
		completionHistory: [],
		color: "#3B82F6",
	};
	frequencyType.value = "recurring";
	selectedPeriod.value = "day";
	frequencyCount.value = 1;
	flexibleTimes.value = 1;
	flexibleWithin.value = 1;
	specificDays.value = [];
	specificMonths.value = [];
	selectedTab.value = "basic";
	newTag.value = "";
	createdHabitId.value = null;
};

const selectIcon = (icon: string) => {
	habit.value.icon = icon;
	showIconPicker.value = false;
};

const handleCreate = async () => {
	const { createHabit } = useHabits();

	if (!habit.value.name?.trim()) return;

	const frequency =
		frequencyType.value === "recurring"
			? {
					type: "recurring" as const,
					recurring: {
						every: frequencyCount.value,
						period: selectedPeriod.value,
						specificDays:
							specificDays.value.length > 0 ? specificDays.value : undefined,
						specificMonths:
							specificMonths.value.length > 0
								? specificMonths.value
								: undefined,
					},
				}
			: {
					type: "flexible" as const,
					flexible: {
						times: flexibleTimes.value,
						withinPeriod: flexibleWithin.value,
						periodUnit: selectedPeriod.value,
					},
				};

	isCreatingHabit.value = true;

	try {
		const newHabit = await createHabit({
			...habit.value,
			frequency,
		} as HabitData);

		if (newHabit) {
			createdHabitId.value = newHabit.id;
		}
		showModal.value = false;
		resetForm();
	} catch (error) {
		console.error("Error creating habit:", error);
	} finally {
		isCreatingHabit.value = false;
	}
};

watch(newHabitName, (newName) => {
	if (newName) {
		habit.value.name = newName;
	}
});

watch(showModal, (isOpen) => {
	if (!isOpen) {
		setTimeout(() => {
			resetForm();
		}, 300);
	}
});
</script>

<template>
  <Universal-Modal :is-open="showModal" :position="ModalPosition.Middle" @close="showModal = false">
    <template #title>
      <h3 class="text-lg font-semibold mb-4">New Habit</h3>
    </template>
    
    <div class="flex flex-col">
      <div class="flex items-center gap-3 mb-4">
        <div 
          class="w-10 h-10 rounded-md flex items-center justify-center bg-base-200 cursor-pointer hover:bg-base-300 transition-colors"
          @click="showIconPicker = true"
        >
          <span class="text-lg">{{ habit.icon }}</span>
        </div>
        <div class="flex-1">
          <input
            v-model="habit.name"
            type="text"
            placeholder="Enter habit name"
            class="input input-bordered w-full h-10 text-sm"
          />
        </div>
      </div>

      <div class="border-b border-base-200 mb-4">
        <HabitModalTabs 
          v-model:selected-tab="selectedTab"
          class="flex gap-2 overflow-x-auto scrollbar-none py-1"
        />
      </div>

      <div class="relative h-[340px]">
        <div class="absolute inset-0 pr-3 overflow-y-auto custom-scrollbar">
          <div class="pb-4 pr-1">
            <HabitModalBasicInfo 
              v-if="selectedTab === 'basic'"
              v-model:habit="habit"
              :difficulty-levels="difficultyLevels"
            />

            <HabitModalFrequency 
              v-if="selectedTab === 'frequency'"
              v-model:frequency-type="frequencyType"
              v-model:selected-period="selectedPeriod"
              v-model:frequency-count="frequencyCount"
              v-model:flexible-times="flexibleTimes"
              v-model:flexible-within="flexibleWithin"
              v-model:specific-days="specificDays"
              :days-of-week="daysOfWeek"
            />

            <HabitModalTags 
              v-if="selectedTab === 'tags'"
              v-model:tags="habit.tags"
              v-model:new-tag="newTag"
              @add="addTag"
              @remove="removeTag"
            />
          </div>
        </div>
      </div>

      <div class="flex justify-end gap-2 pt-4 mt-2 border-t border-base-200">
        <button 
          class="btn btn-sm btn-ghost" 
          @click="showModal = false"
        >
          Cancel
        </button>
        <button 
          class="btn btn-sm btn-primary" 
          @click="handleCreate"
          :class="{ 'loading btn-disabled': isCreatingHabit }"
          :disabled="!habit.name?.trim() || isCreatingHabit"
        >
          <span v-if="!isCreatingHabit">Create Habit</span>
          <span v-else>Creating...</span>	
        </button>
      </div>

      <HabitModalIconPicker
        :show="showIconPicker"
        :icon-categories="iconCategories"
        @close="showIconPicker = false"
        @select="selectIcon"
      />
    </div>
  </Universal-Modal>
</template>