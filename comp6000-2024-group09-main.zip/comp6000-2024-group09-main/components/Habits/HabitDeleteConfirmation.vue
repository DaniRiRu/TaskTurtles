<script lang="ts" setup>
import { ModalPosition } from "~/enums/frontend/modal/ModalPosition";

const props = defineProps<{
	isOpen: boolean;
	name: string;
}>();

const emit = defineEmits(["confirm", "close"]);

const handleConfirm = () => {
	emit("confirm");
	emit("close");
};

const handleClose = () => {
	emit("close");
};
</script>

<template>
  <UniversalModal :is-open="isOpen" :position="ModalPosition.Middle" @close="handleClose">
    <template #title>
      <h3 class="text-lg font-bold mb-4">Delete Confirmation</h3>
    </template>

    <div class="flex flex-col gap-6">
      <div class="flex flex-col gap-2">
        <p class="text-base-content/70">
          Are you sure you want to delete <span class="font-semibold text-base-content">{{ name }}</span>?
        </p>
        <p class="text-sm text-base-content/60">
          This action cannot be undone.
        </p>
      </div>

      <div class="flex justify-end gap-3">
        <button class="btn" @click="handleClose">
          Cancel
        </button>
        <button class="btn btn-error" @click="handleConfirm">
          Delete
        </button>
      </div>
    </div>
  </UniversalModal>
</template>