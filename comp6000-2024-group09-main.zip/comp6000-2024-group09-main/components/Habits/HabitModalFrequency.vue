<script lang="ts" setup>
import type { FrequencyPeriod } from "~/types/habits/habits";

defineProps<{
	frequencyType: "recurring" | "flexible";
	selectedPeriod: FrequencyPeriod;
	frequencyCount: number;
	flexibleTimes: number;
	flexibleWithin: number;
	specificDays: number[];
	daysOfWeek: string[];
}>();

const frequencyType = defineModel<"recurring" | "flexible">("frequencyType");
const selectedPeriod = defineModel<FrequencyPeriod>("selectedPeriod");
const frequencyCount = defineModel<number>("frequencyCount");
const flexibleTimes = defineModel<number>("flexibleTimes");
const flexibleWithin = defineModel<number>("flexibleWithin");
const specificDays = defineModel<number[]>("specificDays", {
	default: () => [],
});
</script>

<template>
  <div class="space-y-6">
    <div class="bg-gradient-to-r from-base-200/50 to-base-200/30 backdrop-blur-sm rounded-2xl overflow-hidden shadow-md border border-base-300/50">
      <div class="flex w-full">
        <button 
          class="flex-1 transition-all duration-300 py-4 px-5 relative bg-base-100"
          :class="{ 'text-primary font-semibold': frequencyType === 'recurring', 'text-base-content/80': frequencyType !== 'recurring' }"
          @click="frequencyType = 'recurring'"
        >
          <div class="flex items-center justify-center gap-2">
            <span class="i-heroicons-arrow-path-rounded-square h-5 w-5" :class="{ 'text-primary': frequencyType === 'recurring' }"></span>
            <span>Recurring Schedule</span>
          </div>
          <div 
            class="absolute bottom-0 left-0 right-0 h-1 transition-all duration-300 rounded-t-full"
            :class="frequencyType === 'recurring' ? 'bg-primary' : 'bg-transparent'"
          ></div>
        </button>
        <button 
          class="flex-1 transition-all duration-300 py-4 px-5 relative bg-base-100"
          :class="{ 'text-primary font-semibold': frequencyType === 'flexible', 'text-base-content/80': frequencyType !== 'flexible' }"
          @click="frequencyType = 'flexible'"
        >
          <div class="flex items-center justify-center gap-2">
            <span class="i-heroicons-calendar-days h-5 w-5" :class="{ 'text-primary': frequencyType === 'flexible' }"></span>
            <span>Flexible Schedule</span>
          </div>
          <div 
            class="absolute bottom-0 left-0 right-0 h-1 transition-all duration-300 rounded-t-full"
            :class="frequencyType === 'flexible' ? 'bg-primary' : 'bg-transparent'"
          ></div>
        </button>
      </div>
    </div>

    <div 
      class="bg-base-100 rounded-2xl shadow-md border border-base-200 p-6 transition-all duration-300"
      :class="{ 'ring-2 ring-primary/10': frequencyType === 'recurring' }"
    >
      <template v-if="frequencyType === 'recurring'">
        <div class="mb-6 flex items-start">
          <div class="p-2 rounded-full bg-primary/10 mr-3">
            <span class="i-heroicons-arrow-path-rounded-square h-5 w-5 text-primary"></span>
          </div>
          <div>
            <h3 class="text-lg font-semibold mb-1 text-base-content">Recurring Schedule</h3>
            <p class="text-sm text-base-content/70">Set a regular pattern for your habit</p>
          </div>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div class="form-control w-full">
            <label class="label pb-1 pt-0">
              <span class="label-text font-medium text-sm text-base-content/80">Repeat every</span>
            </label>
            <input
              v-model.number="frequencyCount"
              type="number"
              min="1"
              class="input input-bordered w-full h-12 focus:outline-none focus:ring-2 focus:ring-primary/30 bg-base-100 text-base"
              placeholder="1"
            />
          </div>
          <div class="form-control w-full">
            <label class="label pb-1 pt-0">
              <span class="label-text font-medium text-sm text-base-content/80">Time period</span>
            </label>
            <select 
              v-model="selectedPeriod" 
              class="select select-bordered w-full h-12 focus:outline-none focus:ring-2 focus:ring-primary/30 bg-base-100 text-base"
            >
              <option value="day">Day(s)</option>
              <option value="week">Week(s)</option>
              <option value="month">Month(s)</option>
              <option value="year">Year(s)</option>
            </select>
          </div>
        </div>

        <div v-if="selectedPeriod === 'week'" class="mt-6">
          <label class="text-sm font-medium text-base-content/80 flex items-center gap-2 mb-3">
            <span class="i-heroicons-calendar h-4 w-4"></span>
            Select active days
          </label>
          <div class="flex flex-wrap gap-2">
            <button
              v-for="(day, index) in daysOfWeek"
              :key="index"
              class="btn h-10 min-h-0 transition-all duration-200"
              :class="{ 
                'bg-primary/90 hover:bg-primary text-primary-content border-primary shadow-sm': specificDays.includes(index),
                'bg-base-200/50 border-base-300 hover:border-primary/50 hover:bg-primary/5 text-base-content': !specificDays.includes(index)
              }"
              @click="
                specificDays.includes(index)
                  ? specificDays.splice(specificDays.indexOf(index), 1)
                  : specificDays.push(index)
              "
            >
              {{ day.slice(0, 3) }}
            </button>
          </div>
        </div>
      </template>

      <template v-else>
        <div class="mb-6 flex items-start">
          <div class="p-2 rounded-full bg-primary/10 mr-3">
            <span class="i-heroicons-calendar-days h-5 w-5 text-primary"></span>
          </div>
          <div>
            <h3 class="text-lg font-semibold mb-1 text-base-content">Flexible Schedule</h3>
            <p class="text-sm text-base-content/70">Complete a number of times within a time period</p>
          </div>
        </div>
        
        <div class="rounded-xl p-4 mb-5 bg-gradient-to-r from-primary/5 to-primary/10 border border-primary/20">
          <div class="flex items-center gap-3">
            <span class="i-heroicons-light-bulb h-6 w-6 text-primary/80"></span>
            <p class="text-sm text-base-content flex items-center flex-wrap gap-x-1">
              Complete your habit
              <span class="px-2 py-0.5 bg-primary/20 rounded-md font-semibold text-primary">{{ flexibleTimes }} times</span>
              within
              <span class="px-2 py-0.5 bg-primary/20 rounded-md font-semibold text-primary">{{ flexibleWithin }} {{ selectedPeriod }}(s)</span>
            </p>
          </div>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div class="form-control w-full">
            <label class="label pb-1 pt-0">
              <span class="label-text font-medium text-sm text-base-content/80">Times to complete</span>
            </label>
            <input
              v-model.number="flexibleTimes"
              type="number"
              min="1"
              class="input input-bordered w-full h-12 focus:outline-none focus:ring-2 focus:ring-primary/30 bg-base-100 text-base"
              placeholder="3"
            />
          </div>
          <div class="form-control w-full">
            <label class="label pb-1 pt-0">
              <span class="label-text font-medium text-sm text-base-content/80">Time period</span>
            </label>
            <div class="flex space-x-3 items-center">
              <div class="relative">
                <input
                  v-model.number="flexibleWithin"
                  type="number"
                  min="1"
                  class="input input-bordered w-24 h-12 focus:outline-none focus:ring-2 focus:ring-primary/30 bg-base-100 text-base"
                  placeholder="1"
                />
              </div>
              <select 
                v-model="selectedPeriod" 
                class="select select-bordered flex-1 h-12 focus:outline-none focus:ring-2 focus:ring-primary/30 bg-base-100 text-base"
              >
                <option value="day">Day(s)</option>
                <option value="week">Week(s)</option>
                <option value="month">Month(s)</option>
                <option value="year">Year(s)</option>
              </select>
            </div>
          </div>
        </div>
      </template>
    </div>
    
    <div class="bg-base-100 rounded-2xl shadow-sm border border-base-100 p-5">
      <div class="flex items-center justify-between">
        <div class="flex items-center gap-2 text-base-content/80">
          <span class="i-heroicons-information-circle h-5 w-5 text-primary/80"></span>
          <span class="text-sm font-medium">Schedule summary</span>
        </div>
        <div class="badge badge-accent badge-outline">Preview</div>
      </div>
      
      <div class="mt-3 p-3 rounded-xl bg-base-100 text-sm">
        <p v-if="frequencyType === 'recurring'">
          <span class="font-medium">Recurring:</span> 
          Every {{ frequencyCount }} {{ selectedPeriod }}(s)
          <span v-if="selectedPeriod === 'week' && specificDays.length > 0">
            on 
            <span v-for="(index, i) in specificDays" :key="index" class="font-medium">
              {{ daysOfWeek[index].slice(0, 3) }}{{ i < specificDays.length - 1 ? ', ' : '' }}
            </span>
          </span>
        </p>
        <p v-else>
          <span class="font-medium">Flexible:</span>
          Complete {{ flexibleTimes }} times within {{ flexibleWithin }} {{ selectedPeriod }}(s)
        </p>
      </div>
    </div>
  </div>
</template>