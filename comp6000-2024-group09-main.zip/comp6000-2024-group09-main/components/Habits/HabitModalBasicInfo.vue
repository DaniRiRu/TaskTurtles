<script lang="ts" setup>
import type { HabitData } from "~/types/habits/habits";

defineProps<{
	habit: Partial<HabitData>;
	difficultyLevels: {
		value: number;
		label: string;
		icon: string;
		color: string;
	}[];
}>();

const habit = defineModel<Partial<HabitData>>("habit");

const description = computed({
	get: () => habit.value?.description || "",
	set: (val) => {
		if (habit.value) habit.value.description = val;
	},
});

const color = computed({
	get: () => habit.value?.color || "#3B82F6",
	set: (val) => {
		if (habit.value) habit.value.color = val;
	},
});

const presetColors = [
	{ name: "Slate", value: "#64748b" },
	{ name: "Red", value: "#ef4444" },
	{ name: "Orange", value: "#f97316" },
	{ name: "Amber", value: "#f59e0b" },
	{ name: "Yellow", value: "#eab308" },
	{ name: "Lime", value: "#84cc16" },
	{ name: "Green", value: "#22c55e" },
	{ name: "Emerald", value: "#10b981" },
	{ name: "Teal", value: "#14b8a6" },
	{ name: "Cyan", value: "#06b6d4" },
	{ name: "Sky", value: "#0ea5e9" },
	{ name: "Blue", value: "#3b82f6" },
	{ name: "Indigo", value: "#6366f1" },
	{ name: "Violet", value: "#8b5cf6" },
	{ name: "Purple", value: "#a855f7" },
	{ name: "Pink", value: "#ec4899" },
];

const isMediumScreen = ref(false);

onMounted(() => {
	updateScreenSize();
	window.addEventListener("resize", updateScreenSize);
});

onBeforeUnmount(() => {
	window.removeEventListener("resize", updateScreenSize);
});

function updateScreenSize() {
	isMediumScreen.value = window.innerWidth >= 480;
}

const colorRows = computed(() => {
	const rows = [];
	const itemsPerRow = isMediumScreen.value ? 8 : 6;

	for (let i = 0; i < presetColors.length; i += itemsPerRow) {
		rows.push(presetColors.slice(i, i + itemsPerRow));
	}

	return rows;
});
</script>

<template>
  <div class="space-y-6 px-1 py-2 sm:p-4">
    <div class="form-control">
      <label class="label">
        <span class="label-text font-medium">Description</span>
      </label>
      <textarea
        v-model="description"
        class="textarea textarea-bordered w-full h-24 sm:h-28 text-sm resize-none"
        placeholder="Describe your habit in detail (optional)"
      />
    </div>

    <div class="form-control">
      <label class="label flex justify-between">
        <span class="label-text font-medium">Difficulty</span>
        <span class="label-text-alt text-xs opacity-70">How challenging is this habit?</span>
      </label>
      
      <div class="sm:hidden space-y-2 mt-1">
        <button
          v-for="level in difficultyLevels"
          :key="level.value"
          type="button"
          class="flex items-center w-full gap-3 p-2 rounded-md transition-all duration-200"
          :class="[
            habit?.difficulty === level.value 
              ? 'bg-base-200 shadow-sm border-2 border-primary/30' 
              : 'bg-base-100 border border-base-300 hover:bg-base-200/50'
          ]"
          @click="habit && (habit.difficulty = level.value as 1 | 2 | 3 | 4 | 5)"
        >
          <span 
            class="inline-block w-3 h-3 rounded-full"
            :class="level.color"
          ></span>
          <span class="text-sm font-medium">{{ level.label }}</span>
        </button>
      </div>
      
      <div class="hidden sm:grid grid-cols-5 gap-2 mt-1">
        <button
          v-for="level in difficultyLevels"
          :key="level.value"
          type="button"
          class="relative flex flex-col items-center rounded-md py-3 transition-all duration-200"
          :class="[
            habit?.difficulty === level.value 
              ? 'bg-base-200 shadow-sm border-2 border-primary/30' 
              : 'bg-base-100 border border-base-300 hover:bg-base-200/50'
          ]"
          @click="habit && (habit.difficulty = level.value as 1 | 2 | 3 | 4 | 5)"
        >
          <div class="flex h-6 items-center justify-center">
            <span 
              class="inline-block w-3 h-3 rounded-full"
              :class="level.color"
            ></span>
          </div>
          <div class="text-xs mt-1 font-medium">{{ level.label }}</div>
        </button>
      </div>
    </div>

    <div class="form-control">
      <label class="label">
        <span class="label-text font-medium">Color</span>
      </label>
      
      <div class="space-y-3 mt-1">
        <div 
          v-for="(row, index) in colorRows" 
          :key="index"
          class="flex justify-center sm:justify-start gap-2.5 flex-wrap"
        >
          <button
            v-for="preset in row"
            :key="preset.value"
            type="button"
            class="w-8 h-8 rounded-full transition-all duration-200 relative"
            :style="{ backgroundColor: preset.value }"
            :class="[
              color === preset.value 
                ? 'ring-2 ring-offset-2 ring-base-content/30 scale-110' 
                : 'hover:scale-110'
            ]"
            @click="color = preset.value"
          >
            <div 
              v-if="color === preset.value" 
              class="absolute inset-0 flex items-center justify-center text-white"
            >
              <div class="i-heroicons-check w-4 h-4"></div>
            </div>
          </button>
          
          <div v-if="index === colorRows.length - 1" class="relative w-8 h-8">
            <input
              v-model="color"
              type="color"
              class="absolute inset-0 opacity-0 w-full h-full cursor-pointer"
            />
            <div 
              class="w-8 h-8 rounded-full overflow-hidden border border-base-300"
              :style="{ backgroundColor: color }"
            >
              <div 
                v-if="!presetColors.some(p => p.value === color)"
                class="absolute inset-0 flex items-center justify-center"
              >
                <div class="i-heroicons-plus w-4 h-4 text-white drop-shadow-md"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="flex items-center mt-3 gap-2 text-xs justify-center sm:justify-start">
        <div 
          class="w-5 h-5 rounded"
          :style="{ backgroundColor: color }"
        ></div>
        <span class="font-mono">{{ color.toUpperCase() }}</span>
      </div>
    </div>
  </div>
</template>