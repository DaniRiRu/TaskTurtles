<script lang="ts" setup>
defineProps<{
	selectedTab: string;
}>();

const selectedTab = defineModel<string>("selectedTab");
</script>

<template>
  <div class="rounded-lg border border-base-200 shadow-sm mb-8">
    <div class="grid grid-cols-3 divide-x divide-base-200">
      <button 
        v-for="(tab, index) in [
          { id: 'basic', label: 'Basic Information' },
          { id: 'frequency', label: 'Schedule Settings' },
          { id: 'tags', label: 'Tags & Categories' }
        ]"
        :key="index"
        class="py-4 px-4 font-medium text-sm transition-all duration-200 outline-none relative bg-base-100"
        :class="[
          selectedTab === tab.id 
            ? 'text-primary' 
            : 'text-base-content/70 hover:text-base-content/90'
        ]"
        @click="selectedTab = tab.id"
      >
        <span>{{ tab.label }}</span>
        <div 
          v-if="selectedTab === tab.id" 
          class="absolute bottom-0 left-0 h-0.5 w-full bg-primary"
        ></div>
      </button>
    </div>
  </div>
</template>