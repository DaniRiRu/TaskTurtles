<script lang="ts" setup>
defineProps<{
	searchQuery: string;
}>();

const searchQuery = defineModel<string>("searchQuery");
const emit = defineEmits<{
	newHabit: () => void;
}>();
</script>

<template>
  <div class="max-w-2xl mx-auto relative flex items-center">
    <input
      v-model="searchQuery"
      type="text"
      placeholder="Search habits..."
      class="input input-bordered rounded-3xl w-full pl-4 pr-32 h-14 text-lg shadow-md"
    />
    <div class="absolute right-3 flex items-center gap-2">
      <button
        class="btn btn-primary btn-sm rounded-xl"
        @click="$emit('newHabit')"
      >
        New Habit
      </button>
    </div>
  </div>
</template>