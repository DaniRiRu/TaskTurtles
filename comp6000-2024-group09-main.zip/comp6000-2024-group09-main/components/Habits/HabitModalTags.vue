<script lang="ts" setup>
import LucideTags from "~icons/lucide/tags";
import MaterialSymbolsAddRounded from "~icons/material-symbols/add-rounded";

defineProps<{
	tags?: string[];
	newTag: string;
}>();

defineEmits<{
	(e: "add"): void;
	(e: "remove", tag: string): void;
}>();

const tags = defineModel<string[] | undefined>("tags");
const newTag = defineModel<string>("newTag");

const safeTagsList = computed(() => tags.value || []);
</script>

<template>
  <div class="space-y-5">
    <div class="flex flex-wrap gap-2 min-h-10">
      <div
        v-for="tag in safeTagsList"
        :key="tag"
        class="badge badge-lg bg-gradient-to-r from-primary/20 to-primary/10 text-primary border border-primary/10 px-4 py-3.5 text-sm font-medium rounded-full flex items-center gap-2 hover:shadow-md hover:scale-105 transition-all duration-300"
      >
        {{ tag }}
        <button 
          @click="$emit('remove', tag)" 
          class="rounded-full w-5 h-5 flex items-center justify-center bg-primary/10 hover:bg-primary hover:text-white transition-all duration-200"
        >
          <span class="text-xs">×</span>
        </button>
      </div>
      <div v-if="safeTagsList.length === 0" class="w-full py-2 text-sm text-base-content/50 italic">
        No tags added yet
      </div>
    </div>
    <div class="flex items-center gap-3 w-full">
      <div class="relative flex-1">
        <input
          v-model="newTag"
          type="text"
          class="input w-full bg-base-100/80 backdrop-blur-sm pl-5 pr-10 py-3.5 rounded-xl border-2 border-base-200 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary/30 transition-all duration-300 shadow-sm"
          placeholder="Add new tag"
          @keyup.enter="$emit('add')"
        />
        <div class="absolute right-4 top-1/2 -translate-y-1/2 text-base-content/30">
          <LucideTags class="w-5 h-5" />
        </div>
      </div>
      <button 
        class="btn btn-primary px-6 py-3 rounded-xl shadow hover:shadow-lg hover:shadow-primary/20 transition-all duration-300 flex items-center gap-2 border-0"
        @click="$emit('add')"
      >
        <MaterialSymbolsAddRounded class="w-5 h-5" />
        <span>Add</span>
      </button>
    </div>
    <div class="flex justify-between text-xs text-base-content/50 px-1">
      <span>Press Enter to add</span>
      <span>{{ safeTagsList.length }} tags</span>
    </div>
  </div>
</template>