<script lang="ts" setup>
import { useHabits } from "~/composables/habits/useHabits";
import type { HabitData } from "~/types/habits/habits";
import HabitDeleteConfirmation from "./HabitDeleteConfirmation.vue";

const props = defineProps<{
	habit: HabitData;
}>();

const emit = defineEmits<{
	complete: [habit: HabitData];
	update: [habit: HabitData, increment: number];
	delete: [habitId: string];
}>();

const showDeleteModal = ref(false);

const handleComplete = () => {
	emit("complete", props.habit);
};

const handleUpdate = (increment: number) => {
	emit("update", props.habit, increment);
};

const handleDeleteClick = () => {
	showDeleteModal.value = true;
};

const handleDeleteConfirm = () => {
	emit("delete", props.habit.id);
	showDeleteModal.value = false;
};

const backend = useBackend();

const HABIT_DAYS = 120;

const getDifficultyColor = (difficulty: number) => {
	const colors = {
		1: "bg-success text-success-content",
		2: "bg-info text-info-content",
		3: "bg-warning text-warning-content",
		4: "bg-error text-error-content",
		5: "bg-purple-500 text-white",
	};
	return colors[difficulty as keyof typeof colors] || "text-base-content";
};

const completionRate = computed(() => {
	if (props.habit.completionHistory.length === 0) return 0;
	const expectedCompletions =
		props.habit.frequency.type === "recurring"
			? props.habit.completionHistory.length
			: props.habit.frequency.flexible?.times || 1;

	return Math.min(
		Math.round((props.habit.totalCompletions / expectedCompletions) * 100),
		100,
	);
});

const tagClass = (index: number) => {
	const colors = [
		"text-primary",
		"text-secondary",
		"text-accent",
		"text-info",
		"text-success",
	];
	return colors[index % colors.length];
};

const monthlyCompletions = computed(() => {
	const today = new Date();
	const completions = props.habit.completionHistory;
	const monthlyStats = Array(HABIT_DAYS).fill(0);

	for (let i = 0; i < HABIT_DAYS; i++) {
		const dateToCheck = new Date();
		dateToCheck.setDate(today.getDate() - i);
		dateToCheck.setHours(0, 0, 0, 0);

		const dailyCompletions = completions.filter((completion) => {
			const completionDate = new Date(completion.completedAt);
			completionDate.setHours(0, 0, 0, 0);
			return completionDate.getTime() === dateToCheck.getTime();
		}).length;

		monthlyStats[i] = dailyCompletions;
	}

	return monthlyStats.reverse();
});

const getCompletionStatusClass = (completions: number) => {
	if (completions === 0) return "bg-base-300";
	if (completions === 1) return "bg-primary opacity-70";
	if (completions === 2) return "bg-primary opacity-85";
	return "bg-primary";
};

const getCompletionIntensity = (completions: number) => {
	if (completions === 0) return "bg-base-300";

	const baseClasses = "bg-primary";

	if (completions === 1) return `${baseClasses} opacity-60`;
	if (completions === 2) return `${baseClasses} opacity-75`;
	if (completions === 3) return `${baseClasses} opacity-90`;
	return baseClasses;
};

const formatDateForTooltip = (daysAgo: number) => {
	const date = new Date();
	date.setDate(date.getDate() - (HABIT_DAYS - daysAgo - 1));
	return date.toLocaleDateString();
};

const { getStreak } = useHabits();
</script>

<template>
  	<div
		class="transition-all duration-300 ease-in-out fixed top-0 h-18 left-0 w-full bg-gradient-to-b from-base-200 from-70% z-2">
	</div>
  <div
    class="bg-base-100 shadow-lg hover:shadow-xl transition-all duration-300 rounded-2xl p-5 flex flex-col h-full"
  >
    <div class="flex items-start gap-4">
      <div 
        class="text-4xl p-4 rounded-xl shrink-0 w-16 h-16 flex items-center justify-center"
        :class="habit.color ? `bg-${habit.color}-100 text-${habit.color}-600` : 'bg-base-200'"
      >
        {{ habit.icon }}
      </div>
      
      <div class="flex flex-col gap-1 flex-grow min-w-0">
        <div class="flex items-center justify-between w-full">
          <h3 class="text-lg font-bold truncate">{{ habit.name }}</h3>
          <div class="flex-shrink-0 ml-2">
            <span
              class="py-1 px-2.5 text-xs font-semibold rounded-full"
              :class="getDifficultyColor(habit.difficulty)"
            >
              Level {{ habit.difficulty }}
            </span>
          </div>
        </div>
        
        <p v-if="habit.description" class="text-sm text-base-content/70 line-clamp-2 min-h-[2.5rem]">
          {{ habit.description }}
        </p>
        <p v-else class="text-sm text-base-content/30 italic min-h-[2.5rem]">No description</p>
      </div>
    </div>
    
    <div class="flex flex-wrap gap-x-2 gap-y-1 mt-2 min-h-[1.5rem]">
      <span 
        v-for="(tag, index) in habit.tags" 
        :key="tag"
        class="text-xs font-medium"
        :class="tagClass(index)"
      >
        #{{ tag }}
      </span>
    </div>
    
    <div class="flex flex-col gap-3 mt-4 mb-4">
      <div class="flex justify-between items-center text-sm">
        <div class="flex items-center gap-2">
          <div class="flex items-center gap-1">
            <MaterialSymbolsLocalFireDepartmentRounded class="w-5 h-5 text-orange-500" />
          <span class="font-bold">{{ getStreak(habit.completionHistory) }}</span>
          </div>
          
          <div class="w-px h-4 bg-base-content/20"></div>
          
          <div class="flex items-center gap-1">
            <MaterialSymbolsBarChartRounded class="w-5 h-5 text-primary/80" />
            <span class="font-bold">{{ completionRate }}%</span>
          </div>
        </div>
        
        <div class="flex items-center gap-1">
          <span class="text-sm font-semibold">{{ habit.totalCompletions }}</span>
          <span class="text-sm text-base-content/70">total</span>
        </div>
      </div>
      
      <div class="mt-3">
        <div class="text-xs font-medium text-base-content/70 mb-1">Last {{ HABIT_DAYS }} days</div>
        <div class="flex flex-wrap">
          <div 
            v-for="(completionCount, index) in monthlyCompletions" 
            :key="index"
            class="mr-0.5 mb-0.5"
          >
            <div 
              class="w-4 h-4 rounded-sm"
              :class="getCompletionIntensity(completionCount)"
              :title="`${formatDateForTooltip(index)}: Completed ${completionCount} ${completionCount === 1 ? 'time' : 'times'}`"
            >
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <div class="flex items-center justify-end gap-4 mt-auto">
      <div class="flex justify-center gap-2">
        <button
          class="btn btn-sm btn-neutral text-base-content"
          @click="handleComplete"
        >
          <GravityUiCheck class="w-4 h-4" />
          <span class="hidden sm:inline">Complete</span>
        </button>
        
        <button 
          class="btn btn-sm btn-outline btn-error" 
          @click="handleDeleteClick"
        >
          <GravityUiTrashBin class="w-4 h-4" />
        </button>
      </div>
    </div>

    <HabitDeleteConfirmation
      :is-open="showDeleteModal" 
      :name="habit.name"
      @confirm="handleDeleteConfirm"
      @close="showDeleteModal = false"
    />
  </div>
</template>