<script lang="ts" setup>
const props = defineProps<{
	day: {
		date: Date;
		day: string;
		dateNum: number;
		isToday: boolean;
	};
	currentDate: Date;
	isDateInFuture: boolean;
}>();

const emit = defineEmits<{
	select: [];
}>();

const handleClick = () => {
	if (!props.isDateInFuture) {
		emit("select");
	}
};
</script>

<template>
  <button 
    @click="handleClick"
    class="flex flex-col items-center justify-center min-w-[2.5rem] sm:min-w-[3rem] md:min-w-[3.5rem] h-12 sm:h-14 md:h-16 rounded-lg sm:rounded-xl"
    :class="[
      currentDate.toDateString() === day.date.toDateString() 
        ? 'bg-primary text-primary-content shadow-md scale-105' 
        : isDateInFuture
          ? 'bg-base-100 opacity-50 cursor-not-allowed'
          : 'bg-base-100 hover:bg-opacity-90 hover:scale-105',
      day.isToday ? 'ring-1 sm:ring-2 ring-accent ring-opacity-70' : ''
    ]"
    :disabled="isDateInFuture"
  >
    <span class="text-xs sm:text-sm font-medium opacity-80">{{ day.day }}</span>
    <span class="text-base sm:text-lg md:text-xl font-bold">{{ day.dateNum }}</span>
  </button>
</template>