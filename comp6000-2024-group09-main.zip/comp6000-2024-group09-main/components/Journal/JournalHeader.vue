<script lang="ts" setup>
import MingcuteLeftFill from "~icons/mingcute/left-fill";
import MingcuteRightFill from "~icons/mingcute/right-fill";

const props = defineProps<{
	showInsights: boolean;
	selectedDate: Date;
	currentDate: Date;
	visibleDays: Array<{
		date: Date;
		day: string;
		dateNum: number;
		isToday: boolean;
	}>;
}>();

const emit = defineEmits<{
	"update:selectedDate": [date: Date];
	"update:showInsights": [value: boolean];
	"navigate:left": [];
	"navigate:right": [];
}>();

const isDateInFuture = (date: Date): boolean => {
	const now = new Date();
	now.setHours(0, 0, 0, 0);

	const compareDate = new Date(date);
	compareDate.setHours(0, 0, 0, 0);

	return compareDate > now;
};

const navigateLeft = () => {
	emit("navigate:left");
};

const navigateRight = () => {
	emit("navigate:right");
};

const selectDate = (date: Date) => {
	emit("update:selectedDate", date);
};

const journalTitle = ref("");
</script>

<template>
  <div class="w-full rounded-t-lg shadow-sm">
    <div class="flex justify-center items-center py-2 sm:py-3 md:py-4 relative">
      <button 
        @click="navigateLeft" 
        class="absolute left-1 sm:left-2 md:left-4 btn btn-primary text-neutral sm:btn-md btn-circle border-0"
        aria-label="Scroll left"
      >
        <MingcuteLeftFill />
      </button>
      
      <div class="overflow-x-auto scrollbar-hide scroll-smooth px-2 sm:px-4 md:px-6 min-w-[75%] w-full max-w-screen-sm mx-auto">
        <div id="date-scroll-container" class="flex justify-center space-x-1 xs:space-x-2 sm:space-x-3 md:space-x-4 py-1 sm:py-2">
          <JournalDayButton 
            v-for="day in visibleDays" 
            :key="day.date.toISOString()"
            :day="day"
            :current-date="currentDate"
            :is-date-in-future="isDateInFuture(day.date)"
            @select="selectDate(day.date)"
          />
        </div>
      </div>
      
      <button 
        @click="navigateRight" 
        class="absolute right-1 sm:right-2 md:right-4 btn btn btn-primary text-neutral sm:btn-md btn-circle border-0"
        aria-label="Scroll right"
        :disabled="isDateInFuture(new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate() + 1))"
      >
        <MingcuteRightFill />
      </button>
    </div>
    
    <div class="flex justify-center items-center pb-4">
      <input 
        v-model="journalTitle"
        type="text" 
        placeholder="Journal Entry Title" 
        class="input text-center input-bordered w-full max-w-md mx-auto text-lg font-semibold bg-base-100 border-base-300 rounded-lg transition-all duration-200"
      />
    </div>
  </div>
</template>