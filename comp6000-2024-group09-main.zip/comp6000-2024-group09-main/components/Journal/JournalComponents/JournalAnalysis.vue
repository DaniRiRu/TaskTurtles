<script lang="ts" setup>
import { AiContexts } from "~/types/ai-service/contexts";
import type { GenerateResponse } from "~/types/backend/ai-service/requests";
import type { AnalysisResult } from "~/types/journal/journal";
import MdiBrain from "~icons/mdi/brain";
import MdiChartLineVariant from "~icons/mdi/chart-line-variant";
import MdiLightbulbOn from "~icons/mdi/lightbulb-on";
import MdiRepeat from "~icons/mdi/repeat";
import MdiRobotOutline from "~icons/mdi/robot-outline";
import MdiTarget from "~icons/mdi/target";

const props = defineProps<{
	journalContent: string;
	analysisResult: AnalysisResult | null;
}>();

const emit = defineEmits(["update:analysisResult"]);

const state = reactive({
	aiAnalysing: false,
	activeTab: "overview",
});

const backend = useBackend();

const analyseJournal = async () => {
	if (!props.journalContent.trim()) return;

	state.aiAnalysing = true;
	try {
		const response = (await backend.ai.generate({
			message: props.journalContent,
			context: AiContexts.JOURNAL_ANALYSIS,
			stream: false,
			json: true,
		})) as GenerateResponse;

		if (response) {
			const parsed = JSON.parse(response.text);
			emit("update:analysisResult", parsed);
		}
	} catch (error) {
		console.error("Failed to analyse journal:", error);
	} finally {
		state.aiAnalysing = false;
	}
};

const getMoodColor = (mood: string) => {
	const colors = {
		positive: "bg-success/10 text-success",
		negative: "bg-error/10 text-error",
		neutral: "bg-info/10 text-info",
		mixed: "bg-warning/10 text-warning",
	};
	return colors[mood as keyof typeof colors] || colors.neutral;
};

const tabs = [
	{ id: "overview", label: "Overview", icon: MdiChartLineVariant },
	{ id: "insights", label: "Insights", icon: MdiLightbulbOn },
	{ id: "patterns", label: "Patterns", icon: MdiRepeat },
	{ id: "actions", label: "Actions", icon: MdiTarget },
];
</script>

<template>
  <div class="card bg-base-100 shadow-xl rounded-box border border-base-200 h-full">
    <div class="card-body h-full overflow-y-auto">
      <div class="flex items-center justify-between mb-6">
        <div class="flex items-center gap-2">
          <MdiRobotOutline class="text-primary text-xl" />
          <h3 class="font-semibold">AI Analysis</h3>
        </div>
        <button
          @click="analyseJournal"
          class="btn btn-primary btn-sm gap-2"
          :disabled="state.aiAnalysing"
        >
          <MdiBrain :class="{ 'animate-spin': state.aiAnalysing }" />
          Analyse
        </button>
      </div>

      <div v-if="state.aiAnalysing" class="flex flex-col items-center py-8">
        <span class="loading loading-spinner loading-lg text-primary" />
        <p class="mt-4 text-sm">Analysing your entry...</p>
      </div>

      <div v-else-if="!analysisResult" class="text-center py-12">
        <MdiBrain class="text-6xl mx-auto mb-4 opacity-30" />
        <p class="text-sm opacity-70">Start analysis to get AI insights</p>
      </div>

      <template v-else>
        <div class="tabs tabs-boxed p-1 mb-6 gap-1">
          <button
            v-for="tab in tabs"
            :key="tab.id"
            class="tab gap-2 flex-1 bg-base-200 hover:bg-base-300"
            :class="{ 'tab-active': state.activeTab === tab.id }"
            @click="state.activeTab = tab.id"
          >
            <component :is="tab.icon" class="text-lg" />
            {{ tab.label }}
          </button>
        </div>

        <div class="space-y-6">
          <div v-show="state.activeTab === 'overview'" class="space-y-4">
            <div
              class="card p-6 rounded-xl"
              :class="getMoodColor(analysisResult.mood.primary)"
            >
              <div class="flex justify-between items-start">
                <div>
                  <h4 class="font-semibold text-lg capitalize">
                    {{ analysisResult.mood.primary }} Mood
                  </h4>
                  <p class="mt-2">{{ analysisResult.mood.description }}</p>
                </div>
                <div class="radial-progress" :style="`--value:${analysisResult.mood.intensity * 10}`">
                  {{ analysisResult.mood.intensity }}/10
                </div>
              </div>
              <div
                v-if="analysisResult.mood.suggestion"
                class="mt-4 p-4 bg-base-100 rounded-lg text-base-content"
              >
                <p class="font-medium">Suggestion</p>
                <p class="mt-1 text-sm">{{ analysisResult.mood.suggestion }}</p>
              </div>
            </div>

            <div class="card bg-base-200 p-6 rounded-xl">
              <h4 class="font-medium mb-3">Topics Discussed</h4>
              <div class="flex flex-wrap gap-2">
                <span
                  v-for="topic in analysisResult.topics"
                  :key="topic"
                  class="badge badge-primary badge-outline"
                >
                  {{ topic }}
                </span>
              </div>
            </div>
          </div>

          <div v-show="state.activeTab === 'insights'" class="space-y-4">
            <div
              v-for="(insight, idx) in analysisResult.keyInsights"
              :key="idx"
              class="card bg-base-200 p-6 rounded-xl"
            >
              <div class="flex items-start gap-4">
                <span
                  class="badge badge-primary badge-lg rounded-full w-8 h-8 flex items-center justify-center"
                >
                  {{ idx + 1 }}
                </span>
                <div>
                  <p>{{ insight }}</p>
                </div>
              </div>
            </div>
          </div>

          <div v-show="state.activeTab === 'patterns'" class="space-y-6">
            <div class="card bg-success/10 p-6 rounded-xl">
              <h4 class="font-medium mb-4 text-success">Recurring Patterns</h4>
              <ul class="space-y-3">
                <li
                  v-for="pattern in analysisResult.patterns.recurring"
                  :key="pattern"
                  class="flex items-center gap-3"
                >
                  <span class="w-2 h-2 rounded-full bg-success" />
                  {{ pattern }}
                </li>
              </ul>
            </div>

            <div class="card bg-info/10 p-6 rounded-xl">
              <h4 class="font-medium mb-4 text-info">Areas of Improvement</h4>
              <ul class="space-y-3">
                <li
                  v-for="improvement in analysisResult.patterns.improvement"
                  :key="improvement"
                  class="flex items-center gap-3"
                >
                  <span class="w-2 h-2 rounded-full bg-info" />
                  {{ improvement }}
                </li>
              </ul>
            </div>
          </div>

          <div v-show="state.activeTab === 'actions'" class="space-y-4">
            <div
              v-for="(suggestion, idx) in analysisResult.suggestions"
              :key="idx"
              class="card bg-base-200 p-6 rounded-xl"
            >
              <div class="flex items-start gap-4">
                <div
                  class="badge badge-primary badge-outline rounded-full w-8 h-8 flex items-center justify-center"
                >
                  {{ idx + 1 }}
                </div>
                <div>
                  <p>{{ suggestion }}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </template>
    </div>
  </div>
</template>