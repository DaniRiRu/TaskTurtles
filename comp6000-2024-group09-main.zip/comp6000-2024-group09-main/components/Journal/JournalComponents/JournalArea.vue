<script lang="ts" setup>
import Modal from "~/components/Universal/Modal.vue";
import { ModalPosition } from "~/enums/frontend/modal/ModalPosition";
import { AiContexts } from "~/types/ai-service/contexts";
import type { GenerateResponse } from "~/types/backend/ai-service/requests";
import FluentLightbulb24Filled from "~icons/fluent/lightbulb-24-filled";
import MdiTemplateOutline from "~icons/mdi/file-document-edit-outline";
import MdiPlusCircleOutline from "~icons/mdi/plus-circle-outline";
import MdiRefresh from "~icons/mdi/refresh";

const props = defineProps<{
	journalContent: string;
}>();

const emit = defineEmits(["update:journalContent"]);

const defaultTemplate = `Today's Journal Entry

Highlights
What were the best moments of your day?

Gratitude
What are three things you're grateful for today?

Challenges
What challenges did you face today and how did you handle them?

Goals
What would you like to accomplish tomorrow?

Reflections
Additional thoughts, feelings, or observations about your day...`;

const state = reactive({
	showPrompts: false,
	showTemplateGenerator: false,
	isSaving: false,
	isGeneratingPrompts: false,
	isGeneratingTemplate: false,
	templateDescription: "",
	selectedFont: "font-serif",
	textSize: "text-base",
	darkMode: false,
	wordGoal: 500,
	journalPrompts: [
		"📝 How would you describe your emotional state today?",
		"🌟 What's something unexpected that happened today?",
		"💡 What's an important lesson you learned recently?",
		"🎯 What progress did you make toward your goals?",
		"🤔 What's something you'd like to do differently tomorrow?",
	],
});

const backend = useBackend();

const wordCount = computed(() => {
	return props.journalContent.split(" ").filter(Boolean).length;
});

const progressPercentage = computed(() => {
	return Math.min((wordCount.value / state.wordGoal) * 100, 100);
});

const handleJournalContentUpdate = (e: Event) => {
	emit("update:journalContent", (e.target as HTMLTextAreaElement).value);
};

const togglePrompts = () => {
	state.showPrompts = !state.showPrompts;
};

const toggleTemplateGenerator = () => {
	state.showTemplateGenerator = !state.showTemplateGenerator;
};

const insertPrompt = (prompt: string) => {
	const cleanPrompt = prompt.replace(/^[📝🌟💡🎯🤔]\s/u, "");
	emit("update:journalContent", `${props.journalContent}\n\n${prompt}\n`);
	state.showPrompts = false;
};

const initializeTemplate = () => {
	if (!props.journalContent) {
		emit("update:journalContent", defaultTemplate);
	}
};

const saveEntry = () => {
	state.isSaving = true;
	setTimeout(() => {
		state.isSaving = false;
	}, 1000);
};

const generateTemplate = async () => {
	if (!state.templateDescription) return;

	state.isGeneratingTemplate = true;
	try {
		const response = (await backend.ai.generate({
			message: `Generate a journal template based on this description: ${state.templateDescription}`,
			context: AiContexts.TEMPLATE_GENERATOR,
			stream: false,
			json: false,
		})) as GenerateResponse;

		if (response) {
			emit("update:journalContent", response.text);
			state.showTemplateGenerator = false;
			state.templateDescription = "";
		}
	} catch (error) {
		console.error("Failed to generate template:", error);
	} finally {
		state.isGeneratingTemplate = false;
	}
};

const generateNewPrompts = async () => {
	state.isGeneratingPrompts = true;
	try {
		const response = (await backend.ai.generate({
			message: props.journalContent,
			context: AiContexts.JOURNAL_PROMPTS,
			stream: false,
			json: true,
		})) as GenerateResponse;

		if (response) {
			const parsedPrompts = JSON.parse(response.text);
			if (parsedPrompts?.prompts) {
				state.journalPrompts = parsedPrompts.prompts;
			}
		}
	} catch (error) {
		console.error("Failed to generate prompts:", error);
	} finally {
		state.isGeneratingPrompts = false;
	}
};

onMounted(() => {
	initializeTemplate();
});
</script>

<template>
	<div class="card bg-base-100 shadow-xl rounded-box border border-base-200 h-full flex flex-col">
		<div class="card-body p-0 flex flex-col h-full">
			<div
				class="flex flex-col sm:flex-row items-center justify-between p-4 border-b border-base-200 bg-base-200/30 gap-4">
				<div class="flex items-center gap-4 flex-wrap justify-center sm:justify-start">
					<button @click="togglePrompts" class="btn btn-ghost gap-2">
						<FluentLightbulb24Filled class="text-warning" />
						<span class="hidden sm:inline">Prompts</span>
						<div class="badge badge-sm">{{ state.journalPrompts.length }}</div>
					</button>

					<button @click="toggleTemplateGenerator" class="btn btn-ghost gap-2">
						<MdiTemplateOutline />
						<span class="hidden sm:inline">Template</span>
					</button>

					<div class="dropdown dropdown-end">
						<label tabindex="0" class="btn btn-ghost">Format</label>
						<ul tabindex="0"
							class="dropdown-content z-[1] menu p-2 shadow-lg bg-base-200 rounded-box w-52 border border-base-content/10">
							<li>
								<a @click="state.selectedFont = 'font-serif'"
									:class="{ 'bg-primary/20': state.selectedFont === 'font-serif' }">
									Serif
								</a>
							</li>
							<li>
								<a @click="state.selectedFont = 'font-sans'"
									:class="{ 'bg-primary/20': state.selectedFont === 'font-sans' }">
									Sans
								</a>
							</li>
							<li>
								<a @click="state.selectedFont = 'font-mono'"
									:class="{ 'bg-primary/20': state.selectedFont === 'font-mono' }">
									Mono
								</a>
							</li>
						</ul>
					</div>

					<div class="dropdown">
						<label tabindex="0" class="btn btn-ghost">Size</label>
						<ul tabindex="0"
							class="dropdown-content z-[1] menu p-2 shadow-lg bg-base-200 rounded-box w-52 border border-base-content/10">
							<li>
								<a @click="state.textSize = 'text-sm'"
									:class="{ 'bg-primary/20': state.textSize === 'text-sm' }">
									Small
								</a>
							</li>
							<li>
								<a @click="state.textSize = 'text-base'"
									:class="{ 'bg-primary/20': state.textSize === 'text-base' }">
									Medium
								</a>
							</li>
							<li>
								<a @click="state.textSize = 'text-lg'"
									:class="{ 'bg-primary/20': state.textSize === 'text-lg' }">
									Large
								</a>
							</li>
						</ul>
					</div>

				</div>

				<div class="flex items-center gap-4">
					<div class="flex flex-col items-end gap-2">
						<div class="flex items-center gap-3">
							<span class="text-sm opacity-70">{{ state.isSaving ? "Saving..." : "Saved" }}</span>
							<div class="badge badge-neutral">{{ wordCount }} / {{ state.wordGoal }} words</div>
						</div>
						<div class="w-full h-2 bg-base-200 rounded-full">
							<div class="h-full bg-primary rounded-full transition-all duration-300"
								:style="{ width: `${progressPercentage}%` }" />
						</div>
					</div>
				</div>
			</div>

			<Modal :is-open="state.showTemplateGenerator" :position="ModalPosition.Middle"
				@close="state.showTemplateGenerator = false">
				<template #title>
					<div class="flex items-center gap-3 mb-4">
						<MdiTemplateOutline class="text-primary text-xl" />
						<h3 class="font-semibold">Template Generator</h3>
					</div>
				</template>

				<div class="flex flex-col gap-4">
					<textarea v-model="state.templateDescription" class="textarea textarea-bordered w-full"
						placeholder="Describe the template you want (e.g., 'Create a template focused on goal tracking with sections for daily targets, achievements, and future planning')"
						rows="3" />
					<div class="flex justify-end gap-3">
						<button @click="state.showTemplateGenerator = false" class="btn btn-ghost">
							Cancel
						</button>
						<button @click="generateTemplate" class="btn btn-primary"
							:disabled="state.isGeneratingTemplate || !state.templateDescription">
							<span class="loading loading-spinner" v-if="state.isGeneratingTemplate" />
							Generate Template
						</button>
					</div>
				</div>
			</Modal>

			<Modal :is-open="state.showPrompts" :position="ModalPosition.Middle" @close="state.showPrompts = false">
				<template #title>
					<div class="flex items-center justify-between mb-4">
						<div class="flex items-center gap-3">
							<FluentLightbulb24Filled class="text-warning text-xl" />
							<h3 class="font-semibold">Writing Prompts</h3>
							<button @click="generateNewPrompts" class="btn btn-sm btn-ghost gap-2"
								:disabled="state.isGeneratingPrompts">
								<MdiRefresh :class="{ 'animate-spin': state.isGeneratingPrompts }" />
								Refresh
							</button>
						</div>
					</div>
				</template>

				<div class="grid grid-cols-1 gap-3">
					<button v-for="(prompt, idx) in state.journalPrompts" :key="`prompt-${idx}`"
						@click="insertPrompt(prompt)"
						class="flex items-center gap-3 p-3 bg-base-200 rounded-lg hover:bg-warning/10 transition-colors text-left">
						<span class="badge badge-sm">{{ idx + 1 }}</span>
						<span class="flex-1 text-sm">{{ prompt }}</span>
						<MdiPlusCircleOutline class="opacity-50" />
					</button>
				</div>
			</Modal>

			<textarea :value="journalContent" @input="handleJournalContentUpdate" :class="[
				'textarea w-full flex-1 focus:outline-none bg-transparent p-6 resize-none',
				state.selectedFont,
				state.textSize
			]" placeholder="Begin your journal entry here..." />
		</div>
	</div>
</template>