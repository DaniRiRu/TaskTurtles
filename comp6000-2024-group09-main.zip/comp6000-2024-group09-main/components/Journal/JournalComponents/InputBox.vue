<script lang="ts" setup>
import { AiContexts } from "~/types/ai-service/contexts";
import type { GenerateResponse } from "~/types/backend/ai-service/requests";
import MdiBrain from "~icons/mdi/brain";
import MdiCheck from "~icons/mdi/check";
import MdiDelete from "~icons/mdi/delete";
import MdiPlus from "~icons/mdi/plus";

interface Item {
	text: string;
	completed?: boolean;
}

const props = defineProps<{
	items: (string | Item)[];
	title: string;
	icon: string;
	color: string;
	placeholder: string;
	showNumbers?: boolean;
	showCheckbox?: boolean;
	emptyStateText: string;
	emptyStateIcon: string;
	journalContent?: string;
}>();

const emit = defineEmits(["update:items"]);

const backend = useBackend();

const state = reactive({
	isGenerating: false,
});

const textareaRefs = ref<HTMLTextAreaElement[]>([]);

const adjustHeight = (index: number) => {
	if (textareaRefs.value[index]) {
		textareaRefs.value[index].style.height = "auto";
		textareaRefs.value[index].style.height =
			`${textareaRefs.value[index].scrollHeight}px`;
	}
};

const updateItem = (index: number, value: string) => {
	const newItems = [...props.items];
	if (typeof newItems[index] === "string") {
		newItems[index] = value;
	} else {
		(newItems[index] as Item).text = value;
	}
	emit("update:items", newItems);
	adjustHeight(index);
};

const toggleItem = (index: number) => {
	const newItems = [...props.items];
	if (typeof newItems[index] === "object") {
		(newItems[index] as Item).completed = !(newItems[index] as Item).completed;
		emit("update:items", newItems);
	}
};

const addItem = () => {
	const newItem = props.showCheckbox ? { text: "", completed: false } : "";
	emit("update:items", [...props.items, newItem]);
};

const removeItem = (index: number) => {
	const newItems = [...props.items];
	newItems.splice(index, 1);
	emit("update:items", newItems);
};

const generateSuggestions = async () => {
	state.isGenerating = true;
	try {
		const response = (await backend.ai.generate({
			message: `Generate suggestions for ${props.title} based on this context: ${props.journalContent}\nCurrent items: ${props.items.map((item) => (typeof item === "string" ? item : item.text)).join(", ")}`,
			context: AiContexts.ITEM_SUGGESTIONS,
			stream: false,
			json: true,
		})) as GenerateResponse;

		if (response) {
			const parsed = JSON.parse(response.text);
			const newItems = parsed.suggestions.map((suggestion: string) =>
				props.showCheckbox
					? { text: suggestion, completed: false }
					: suggestion,
			);
			emit("update:items", [...props.items, ...newItems]);
		}
	} catch (error) {
		console.error("Failed to generate suggestions:", error);
	} finally {
		state.isGenerating = false;
	}
};

onMounted(() => {
	for (let i = 0; i < props.items.length; i++) {
		adjustHeight(i);
	}
});
</script>

<template>
  <div
    class="card bg-base-100 border border-base-200 shadow-sm hover:shadow-md hover:border-accent/50 transition-all duration-300"
  >
    <div class="card-body p-5">
      <div class="flex items-center justify-between mb-4">
        <h3 class="card-title text-lg font-semibold flex items-center gap-2">
          <span :class="`text-${color}`">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              class="h-5 w-5"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              v-html="icon"
            />
          </span>
          <span class="text-base-content">{{ title }}</span>
        </h3>
        <div class="flex items-center gap-1">
          <button
            @click="generateSuggestions"
            :class="`btn btn-sm btn-ghost hover:bg-${color}/10 tooltip tooltip-left`"
            :disabled="state.isGenerating || !journalContent"
            data-tip="Generate with AI"
          >
            <MdiBrain
              class="h-5 w-5"
              :class="[
                `text-${color}`,
                { 'animate-spin': state.isGenerating },
              ]"
            />
          </button>
          <button
            @click="addItem"
            :class="`btn btn-sm btn-ghost hover:bg-${color}/10 tooltip tooltip-left`"
            data-tip="Add new item"
          >
            <MdiPlus class="h-5 w-5" :class="`text-${color}`" />
          </button>
        </div>
      </div>
      <div class="space-y-3">
        <div
          v-for="(item, index) in items"
          :key="`item-${index}`"
          class="group flex items-start gap-3 px-1"
        >
          <div
            v-if="showNumbers"
            :class="`w-6 h-6 rounded-box bg-${color}/10 text-${color} flex items-center justify-center text-sm font-medium mt-2`"
          >
            {{ index + 1 }}
          </div>
          <div
            v-if="showCheckbox"
            class="mt-2"
            @click="toggleItem(index)"
            role="checkbox"
            :aria-checked="(item as Item).completed"
            tabindex="0"
            :class="`cursor-pointer w-6 h-6 rounded-box border-2 flex items-center justify-center transition-colors duration-200 ${
              (item as Item).completed
                ? `bg-${color} border-${color}`
                : 'border-base-300 hover:border-base-400'
            }`"
          >
            <MdiCheck
              v-if="(item as Item).completed"
              class="h-4 w-4 text-base-100"
            />
          </div>
          <textarea
            :ref="(el) => (textareaRefs[index] = el as HTMLTextAreaElement)"
            :value="typeof item === 'string' ? item : (item as Item).text"
            @input="(e) => updateItem(index, (e.target as HTMLTextAreaElement).value)"
            :placeholder="placeholder"
            :class="`textarea w-full bg-transparent border-b border-base-200 focus:border-${color} rounded-box focus:outline-none px-2 py-2 transition-all resize-none overflow-hidden min-h-[2.5rem] ${
              (item as Item).completed ? 'line-through opacity-60' : ''
            }`"
            rows="1"
          />
          <button
            @click="() => removeItem(index)"
            class="btn btn-sm btn-ghost transition-opacity mt-2 hover:bg-error/10"
          >
            <MdiDelete class="h-4 w-4 text-error" />
          </button>
        </div>
        <div
          v-if="items.length === 0"
          class="flex flex-col items-center justify-center p-8 bg-base-100 rounded-box border border-dashed border-base-300"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            class="h-12 w-12 text-base-300 mb-3"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            v-html="emptyStateIcon"
          />
          <p class="text-base-content/60 text-sm font-medium">
            {{ emptyStateText }}
          </p>
        </div>
      </div>
    </div>
  </div>
</template>