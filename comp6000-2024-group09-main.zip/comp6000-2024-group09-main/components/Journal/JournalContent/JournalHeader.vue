<script lang="ts" setup>
defineProps<{
	formattedDate: string;
}>();
</script>

<template>
    <div class="flex flex-col sm:flex-row justify-between items-center gap-3">
      <div>
        <h2 class="text-xl font-semibold text-base-content">{{ formattedDate }}</h2>
        <p class="text-xs text-base-content/60">Daily Journal Entry</p>
      </div>
    </div>
</template>