<script lang="ts" setup>
import type { AnalysisResult } from "~/types/journal/journal";
import JournalAnalysis from "../JournalComponents/JournalAnalysis.vue";
import JournalArea from "../JournalComponents/JournalArea.vue";

const props = defineProps<{
	journalContent: string;
}>();

const emit = defineEmits(["update:journalContent"]);

const state = reactive({
	analysisResult: null as AnalysisResult | null,
});
</script>

<template>
	<div class="flex flex-col min-h-[max(900px,calc(100vh-22rem))] mb-8">
		<div class="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1">
			<div class="lg:col-span-2 h-full">
				<JournalArea
					:journal-content="journalContent"
					@update:journal-content="emit('update:journalContent', $event)"
				/>
			</div>

			<div class="lg:col-span-1 h-full">
				<JournalAnalysis
					:journal-content="journalContent"
					v-model:analysis-result="state.analysisResult"
				/>
			</div>
		</div>
	</div>
</template>