<script lang="ts" setup>
import type { JournalListResponse } from "~/types/backend/journal/list";
import GoalsIdeasTab from "./GoalsIdeasTab.vue";
import ReflectionsTab from "./ReflectionsTab.vue";

import type { JournalEntry } from "~/types/backend/journal/create";
import MaterialSymbolsDeleteOutline from "~icons/material-symbols/delete-outline";
import MdiContentSaveOutline from "~icons/mdi/content-save-outline";

const props = defineProps<{
	showInsights: boolean;
	formattedDate: string;
}>();

const backend = useBackend();

const moodOptions = [
	{ value: "amazing", label: "Amazing", emoji: "😄" },
	{ value: "good", label: "Good", emoji: "🙂" },
	{ value: "okay", label: "Okay", emoji: "😐" },
	{ value: "bad", label: "Bad", emoji: "😕" },
	{ value: "terrible", label: "Terrible", emoji: "😢" },
];

const selectedMood = ref(moodOptions[2].value);
const journalContent = ref("");
const ideas = ref(<string[]>[]);
const goals = ref<string[]>([]);
const actionItems = ref([{ text: "", completed: false }]);
const tags = ref<string[]>(["personal", "work", "idea", "memory"]);
const newTag = ref("");
const activeTab = ref("reflection");
const isSaving = ref(false);
const isLoading = ref(true);
const journalEntries = ref<JournalEntry[]>([]);

async function loadJournalEntries(): Promise<void> {
	try {
		isLoading.value = true;
		const response = (await backend.journal.list()) as JournalListResponse;

		journalEntries.value = response.entries || [];

		const todayEntry = journalEntries.value.find(
			(entry: JournalEntry) => entry.date === props.formattedDate,
		);

		if (todayEntry) {
			journalContent.value = todayEntry.content;
			ideas.value = todayEntry.ideas;
			goals.value = todayEntry.goals;
			actionItems.value = todayEntry.actionItems;
		}
	} catch (error) {
	} finally {
		isLoading.value = false;
	}
}

async function saveJournalEntry() {
	if (!journalContent.value.trim()) {
		return;
	}

	try {
		isSaving.value = true;

		const entry = {
			date: props.formattedDate,
			mood: selectedMood.value,
			content: journalContent.value,
			tags: tags.value,
			ideas: ideas.value,
			goals: goals.value,
			actionItems: actionItems.value.filter((item) => item.text.trim()),
		};

		await backend.journal.create({ entry });
		await loadJournalEntries();
	} catch (error) {
	} finally {
		isSaving.value = false;
	}
}

function discardChanges() {
	journalContent.value = "";
	selectedMood.value = moodOptions[2].value;
	ideas.value = [];
	goals.value = [];
	actionItems.value = [{ text: "", completed: false }];
	tags.value = ["personal", "work", "idea", "memory"];
}

onMounted(() => {
	loadJournalEntries();
});
</script>

<template>
  <div class="w-full rounded-box max-h-full flex flex-col">
    <div v-if="isLoading" class="flex items-center justify-center p-4">
      <span class="loading loading-spinner loading-lg"></span>
    </div>

    <template v-else>
      <JournalJournalContentJournalHeader 
        :formatted-date="formattedDate" 
        :mood-options="moodOptions"
        v-model:selected-mood="selectedMood"
        class="flex-none"
      />

      <div class="flex-none mt-2">
        <JournalJournalContentJournalTabs 
          :active-tab="activeTab"
          :show-insights="showInsights"
          @update:tab="activeTab = $event"
        />
      </div>

      <div class="flex-1 min-h-10 overflow-y-auto">
        <div class="h-full flex flex-col">
          <div class="flex-1 overflow-y-auto">
            <ReflectionsTab
              v-if="activeTab === 'reflection'"
              v-model:journal-content="journalContent"
              v-model:tags="tags"
              v-model:new-tag="newTag"
            />

            <GoalsIdeasTab
              v-if="activeTab === 'goals'"
              v-model:goals="goals"
              v-model:ideas="ideas"
              v-model:action-items="actionItems"
              :journal-content="journalContent"
            />
          </div>

          <div class="flex-none flex flex-col sm:flex-row items-center justify-between gap-2 p-2">
            <button 
              class="btn btn-ghost gap-2 btn-outline btn-error rounded-box"
              @click="discardChanges"
            >
              <MaterialSymbolsDeleteOutline />
              Discard
            </button>
            <button 
              class="btn btn-primary gap-2 rounded-box" 
              :class="{ 'loading': isSaving }"
              @click="saveJournalEntry"
            >
              <MdiContentSaveOutline v-if="!isSaving" />
              Save Entry
            </button>
          </div>
        </div>
      </div>
    </template>
  </div>
</template>