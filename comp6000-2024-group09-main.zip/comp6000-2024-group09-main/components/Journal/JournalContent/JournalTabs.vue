<script lang="ts" setup>
import IonBook from "~icons/ion/book";
import MageGoals from "~icons/mage/goals";
import MaterialSymbolsHistory from "~icons/material-symbols/history";

const props = defineProps<{
	activeTab: string;
}>();

const emit = defineEmits(["update:tab"]);

const changeTab = (tab: string) => {
	emit("update:tab", tab);
};

const tabs = [
	{ id: "reflection", label: "Reflection", icon: IonBook },
	{ id: "goals", label: "Goals & Ideas", icon: MageGoals },
];
</script>

<template>
  <div class="flex flex-col sm:flex-row items-center justify-between mb-8 gap-2">
    <div class="flex flex-col sm:flex-row items-center gap-2 rounded-box bg-base-100 shadow-sm p-1">
      <div v-for="tab in tabs" :key="tab.id" 
        @click="changeTab(tab.id)"
        :class="[
          'flex items-center gap-2 py-3 px-4 font-medium rounded-box cursor-pointer transition-all duration-200 text-center justify-center',
          activeTab === tab.id 
            ? 'bg-primary text-primary-content shadow-md transform scale-102' 
            : 'text-base-content hover:bg-base-200'
        ]">
        <component :is="tab.icon" class="text-xl" />
        <span>{{ tab.label }}</span>
      </div>
    </div>
    <div class="rounded-box bg-base-100 shadow-sm p-1">
      <div 
        class="flex items-center gap-2 py-3 px-4 font-medium rounded-box cursor-pointer transition-all duration-200 text-center justify-center text-base-content hover:bg-base-200"
      >
        <MaterialSymbolsHistory class="text-xl" />
        <span>History</span>
      </div>
    </div>
  </div>
</template>