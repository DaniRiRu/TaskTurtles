<script lang="ts" setup>
import InputBox from "~/components/Journal/JournalComponents/InputBox.vue";

const props = defineProps<{
	goals: string[];
	ideas: string[];
	actionItems: { text: string; completed: boolean }[];
	journalContent: string;
}>();

const emit = defineEmits([
	"update:goals",
	"update:ideas",
	"update:actionItems",
]);

interface ProgressItem {
	progress: number;
}

const progressItems = ref<ProgressItem[]>([]);
</script>

<template>
  <JournalJournalContentJournalTabTemplate>
    <template #content>
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <InputBox
          title="Today's Goals"
          icon="<path stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2' />"
          color="accent"
          :items="goals"
          @update:items="$emit('update:goals', $event)"
          placeholder="I want to accomplish..."
          :show-numbers="true"
          empty-state-text="Add goals for today"
          empty-state-icon="<path stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M12 6v6m0 0v6m0-6h6m-6 0H6' />"
          :journal-content="journalContent"
        />

        <InputBox
          title="Ideas & Inspiration"
          icon="<path stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z' />"
          color="info"
          :items="ideas"
          @update:items="$emit('update:ideas', $event)"
          placeholder="I had this idea..."
          :show-numbers="true"
          empty-state-text="Add inspirational ideas"
          empty-state-icon="<path stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z' />"
          :journal-content="journalContent"
        />
      </div>
    </template>

    <template #cards>
      <InputBox
        title="Action Items for Tomorrow"
        icon="<path stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z' />"
        color="primary"
        :items="actionItems"
          @update:items="$emit('update:actionItems', $event)"
        placeholder="Task to complete tomorrow..."
        :show-checkbox="true"
        empty-state-text="Add tasks for tomorrow"
        empty-state-icon="<path stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2' />"
        class="mb-6"
        :journal-content="journalContent"
      />
    </template>
  </JournalJournalContentJournalTabTemplate>
</template>