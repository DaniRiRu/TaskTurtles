<script lang="ts" setup>
</script>

<template>
  <div class="journal-tab w-full">
    <div class="mb-6">
      <slot name="header">
      </slot>
    </div>

    <div class="space-y-6">
      <slot name="content">
      </slot>
    </div>

    <div class="mt-8 space-y-6">
      <slot name="cards">
      </slot>
    </div>

    <div class="mt-8">
      <slot name="actions">
      </slot>
    </div>
  </div>
</template>