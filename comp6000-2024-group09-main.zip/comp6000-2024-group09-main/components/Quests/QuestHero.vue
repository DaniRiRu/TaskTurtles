<script setup lang="ts">
import { useDailyQuests } from "~/composables/quests/useDailyQuests";
import type { Quest } from "~/types/quests/quests";
import AkarIconsArrowLeft from "~icons/akar-icons/arrow-left";
import AkarIconsArrowRight from "~icons/akar-icons/arrow-right";
import GameIconsSwordsEmblem from "~icons/game-icons/swords-emblem";
import LucideClock from "~icons/lucide/clock";
import LucideStar from "~icons/lucide/star";

const props = defineProps<{
	quests: Quest[];
	canGoPrevious: boolean;
	canGoNext: boolean;
}>();

const emit = defineEmits<{
	previous: [];
	next: [];
	toggleActive: [id: number];
}>();

const { formatTimeRemaining, isRefreshing } = useDailyQuests();
</script>

<template>
  <div class="flex flex-col gap-6">
    <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
      <div>
        <span class="font-semibold tracking-widest text-primary text-sm uppercase block mb-1">Featured Quests</span>
        <div class="flex items-center gap-4">
          <h2 class="text-2xl font-extrabold drop-shadow-md">Your Next Adventure Awaits</h2>
          <div class="flex items-center gap-2 text-base-content/70 bg-base-200/50 px-3 py-1.5 rounded-full">
            <LucideClock class="w-4 h-4" />
            <span class="font-mono text-sm">
              {{ formatTimeRemaining.hours }}:{{ formatTimeRemaining.minutes }}:{{ formatTimeRemaining.seconds }}
            </span>
            <div v-if="isRefreshing" class="loading loading-spinner loading-xs"></div>
          </div>
        </div>
      </div>
      <div class="flex gap-3">
        <button
          class="btn btn-circle btn-outline btn-primary border-2 transition-all hover:scale-105 hover:-rotate-15 transition-all duration-200"
          :class="!canGoPrevious ? '!opacity-50 !btn-disabled' : ''" :disabled="!canGoPrevious" @click="emit('previous')">
          <AkarIconsArrowLeft class="w-6 h-6" />
        </button>
        <button
          class="btn btn-circle btn-outline btn-primary border-2 transition-all hover:scale-105 hover:-rotate-15 transition-all duration-200"
          :class="!canGoNext ? '!opacity-50 !btn-disabled' : ''" :disabled="!canGoNext" @click="emit('next')">
          <AkarIconsArrowRight class="w-6 h-6" />
        </button>
      </div>
    </div>
  
    <div class="flex gap-4 w-full">
      <div v-for="quest in quests" :key="quest.id"
        class="shadow-lg !rounded-box border border-secondary/10 border-2 hover:border-secondary/20 bg-base-100 hover:shadow-xl hover:scale-102 transition-all duration-300 min-w-80 max-w-128">
        <figure class="h-52">
          <img :src="quest.imageUrl" :alt="quest.title" class="w-full h-full object-cover bg-base-200 rounded-t-box" />
        </figure>
        <div class="p-5 flex flex-col gap-3">
          <div class="flex items-center justify-between">
            <h2 class="text-xl font-semibold">{{ quest.title }}</h2>
            <div class="flex items-center gap-2 p-2">
              <div v-if="quest.type === 'daily'" 
                class="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-primary/20 to-primary/10 border border-primary/20 rounded-full">
                <LucideStar class="w-3.5 h-3.5 text-primary animate-pulse" />
                <span class="text-xs font-bold text-primary uppercase tracking-wider">Daily</span>
              </div>
              <div
                class="px-2.5 py-1.5 bg-secondary/40 font-semibold flex rounded-full text-base-secondary text-xs uppercase items-center justify-center">
                {{ quest.category }}
              </div>
            </div>
          </div>
          <p class="opacity-80">{{ quest.description }}</p>
          <div class="flex items-center justify-between mt-4">
            <GameIconsSwordsEmblem class="text-primary w-8 h-8" />
            <button class="btn btn-md" @click="emit('toggleActive', quest.id)"
              :class="quest.isActive ? 'btn-error' : 'btn-success'">
              {{ quest.isActive ? "Abandon Quest" : "Accept Quest" }}
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>