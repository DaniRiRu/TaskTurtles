<script setup lang="ts">
import type { Quest } from "~/types/quests/quests";

defineProps<{
	quests: Quest[];
}>();

const emit = defineEmits<{
	toggleActive: [id: number];
}>();
</script>

<template>
  <section class="w-full">
    <div class="mb-4 mx-2">
      <span class="text-sm font-semibold tracking-wider text-primary block mb-1 uppercase">Available</span>
      <h2 class="text-2xl font-bold">Quest Board</h2>
    </div>

    <QuestsQuestTable :quests="quests" @toggle-active="emit('toggleActive', $event)" />
  </section>
</template>