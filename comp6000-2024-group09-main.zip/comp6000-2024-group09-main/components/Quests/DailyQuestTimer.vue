<script setup lang="ts">
import { useDailyQuests } from "~/composables/quests/useDailyQuests";
import LucideClock from "~icons/lucide/clock";

const { formatTimeRemaining, isRefreshing } = useDailyQuests();
</script>

<template>
  <div class="flex items-center gap-2 text-base-content/70">
    <LucideClock class="w-4 h-4" />
    <span class="font-mono">
      {{ formatTimeRemaining.hours }}:{{ formatTimeRemaining.minutes }}:{{ formatTimeRemaining.seconds }}
    </span>
    <div v-if="isRefreshing" class="loading loading-spinner loading-xs"></div>
  </div>
</template>