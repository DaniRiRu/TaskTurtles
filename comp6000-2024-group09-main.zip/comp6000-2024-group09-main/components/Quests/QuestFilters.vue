<script setup lang="ts">
import type { QuestFilters } from "~/types/quests/quests";

const props = defineProps<{
	filters: QuestFilters;
}>();

const emit = defineEmits<{
	updateFilters: [filters: QuestFilters];
}>();
</script>

<template>
  <div class="max-w-3xl mx-auto mb-6">
    <div
      class="rounded-box shadow-lg top-0 bg-base-100 transition-all duration-300 hover:shadow-xl border border-base-content/10 hover:border-primary/30 px-2"
    >
      <div class="flex items-center gap-1">
        <input
          v-model="filters.searchQuery"
          type="text"
          placeholder="Search quests..."
          class="input ring-none border-none bg-transparent w-full h-12 text-base placeholder:text-base-content/40 focus:outline-none"
          @input="emit('updateFilters', filters)"
        />

        <div class="divider divider-horizontal p-0 m-0 w-2 my-3"></div>

        <div class="dropdown dropdown-end">
          <label tabindex="0" class="btn btn-sm btn-ghost w-10 p-0">
            <LucideGauge class="w-5 h-5 text-primary" />
          </label>
          <ul
            tabindex="0"
            class="dropdown-content z-[1] menu p-2 shadow-lg bg-base-200/80 backdrop-blur-xl rounded-box w-52 border border-base-content/10"
          >
            <li>
              <a @click="filters.difficulty = null; emit('updateFilters', filters)">
                All Difficulties
              </a>
            </li>
            <li>
              <a @click="filters.difficulty = 'easy'; emit('updateFilters', filters)">
                Easy
              </a>
            </li>
            <li>
              <a @click="filters.difficulty = 'medium'; emit('updateFilters', filters)">
                Medium
              </a>
            </li>
            <li>
              <a @click="filters.difficulty = 'hard'; emit('updateFilters', filters)">
                Hard
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>