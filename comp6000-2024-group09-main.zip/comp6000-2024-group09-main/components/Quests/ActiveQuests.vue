<script setup lang="ts">
import { useRewardEffect } from "~/composables/effects/useRewardEffect";
import type { Quest } from "~/types/quests/quests";
import LucideCheck from "~icons/lucide/check";
import LucideCrown from "~icons/lucide/crown";
import LucideEdit from "~icons/lucide/edit";
import LucideGoal from "~icons/lucide/goal";
import LucideRefreshCcw from "~icons/lucide/refresh-ccw";
import LucideTarget from "~icons/lucide/target";
import LucideX from "~icons/lucide/x";

const props = defineProps<{
	quests: Quest[];
}>();

const emit = defineEmits<{
	updateProgress: [id: number, progress: number];
	toggleActive: [id: number];
	completeQuest: [id: number];
}>();

const editingProgress = ref<{ [key: number]: boolean }>({});
const progressInputs = ref<{ [key: number]: number }>({});
const { playRewardEffect } = useRewardEffect();

function getQuestLevel(difficulty: string) {
	switch (difficulty) {
		case "easy":
			return "Novice";
		case "medium":
			return "Adventurer";
		case "hard":
			return "Expert";
		default:
			return "Unknown";
	}
}

function getDifficultyClass(difficulty: string) {
	return {
		"bg-success/90 text-success-content": difficulty === "easy",
		"bg-warning/90 text-warning-content": difficulty === "medium",
		"bg-error/90 text-error-content": difficulty === "hard",
	};
}

function getProgressDescription(progress: number) {
	if (progress === 0) return "Quest not started";
	if (progress < 25) return "Just beginning";
	if (progress < 50) return "Making progress";
	if (progress < 75) return "Well underway";
	if (progress < 100) return "Almost there";
	return "Ready to complete!";
}

function getProgressEmoji(progress: number) {
	if (progress === 0) return "🏁";
	if (progress < 25) return "🌱";
	if (progress < 50) return "⚔️";
	if (progress < 75) return "🔥";
	if (progress < 100) return "⭐";
	return "🏆";
}

function startEditProgress(questId: number, currentProgress: number) {
	editingProgress.value[questId] = true;
	progressInputs.value[questId] = currentProgress;
}

function saveProgress(questId: number) {
	const newProgress = Math.min(100, Math.max(0, progressInputs.value[questId]));
	emit("updateProgress", questId, newProgress);
	editingProgress.value[questId] = false;
}

function cancelEdit(questId: number) {
	editingProgress.value[questId] = false;
}

function resetProgress(questId: number) {
	emit("updateProgress", questId, 0);
}

function completeProgress(questId: number) {
	emit("updateProgress", questId, 100);
}

function isQuestComplete(progress: number) {
	return progress >= 100;
}

function handleClaimReward(questId: number, event: MouseEvent) {
	const button = event.currentTarget as HTMLElement;
	const rect = button.getBoundingClientRect();
	const x = rect.left + rect.width / 2;
	const y = rect.top + rect.height / 2;
	playRewardEffect(x, y);
	emit("completeQuest", questId);
}
</script>

<template>
  <div v-if="quests.length === 0" class="flex items-center justify-center">
    <ContentUnavailable 
      :image="LucideGoal"
      title="Your Quest Log Awaits"
      description="Venture forth to the quest board to embark on new adventures and challenges!"
      class="h-96 mt-12" />
  </div>
  <section v-else class="w-full">
    <div class="mb-6">      
      <div class="flex items-center gap-3 mb-4">
        <LucideGoal class="w-6 h-6 text-primary" />
        <h2 class="text-2xl font-bold translate-y-0 opacity-100">Quest Journal</h2>
      </div>
    </div>

    <div class="grid grid-cols-[repeat(auto-fill,minmax(400px,1fr))] gap-6">
      <div v-for="quest in quests" :key="quest.id"
        class="rounded-xl border border-base-300 bg-base-100 p-6 flex flex-col justify-between gap-4 transition-all duration-300 hover:shadow-xl hover:border-primary/20 translate-y-0 opacity-100">
        <div class="flex flex-col gap-3">
          <div class="flex justify-between items-start">
            <div class="flex flex-col gap-1">
              <div class="font-bold text-lg text-base-content">{{ quest.title }}</div>
              <div class="text-xs text-base-content/60">{{ getQuestLevel(quest.difficulty) }} Quest</div>
            </div>
            <div class="badge !px-3 py-2.5 border-none" :class="getDifficultyClass(quest.difficulty)">
              {{ getQuestLevel(quest.difficulty) }}
            </div>
          </div>
          <div class="text-sm text-base-content/70 leading-relaxed">{{ quest.description }}</div>
        </div>

        <div class="flex items-center gap-2 mt-1 flex-wrap">
          <div class="badge badge-secondary badge-outline !px-3 py-2.5">{{ quest.formattedReward }}</div>
          <div class="badge badge-ghost">{{ getProgressEmoji(quest.progress.current) }} {{ getProgressDescription(quest.progress.current) }}</div>
        </div>

        <div class="flex flex-col gap-4 mt-2">
          <div v-if="editingProgress[quest.id]" class="flex items-center justify-between w-full gap-2">
            <div class="flex items-center flex-1 gap-2">
              <input 
                type="number" 
                v-model="progressInputs[quest.id]"
                class="input input-bordered input-sm w-24 text-center"
                min="0"
                max="100"
              />
              <span class="text-sm text-base-content/70">%</span>
            </div>
            <div class="flex items-center gap-2">
              <button @click="saveProgress(quest.id)" class="btn btn-ghost btn-sm tooltip" data-tip="Save Progress">
                <LucideCheck class="w-4 h-4" />
              </button>
              <button @click="cancelEdit(quest.id)" class="btn btn-ghost btn-sm tooltip" data-tip="Cancel">
                <LucideX class="w-4 h-4" />
              </button>
            </div>
          </div>
          <div v-else class="flex items-center gap-2">
            <div class="flex-1">
              <div class="flex items-center gap-2 mb-1">
                <progress 
                  class="progress progress-primary h-3 flex-1 transition-all duration-300"
                  :value="quest.progress.current" 
                  :max="quest.progress.max"
                />
                <div class="flex items-center gap-1">
                  <button 
                    @click="startEditProgress(quest.id, quest.progress.current)"
                    class="btn btn-ghost btn-sm tooltip"
                    data-tip="Edit Progress"
                  >
                    <LucideEdit class="w-4 h-4" />
                  </button>
                  <button 
                    @click="resetProgress(quest.id)"
                    class="btn btn-ghost btn-sm tooltip"
                    data-tip="Reset Progress"
                  >
                    <LucideRefreshCcw class="w-4 h-4" />
                  </button>
                  <button 
                    @click="completeProgress(quest.id)"
                    class="btn btn-ghost btn-sm tooltip"
                    data-tip="Complete Quest"
                  >
                    <LucideCrown class="w-4 h-4" />
                  </button>
                </div>
                <span class="text-sm font-medium text-base-content/80 w-12 text-right">
                  {{ quest.progress.current }}%
                </span>
              </div>
              <div class="text-xs text-base-content/60">
                {{ getProgressDescription(quest.progress.current) }}
              </div>
            </div>
          </div>

          <div class="flex gap-3">
            <button
              v-if="isQuestComplete(quest.progress.current)"
              class="btn btn-success btn-sm flex-1 transition-all duration-300 hover:scale-[1.02] active:scale-95 gap-2"
              @click="handleClaimReward(quest.id, $event)"
            >
              <LucideCheck class="w-4 h-4" />
              Claim Reward
            </button>
            <template v-else>
              <button
                class="btn btn-primary btn-sm flex-1 transition-all duration-300 hover:scale-[1.02] active:scale-95 gap-2"
                @click="emit('updateProgress', quest.id, quest.progress.current + 10)"
              >
                <LucideTarget class="w-4 h-4" />
                Progress Quest
              </button>
              <button
                class="btn btn-error btn-sm flex-1 transition-all duration-300 hover:scale-[1.02] active:scale-95 gap-2"
                @click="emit('toggleActive', quest.id)"
              >
                <LucideX class="w-4 h-4" />
                Abandon
              </button>
            </template>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>