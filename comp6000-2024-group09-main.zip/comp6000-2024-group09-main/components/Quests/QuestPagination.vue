<script setup lang="ts">
const props = defineProps<{
	totalPages: number;
	currentPage: number;
}>();

const emit = defineEmits<{
	setPage: [page: number];
}>();

function getActiveClass(page: number) {
	return {
		"hover:!bg-secondary/60 text-primary-content active-page !bg-primary/80":
			props.currentPage === page,
	};
}
</script>

<template>
  <div class="flex justify-end p-4">
    <div class="join !bg-base-100 rounded-box shadow-md">
      <button
        class="join-item btn btn-sm bg-base-100 hover:bg-secondary/20 outline-none border-none p-0 px-2 transition-all duration-300"
        :disabled="currentPage === 1" @click="emit('setPage', currentPage - 1)">
        <MaterialSymbolsArrowLeft class="size-4" />
      </button>

      <button v-for="page in totalPages" :key="page"
        class="join-item btn btn-sm bg-base-100 hover:bg-secondary/20 outline-none border-none transition-all duration-300 ease-in-out relative"
        :class="getActiveClass(page)" @click="emit('setPage', page)">
        <span class="relative z-10">{{ page }}</span>
      </button>

      <button
        class="join-item btn btn-sm hover:bg-secondary/20 bg-base-100 outline-none border-none p-0 px-2 transition-all duration-300"
        :disabled="currentPage === totalPages" @click="emit('setPage', currentPage + 1)">
        <MaterialSymbolsArrowRight class="size-4" />
      </button>
    </div>
  </div>

</template>