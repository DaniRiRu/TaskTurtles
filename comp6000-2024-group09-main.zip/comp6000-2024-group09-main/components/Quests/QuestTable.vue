<script setup lang="ts">
import type { Quest } from "~/types/quests/quests";
import LucideGoal from "~icons/lucide/goal";

const props = defineProps<{
	quests: Quest[];
}>();

const emit = defineEmits<{ toggleActive: [id: number] }>();

function formatText(text: string) {
	return text.charAt(0).toUpperCase() + text.slice(1);
}

function getDifficultyClass(difficulty: string) {
	return {
		"bg-success text-success-content": difficulty === "easy",
		"bg-warning text-warning-content": difficulty === "medium",
		"bg-error text-error-content": difficulty === "hard",
	};
}

const quests = computed(() => props.quests.filter((quest) => !quest.isActive));
</script>

<template>
  <div class="w-full">
    <div v-if="quests.length === 0" class="flex items-center justify-center animate-fade-up">
      <ContentUnavailable
        :image="LucideGoal"
        title="All quests active"
        description="Looks like you're taking on all available quests. Good luck!" class="!h-96 mb-12" />
    </div>
    <div v-else class="grid grid-cols-[repeat(auto-fill,minmax(400px,1fr))] gap-4">
      <div v-for="quest in quests" :key="quest.id"
        class="rounded-box shadow bg-base-100 p-6 flex flex-col justify-between gap-4 hover:bg-base-300 transition-all duration-300 hover:scale-102 hover:shadow-lg animate-fade-up relative w-full">
        <div class="flex flex-col gap-2">
          <div class="flex justify-between">
            <div class="font-semibold text-lg truncate">{{ quest.title }}</div>
            <input type="checkbox" class="checkbox size-6" :class="{ 'checkbox-success': quest.isActive }"
              :checked="quest.isActive" @change="() => emit('toggleActive', quest.id)" />
          </div>
          <div class="text-sm text-base-content/60">{{ quest.description }}</div>
        </div>
        <div class="flex justify-between items-center mt-2">
          <div class="badge !px-2.5 h-6 border-none bg-secondary/20">{{ quest.formattedReward }}</div>
          <div class="badge !px-2.5 h-6 rounded-box border-none" :class="getDifficultyClass(quest.difficulty)">
            {{ formatText(quest.difficulty) }}
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style>
@keyframes fade-up {
  0% {
    opacity: 0;
    transform: translateY(10px);
  }

  100% {
    opacity: 1;
    transform: translateY(0);
  }
}

.animate-fade-up {
  animation: fade-up 300ms ease-out;
}
</style>
