<script setup lang="ts">
import type { Quest } from "~/types/quests/quests";
import LucideArchive from "~icons/lucide/archive";
import LucideGoal from "~icons/lucide/goal";

const props = defineProps<{
	quests: Quest[];
}>();

function getDifficultyClass(difficulty: string) {
	return {
		"bg-success/90 text-success-content": difficulty === "easy",
		"bg-warning/90 text-warning-content": difficulty === "medium",
		"bg-error/90 text-error-content": difficulty === "hard",
	};
}

function getQuestLevel(difficulty: string) {
	switch (difficulty) {
		case "easy":
			return "Novice";
		case "medium":
			return "Adventurer";
		case "hard":
			return "Expert";
		default:
			return "Unknown";
	}
}
</script>

<template>
  <div v-if="quests.length === 0" class="flex items-center justify-center">
    <ContentUnavailable 
      :image="LucideGoal"
      title="No Archived Quests"
      description="Complete some quests to see them in your archive!"
      class="h-96 mt-12" />
  </div>
  <section v-else class="w-full">
    <div class="mb-6">      
      <div class="flex items-center gap-3 mb-4">
        <LucideArchive class="w-6 h-6 text-primary" />
        <h2 class="text-2xl font-bold translate-y-0 opacity-100">Quest Archive</h2>
      </div>
    </div>

    <div class="grid grid-cols-[repeat(auto-fill,minmax(400px,1fr))] gap-6">
      <div v-for="quest in quests" :key="quest.id"
        class="rounded-xl border border-base-300 bg-base-100 p-6 flex flex-col justify-between gap-4 transition-all duration-300 hover:shadow-xl hover:border-primary/20 translate-y-0 opacity-100">
        <div class="flex flex-col gap-3">
          <div class="flex justify-between items-start">
            <div class="flex flex-col gap-1">
              <div class="font-bold text-lg text-base-content">{{ quest.title }}</div>
              <div class="text-xs text-base-content/60">{{ getQuestLevel(quest.difficulty) }} Quest</div>
            </div>
            <div class="badge !px-3 py-2.5 border-none" :class="getDifficultyClass(quest.difficulty)">
              {{ getQuestLevel(quest.difficulty) }}
            </div>
          </div>
          <div class="text-sm text-base-content/70 leading-relaxed">{{ quest.description }}</div>
        </div>

        <div class="flex items-center gap-2 mt-1 flex-wrap">
          <div class="badge badge-secondary badge-outline !px-3 py-2.5">{{ quest.formattedReward }}</div>
          <div class="badge badge-success">Completed</div>
        </div>

        <div class="flex flex-col gap-4 mt-2">
          <div class="flex items-center gap-2">
            <div class="flex-1">
              <div class="flex items-center gap-2 mb-1">
                <progress 
                  class="progress progress-success h-3 flex-1"
                  :value="100" 
                  :max="100"
                />
                <span class="text-sm font-medium text-base-content/80 w-12 text-right">
                  100%
                </span>
              </div>
              <div class="text-xs text-base-content/60">
                Quest Completed
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>