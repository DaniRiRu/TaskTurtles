<script setup lang="ts">
import { useNavigation } from "~/composables/useOnboardingNavItems";
const { navigation, isActiveRoute } = useNavigation();
const isMobileMenuOpen = ref(false);

const toggleMobileMenu = () => {
	isMobileMenuOpen.value = !isMobileMenuOpen.value;
};
</script>

<template>
    <transition name="fade">
        <div v-if="isMobileMenuOpen" class="fixed z-45 max-md:bg-gradient-to-b from-black/40 inset-0"
            @click="toggleMobileMenu"></div>
    </transition>

    <nav class="z-50 rounded-box max-md:w-full max-md:mx-4">
        <div
            class="mx-auto max-md:max-w-xs px-4 bg-base-100/40 backdrop-blur-3xl rounded-full border border-secondary/10 flex items-center h-14 overflow-hidden backdrop-saturate-120">
            <NuxtLink to="/" class="flex items-center gap-2 hover:opacity-90 transition-opacity">
                <MdiTurtle class="text-primary text-2xl" />
                <span class="text-base-content font-semibold">TaskTurtles</span>
            </NuxtLink>

            <div class="hidden md:flex items-center ml-4 flex-grow">
                <div v-for="item in navigation" :key="item.name" class="relative group">
                    <NuxtLink :to="item.path"
                        class="inline-flex items-center px-4 py-2 text-sm text-base-content/80 hover:text-base-content rounded-md transition-colors"
                        :class="{ 'text-base-content': isActiveRoute(item.path) }">
                        {{ item.name }}
                    </NuxtLink>
                </div>
            </div>

            <div class="hidden md:flex gap-3 ml-auto -mr-1 pl-4">
                <NuxtLink to="/dashboard"
                    class="btn btn-primary min-h-8 h-8 rounded-full flex-grow hover:scale-101 hover:shadow-lg hover:bg-primary/10 hover:text-primary transition-all">
                    Get Started</NuxtLink>
            </div>

            <button @click="toggleMobileMenu"
                class="md:hidden -mr-1 p-2 text-base-content hover:bg-primary/10 transition-colors bg-transparent rounded-full ml-auto">
                <MdiMenu class="transition-transform duration-300" />
            </button>
        </div>

        <transition name="fade">
            <div v-if="isMobileMenuOpen"
                class="md:hidden max-w-xs mx-auto p-4 mt-4 bg-base-100/40 backdrop-blur-3xl rounded-box border border-secondary/10">
                <div class="space-y-4">
                    <div v-for="item in navigation" :key="item.name">
                        <NuxtLink :to="item.path"
                            class="block text-sm text-base-content/80 hover:text-base-content rounded-md transition-colors"
                            :class="{ 'text-base-content': isActiveRoute(item.path) }">
                            {{ item.name }}
                        </NuxtLink>
                    </div>
                    <div class="flex gap-3">
                        <NuxtLink to="/dashboard"
                            class="btn btn-primary min-h-8 h-8 rounded-full flex-grow hover:scale-101 hover:shadow-lg hover:bg-primary/10 hover:text-primary transition-all">
                            Get Started</NuxtLink>
                    </div>
                </div>
            </div>
        </transition>
    </nav>
</template>

<style>
.fade-enter-active,
.fade-leave-active {
    transition: all 0.1s cubic-bezier(0.075, 0.82, 0.9, 1);
}

.fade-enter-from,
.fade-leave-to {
    opacity: 0;
    transform: translateY(-8px);
}
</style>