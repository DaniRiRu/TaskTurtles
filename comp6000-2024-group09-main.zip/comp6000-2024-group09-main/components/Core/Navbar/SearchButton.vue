<script lang="ts" setup>
import MaterialSymbolsSearch from "~icons/material-symbols/search";

const isSearchOpen = useCookie<boolean>(COOKIE_NAMES.SEARCH, {
	default: () => false,
});

const toggleSearch = () => {
	isSearchOpen.value = !isSearchOpen.value;
};
</script>

<template>
    <button class="btn btn-ghost btn-circle border-none" @click="toggleSearch">
        <component :is="MaterialSymbolsSearch" class="text-2xl" />
    </button>
</template>