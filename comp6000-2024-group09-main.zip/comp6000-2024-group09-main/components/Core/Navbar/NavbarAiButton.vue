<script setup lang="ts">
import MingcuteAiFill from "~icons/mingcute/ai-fill";

const emit = defineEmits<(e: "toggleChat") => void>();

const toggleChat = () => {
	emit("toggleChat");
};
</script>

<template>
  <button
    @click="toggleChat"
    class="btn btn-ghost btn-circle border-0 hover:bg-base-300 transition-all duration-300 ease-in-out hover:shadow-xl hover:bg-gradient-to-br from-secondary to-secondary-100 hover:bg-opacity-100 bg-opacity-0 hover:text-secondary-content"
    title="AI Assistant"
  >
    <MingcuteAiFill class="w-7 h-7" />
  </button>
</template>
