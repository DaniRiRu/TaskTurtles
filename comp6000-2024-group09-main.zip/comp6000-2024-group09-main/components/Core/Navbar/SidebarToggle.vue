<script lang="ts" setup>
import CodiconLayoutSidebarLeft from "~icons/codicon/layout-sidebar-left";
import CodiconLayoutSidebarLeftOff from "~icons/codicon/layout-sidebar-left-off";

const isSidebarOpen = useCookie<boolean>(COOKIE_NAMES.SIDEBAR, {
	default: () => false,
});

const ToggleIcon = computed(() =>
	isSidebarOpen.value ? CodiconLayoutSidebarLeft : CodiconLayoutSidebarLeftOff,
);

const toggleSidebar = () => {
	isSidebarOpen.value = !isSidebarOpen.value;
};
</script>

<template>
    <button class="btn btn-ghost btn-square" @click="toggleSidebar">
        <component :is="ToggleIcon"/>
    </button>
</template>