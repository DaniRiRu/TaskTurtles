<script lang="ts" setup>
import { useRoute } from "vue-router";

const route = useRoute();

const breadcrumbs = computed(() => {
	// split path into array and remove empty strings
	const paths = route.path.split("/").filter(Boolean);

	// create array of objects for each path
	return paths.map((path, index) => {
		const to = `/${paths.slice(0, index + 1).join("/")}`;
		const decodedPath = decodeURIComponent(path);
		const label = decodedPath.charAt(0).toUpperCase() + decodedPath.slice(1);
		return { to, label };
	});
});

const canSelect = (index: number) => {
	return (
		index !== breadcrumbs.value.length - 1 &&
		breadcrumbs.value[index].label !== "Settings"
	);
};
</script>
<template>
	<div class="breadcrumbs text-base">
		<ul>
			<li v-for="(breadcrumb, index) in breadcrumbs" :key="index" class="space-x-2">
				<router-link :to="breadcrumb.to" v-if="canSelect(index)">{{ breadcrumb.label
				}}</router-link>
				<span v-else>{{ breadcrumb.label }}</span>
			</li>
		</ul>
	</div>
</template>