<script lang="ts" setup>
const user = useCurrentUser();

const emit = defineEmits(["toggleChat"]);

const handleToggleChat = () => {
	emit("toggleChat");
};
</script>

<template>
    <nav class="navbar p-0 flex justify-between items-center">
        <div class="left space-x-2 flex items-center align-middle px-2">
            <CoreNavbarSidebarToggle class="text-lg"/>
            <CoreNavbarBreadcrumbs />
        </div>

        <div class="flex-none space-x-2 flex items-center align-middle px-3">
            <CoreNavbarAiButton @toggleChat="handleToggleChat" />
            <CoreNavbarSearchButton />
            <CoreNavbarNotificationBell v-if="user" :count="15" />
        </div>
    </nav>
</template>