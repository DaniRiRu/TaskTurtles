<script lang="ts" setup>
import { useScroll } from "@vueuse/core";
import MaterialSymbolsCheck from "~icons/material-symbols/check";
import MaterialSymbolsKeyboardArrowDown from "~icons/material-symbols/keyboard-arrow-down";

const theme = useCookie<string>(COOKIE_NAMES.THEME, {
	default: () => DEFAULT_THEME,
});

const selectTheme = (t: string) => {
	theme.value = t;
};

const { allThemes } = useCustomThemes();

const scrollContainer = ref<HTMLElement | null>(null);
const { y } = useScroll(scrollContainer);

const maxScrollHeight = computed(() => {
	return (
		(scrollContainer.value?.scrollHeight ?? 0) -
		(scrollContainer.value?.clientHeight ?? 0)
	);
});

const topMaskOpacity = computed(() => {
	return {
		"opacity-0": y.value <= 0,
		"opacity-100": y.value > 0,
	};
});

const bottomMaskOpacity = computed(() => {
	return {
		"opacity-0": y.value >= maxScrollHeight.value,
		"opacity-100": y.value < maxScrollHeight.value,
	};
});
</script>
<template>
	<div class="dropdown dropdown-end">
		<label tabindex="0" class="btn m-1">
			<span class="text-sm font-medium">{{ theme.split("_").join(" ") }}</span>
			<MaterialSymbolsKeyboardArrowDown class="h-4 w-4" />
		</label>
		<ul tabindex="0"
			class="dropdown-content mt-1 z-[1] menu px-2 shadow-xl bg-base-100/80 backdrop-blur-lg rounded-box w-64 max-h-[60vh] overflow-hidden relative">

			<div :class="topMaskOpacity"
				class="absolute top-0 left-0 right-0 h-12 overflow-hidden z-10 transition-opacity duration-300 pointer-events-none">
				<div class="absolute inset-0 bg-gradient-to-b from-base-100/80 to-transparent"></div>
			</div>

			<div :class="bottomMaskOpacity"
				class="absolute bottom-0 left-0 right-0 h-12 overflow-hidden z-10 transition-opacity duration-300 pointer-events-none">
				<div class="absolute inset-0 bg-gradient-to-t from-base-100/80 to-transparent"></div>
			</div>

			<div ref="scrollContainer"
				class="h-full w-full overflow-y-auto [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none] -my-2">
				<div class="w-full py-2">
					<li v-for="t in allThemes" :key="t" class="rounded-box mb-2 last:mb-0 w-60">
						<button @click="selectTheme(t)"
							class="btn bg-base-200 hover:bg-base-300 transition-all duration-200 flex items-center align-middle rounded-box min-h-10 h-10"
							:data-theme="t" :class="{ 'border-2 border-primary': theme === t }">
							<div class="flex rounded-box -ml-1">
								<div class="w-4 h-4 rounded-full bg-primary"></div>
								<div class="w-4 h-4 rounded-full bg-secondary"></div>
								<div class="w-4 h-4 rounded-full bg-accent"></div>
							</div>
							<span class="text-sm font-medium flex-grow">{{ t.split("_").join(" ") }}</span>
							<MaterialSymbolsCheck v-if="theme === t" class="h-5 w-5 text-primary" />
							<div v-else class="w-5"></div>
						</button>
					</li>
				</div>
			</div>
		</ul>
	</div>
</template>