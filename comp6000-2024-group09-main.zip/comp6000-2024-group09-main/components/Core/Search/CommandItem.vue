<script setup lang="ts">
import type { Command } from "~/types/frontend/command";

const props = defineProps<{
	command: Command;
	active?: boolean;
}>();
</script>

<template>
  <div class="mx-3 py-2 px-3 my-0.5 hover:bg-primary/10 rounded-lg cursor-pointer flex items-center space-x-2" :class="active ? 'bg-secondary/10' : ''">
    <component :is="command.icon" class="text-lg opacity-60" />
    <span class="flex-grow">{{ command.title }}</span>
    <span v-if="command.path" class="ml-auto text-xs opacity-60">
      {{ command.path }}
    </span>
  </div>
</template>