<script setup lang="ts">
import SuggestionCard from "~/components/SuggestionCard.vue";
import type { Command } from "~/types/frontend/command";
import CommandItem from "./CommandItem.vue";

interface Props {
	commands: Command[];
	commandType: "suggestions" | "results";
	title?: string;
	activeCommandId?: string | number | null;
}

const props = defineProps<Props>();
</script>

<template>
  <SuggestionCard>
    <div class="py-2.5 space-y-1">
        <div v-for="command in commands" :key="command.id" @click="$emit('select', command)">
          <CommandItem :command="command" :active="command.id === props.activeCommandId" />
        </div>
    </div>
  </SuggestionCard>
</template>