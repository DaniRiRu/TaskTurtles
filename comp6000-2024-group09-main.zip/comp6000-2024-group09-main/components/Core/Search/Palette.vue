<script setup lang="ts">
import type { Command } from "~/types/frontend/command";
import MaterialSymbolsSearch from "~icons/material-symbols/search";
import CommandList from "./CommandList.vue";

const searching = useCookie(COOKIE_NAMES.SEARCH, {
	default: () => false,
});
const query = ref("");
const inputRef = ref<HTMLInputElement | null>(null);

const commonTransitionClasses = {
	enterActive: "transition-all duration-150 ease-in-out",
	enterFrom: "opacity-0",
	enterTo: "opacity-100",
	leaveActive: "transition-all duration-150 ease-in-out",
	leaveFrom: "opacity-100",
	leaveTo: "opacity-0",
};

const { pages, navigateTo } = useSitemap();

const commands = {
	suggestions: pages,
};

function filterCommands(commandList: Command[]) {
	if (!query.value) return commandList;
	return commandList.filter((command) =>
		command.title.toLowerCase().includes(query.value.toLowerCase()),
	);
}

const filteredCommands = computed(() => ({
	suggestions: filterCommands(commands.suggestions),
}));

const shouldBeHidden = computed(() => ({
	suggestions: filteredCommands.value.suggestions.length === 0,
}));

function handleCommandSelect(command: Command) {
	navigateTo(command);
	searching.value = false;
}

const activeIndex = ref(0);

const visibleCommands = computed(() => {
	let cmds: Command[] = [];
	if (!shouldBeHidden.value.suggestions) {
		cmds = cmds.concat(filteredCommands.value.suggestions);
	}
	return cmds;
});

const activeCommand = computed(() => {
	return activeIndex.value === 0
		? null
		: visibleCommands.value[activeIndex.value - 1];
});

function handleKeyDown(e: KeyboardEvent) {
	if (e.key === "k" && (e.metaKey || e.ctrlKey)) {
		e.preventDefault();
		toggleSearch();
		return;
	}
	if (e.key === "Escape" && searching.value) {
		e.preventDefault();
		searching.value = false;
		return;
	}
	if (searching.value && ["ArrowDown", "ArrowUp", "Enter"].includes(e.key)) {
		e.preventDefault();
		const totalItems = visibleCommands.value.length + 1;
		if (!totalItems) return;
		if (e.key === "ArrowDown") {
			activeIndex.value = (activeIndex.value + 1) % totalItems;
		} else if (e.key === "ArrowUp") {
			activeIndex.value = (activeIndex.value - 1 + totalItems) % totalItems;
		} else if (e.key === "Enter") {
			if (activeIndex.value === 0) {
				inputRef.value?.focus();
			} else {
				const cmd = activeCommand.value;
				if (cmd) handleCommandSelect(cmd);
			}
		}
	}
}

function toggleSearch() {
	searching.value = !searching.value;
	activeIndex.value = 0;
	if (searching.value) {
		nextTick(() => inputRef.value?.focus());
	}
}

watch(activeIndex, (newVal) => {
	if (newVal === 0) {
		nextTick(() => inputRef.value?.focus());
	}
});

onMounted(() => window.addEventListener("keydown", handleKeyDown));
onUnmounted(() => window.removeEventListener("keydown", handleKeyDown));
</script>

<template>
  <Transition v-bind="commonTransitionClasses">
    <div v-if="searching" class="backdrop-blur-md fixed w-screen h-screen z-99 bg-black/20" @click="toggleSearch"></div>
  </Transition>

  <Transition enter-active-class="transition-all duration-150 ease-in-out"
    enter-from-class="opacity-0 -translate-y-2 scale-80" enter-to-class="opacity-100 translate-y-0 scale-100"
    leave-active-class="transition-all duration-150 ease-in-out" leave-from-class="opacity-100 translate-y-0 scale-100"
    leave-to-class="opacity-0 -translate-y-2 scale-80">
    <div v-if="searching" class="fixed inset-0 z-100 flex items-start justify-center pt-24" @click.self="toggleSearch">
      <div class="w-full max-w-2xl mx-8 space-y-2 relative">
        <div :class="['rounded-box bg-base-100/80 backdrop-blur-2xl shadow-md', activeIndex === 0 ? 'ring-1 ring-secondary/20' : '']">
          <div class="px-4 py-0">
            <div class="flex flex-row items-center space-x-2">
              <MaterialSymbolsSearch class="text-md" />
              <input ref="inputRef" v-model="query" type="text"
                class="input w-full focus:border-none focus:outline-none bg-transparent p-0"
                placeholder="Search TaskTurtles" spellcheck="true" />
            </div>
          </div>
        </div>
        <Transition enter-active-class="transition-all duration-150 ease-in-out"
          enter-from-class="opacity-0 -translate-y-2 scale-80" enter-to-class="opacity-100 translate-y-0 scale-100"
          leave-active-class="transition-all duration-150 ease-in-out"
          leave-from-class="opacity-100 translate-y-0 scale-100" leave-to-class="opacity-0 -translate-y-2 scale-80">
          <CommandList v-if="!shouldBeHidden.suggestions" commandType="suggestions"
            :commands="filteredCommands.suggestions" @select="handleCommandSelect"
            :activeCommandId="activeCommand ? activeCommand.id : null" />
        </Transition>
      </div>
    </div>
  </Transition>
</template>