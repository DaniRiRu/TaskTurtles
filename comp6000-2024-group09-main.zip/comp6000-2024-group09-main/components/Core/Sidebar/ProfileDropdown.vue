<script setup lang="ts">
const signout = useSignout();
const isLoading = ref(false);

const signoutFlow = async () => {
	isLoading.value = true;
	try {
		await signout();
	} catch (error) {
		console.error("Logout error:", error);
	} finally {
		isLoading.value = false;
	}
};
</script>

<template>
  <ul tabindex="0" class="dropdown-content rounded-box bg-secondary/10 backdrop-blur-xl p-2 mb-2 w-full">
    <div class="grid grid-cols-3 gap-2">
      <li>
        <NuxtLink to="/settings/profile"
          class="flex flex-col items-center justify-center p-2 btn btn-ghost h-max outline-none border-none rounded-box w-full">
          <TablerUser class="w-5 h-5 mb-1" />
          <span class="text-xs">Profile</span>
        </NuxtLink>
      </li>

      <li>
        <NuxtLink to="/settings/account"
          class="flex flex-col items-center justify-center p-2 btn btn-ghost h-max outline-none border-none rounded-box w-full">
          <TablerSettings class="w-5 h-5 mb-1" />
          <span class="text-xs">Settings</span>
        </NuxtLink>
      </li>

      <li>
        <button @click="signoutFlow" :disabled="isLoading"
          class="flex flex-col items-center justify-center p-2 btn btn-ghost h-max outline-none border-none rounded-box w-full">
          <TablerLogout v-if="!isLoading" class="w-5 h-5 mb-1" />
          <span v-else class="loading loading-spinner w-5 h-5 mb-1"></span>
          <span class="text-xs">{{ isLoading ? 'Logging out...' : 'Logout' }}</span>
        </button>
      </li>
    </div>
  </ul>
</template>