<script lang="ts" setup>
import IcBaselineAccountCircle from "~icons/ic/baseline-account-circle";
import ProfileDropdown from "./ProfileDropdown.vue";

const user = useCurrentUser();
</script>

<template>
    <div v-if="user" class="dropdown dropdown-top">
        <label tabindex="0" class="btn btn-ghost btn-block text-sm justify-start pl-1">
            <div class="min-w-10 min-h-10 rounded-full flex items-center justify-center">
                <img v-if="user && user.photoURL" :src="user.photoURL" class="rounded-full w-10 h-10 object-cover"
                    referrerpolicy="no-referrer" alt="User" />
                <IcBaselineAccountCircle v-else class="w-10 h-10" />
            </div>
            <div class="text-left ml-1 font-light">
                {{ user?.displayName }}
                <div class="text-xs">
                    {{ user?.email?.split('@')[0] }}
                </div>
            </div>
        </label>
        <ProfileDropdown />
    </div>
</template>