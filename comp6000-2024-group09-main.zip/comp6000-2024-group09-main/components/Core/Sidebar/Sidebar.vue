<script lang="ts" setup>
const route = useRoute();
const { navigationItems } = useNavItems();

const isTauri = useTauri();

const isActive = (path: string) => {
	return route.path === path || route.path.startsWith(path);
};

const groupedNavItems = computed(() => {
	const items = Object.entries(navigationItems.value);
	const result: { key: string; item: NavItem; children: NavItem[] }[] = [];

	for (const [key, item] of items) {
		const children: NavItem[] = [];
		result.push({
			key,
			item,
			children,
		});
	}

	return result;
});
</script>

<template>
    <div class="flex flex-col h-full justify-between w-64 bg-base-100/80 backdrop-blur-2xl shadow-sm overflow-y-auto" :class="{ 'rounded-box': !isTauri, 'px-1 pt-3 border-base-300/40 border-r': isTauri }">
        <div class="h-full flex flex-col justify-between my-2">
            <div class="space-y-1">
                <h1 class="text-xl font-base mt-4 mx-4">
                    TaskTurtles
                    <CoreNavbarSidebarToggle class="flex md:hidden float-right -mt-3 text-sm" />
                </h1>

                <ul class="menu rounded-box w-full space-y-0.5">
                    <template v-for="group in groupedNavItems" :key="group.key">
                        <li v-if="group.children.length > 0" :class="{ 'active': isActive(group.item.to) }">
                            <details open>
                                <summary class="pl-2">
                                    <component
                                        :is="isActive(group.item.to) ? group.item.selectedIcon : group.item.icon" />
                                    {{ group.item.label }}
                                </summary>
                                <ul class="space-y-0.5 mt-0.5">
                                    <li v-for="child in group.children" :key="child.to">
                                        <router-link class="px-2" :to="child.to" :class="{ 'active': isActive(child.to) }">
                                            {{ child.label }}
                                        </router-link>
                                    </li>
                                </ul>
                            </details>
                        </li>

                        <li v-else>
                            <router-link class="px-2" :to="group.item.to" :class="{ 'active': isActive(group.item.to) }">
                                <component :is="isActive(group.item.to) ? group.item.selectedIcon : group.item.icon" />
                                {{ group.item.label }}
                            </router-link>
                        </li>
                    </template>
                </ul>
            </div>
            <CoreSidebarUserProfile class="mx-2" />
        </div>
    </div>
</template>