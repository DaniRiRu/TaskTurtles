<template>
	<button :class="[
		'btn',
		'group relative flex items-center gap-2',
		'normal-case rounded-full hover:scale-105 transition-transform',
		variant === 'primary'
			? 'btn-primary hover:btn-primary-focus'
			: 'btn-ghost hover:btn-ghost-focus',
		className
	]" @click="onClick">
		<span class="relative z-10 flex items-center gap-2">
			<component v-if="leftIcon && iconMap[leftIcon]" :is="iconMap[leftIcon]"
				class="w-4 h-4 transition-transform duration-300 group-hover:-translate-x-0.5" />
			{{ text }}
			<component v-if="rightIcon && iconMap[rightIcon]" :is="iconMap[rightIcon]"
				class="w-4 h-4 transition-transform duration-300 group-hover:translate-x-0.5" />
		</span>
	</button>
</template>

<script setup>
const { iconMap } = useIcons();

defineProps({
	text: {
		type: String,
		required: true,
	},
	variant: {
		type: String,
		default: "primary",
		validator: (value) => ["primary", "ghost"].includes(value),
	},
	leftIcon: {
		type: String,
		default: "",
	},
	rightIcon: {
		type: String,
		default: "",
	},
	className: {
		type: String,
		default: "",
	},
	onClick: {
		type: Function,
		default: () => {},
	},
});
</script>