<script lang="ts" setup>
import { useAccountActions } from "~/composables/account/useAccountActions";
import { useAccountFields } from "~/composables/account/useAccountFields";
import { useAccountForm } from "~/composables/account/useAccountForm";
import { ModalPosition } from "~/enums/frontend/modal/ModalPosition";
import { genderOptions } from "~/types/schemas/user";

const user = useCurrentUser();
const accountStore = useAccountStore();

const { formFields } = useAccountFields();
const {
	formData,
	formErrors,
	touchedFields,
	editedFields,
	hasUnsavedChanges,
	isSaving,
	showSaveSuccess,
	isValid,
	validateForm,
	resetData,
} = useAccountForm(accountStore);

const {
	confirmPassword,
	passwordError,
	isProcessing,
	verifyPassword,
	saveChanges,
	deleteAccount,
} = useAccountActions();

const isOpenDeleteModal = ref(false);
const isOpenClearModal = ref(false);

const clearAllData = async () => {
	if (!(await verifyPassword())) return;

	formData.value = {
		name: "",
		gender: "",
		dob: new Date(),
		occupation: "",
		weeklyHours: 0,
	};
	isOpenClearModal.value = false;
	confirmPassword.value = "";
	validateForm();
};

const handleSaveChanges = () => {
	saveChanges(
		formData.value,
		validateForm,
		isSaving,
		showSaveSuccess,
		hasUnsavedChanges,
		editedFields,
	);
};
</script>

<template>
	<div class="flex justify-between items-center">
		<div class="flex flex-col mb-4">
			<h2 class="text-2xl font-bold">Account Settings</h2>
			<p class="text-base text-base-content/70">
				View and update your account information.
			</p>
		</div>
		<span v-if="hasUnsavedChanges" class="text-sm font-normal text-warning mb-4">Unsaved changes</span>
	</div>
	<div class="space-y-4">
		<div class="relative p-4 space-y-3 shadow-md bg-base-100 rounded-box">
			<h3 class="flex items-center justify-between pb-1 pl-2 my-2 text-xl font-semibold">
				<span>Personal Information</span>
			</h3>
			<div class="flex flex-col space-y-3">
				<div v-for="field in formFields" :key="field.key" class="flex flex-col w-full">
					<div class="flex flex-row items-center w-full space-x-3 transition border rounded-btn bg-base-200/50 group border-base-200 hover:border-secondary/20 hover:bg-base-200/40 focus-within:border-secondary/20 focus-within:bg-base-200/40"
						:class="{
							'border-error': formErrors[field.key],
						}">
						<div class="w-40 py-2 ml-4 overflow-hidden font-medium text-md">
							{{ field.label }}
						</div>
						<div class="py-2 divider divider-horizontal"></div>
						<template v-if="field.key === 'gender'">
							<div class="w-full dropdown">
								<div tabindex="0" role="button"
									class="h-12 flex items-center !bg-transparent shadow-none hover:!bg-transparent focus-within:bg-transparent border-0 text-left p-2 w-full flex justify-between items-center">
									<span>{{
										formData.gender
											? formData.gender.charAt(0).toUpperCase() +
											formData.gender.slice(1)
											: "Select Gender"
									}}</span>
									<MaterialSymbolsArrowDropDown class="w-6 h-6" />
								</div>
								<ul tabindex="0"
									class="dropdown-content z-[1] menu p-2 shadow bg-base-100/80 rounded-box w-52 backdrop-blur-xl">
									<li v-for="option in genderOptions" :key="option" @click="formData.gender = option"
										class="p-2 rounded cursor-pointer hover:bg-base-200">
										{{ option.charAt(0).toUpperCase() + option.slice(1) }}
									</li>
								</ul>
							</div>
						</template>
						<template v-else>
							<input :type="field.type" :placeholder="field.placeholder"
								v-model="(formData as any)[field.key]" :min="field.type === 'number' ? 0 : undefined"
								:max="field.type === 'number' ? 168 : undefined"
								class="w-full h-12 p-2 bg-transparent border-0 ring-0 outline-0 rounded-btn" />
						</template>
					</div>
					<span v-if="formErrors[field.key]" class="mt-1 ml-2 text-sm text-error">
						{{ formErrors[field.key] }}
					</span>
				</div>
			</div>
		</div>
		<div class="p-4 border border-red-500 shadow-md bg-base-100 rounded-box">
			<h3 class="pb-1 text-xl font-semibold text-red-500">Danger Zone</h3>
			<p class="text-sm text-base-content">
				Clear stored data or delete your account permanently. These actions are
				irreversible.
			</p>
			<div class="flex mt-4 space-x-3">
				<button @click="isOpenClearModal = true" class="w-full py-2 text-white bg-red-500 border-0 rounded-box">
					Clear All Data
				</button>
				<button @click="isOpenDeleteModal = true"
					class="w-full py-2 text-white bg-red-500 border-0 rounded-box">
					Delete Account
				</button>
			</div>
		</div>
		<div class="flex justify-end">
			<button v-if="hasUnsavedChanges" @click="resetData" class="btn btn-ghost">
				Reset
			</button>
			<button @click="handleSaveChanges" :disabled="!hasUnsavedChanges || isSaving || !isValid" class="btn"
				:class="[
					hasUnsavedChanges && isValid ? 'btn-primary' : 'btn-disabled',
					{ loading: isSaving },
				]">
				{{ isSaving ? "Saving..." : "Save Changes" }}
			</button>
		</div>
	</div>
	<div v-if="showSaveSuccess"
		class="absolute px-4 py-2 transition-all duration-300 transform translate-y-0 shadow-lg opacity-100 rounded-box top-2 right-4 bg-success text-success-content">
		Changes saved successfully!
	</div>

	<UniversalModal :is-open="isOpenClearModal" :position="ModalPosition.Middle" @close="isOpenClearModal = false">
		<template #title>
			<h3 class="mb-4 text-xl font-bold">Clear Data</h3>
		</template>
		<template v-if="user?.providerData[0]?.providerId === 'password'">
			<p class="mb-4">Please enter your password to confirm data clearing:</p>
			<input type="password" v-model="confirmPassword" placeholder="Enter your password"
				class="w-full input input-bordered" />
		</template>
		<template v-else-if="user?.providerData[0]?.providerId === 'google.com'">
			<p class="mb-4">Please authenticate with Google to confirm data clearing:</p>
		</template>
		<p v-if="passwordError" class="mt-2 text-sm text-error">{{ passwordError }}</p>
		<div class="flex justify-end gap-3 mt-6">
			<button @click="clearAllData" :disabled="isProcessing" class="btn btn-error"
				:class="{ loading: isProcessing }">
				Clear
			</button>
			<button @click="isOpenClearModal = false" class="btn btn-ghost">Cancel</button>
		</div>
	</UniversalModal>

	<UniversalModal :is-open="isOpenDeleteModal" :position="ModalPosition.Middle" @close="isOpenDeleteModal = false">
		<template #title>
			<h3 class="mb-4 text-xl font-bold">Delete Account</h3>
		</template>
		<template v-if="user?.providerData[0]?.providerId === 'password'">
			<p class="mb-4">Please enter your password to confirm account deletion:</p>
			<input type="password" v-model="confirmPassword" placeholder="Enter your password"
				class="w-full input input-bordered" />
		</template>
		<template v-else-if="user?.providerData[0]?.providerId === 'google.com'">
			<p class="mb-4">Please authenticate with Google to confirm account deletion:</p>
		</template>
		<p v-if="passwordError" class="mt-2 text-sm text-error">{{ passwordError }}</p>
		<div class="flex justify-end gap-3 mt-6">
			<button @click="deleteAccount" :disabled="isProcessing" class="btn btn-error"
				:class="{ loading: isProcessing }">
				Delete Account
			</button>
			<button @click="isOpenDeleteModal = false" class="btn btn-ghost">Cancel</button>
		</div>
	</UniversalModal>
</template>
