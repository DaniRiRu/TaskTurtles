<script lang="ts" setup>
const billingPlans = [
	{
		name: "Free",
		price: 0,
		features: [
			"Limited Tasks and Quests",
			"Basic Calendar",
			"Basic Habit Tracking and Journal",
			"Limited access to TurtleAssistant",
		],
		selected: true,
	},
	{
		name: "Basic",
		price: 9.99,
		features: [
			"Unlimited Tasks and Quests",
			"Automatic Calendar",
			"Advanced Habit Tracking",
			"Insightful Journal",
			"Basic Insights",
			"Three Monthly Skill Trees",
		],
		selected: false,
	},
	{
		name: "Pro",
		price: 19.99,
		features: [
			"Unlimited Tasks and Quests",
			"Self-reorganising Calendar",
			"Insightful Journal",
			"Advanced Habit Tracking",
			"Advanced Insights",
			"Unlimited Skill Trees",
		],
		selected: false,
	},
];

const handlePlanSelect = async (planName: string) => {
	alert(`You selected the ${planName} plan!`);
};
</script>

<template>
  <div class="flex flex-col text-base-content">
    <div class="mb-4">
      <h2 class="text-2xl font-bold">Billing & Subscriptions</h2>
      <p class="text-base text-base-content/70">
        Choose a plan that best suits your needs. You can upgrade, downgrade, or cancel at any time.
      </p>
    </div>

    <div class="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
      <div v-for="plan in billingPlans" :key="plan.name"
        class="h-full transition-all duration-200 duration-300 border shadow-sm border-secondary/10 hover:border-secondary/20 rounded-box hover:shadow-lg hover:scale-101 hover:md:scale-102 bg-base-100"
        :class="{ 'border-2 !border-secondary hover:!border-primary': plan.selected }">
        <div class="card card-border border-base-300 bg-gradient-to-br from-secondary/5 to-60%">
          <div class="justify-between p-6 card-body">
            <div class="flex flex-col gap-4 h-72">
              <div class="flex flex-col">
                <h4 class="font-bold tracking-wide opacity-50">{{ plan.name }}</h4>
                <div>
                  <span class="text-4xl font-black">£{{ plan.price }}</span>
                  <span class="opacity-50">/month</span>
                </div>
              </div>
              <div class="flex flex-col text-sm">
                <div v-for="feature in plan.features" :key="feature" class="flex items-center gap-2 pb-2">
                  <MaterialSymbolsCheckCircle class="w-5 h-5 text-success" />
                  {{ feature }}
                </div>
              </div>
            </div>
            <button @click="handlePlanSelect(plan.name)" class="btn btn-secondary"
              :class="{ 'btn-disabled': plan.selected }">
              {{ plan.selected ? 'Current Plan' : 'Buy Now' }}
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>