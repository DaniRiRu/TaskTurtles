<script setup lang="ts">
import { ModalPosition } from "~/enums/frontend/modal/ModalPosition";
import type { StoredUser } from "~/types/core/user";
import type { FormField } from "~/types/frontend/settings";
import MaterialSymbolsAddPhotoAlternate from "~icons/material-symbols/add-photo-alternate";
import MaterialSymbolsGifBox from "~icons/material-symbols/gif-box";
import ProfileActions from "./ProfileActions.vue";
import ProfileAvatarDecorations from "./ProfileAvatarDecorations.vue";
import ProfileForm from "./ProfileForm.vue";
import ProfileHeader from "./ProfileHeader.vue";

const backend = useBackend();
const user = useCurrentUser();

const state = reactive({
	formData: { username: "", pronouns: "", bio: "" },
	initialFormState: { username: "", pronouns: "", bio: "" },
	bannerColor: "#000000",
	activeModal: null as string | null,
	isSaving: false,
	isValid: true,
	initialLoad: true,
	hasUnsavedChanges: false,
});

const MODALS = {
	ADD_BADGES: "addBadges",
	PROFILE_EFFECT: "profileEffect",
	REMOVE_EFFECT: "removeEffect",
	REMOVE_IMAGE: "removeImage",
	SELECT_IMAGE: "selectImage",
};

const formFields: FormField[] = [
	{
		label: "Username",
		key: "username",
		type: "text",
		placeholder: "Choose a unique username",
	},
	{
		label: "Pronouns",
		key: "pronouns",
		type: "text",
		placeholder: "Your preferred pronouns",
	},
	{
		label: "Bio",
		key: "bio",
		type: "text",
		placeholder: "Tell us about yourself",
	},
];

const imageOptions = [
	{ icon: MaterialSymbolsAddPhotoAlternate, text: "Upload Image" },
	{ icon: MaterialSymbolsGifBox, text: "Choose GIF" },
];

const userProfile = computed(() => ({
	avatarUrl: user.value?.photoURL || "/default-avatar.png",
	username: user.value?.displayName || state.formData.username || "Username",
	pronouns: state.formData.pronouns || "he/him",
	bio: state.formData.bio || "",
}));

const { data: accountData, refresh } = useAsyncData(
	"accountData",
	async () => {
		const userData = (await backend.account.get()) as StoredUser;
		if (user.value && userData && !("error" in userData)) {
			state.formData = {
				username: userData.username || "",
				pronouns: userData.pronouns || "",
				bio: userData.bio || "",
			};
			state.bannerColor = userData.bannerColor || "#000000";
			state.initialFormState = { ...state.formData };
		}
		nextTick(() => {
			state.initialLoad = false;
			validateForm();
		});
		return userData;
	},
	{ server: false },
);

function validateForm() {
	state.isValid = Boolean(
		state.formData.username && state.formData.username.length >= 3,
	);
	return state.isValid;
}

interface ModalStateAction {
	action?: "open" | "close";
	type: (typeof MODALS)[keyof typeof MODALS] | null;
}

function handleModal(
	type: ModalStateAction["type"],
	action: ModalStateAction["action"] = "open",
): void {
	state.activeModal = action === "open" ? type : null;
}

async function handleRemoveImage() {
	try {
		await backend.account.update({ avatarUrl: "/default-avatar.png" });
		await refresh();
		handleModal(null);
	} catch (error) {
		console.error("Failed to remove image:", error);
	}
}

async function saveChanges() {
	if (!validateForm()) return;
	state.isSaving = true;
	try {
		await backend.account.update({
			username: state.formData.username,
			pronouns: state.formData.pronouns,
			bio: state.formData.bio,
			bannerColor: state.bannerColor,
			avatarUrl: userProfile.value.avatarUrl,
		});
		state.initialFormState = { ...state.formData };
		state.hasUnsavedChanges = false;
		await refresh();
	} catch (error) {
		console.error("Failed to save changes:", error);
	} finally {
		state.isSaving = false;
	}
}

function resetData() {
	state.formData = { ...state.initialFormState };
	state.bannerColor = accountData.value?.bannerColor || "#000000";
	state.hasUnsavedChanges = false;
	validateForm();
}

function updateFormData(newData: Record<string, string>) {
	state.formData = { ...state.formData, ...newData };
}

watch(
	[() => state.formData, () => state.bannerColor],
	([newFormData, newBannerColor]) => {
		if (state.initialLoad) return;
		validateForm();
		const formDataChanged = Object.entries(newFormData).some(
			([key, value]) =>
				value !==
				state.initialFormState[key as keyof typeof state.initialFormState],
		);
		const bannerColorChanged =
			newBannerColor !== (accountData.value?.bannerColor || "#000000");
		state.hasUnsavedChanges = formDataChanged || bannerColorChanged;
	},
	{ deep: true },
);
</script>

<template>
	<ProfileHeader :has-unsaved-changes="state.hasUnsavedChanges" />

	<div class="grid grid-cols-1 gap-4 xl:grid-cols-2">
		<div class="-mt-4 space-y-4">
			<div class="xl:hidden">
				<SettingsProfilePreview :user-profile="accountData" :banner-color="state.bannerColor" />
			</div>

			<ProfileForm :form-fields="formFields" :form-data="state.formData"
				@update:form-data="updateFormData($event)" />

			<div class="p-4 space-y-3 shadow-md bg-base-100 rounded-box">
				<h3 class="pb-1 pl-2 my-2 text-xl font-semibold">Banner Customisation</h3>
				<SettingsProfileBannerPicker v-model="state.bannerColor" />
			</div>

			<ProfileAvatarDecorations @open-add-badges="handleModal(MODALS.ADD_BADGES)"
				@open-profile-effect="handleModal(MODALS.PROFILE_EFFECT)"
				@open-remove-effect="handleModal(MODALS.REMOVE_EFFECT)" />
		</div>

		<div class="max-xl:hidden">
			<SettingsProfilePreview :user-profile="accountData" :banner-color="state.bannerColor" />
		</div>
	</div>

	<ProfileActions :has-unsaved-changes="state.hasUnsavedChanges" :is-saving="state.isSaving" :is-valid="state.isValid"
		@reset="resetData" @save="saveChanges" />

	<UniversalModal v-for="(modalType, key) in MODALS" :key="key" :is-open="state.activeModal === modalType"
		:position="ModalPosition.Middle" @close="handleModal(null)" class="z-10">
		<template #title>
			<h3 class="text-xl font-semibold capitalize">{{ modalType.replace(/([A-Z])/g, ' $1').trim() }}</h3>
		</template>

		<template v-if="modalType === MODALS.SELECT_IMAGE">
			<div class="grid grid-cols-2 gap-4 mt-4">
				<button v-for="(option, index) in imageOptions" :key="index"
					class="flex flex-col items-center justify-center p-4 transition bg-base-100 rounded-box hover:bg-base-300">
					<div class="flex items-center justify-center w-24 h-24 rounded-full bg-secondary">
						<component :is="option.icon" class="w-12 h-12 text-white" />
					</div>
					<span class="mt-2">{{ option.text }}</span>
				</button>
			</div>
		</template>

		<template v-else-if="modalType === MODALS.REMOVE_IMAGE || modalType === MODALS.REMOVE_EFFECT">
			<div class="mt-4">
				<p class="text-base text-base-content/70">
					Are you sure you want to remove your {{ modalType === MODALS.REMOVE_IMAGE ? 'current avatar' :
						'profile effect' }}?
				</p>
			</div>
			<div class="flex justify-end gap-3 mt-6">
				<button @click="modalType === MODALS.REMOVE_IMAGE ? handleRemoveImage() : handleModal(null)"
					class="btn btn-error">
					Remove
				</button>
				<button @click="handleModal(null)" class="btn btn-ghost">Cancel</button>
			</div>
		</template>

		<template v-else>
			<div class="grid grid-cols-3 gap-4 mt-4">
				<div v-for="i in 3" :key="i"
					class="flex items-center justify-center w-24 h-24 border-2 rounded-full border-base-300">
					<span class="text-sm text-base-content/70">Coming Soon</span>
				</div>
			</div>
			<div class="flex justify-end gap-3 mt-6">
				<button @click="handleModal(modalType)" class="btn btn-primary">
					Add {{ modalType === MODALS.ADD_BADGES ? 'Badge' : 'Effect' }}
				</button>
				<button @click="handleModal(null)" class="btn btn-ghost">Cancel</button>
			</div>
		</template>
	</UniversalModal>
</template>
