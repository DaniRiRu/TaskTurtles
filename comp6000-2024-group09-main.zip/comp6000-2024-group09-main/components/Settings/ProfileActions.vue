<script lang="ts" setup>
defineProps<{
	hasUnsavedChanges: boolean;
	isSaving: boolean;
	isValid: boolean;
}>();

defineEmits<{
	reset: [];
	save: [];
}>();
</script>

<template>
    <div class="flex justify-end gap-3 mt-4">
        <button v-if="hasUnsavedChanges" @click="$emit('reset')" class="btn btn-ghost">
            Reset
        </button>
        <button @click="$emit('save')" :disabled="!hasUnsavedChanges || isSaving || !isValid" class="btn" :class="[
            hasUnsavedChanges && isValid ? 'btn-success' : 'btn-disabled',
            { loading: isSaving }
        ]">
            {{ isSaving ? 'Saving...' : 'Save Changes' }}
        </button>
    </div>
</template>