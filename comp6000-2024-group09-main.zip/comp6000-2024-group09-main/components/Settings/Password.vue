<script lang="ts" setup>
import MaterialSymbolsVisibilityOff from "~icons/material-symbols/visibility-off";
let showCurrentPassword = false;
let showNewPassword = false;
let showConfirmPassword = false;

const togglePasswordVisibility = (field: string) => {
	if (field === "current") {
		showCurrentPassword = !showCurrentPassword;
	} else if (field === "new") {
		showNewPassword = !showNewPassword;
	} else if (field === "confirm") {
		showConfirmPassword = !showConfirmPassword;
	}
};
</script>

<template>
  <div class="flex flex-col space-y-4 bg-base-200 text-base-content">
    <div class="space-y-2">
      <h2 class="text-2xl font-bold">Password</h2>
      <p class="text-base text-base-content/70">
        Please enter your current password if you would like to change your password.
      </p>
      <div class="relative">
        <input 
          :type="showCurrentPassword ? 'text' : 'password'" 
          placeholder="Current Password" 
          class="w-full input input-bordered rounded-xl"
        />
        <button 
          @click="togglePasswordVisibility('current')" 
          class="absolute text-xl transform -translate-y-1/2 right-3 top-1/2 text-base-content/50"
        >
          <MaterialSymbolsVisibilityOff/>
        </button>
      </div>
    </div>

    <div class="space-y-2">
      <h2 class="text-2xl font-bold">New Password</h2>
      <p class="text-base text-base-content/70">
        Please enter your new password.
      </p>
      <div class="relative">
        <input 
          :type="showNewPassword ? 'text' : 'password'" 
          placeholder="New Password" 
          class="w-full input input-bordered rounded-xl"
        />
        <button 
          @click="togglePasswordVisibility('new')" 
          class="absolute text-xl transform -translate-y-1/2 right-3 top-1/2 text-base-content/50"
        >
          <MaterialSymbolsVisibilityOff/>
        </button>
      </div>
    </div>

    <div class="space-y-2">
      <h2 class="text-2xl font-bold">Confirm New Password</h2>
      <p class="text-base text-base-content/70">
        Please re-enter your new password.
      </p>
      <div class="relative">
        <input 
          :type="showConfirmPassword ? 'text' : 'password'" 
          placeholder="Confirm Password" 
          class="w-full input input-bordered rounded-xl"
        />
        <button 
          @click="togglePasswordVisibility('confirm')" 
          class="absolute text-xl transform -translate-y-1/2 right-3 top-1/2 text-base-content/50"
        >
           <MaterialSymbolsVisibilityOff/>
        </button>
      </div>
    </div>

    <div class="flex justify-end space-x-4">
      <button class="flex items-center justify-center px-6 py-3 font-medium text-white rounded-md bg-primary">
        Update Password
      </button>
      <button class="flex items-center justify-center px-6 py-3 font-medium text-white rounded-md bg-error">
        Cancel
      </button>
    </div>
  </div>
</template>
