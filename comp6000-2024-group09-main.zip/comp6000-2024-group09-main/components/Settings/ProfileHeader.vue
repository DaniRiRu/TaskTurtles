<script lang="ts" setup>
defineProps<{
	hasUnsavedChanges: boolean;
}>();
</script>

<template>
    <div class="flex justify-between items-center">
        <div class="flex flex-col mb-4 max-xl:mb-10">
            <h2 class="text-2xl font-bold">Edit Profile</h2>
            <p class="text-base text-base-content/70">
                Customise your profile to stand out and make yourself look awesome!
            </p>
        </div>
        <span v-if="hasUnsavedChanges" class="text-sm font-normal text-warning mb-4">
            Unsaved changes
        </span>
    </div>
</template>