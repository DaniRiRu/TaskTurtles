<script lang="ts" setup>
import type { SendPasswordResetResponse } from "~/types/backend/auth/passwordreset";

const user = useCurrentUser();
const backend = useBackend();

const isLoading = ref(false);
const isSuccess = ref(false);
const errorMessage = ref("");
const showSuccessToast = ref(false);

const sendPasswordReset = async () => {
	try {
		isLoading.value = true;
		errorMessage.value = "";
		const response = (await backend.account.sendPasswordReset({
			email: user.value?.email || "",
		})) as SendPasswordResetResponse;

		if (!response.success) {
			throw new Error("Failed to send reset email");
		}

		if (response.url) {
			open(response.url);
		}

		showSuccessToast.value = true;
		setTimeout(() => {
			showSuccessToast.value = false;
		}, 2000);

		isSuccess.value = true;
	} catch (error) {
		if (error instanceof Error && error.message.includes("403")) {
			errorMessage.value =
				"You've recently requested a password reset. Please wait before trying again.";
		} else {
			errorMessage.value =
				"Failed to send password reset email. Please try again later.";
		}
		isSuccess.value = false;
	} finally {
		isLoading.value = false;
	}
};

const reset = () => {
	isSuccess.value = false;
	errorMessage.value = "";
};
</script>

<template>
  <div class="flex flex-col mb-4">
    <h2 class="text-2xl font-bold">Security Settings</h2>
    <p class="text-base text-base-content/70">
      Manage your account security and password settings.
    </p>
  </div>

  <div class="space-y-4">
    <div class="p-4 space-y-3 shadow-md bg-base-100 rounded-box relative">
      <h3 class="pb-1 pl-2 my-2 text-xl font-semibold">Password Reset</h3>

      <div class="flex flex-col space-y-3">
        <div class="flex flex-col w-full">
          <div
            class="flex flex-row items-center w-full space-x-3 transition border rounded-btn bg-base-200/50 group border-base-200 hover:border-secondary/20 hover:bg-base-200/40 shadow-sm">
            <div class="w-40 py-2 ml-4 overflow-hidden font-medium text-md">
              Email Address
            </div>
            <div class="py-2 divider divider-horizontal"></div>
            <div class="w-full h-12 p-2 flex items-center">
              {{ user?.email }}
            </div>
          </div>
        </div>
      </div>

      <div v-if="errorMessage" class="alert alert-error mt-4">
        <svg xmlns="http://www.w3.org/2000/svg" class="stroke-current shrink-0 h-6 w-6" fill="none" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
            d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <span>{{ errorMessage }}</span>
      </div>

      <div class="flex justify-end gap-3 mt-4">
        <button v-if="isSuccess" @click="reset" class="btn btn-ghost">
          Try Again
        </button>
        <button @click="sendPasswordReset" :disabled="!user?.email || isLoading" class="btn" :class="[
          !isLoading && !errorMessage ? 'btn-primary' : 'btn-disabled',
          { loading: isLoading },
        ]">
          {{ isLoading ? "Sending..." : "Send Reset Link" }}
        </button>
      </div>

      <div v-if="showSuccessToast"
        class="absolute top-4 right-4 bg-success text-success-content px-4 py-2 rounded-lg shadow-lg transform transition-all duration-300 opacity-100 translate-y-0">
        Reset link sent successfully!
      </div>
    </div>

    <div class="p-4 border border-red-500 shadow-md bg-base-100 rounded-box">
      <h3 class="pb-1 text-xl font-semibold text-red-500">Security Notice</h3>
      <p class="text-sm text-base-content">
        For your security, password reset requests are rate limited. If you don't receive the email, please check your
        spam folder before trying again.
      </p>
      <ul class="text-sm text-base-content mt-2 list-disc list-inside">
        <li>Never share your password with anyone</li>
        <li>Use a strong, unique password</li>
        <li>Enable two-factor authentication when possible</li>
      </ul>
    </div>
  </div>
</template>