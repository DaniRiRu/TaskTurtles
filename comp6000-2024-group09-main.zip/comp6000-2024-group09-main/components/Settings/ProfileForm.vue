<script lang="ts" setup>
import type { FormField } from "~/types/frontend/settings";

defineProps<{
	formFields: FormField[];
	formData: Record<string, string>;
}>();

defineEmits<{
	"update:formData": [value: Record<string, string>];
}>();
</script>

<template>
  <div class="relative p-4 space-y-3 shadow-md bg-base-100 rounded-box">
    <h3 class="flex items-center justify-between pb-1 pl-2 my-2 text-xl font-semibold">
      <span>Profile</span>
    </h3>
    <div v-for="field in formFields" :key="field.key"
      class="flex items-center w-full space-x-3 transition border shadow-sm shadow-inner rounded-btn bg-base-200/50 group border-base-200 hover:border-secondary/20 hover:bg-base-200/40">
      <div class="w-32 ml-4 font-medium text-md">{{ field.label }}</div>
      <div class="py-2 divider divider-horizontal"></div>
      <input :type="field.type" class="w-full h-12 p-2 bg-transparent border-0 ring-0 outline-0 rounded-btn"
        :placeholder="field.placeholder" :value="formData[field.key]"
        @input="$emit('update:formData', { ...formData, [field.key]: ($event.target as HTMLInputElement).value })" />
    </div>
  </div>
</template>