<script lang="ts" setup>
import type { InventoryItem } from "~/types/backend/shop/item";
import EntypoLock from "~icons/entypo/lock";
import MdiClose from "~icons/mdi/close";
import MdiFilter from "~icons/mdi/filter";
import MdiMagnify from "~icons/mdi/magnify";
import MdiSort from "~icons/mdi/sort";

const accountStore = useAccountStore();
const theme = useCookie<string>(COOKIE_NAMES.THEME, {
	default: () => DEFAULT_THEME,
});

const { allThemes, themes } = useCustomThemes();
const inventory = ref<InventoryItem[]>([]);
const searchQuery = ref("");
const showOnlyUnlocked = ref(false);
const sortBy = ref("name");
const sortOrder = ref("asc");
const themeCategory = ref("all");

const selectTheme = (t: string) => {
	if (!isThemeUnlocked(t)) return;
	theme.value = t;
};

const getInventory = async () => {
	const backend = useBackend();
	const items = (await backend.shop.fetchInventory()) as InventoryItem[];
	inventory.value = items;
};

const isThemeUnlocked = (themeName: string) => {
	if (themeName === DEFAULT_THEME) return true;
	return inventory.value.some(
		(item) => item.type === "theme" && item.id === themeName,
	);
};

const getThemeCategory = (themeName: string) => {
	const categories = {
		light: ["simplistic", "light", "cupcake", "lemonade", "garden", "pastel"],
		dark: ["dark", "dim", "night", "midnight", "dracula", "synthwave"],
		colorful: ["retro", "cyberpunk", "valentine", "aqua", "rainbow"],
		minimal: ["simple", "minimalist", "clean", "monochrome"],
	};

	const lowerName = themeName.toLowerCase();

	for (const [category, keywords] of Object.entries(categories)) {
		if (keywords.some((keyword) => lowerName.includes(keyword))) {
			return category;
		}
	}
	return "other";
};

const getThemeBackground = (themeName: string) => {
	return (
		customThemes[themeName as keyof typeof customThemes]?.background ||
		undefined
	);
};

const unlockedThemes = computed(() => {
	return allThemes.filter((t) => isThemeUnlocked(t));
});

const filteredThemes = computed(() => {
	let result = allThemes.filter((t) => !isThemeUnlocked(t));

	if (themeCategory.value !== "all") {
		result = result.filter((t) => getThemeCategory(t) === themeCategory.value);
	}

	if (searchQuery.value) {
		const query = searchQuery.value.toLowerCase();
		result = result.filter((t) =>
			t.toLowerCase().replace(/_/g, " ").includes(query),
		);
	}

	if (sortBy.value === "name") {
		result = result.sort((a, b) => {
			const nameA = a.replace(/_/g, " ").toLowerCase();
			const nameB = b.replace(/_/g, " ").toLowerCase();
			return sortOrder.value === "asc"
				? nameA.localeCompare(nameB)
				: nameB.localeCompare(nameA);
		});
	}

	return result;
});

const clearFilters = () => {
	searchQuery.value = "";
	showOnlyUnlocked.value = false;
	themeCategory.value = "all";
	sortBy.value = "name";
	sortOrder.value = "asc";
};

const toggleSortOrder = () => {
	sortOrder.value = sortOrder.value === "asc" ? "desc" : "asc";
};

onMounted(() => {
	getInventory();
});
</script>

<template>
  <div class="flex flex-col mb-4">
    <h2 class="text-2xl font-bold">Appearance</h2>
    <p class="text-base text-base-content/70">
      Customise your TaskTurtles! experience by selecting a theme.
    </p>
  </div>

  <div class="flex flex-col lg:flex-row gap-4 mb-6">
    <div class="relative flex-grow">
      <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
        <MdiMagnify class="w-5 h-5 text-base-content/60" />
      </div>
      <input
        type="text"
        v-model="searchQuery"
        placeholder="Search themes..."
        class="input input-bordered w-full pl-10 pr-10"
      />
      <button 
        v-if="searchQuery" 
        @click="searchQuery = ''" 
        class="absolute inset-y-0 right-0 flex items-center pr-3"
      >
        <MdiClose class="w-5 h-5 text-base-content/60" />
      </button>
    </div>

    <div class="flex gap-2">
      <div class="dropdown dropdown-end">
        <button tabindex="0" class="btn btn-outline gap-2">
          <MdiSort />
          <span class="hidden sm:inline">Sort</span>
        </button>
        <ul tabindex="0" class="dropdown-content z-[1] menu p-2 shadow bg-base-100 rounded-box w-52">
          <li><a @click="sortBy = 'name'; toggleSortOrder()" :class="{'active': sortBy === 'name'}">
            Name ({{ sortOrder === 'asc' ? 'A-Z' : 'Z-A' }})
          </a></li>
        </ul>
      </div>

      <div class="dropdown dropdown-end">
        <button tabindex="0" class="btn btn-outline gap-2">
          <MdiFilter />
          <span class="hidden sm:inline">Filter</span>
        </button>
        <ul tabindex="0" class="dropdown-content z-[1] menu p-2 shadow bg-base-100 rounded-box w-52">
          <li><a @click="themeCategory = 'all'" :class="{'active': themeCategory === 'all'}">All</a></li>
          <li><a @click="themeCategory = 'light'" :class="{'active': themeCategory === 'light'}">Light</a></li>
          <li><a @click="themeCategory = 'dark'" :class="{'active': themeCategory === 'dark'}">Dark</a></li>
          <li><a @click="themeCategory = 'colorful'" :class="{'active': themeCategory === 'colorful'}">Colorful</a></li>
          <li><a @click="themeCategory = 'minimal'" :class="{'active': themeCategory === 'minimal'}">Minimal</a></li>
          <li><a @click="clearFilters" class="text-error">Clear filters</a></li>
        </ul>
      </div>
    </div>
  </div>

  <div class="mb-8">
    <h3 class="text-lg font-semibold mb-4">Your Themes</h3>
    <div class="grid grid-cols-1 xs:grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
      <div 
        v-for="t in unlockedThemes" 
        :key="t" 
        :data-theme="t"
        class="card bg-base-100 hover:shadow-lg transition-all duration-200 cursor-pointer group relative overflow-hidden"
        :class="{ 
          'border-2 border-primary': theme === t,
          'border border-base-300': theme !== t
        }"
        @click="selectTheme(t)"
      >
        <div class="relative h-36">
          <div 
            class="absolute inset-0 bg-gradient-to-br from-base-200 to-base-300 transition-all duration-300 group-hover:scale-105"
          >
            <div 
              v-if="getThemeBackground(t)" 
              class="absolute inset-0"
            >
              <img 
                :src="getThemeBackground(t)" 
                alt="Theme background" 
                class="w-full h-full object-cover opacity-40"
              />
            </div>
          </div>
          
          <div class="absolute inset-0 p-4">
            <div class="flex gap-2 mb-3">
              <div class="w-5 h-5 rounded-full bg-primary shadow-sm"></div>
              <div class="w-5 h-5 rounded-full bg-secondary shadow-sm"></div>
              <div class="w-5 h-5 rounded-full bg-accent shadow-sm"></div>
            </div>
            <div class="space-y-2">
              <div class="w-full h-2 rounded bg-base-content/20"></div>
              <div class="w-3/4 h-2 rounded bg-base-content/10"></div>
            </div>
          </div>
        </div>
          
        <div class="card-body p-3">
          <div class="flex items-center justify-between">
            <h3 class="font-medium text-sm truncate">
              {{ t.split("_").join(" ") }}
            </h3>
            <div v-if="theme === t" class="badge badge-xs badge-primary">Current</div>
          </div>
          
          <div class="mt-2">
            <button 
              class="btn btn-xs w-full"
              :class="theme === t ? 'btn-primary' : 'btn-outline'"
            >
              {{ theme === t ? 'Applied' : 'Apply' }}
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div v-if="filteredThemes.length > 0">
    <h3 class="text-lg font-semibold mb-4">Available Themes</h3>
    <div class="grid grid-cols-1 xs:grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
      <div 
        v-for="t in filteredThemes" 
        :key="t" 
        :data-theme="t"
        class="card bg-base-100 hover:shadow-lg transition-all duration-200 cursor-pointer group relative overflow-hidden opacity-90 hover:opacity-100 border border-base-300"
        @click="selectTheme(t)"
      >
        <div class="relative h-36">
          <div 
            class="absolute inset-0 bg-gradient-to-br from-base-200 to-base-300 transition-all duration-300 group-hover:scale-105"
          >
            <div 
              v-if="getThemeBackground(t)" 
              class="absolute inset-0"
            >
              <img 
                :src="getThemeBackground(t)" 
                alt="Theme background" 
                class="w-full h-full object-cover opacity-40"
              />
            </div>
          </div>
          
          <div class="absolute inset-0 p-4">
            <div class="flex gap-2 mb-3">
              <div class="w-5 h-5 rounded-full bg-primary shadow-sm"></div>
              <div class="w-5 h-5 rounded-full bg-secondary shadow-sm"></div>
              <div class="w-5 h-5 rounded-full bg-accent shadow-sm"></div>
            </div>
            <div class="space-y-2">
              <div class="w-full h-2 rounded bg-base-content/20"></div>
              <div class="w-3/4 h-2 rounded bg-base-content/10"></div>
            </div>
          </div>

          <div class="absolute inset-0 flex items-center justify-center bg-base-100/30 backdrop-blur-[1px]">
            <EntypoLock class="w-8 h-8 text-base-content/70" />
          </div>
        </div>
          
        <div class="card-body p-3">
          <div class="flex items-center justify-between">
            <h3 class="font-medium text-sm truncate">
              {{ t.split("_").join(" ") }}
            </h3>
          </div>
          
          <div class="mt-2">
            <button class="btn btn-outline btn-xs w-full gap-1">
              <EntypoLock class="w-3 h-3" />
              Unlock
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>