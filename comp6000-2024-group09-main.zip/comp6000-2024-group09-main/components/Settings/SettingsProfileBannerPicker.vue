<script setup lang="ts">
const props = defineProps<{
	modelValue: string;
}>();

const emit = defineEmits<{
	"update:modelValue": [value: string];
}>();

const selectedColor = computed({
	get: () => props.modelValue,
	set: (value) => emit("update:modelValue", value),
});

const isOpen = ref(false);

const rgb = reactive({
	r: 0,
	g: 0,
	b: 0,
});

const handleColorChange = (event: Event) => {
	const input = event.target as HTMLInputElement;
	selectedColor.value = input.value;
	updateRGBFromHex(input.value);
};

const updateRGBFromHex = (hex: string) => {
	const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
	if (result) {
		rgb.r = Number.parseInt(result[1], 16);
		rgb.g = Number.parseInt(result[2], 16);
		rgb.b = Number.parseInt(result[3], 16);
	}
};

const updateHexFromRGB = () => {
	const componentToHex = (c: number) => {
		const hex = Math.min(255, Math.max(0, Math.round(c))).toString(16);
		return hex.length === 1 ? `0${hex}` : hex;
	};

	selectedColor.value = `#${componentToHex(rgb.r)}${componentToHex(rgb.g)}${componentToHex(rgb.b)}`;
};

watch(
	() => selectedColor.value,
	(newValue) => {
		updateRGBFromHex(newValue);
	},
);

onMounted(() => {
	updateRGBFromHex(selectedColor.value);
});
</script>

<template>
    <div class="p-4 flex justify-between items-center w-full space-x-3 transition border shadow-sm shadow-inner rounded-btn bg-base-200/50 group border-base-200 hover:border-secondary/20 hover:bg-base-200/40
        ">
        <div class="space-y-4 w-full">
            <div class="flex items-center justify-between">
                <div>
                    <div class="font-medium text-sm">Banner Colour</div>
                    <div class="text-xs text-base-content/70">
                        Choose a colour for your profile banner
                    </div>
                </div>
                <div class="flex items-center space-x-2">
                    <div class="text-xs font-mono">{{ selectedColor.toUpperCase() }}</div>
                    <button @click="isOpen = !isOpen"
                        class="w-6 h-6 border-2 rounded-lg shadow-md cursor-pointer border-base-300 transition-transform hover:scale-110"
                        :style="{ backgroundColor: selectedColor }"></button>
                </div>
            </div>

            <div v-if="isOpen" class="space-y-4 pt-2 overflow-hidden">
                <div class="grid grid-cols-3 gap-4">
                    <div class="space-y-1">
                        <label class="text-xs font-medium">Red</label>
                        <input type="number" v-model.number="rgb.r" min="0" max="255" @input="updateHexFromRGB"
                            class="w-full input input-sm input-bordered" />
                    </div>
                    <div class="space-y-1">
                        <label class="text-xs font-medium">Green</label>
                        <input type="number" v-model.number="rgb.g" min="0" max="255" @input="updateHexFromRGB"
                            class="w-full input input-sm input-bordered" />
                    </div>
                    <div class="space-y-1">
                        <label class="text-xs font-medium">Blue</label>
                        <input type="number" v-model.number="rgb.b" min="0" max="255" @input="updateHexFromRGB"
                            class="w-full input input-sm input-bordered" />
                    </div>
                </div>

                <div class="flex items-center space-x-3">
                    <input type="color" :value="selectedColor" @input="handleColorChange"
                        class="w-full h-8 cursor-pointer rounded-lg" />
                </div>

                <div class="flex items-center justify-between p-3 rounded-lg bg-base-100 border border-base-300">
                    <div class="text-xs">Preview</div>
                    <div class="w-32 h-12 rounded-lg shadow-md transition-all duration-200"
                        :style="{ backgroundColor: selectedColor }"></div>
                </div>
            </div>
        </div>
    </div>
</template>