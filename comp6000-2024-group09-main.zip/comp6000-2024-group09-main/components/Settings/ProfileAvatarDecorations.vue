<script lang="ts" setup>
import MaterialSymbolsAdd from "~icons/material-symbols/add";
import MaterialSymbolsDelete from "~icons/material-symbols/delete";
import MaterialSymbolsEdit from "~icons/material-symbols/edit";

defineEmits<{
	openAddBadges: [];
	openProfileEffect: [];
	openRemoveEffect: [];
}>();
</script>

<template>
    <div class="p-4 space-y-3 shadow-md bg-base-100 rounded-box">
        <h3 class="pb-1 pl-2 my-2 text-xl font-semibold">Avatar Decorations</h3>
        <div class="space-y-4">
            <div
                class="flex items-center w-full p-4 transition border shadow-sm shadow-inner rounded-btn bg-base-200/50 group border-base-200 hover:border-secondary/20 hover:bg-base-200/40">
                <div class="flex items-center justify-between w-full">
                    <div>
                        <div class="font-medium">Profile Badges</div>
                        <div class="text-sm text-base-content/70">Show off your achievements!</div>
                    </div>
                    <div class="flex gap-3">
                        <template v-for="i in 3" :key="i">
                            <div @click="$emit('openAddBadges')"
                                class="flex items-center justify-center w-12 h-12 transition-all duration-200 border-2 border-dashed rounded-full cursor-pointer border-base-300 hover:border-secondary/20 hover:bg-base-200/40 hover:shadow-md">
                                <MaterialSymbolsAdd class="w-6 h-6 text-base-content/50" />
                            </div>
                        </template>
                    </div>
                </div>
            </div>
            <div
                class="flex items-center w-full p-4 transition border shadow-sm shadow-inner rounded-btn bg-base-200/50 group border-base-200 hover:border-secondary/20 hover:bg-base-200/40">
                <div class="flex items-center justify-between w-full">
                    <div>
                        <div class="font-medium">Profile Effects</div>
                        <div class="text-sm text-base-content/70">
                            Add a cool profile effect to your avatar!
                        </div>
                    </div>
                    <div class="space-x-3">
                        <button @click="$emit('openProfileEffect')"
                            class="w-10 h-10 p-0 btn btn-secondary btn-circle min-h-8 min-w-10">
                            <MaterialSymbolsEdit class="w-6 h-6" />
                        </button>
                        <button @click="$emit('openRemoveEffect')"
                            class="w-10 h-10 p-0 btn btn-error btn-circle min-h-10 min-w-10">
                            <MaterialSymbolsDelete class="w-6 h-6" />
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>