<script lang="ts" setup>
import MaterialSymbolsCreditCard from "~icons/material-symbols/credit-card";
import MaterialSymbolsEdit from "~icons/material-symbols/edit";
import MaterialSymbolsKey from "~icons/material-symbols/key";
import MaterialSymbolsPalette from "~icons/material-symbols/palette";
import MaterialSymbolsPerson from "~icons/material-symbols/person";

const route = useRoute();

const tabs = [
	{ name: "account", icon: MaterialSymbolsPerson, path: "/settings/account" },
	{ name: "profile", icon: MaterialSymbolsEdit, path: "/settings/profile" },
	{ name: "security", icon: MaterialSymbolsKey, path: "/settings/security" },
	{
		name: "appearance",
		icon: MaterialSymbolsPalette,
		path: "/settings/appearance",
	},
	{
		name: "billing",
		icon: MaterialSymbolsCreditCard,
		path: "/settings/billing",
	},
];

const isActive = (path: string) => route.path === path;
</script>

<template>
	<div class="fixed top-20 z-5 sticky">
		<div
			class="transition-all duration-300 ease-in-out fixed top-0 h-38 left-0 w-full bg-gradient-to-b from-base-200 from-70% z-2">
		</div>
		<div class="sticky flex justify-between mb-8 shadow-sm rounded-btn top-20 bg-base-100 z-5">
			<div class="join">
				<div v-for="tab in tabs" :key="tab.name">
					<NuxtLink :to="tab.path">
						<button class="border-none btn btn-ghost join-item" :class="{
              'btn-active': isActive(tab.path)
            }">
							<component :is="tab.icon" class="w-5 h-5 sm:max-md:hidden" />
							<span class="hidden sm:block">
								{{ tab.name.charAt(0).toUpperCase() + tab.name.slice(1) }}
							</span>
						</button>
					</NuxtLink>
				</div>
			</div>
		</div>
	</div>
</template>