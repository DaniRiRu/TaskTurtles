<script lang="ts" setup>
import type { StoredUser } from "~/types/core/user";

defineProps<{
	userProfile: StoredUser | null;
	bannerColor: string;
}>();

const user = useCurrentUser();

function getMonthAndYear(date: Date) {
	const month = date.toLocaleString("default", { month: "long" });
	const year = date.getFullYear();
	return `${month} ${year}`;
}
</script>

<template>
    <div class="relative flex flex-col rounded-box shadow-md h-full bg-base-100 overflow-hidden">
        <div class="relative flex flex-col h-full overflow-hidden">
            <div class="w-full h-48 md:h-56 lg:h-64 transition-all duration-300"
                :style="{ backgroundColor: bannerColor }">
            </div>
            <div class="relative px-4 sm:px-6 md:px-8 pb-6">
                <div class="absolute -top-16 left-4 sm:left-6 md:left-8">
                    <div class="relative group">
                        <img :src="userProfile?.avatarUrl || '/default-avatar.png'" alt="Profile Picture"
                            class="w-32 h-32 sm:w-36 sm:h-36 md:w-40 md:h-40 rounded-full border-4 border-base-100 shadow-lg object-cover transition-transform duration-200 group-hover:scale-105" />
                        <div
                            class="absolute inset-0 rounded-full border-4 border-secondary/30 scale-110 opacity-0 group-hover:opacity-100 transition-all duration-200">
                        </div>
                    </div>
                </div>
                <div class="absolute top-4 right-4 sm:right-6 md:right-8 flex flex-row space-x-2">
                    <template v-for="i in 3" :key="i">
                        <div
                            class="flex items-center justify-center w-10 h-10 sm:w-12 sm:h-12 md:w-14 md:h-14 transition-all duration-200 rounded-full bg-base-100/95 shadow-sm hover:shadow-md hover:scale-103 hover:bg-base-100 cursor-pointer border border-base-200 backdrop-blur-sm">
                            <MaterialSymbolsAdd class="w-5 h-5 sm:w-6 sm:h-6 md:w-7 md:h-7 text-base-content/80" />
                        </div>
                    </template>
                </div>

                <div class="mt-20 sm:mt-24 md:mt-28 space-y-4">
                    <div class="space-y-1">
                        <h2 class="text-2xl sm:text-3xl md:text-4xl font-bold text-base-content">
                            {{ user?.displayName || 'Name' }}
                        </h2>
                        <div
                            class="flex items-center gap-2 align-middle text-lg sm:text-xl font-medium text-base-content/70">
                            <h3>{{ userProfile?.username || 'Username' }}</h3>
                            •
                            <h4 class="text-lg">{{ userProfile?.pronouns || 'Pronouns' }}</h4>
                        </div>
                    </div>
                    <div class="bg-base-200/50 rounded-xl p-4 sm:p-5 md:p-6 backdrop-blur-sm border border-base-200">
                        <p class="text-base sm:text-lg text-base-content/70">
                            {{ userProfile?.bio || 'Write something about yourself...' }}
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="flex flex-wrap gap-4 m-8 mb-7 justify-between">
            <div class="flex items-center space-x-2 text-base-content/70">
                <span class="text-sm font-medium">Level</span>
                <span class="text-sm">42</span>
            </div>
            <div class="flex items-center space-x-2 text-base-content/70">
                <span class="text-sm font-medium">Joined</span>
                <span class="text-sm">
                    {{ user?.metadata?.creationTime ? getMonthAndYear(new Date(user.metadata.creationTime)) : 'Unknown'
                    }}
                </span>
            </div>
        </div>
    </div>
</template>