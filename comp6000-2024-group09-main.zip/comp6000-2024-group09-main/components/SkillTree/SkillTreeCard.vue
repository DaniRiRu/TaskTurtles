<script lang="ts" setup>
import { useSkillState } from "~/composables/skillTree/useSkillState";

interface SkillCount {
	mastered: number;
	available: number;
	locked: number;
}

const props = defineProps<{
	treeName: string;
	skillCount: SkillCount;
	masteryLevel: string;
	masteryPercentage: number;
}>();

const skillStore = useSkillState();
const currentView = computed(() => skillStore.currentView.value);
</script>

<template>
	<SkillTreeViewsGridView v-if="currentView === 'grid'" v-bind="$props" />
	<SkillTreeViewsListView v-else-if="currentView === 'list'" v-bind="$props" />
	<SkillTreeViewsCompactView v-else-if="currentView === 'compact'" v-bind="$props" />
	<SkillTreeViewsTimeLineView v-else-if="currentView === 'timeline'" v-bind="$props" />
	<SkillTreeViewsCompactCard v-else-if="currentView === 'compactcard'" v-bind="$props" />
</template>