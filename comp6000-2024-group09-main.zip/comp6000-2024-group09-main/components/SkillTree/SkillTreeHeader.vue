<script lang="ts" setup>
import { useSkillTreeManagement } from "~/composables/skillTree/useSkillTreeManagement";
import type { ViewType } from "~/types/skills/views";
import FlowbiteTrashBinSolid from "~icons/flowbite/trash-bin-solid";
import MaterialSymbolsGridViewOutlineRounded from "~icons/material-symbols/grid-view-outline-rounded";
import MaterialSymbolsViewCompactOutline from "~icons/material-symbols/view-compact-outline";
import MaterialSymbolsViewListRounded from "~icons/material-symbols/view-list-rounded";
import MaterialSymbolsViewTimelineOutline from "~icons/material-symbols/view-timeline-outline";
import MingcuteAddFill from "~icons/mingcute/add-fill";
import MynauiTreeSolid from "~icons/mynaui/tree-solid";

const skillStore = useSkillTreeStore();
const { deleteAllSkillTrees } = useSkillTreeManagement();
const isDeleteModalOpen = ref(false);
const searchQuery = ref("");

const onCreateClick = () => {
	skillStore.setCreateModalOpen(true);
};

const onDeleteAllTrees = async () => {
	await deleteAllSkillTrees();
	isDeleteModalOpen.value = false;
	location.reload();
};

const viewOptions = [
	{
		id: "grid" as ViewType,
		icon: MaterialSymbolsGridViewOutlineRounded,
		label: "Grid View",
	},
	{
		id: "list" as ViewType,
		icon: MaterialSymbolsViewListRounded,
		label: "List View",
	},
	{
		id: "compact" as ViewType,
		icon: MaterialSymbolsViewCompactOutline,
		label: "Compact View",
	},
	{
		id: "timeline" as ViewType,
		icon: MaterialSymbolsViewTimelineOutline,
		label: "Timeline View",
	},
	{
		id: "compactcard" as ViewType,
		icon: MynauiTreeSolid,
		label: "Compact Card View",
	},
];
</script>

<template>
  <div class="max-w-3xl mx-auto max-md:mb-4 md:mb-8 lg:mb-12">
    <div
      class="relative group bg-base-200 rounded-2xl shadow-lg transition-all duration-300 hover:shadow-xl border border-base-content/10 hover:border-primary/30">
      <div class="flex items-center gap-0 pr-2">
        <input v-model="searchQuery" type="text" placeholder="Search skills..."
          class="input bg-transparent w-full border-none focus:outline-none h-12 px-4 text-base placeholder:text-base-content/40" />
        <div class="dropdown dropdown-end">
          <label tabindex="0" class="btn btn-sm btn-circle p-0 btn-ghost m-1">
            <component :is="viewOptions.find((v) => v.id === skillStore.currentView)?.icon"
              class="w-5 h-5 text-primary" />
          </label>
          <ul tabindex="0"
            class="dropdown-content z-[1] menu p-2 shadow-lg bg-base-200 rounded-box w-52 border border-base-content/10">
            <li v-for="viewOption in viewOptions" :key="viewOption.id">
              <a @click="skillStore.setCurrentView(viewOption.id)"
                :class="{ active: skillStore.currentView === viewOption.id }">
                <component :is="viewOption.icon" class="w-4 h-4" />
                {{ viewOption.label }}
              </a>
            </li>
          </ul>
        </div>
        <button @click="onCreateClick" class="btn btn-sm btn-circle p-0 btn-ghost mx-1">
          <MingcuteAddFill class="w-5 h-5 text-primary" />
        </button>
        <button @click="isDeleteModalOpen = true" class="btn btn-sm btn-circle btn-error p-0 btn-ghost mx-1">
          <FlowbiteTrashBinSolid class="w-5 h-5 text-primary" />
        </button>
      </div>
    </div>
  </div>

  <input type="checkbox" :checked="isDeleteModalOpen" @change="isDeleteModalOpen = !isDeleteModalOpen"
    class="modal-toggle" />
  <div class="modal" :class="{ 'modal-open': isDeleteModalOpen }">
    <div class="modal-box">
      <h3 class="font-bold text-lg">Delete All Skill Trees</h3>
      <p class="py-4">
        Are you sure you want to delete all skill trees? This action cannot be
        undone.
      </p>
      <div class="modal-action">
        <button @click="isDeleteModalOpen = false" class="btn btn-ghost">
          Cancel
        </button>
        <button @click="onDeleteAllTrees" class="btn btn-error">
          Delete All
        </button>
      </div>
    </div>
    <label class="modal-backdrop" @click="isDeleteModalOpen = false">Close</label>
  </div>
</template>
