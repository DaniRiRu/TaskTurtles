<script lang="ts" setup>
import { useSkillTrees } from "~/composables/skillTree/useSkillTree";
import type { Skill } from "~/types/skills/skill";

const props = defineProps<{
	modelValue: boolean;
	selectedSkill: Skill | null;
	treeId: string;
}>();

const emit = defineEmits<{
	"update:modelValue": [value: boolean];
	close: [];
}>();

const skillTrees = useSkillTrees();
const activeTab = ref<"overview" | "tasks" | "path">("tasks");
const taskStates = ref(new Map());
const pendingUpdates = ref(new Set());

const initializeTaskStates = () => {
	taskStates.value.clear();
	if (props.selectedSkill?.tasks) {
		for (const task of props.selectedSkill.tasks) {
			taskStates.value.set(task.id, task.completed);
		}
	}
};

const handleTaskCompletion = async (taskId: string) => {
	if (!props.selectedSkill?.id) return;

	const newState = !taskStates.value.get(taskId);
	taskStates.value.set(taskId, newState);
	pendingUpdates.value.add(taskId);

	try {
		await skillTrees.updateTaskCompletion(
			props.treeId,
			props.selectedSkill.id,
			taskId,
			newState,
		);
	} catch (error) {
		taskStates.value.set(taskId, !newState);
	} finally {
		pendingUpdates.value.delete(taskId);
	}
};

const completeAllTasks = async () => {
	if (!props.selectedSkill?.tasks) return;

	const updatePromises = props.selectedSkill.tasks.map(async (task) => {
		if (taskStates.value.get(task.id)) return;

		taskStates.value.set(task.id, true);
		pendingUpdates.value.add(task.id);

		try {
			await skillTrees.updateTaskCompletion(
				props.treeId,
				props.selectedSkill?.id!,
				task.id,
				true,
			);
		} catch (error) {
			taskStates.value.set(task.id, false);
		} finally {
			pendingUpdates.value.delete(task.id);
		}
	});

	await Promise.all(updatePromises);
};

const progress = computed(() => {
	if (!props.selectedSkill?.id) return 0;
	const skill = skillTrees.findSkillById(props.treeId, props.selectedSkill.id);
	if (!skill?.tasks?.length) return 0;

	const completedTasks = skill.tasks.filter((task) =>
		taskStates.value.get(task.id),
	).length;
	return (completedTasks / skill.tasks.length) * 100;
});

const skillPath = computed(() => {
	if (!props.selectedSkill?.id) return [];
	return skillTrees.getSkillPath(props.treeId, props.selectedSkill.id);
});

const getSkillLevel = computed(() => {
	if (!props.selectedSkill?.id) return 0;
	const skill = skillTrees.findSkillById(props.treeId, props.selectedSkill.id);
	if (!skill?.tasks?.length) return 0;

	const completedTasks = skill.tasks.filter((task) =>
		taskStates.value.get(task.id),
	).length;
	return (completedTasks / skill.tasks.length) * 100;
});

const areAllTasksCompleted = computed(() => {
	if (!props.selectedSkill?.tasks) return false;
	return props.selectedSkill.tasks.every((task) =>
		taskStates.value.get(task.id),
	);
});

const isTaskPending = (taskId: string) => pendingUpdates.value.has(taskId);

const handleClose = () => {
	emit("close");
};

watch(
	() => props.selectedSkill,
	(newSkill) => {
		if (newSkill) {
			initializeTaskStates();
		}
	},
	{ immediate: true },
);
</script>

<template>
  <UniversalSidebar :isOpen="modelValue" @close="handleClose">
    <template #header>
      <div class="w-full ml-4">
        <h1 class="text-lg font-bold text-semibold text-base-content">
          {{ selectedSkill?.name }}
        </h1>
      </div>
    </template>
    <div v-if="modelValue" class="transition-transform duration-300 z-50 overflow-hidden"
      :class="{ 'translate-x-0': modelValue, 'translate-x-full': !modelValue }">
      <div class="h-full flex flex-col">
        <div class="p-6 pb-2">
          <div class="grid grid-cols-2 gap-4 mb-4">
            <div class="bg-base-200 rounded-box border border-base-300 p-4">
              <div class="text-sm text-base-content/70">Mastery Level</div>
              <div class="text-2xl font-bold text-accent mt-1">
                {{ Math.round(getSkillLevel) }}%
              </div>
              <div class="w-full h-1.5 rounded-full bg-base-300 mt-2">
                <div class="h-full rounded-full bg-accent transition-all" :style="{ width: `${getSkillLevel}%` }" />
              </div>
            </div>
            <div class="bg-base-200 rounded-box border border-base-300 p-4">
              <div class="text-sm text-base-content/70">Total Tasks</div>
              <div class="text-2xl font-bold mt-1 text-base-content">
                {{ selectedSkill?.tasks?.length || 0 }}
              </div>
              <div class="text-xs text-base-content/60 mt-2">
                Tasks to master this skill
              </div>
            </div>
          </div>
        </div>

        <div class="px-6">
          <div class="tabs tabs-bordered gap-8 justify-center">
            <a class="tab" :class="{ 'tab-active': activeTab === 'tasks' }" @click="activeTab = 'tasks'">
              Tasks
            </a>
            <a class="tab" :class="{ 'tab-active': activeTab === 'overview' }" @click="activeTab = 'overview'">
              Overview
            </a>
            <a class="tab" :class="{ 'tab-active': activeTab === 'path' }" @click="activeTab = 'path'">
              Path
            </a>
          </div>
        </div>

        <div class="flex-1 overflow-y-auto p-6 pt-4">
          <div v-if="activeTab === 'overview'" class="space-y-4">
            <div class="card bg-base-200 border border-base-300">
              <div class="card-body p-4">
                <h3 class="card-title text-sm text-base-content">About this Skill</h3>
                <p class="text-base-content/70">{{ selectedSkill?.description }}</p>
              </div>
            </div>

            <div class="card bg-base-200 border border-base-300">
              <div class="card-body p-4">
                <h3 class="card-title text-sm text-base-content">Prerequisites</h3>
                <div class="flex flex-wrap gap-3 mt-1">
                  <template v-if="skillPath.length > 1">
                    <div v-for="prereq in skillPath.slice(0, -1)" :key="prereq.id"
                      class="px-2 py-1 rounded-badge text-sm border border-accent">
                      {{ prereq.name }}
                    </div>
                  </template>
                  <div v-else class="badge badge-ghost">None</div>
                </div>
              </div>
            </div>
          </div>

          <div v-if="activeTab === 'tasks'" class="space-y-3">
            <div class="flex justify-end mb-4">
              <button v-if="!areAllTasksCompleted" @click="completeAllTasks" class="btn btn-sm btn-accent"
                :class="{ 'btn-disabled': pendingUpdates.size > 0 }">
                Complete All
              </button>
            </div>
            <button v-for="task in props.selectedSkill?.tasks" :key="task.id" @click="handleTaskCompletion(task.id)"
              class="w-full group text-left bg-base-200 hover:bg-base-300 p-4 rounded-box border border-base-300 transition-all duration-200"
              :class="{ 'cursor-wait': isTaskPending(task.id) }">
              <div :class="{ 'opacity-50': taskStates.get(task.id) }">
                <div class="flex items-center justify-between">
                  <h3 class="font-medium text-base-content">
                    {{ task.name }}
                  </h3>
                  <div v-if="taskStates.get(task.id)"
                    class="rounded-badge flex items-center p-1 px-2 gap-1 bg-accent text-xs text-accent-content">
                    {{ isTaskPending(task.id) ? "Saving..." : "Completed" }}
                    <MaterialSymbolsCheck v-if="!isTaskPending(task.id)" class="w-4 h-4" />
                  </div>
                </div>
                <p class="text-base-content/60 mt-1.5 text-sm">
                  {{ task.description }}
                </p>

                <div class="flex items-center gap-2 mt-3 pt-2 border-t border-base-300">
                  <div class="rounded-full flex items-center px-2 py-0.5 gap-1 bg-base-100 text-xs text-base-content">
                    {{ task.difficulty }}
                  </div>
                  <div class="text-xs text-base-content/60">
                    Click to mark as
                    {{ taskStates.get(task.id) ? "incomplete" : "complete" }}
                  </div>
                </div>
              </div>
            </button>
          </div>

          <div v-if="activeTab === 'path'" class="space-y-4">
            <div v-for="(skill, index) in skillPath" :key="skill.id" class="card bg-base-200 border border-base-300">
              <div class="card-body p-4">
                <div class="flex items-center gap-4">
                  <div class="w-8 h-8 rounded-lg bg-base-300 flex items-center justify-center font-bold">
                    {{ index + 1 }}
                  </div>
                  <div class="flex-1">
                    <h3 class="font-medium text-base-content">{{ skill.name }}</h3>
                    <p class="text-sm text-base-content/60 mt-1">
                      {{ skill.description }}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </UniversalSidebar>
</template>