<script setup lang="ts">
import {
	breakpointsTailwind,
	useBreakpoints,
	useDebounceFn,
	useElementSize,
	useRafFn,
} from "@vueuse/core";
import { useSkillTrees } from "~/composables/skillTree/useSkillTree";
import type { Skill } from "~/types/skills/skill";

interface Props {
	treeName: string;
	skills: Skill[];
	onSkillClick: (skill: Skill) => void;
}

const props = defineProps<Props>();
const skillTreesStore = useSkillTrees();
const containerRef = ref<HTMLDivElement | null>(null);
const hoveredSkill = useState<Skill | null>("hoveredSkill", () => null);
const nodeRefs = ref(new Map<string, HTMLElement>());
const isReady = ref(false);
const { width: containerWidth, height: containerHeight } =
	useElementSize(containerRef);
const { connections, svgViewBox, updateNodeRef, queueConnectionUpdate } =
	useConnectionManager(containerRef);

watch(
	[containerWidth, containerHeight],
	() => {
		if (isReady.value) {
			requestAnimationFrame(() => {
				queueConnectionUpdate(props.skills, isSkillCompleted);
			});
		}
	},
	{ immediate: true },
);

const availableSkills = computed(() => {
	return skillTreesStore.getAvailableSkills(props.treeName);
});

const isSkillAvailable = (skill: Skill) => {
	return availableSkills.value.some(
		(availableSkill) => availableSkill.id === skill.id,
	);
};

const breakpoints = useBreakpoints(breakpointsTailwind);
const mobileMode = breakpoints.smaller("md");

const isSkillCompleted = (skill: Skill) => {
	return (skill.tasks ?? []).every((task) => task.completed);
};

const getSkillDepth = (skill: Skill, visited = new Set<string>()): number => {
	if (!skill.id || visited.has(skill.id)) return 0;
	visited.add(skill.id);
	if (skill.prerequisites.length === 0) return 0;
	return Math.max(
		...skill.prerequisites.map((prereqId) => {
			const prereq = props.skills.find((s) => s.id === prereqId);
			return prereq ? getSkillDepth(prereq, visited) + 1 : 0;
		}),
	);
};

const calculateSkillProgress = (skill: Skill): number => {
	const skillDepths = props.skills.map((s) => getSkillDepth(s));
	const totalDepth = Math.max(...skillDepths);
	if (totalDepth === 0) return 0;
	return (getSkillDepth(skill) / totalDepth) * 100;
};

const organizeSkillsByLevel = (skills: Skill[]): Map<number, Skill[]> => {
	const levels = new Map<number, Skill[]>();
	const depthMap = new Map(
		skills.map((skill) => [skill.id, getSkillDepth(skill)]),
	);

	for (const skill of skills) {
		const depth = depthMap.get(skill.id) ?? 0;
		const levelSkills = levels.get(depth) ?? [];
		levelSkills.push(skill);
		levels.set(depth, levelSkills);
	}

	for (const [depth, levelSkills] of levels.entries()) {
		levelSkills.sort((a, b) => a.position - b.position);
		levels.set(depth, levelSkills);
	}

	return new Map([...levels.entries()].sort((a, b) => a[0] - b[0]));
};

const skillLevels = computed(() => {
	return organizeSkillsByLevel(props.skills);
});

const skillLevelPairs = computed(() => {
	const pairs = [];
	const levels = Array.from(skillLevels.value.entries());

	for (let i = 0; i < levels.length; i += 2) {
		const pair = [levels[i]];
		if (i + 1 < levels.length) {
			pair.push(levels[i + 1]);
		}
		pairs.push(pair);
	}

	return pairs;
});

const updateConnections = () => {
	if (!isReady.value) return;
	requestAnimationFrame(() => {
		queueConnectionUpdate(props.skills, isSkillCompleted);
	});
};

const handleNodeRef = (el: HTMLElement | null, skill: Skill) => {
	if (!skill.id) return;
	if (el) {
		nodeRefs.value.set(skill.id, el);
		updateNodeRef(el, skill.id);
	} else {
		nodeRefs.value.delete(skill.id);
	}
	if (nodeRefs.value.size === props.skills.length && !isReady.value) {
		isReady.value = true;
		nextTick(updateConnections);
	}
};

const handleResize = useDebounceFn(() => {
	if (isReady.value) {
		updateConnections();
	}
}, 0);

const rafControl = useRafFn(
	() => {
		if (isReady.value) updateConnections();
	},
	{ immediate: true },
);

onMounted(() => {
	window.addEventListener("resize", handleResize);
	nextTick(updateConnections);
});

onUnmounted(() => {
	window.removeEventListener("resize", handleResize);
	rafControl.pause();
	nodeRefs.value.clear();
	isReady.value = false;
});

watch(
	() => props.skills.map((skill) => skill.tasks?.map((task) => task.completed)),
	updateConnections,
	{ deep: true, immediate: true },
);
watch(() => props.skills, updateConnections, { deep: true, immediate: true });

const handleSkillClick = (skill: Skill) => {
	if (isSkillAvailable(skill)) {
		props.onSkillClick(skill);
	}
};
</script>

<template>
	<div class="-mx-7 -mt-28" v-if="mobileMode">
		<div ref="containerRef" class="h-screen relative overflow-x-auto">
			<div
				class="fixed left-0 top-0 h-full w-16 z-2 pointer-events-none bg-gradient-to-r from-base-200 to-transparent">
			</div>

			<div
				class="fixed right-0 top-0 h-full w-16 z-2 pointer-events-none bg-gradient-to-l from-base-200 to-transparent">
			</div>

			<div class="absolute top-0 left-0 h-full pl-7 pr-4 pt-8">
				<svg class="fixed top-0 left-0 w-full h-full pointer-events-none"
					:class="[isReady ? 'translate-y-0 opacity-100' : 'translate-y-2 opacity-0']" :viewBox="svgViewBox"
					preserveAspectRatio="xMidYMid meet">
					<defs>
						<linearGradient id="activeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
							<stop offset="0%" class="text-primary" style="stop-color: currentColor; stop-opacity: 1" />
							<stop offset="100%" class="text-primary-focus"
								style="stop-color: currentColor; stop-opacity: 1" />
						</linearGradient>
					</defs>
					<g vector-effect="non-scaling-stroke">
						<path v-for="(connection, index) in connections" :key="index" :d="connection.path" fill="none"
							:class="[connection.isUnlocked ? 'stroke-2 stroke-secondary/20' : 'stroke-2 stroke-base-content/10']"
							:style="{ filter: 'drop-shadow(0 1px 2px rgb(0 0 0 / 0.1))' }" stroke-dasharray="8 4">
						</path>
					</g>
				</svg>

				<div class="flex flex-row h-full">
					<div v-for="[level, skillsInLevel] in skillLevels" :key="level"
						class="flex flex-col justify-center items-center p-4 gap-8 md:gap-12 md:w-52 transition-all duration-300 transform-gpu">
						<SkillTreeSkillTreeCanvasSkillNode v-for="skill in skillsInLevel" :key="skill.id" :skill="skill"
							:tree-name="treeName" :percentage_towards_the_end="calculateSkillProgress(skill)"
							:font-size="'clamp(0.75rem, 0.875vw, 1rem)'" :icon-size="'clamp(1rem, 1.25vw, 1.5rem)'"
							:is-available="isSkillAvailable(skill)" :is-completed="isSkillCompleted(skill)" :parents="skill.prerequisites.map(id => ({
								id,
								isCompleted: isSkillCompleted(props.skills.find(s => s.id === id)!)
							}))" class="transform-gpu" @node-ref="(el) => handleNodeRef(el, skill)" @click="handleSkillClick(skill)"
							@mouseenter="hoveredSkill = skill" @mouseleave="hoveredSkill = null" />
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="flex relative w-full h-full min-h-screen flex-col justify-start items-center gap-12 -mt-4 mb-12"
		v-if="!mobileMode" ref="containerRef">
		<svg class="absolute top-0 left-0 w-full h-full pointer-events-none transition-all duration-300"
			:class="[isReady ? 'translate-y-0 opacity-100' : 'translate-y-2 opacity-0']" :viewBox="svgViewBox"
			preserveAspectRatio="xMidYMid meet">
			<defs>
				<linearGradient id="activeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
					<stop offset="0%" class="text-primary" style="stop-color: currentColor; stop-opacity: 1" />
					<stop offset="100%" class="text-primary-focus" style="stop-color: currentColor; stop-opacity: 1" />
				</linearGradient>
			</defs>
			<g vector-effect="non-scaling-stroke">
				<path v-for="(connection, index) in connections" :key="index" :d="connection.path" fill="none" :class="[
					connection.isUnlocked ? 'stroke-2 stroke-secondary/20' : 'stroke-2 stroke-base-content/10'
				]" :style="{ filter: 'drop-shadow(0 1px 2px rgb(0 0 0 / 0.1))' }" stroke-dasharray="8 4">
				</path>
			</g>
		</svg>

		<div v-for="[level, skillsInLevel] in skillLevels" :key="level"
			class="flex flex-wrap justify-center items-center w-full gap-12">
			<SkillTreeSkillTreeCanvasSkillNode v-for="skill in skillsInLevel" :key="skill.id" :skill="skill"
				:tree-name="treeName" :percentage_towards_the_end="calculateSkillProgress(skill)"
				:font-size="'clamp(0.875rem, 1vw, 1.125rem)'" :icon-size="'clamp(1.25rem, 1.5vw, 1.875rem)'"
				:is-available="isSkillAvailable(skill)" :is-completed="isSkillCompleted(skill)"
				:parents="skill.prerequisites.map(id => ({ id, isCompleted: isSkillCompleted(props.skills.find(s => s.id === id)!) }))"
				@node-ref="(el) => handleNodeRef(el, skill)" @click="handleSkillClick(skill)"
				@mouseenter="hoveredSkill = skill" @mouseleave="hoveredSkill = null" />
		</div>
	</div>
</template>
