<script setup lang="ts">
import { useRevealState } from "~/composables/skillTree/useRevealState";
import { useSkillTreeManagement } from "~/composables/skillTree/useSkillTreeManagement";
import type { Skill } from "~/types/skills/skill";

const { revealSkill } = useSkillTreeManagement();
const { isRevealing } = useRevealState();

const props = defineProps<{
	treeName: string;
	skill: Skill;
	percentage_towards_the_end: number;
	fontSize: string;
	iconSize: string;
	isAvailable: boolean;
	isCompleted: boolean;
	parents: { id: string; isCompleted: boolean }[];
	onNodeRef?: (el: HTMLElement | null) => void;
	onClick?: () => void;
	onMouseEnter?: () => void;
	onMouseLeave?: () => void;
}>();

const nodeRef = ref<HTMLElement | null>(null);
const isVisible = ref(false);
const wasUnlocked = ref(false);
const isRevealing_ = ref(false);
const hasAttemptedReveal = ref(false);
const showRetry = ref(false);
const revealTimeout = ref<NodeJS.Timeout | null>(null);
const retryAttempts = ref(0);
const maxRetries = 3;
const errorMessage = ref("");
const isInQueue = ref(false);
const queueStartTime = ref(Date.now());
const loadingProgress = ref(0);
const loadingInterval = ref<NodeJS.Timeout | undefined>(undefined);

const isLoadingState = computed(() => {
	return (
		props.isAvailable &&
		(!props.skill.revealed || props.skill.name.includes(">"))
	);
});

const startLoadingAnimation = () => {
	if (loadingInterval.value) clearInterval(loadingInterval.value);
	loadingProgress.value = 0;
	loadingInterval.value = setInterval(() => {
		loadingProgress.value += 1;
		if (loadingProgress.value >= 100) clearInterval(loadingInterval.value);
	}, 80);
};

const startRetryTimer = () => {
	if (revealTimeout.value) clearTimeout(revealTimeout.value);
	revealTimeout.value = setTimeout(() => {
		if (isLoadingState.value) {
			showRetry.value = true;
			isRevealing_.value = false;
			if (loadingInterval.value) clearInterval(loadingInterval.value);
		}
	}, 10000);
};

const revealSkillOnce = async () => {
	if (
		isRevealing_.value ||
		!props.skill.id ||
		props.skill.revealed ||
		!isLoadingState.value ||
		!props.isAvailable ||
		retryAttempts.value >= maxRetries ||
		isRevealing(props.skill.id)
	) {
		return;
	}

	try {
		isRevealing_.value = true;
		hasAttemptedReveal.value = true;
		showRetry.value = false;
		errorMessage.value = "";
		if (!isInQueue.value) queueStartTime.value = Date.now();
		isInQueue.value = false;
		startRetryTimer();
		startLoadingAnimation();

		await revealSkill(props.treeName, props.skill.id);
		retryAttempts.value = 0;
	} catch (error) {
		console.error("Error revealing skill:", error);
		if (error instanceof Error && error.message.includes("Too many skills")) {
			isInQueue.value = true;
			setTimeout(() => revealSkillOnce(), 1000);
		} else {
			errorMessage.value =
				error instanceof Error ? error.message : "Unknown error";
			retryAttempts.value++;
			showRetry.value = true;
			if (retryAttempts.value < maxRetries) {
				setTimeout(() => revealSkillOnce(), 2000);
			}
		}
	} finally {
		isRevealing_.value = false;
	}
};

onMounted(() => {
	if (isLoadingState.value && props.isAvailable && !hasAttemptedReveal.value) {
		revealSkillOnce();
	}
});

watch(
	() => props.isAvailable,
	(newValue) => {
		if (newValue && isLoadingState.value && !hasAttemptedReveal.value) {
			revealSkillOnce();
		}
	},
);

const skillProgress = computed(() => {
	if (!props.skill.tasks?.length) return { value: 0, completed: 0, total: 0 };
	const total = props.skill.tasks.length;
	const completed = props.skill.tasks.filter((t) => t.completed).length;
	const value = total > 0 ? (completed / total) * 100 : 0;
	return { value, completed, total };
});

const nodeClasses = computed(() => {
	const baseClasses = [
		"relative group p-4",
		"transition-all duration-200",
		"rounded-2xl",
		"border-2",
		"transform hover:scale-102 aspect-square",
		isVisible.value ? "translate-y-0 opacity-100" : "translate-y-2 opacity-0",
	];

	if (!isLoadingState.value && props.isAvailable)
		baseClasses.push("cursor-pointer");

	if (!props.isAvailable) {
		baseClasses.push(
			"bg-base-300/90 border-base-content/20 hover:border-base-content/30 hover:bg-base-300/80",
		);
	} else if (isLoadingState.value) {
		baseClasses.push(
			"bg-neutral/80 border-neutral-content/30 hover:border-neutral-content/40 hover:bg-neutral/90",
		);
	} else if (props.isCompleted) {
		baseClasses.push(
			"bg-primary/10 border-primary/20 hover:border-primary/60 hover:bg-primary/20",
		);
	} else {
		baseClasses.push(
			"bg-secondary/5 border-secondary/10 hover:border-secondary/60 hover:bg-secondary/10",
		);
	}

	return baseClasses.join(" ");
});

const textClasses = computed(() => {
	if (!props.isAvailable) return "text-base-content/70";
	if (isLoadingState.value) return "text-neutral-content/80";
	return props.isCompleted ? "text-base-content" : "text-base-content";
});

const handleClick = () => {
	if (props.isAvailable && !isLoadingState.value && props.onClick) {
		props.onClick();
	} else if (showRetry.value && isLoadingState.value) {
		hasAttemptedReveal.value = false;
		revealSkillOnce();
	}
};

watch(
	() => props.isAvailable,
	(newValue) => {
		if (!wasUnlocked.value && newValue) wasUnlocked.value = true;
		if (newValue && isLoadingState.value && !hasAttemptedReveal.value)
			revealSkillOnce();
	},
);

watch(nodeRef, (el) => {
	props.onNodeRef?.(el);
});

onMounted(() => {
	setTimeout(() => {
		isVisible.value = true;
	}, 100);
});

onBeforeUnmount(() => {
	if (revealTimeout.value) {
		clearTimeout(revealTimeout.value);
	}
	if (loadingInterval.value) {
		clearInterval(loadingInterval.value);
	}
});
</script>

<template>
	<div ref="nodeRef" class="aspect-square " style="width: 160px;" @click="handleClick">
		<div :class="nodeClasses" class="w-full h-full backdrop-blur-xl">
			<div class="h-full w-full flex flex-col items-center justify-between">
				<template v-if="!isAvailable">
					<div class="flex-1 flex flex-col items-center justify-center gap-3">
						<div class="relative flex items-center justify-center w-12 h-12 rounded-xl bg-base-content/10">
							<i class="ri-lock-2-line text-2xl text-base-content/50" />
							<div
								class="absolute inset-0 bg-gradient-to-b from-transparent to-base-content/10 rounded-xl" />
						</div>
						<div class="relative">
							<span class="text-base font-medium text-center blur-sm select-none text-base-content/50">
								{{ skill.name }}
							</span>
							<div class="absolute inset-0 flex items-center justify-center">
								<span class="text-base font-medium text-base-content/60">???</span>
							</div>
						</div>
						<div class="flex gap-1 mt-2">
							<div v-for="prereq in parents" :key="prereq.id" class="w-2 h-2 rounded-full"
								:class="prereq.isCompleted ? 'bg-primary/50' : 'bg-base-content/20'" />
						</div>
					</div>
				</template>

				<template v-else-if="isLoadingState">
					<div class="flex-1 flex flex-col items-center justify-center gap-3">
						<div class="relative">
							<div v-if="isInQueue"
								class="w-12 h-12 rounded-xl bg-base-content/10 flex items-center justify-center">
								<div class="relative w-8 h-8 animate-spin">
									<div class="absolute inset-0">
										<div
											class="h-full w-full rounded-full border-4 border-neutral-content/5 border-t-neutral-content/40" />
									</div>
								</div>
							</div>
							<div v-else-if="!showRetry"
								class="relative w-12 h-12 rounded-xl overflow-hidden bg-neutral-content/5">
								<div class="absolute inset-0 flex items-center justify-center">
									<div
										class="w-8 h-8 rounded-full border-4 border-neutral-content/20 border-t-neutral-content/60 animate-spin" />
								</div>
							</div>
							<div v-else
								class="w-12 h-12 rounded-xl bg-base-content/10 flex items-center justify-center cursor-pointer hover:bg-base-content/20 transition-colors">
								<TablerReload class="text-neutral-content/80 w-6 h-6 animate-pulse" />
							</div>
						</div>
						<div v-if="isInQueue" class="text-base font-semibold text-neutral-content/80 animate-pulse">In
							Queue
						</div>
						<div v-else-if="errorMessage" class="text-xs font-medium text-error">{{ errorMessage }}</div>
						<div v-else class="w-full flex flex-col items-center gap-1">
							<div class="relative w-24 h-2 rounded-full bg-neutral-content/5 overflow-hidden">
								<div class="absolute left-0 top-0 bottom-0 bg-neutral-content/30 transition-all duration-100"
									:style="{ width: `${loadingProgress}%` }" />
							</div>
							<span class="text-xs text-neutral-content/60">Revealing {{ loadingProgress }}%</span>
						</div>
					</div>
				</template>

				<template v-else>
					<div class="flex-1 flex flex-col items-center justify-center gap-4">
						<div class="relative">
							<span class="text-3xl md:text-4xl" :class="textClasses">{{ skill.icon }}</span>
							<div v-if="skillProgress.total > 0"
								class="absolute -bottom-1 -right-1 flex items-center justify-center min-w-[1.5rem] h-5 px-1.5 py-2 rounded-full border text-xs backdrop-blur-sm"
								:class="[props.isCompleted ? 'bg-primary/90 border-primary-content/60' : 'bg-secondary/90 border-secondary-content/60']">
								<span class="text-sm font-bold" :class="textClasses">
									{{ skillProgress.completed }}/{{ skillProgress.total }}
								</span>
							</div>
						</div>

						<h3 class="font-semibold tracking-tight text-center leading-tight" :class="textClasses">
							{{ skill.name }}
						</h3>
					</div>
				</template>
			</div>

			<div v-if="wasUnlocked && isAvailable && !isLoadingState"
				class="absolute inset-0 -z-10 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 backdrop-blur-sm"
				:class="props.isCompleted ? 'bg-primary/20' : 'bg-secondary/20'" />
		</div>
	</div>
</template>