<script lang="ts" setup>
import { useSkillTrees } from "~/composables/skillTree/useSkillTree";
import { useSkillTreeManagement } from "~/composables/skillTree/useSkillTreeManagement";
import { ModalPosition } from "~/enums/frontend/modal/ModalPosition";

const modelValue = defineModel<boolean>({ default: false });

const props = defineProps<{
	treeName: string;
}>();

const { getTreeCompletion } = useSkillTrees();
const { deleteSkillTree, updateTreeDetails, resetTreeProgress } =
	useSkillTreeManagement();

const router = useRouter();
const activeTab = ref("general");
const dialogRef = ref(false);
const deleteDialogRef = ref(false);
const treeNameEdit = ref("");
const treeIcon = ref("");
const responseMessage = ref("");
const isSuccess = ref(false);

const treeCompletion = computed(() => {
	return Math.round(getTreeCompletion(props.treeName));
});

const showResponse = (message: string, success: boolean) => {
	responseMessage.value = message;
	isSuccess.value = success;
	setTimeout(() => {
		responseMessage.value = "";
	}, 3000);
};

const handleReset = () => {
	dialogRef.value = true;
};
const handleDeleteConfirm = () => {
	deleteDialogRef.value = true;
};

const confirmReset = async () => {
	try {
		await resetTreeProgress(props.treeName);
		dialogRef.value = false;
		showResponse("Progress has been reset successfully", true);
		modelValue.value = false;
	} catch (error) {
		showResponse("Failed to reset progress", false);
	}
};

const handleDelete = async () => {
	try {
		await deleteSkillTree(props.treeName);
		deleteDialogRef.value = false;
		showResponse("Tree deleted successfully", true);
		router.push("/skills");
	} catch (error) {
		showResponse("Failed to delete tree", false);
	}
};

const updateTreeName = async () => {
	try {
		const updatedName = treeNameEdit.value.trim();
		if (!updatedName) return;

		await updateTreeDetails(props.treeName, {
			name: updatedName,
			icon: treeIcon.value,
		});
		showResponse(`Tree Name updated to ${updatedName}`, true);
		router.push(`/skills/${updatedName}`);
	} catch (error) {
		showResponse("Failed to update tree details", false);
	}
};

onMounted(() => {
	treeNameEdit.value = props.treeName;
});
</script>

<template>
  <UniversalModal :is-open="modelValue" :position="ModalPosition.Middle" @close="modelValue = false">
    <div v-if="responseMessage" class="absolute top-6 left-1/2 transform -translate-x-1/2">
      <div class="alert shadow-lg"
        :class="isSuccess ? 'alert-success text-success-content' : 'alert-error text-error-content'">
        <span class="font-medium">{{ responseMessage }}</span>
      </div>
    </div>

    <div class="flex flex-col md:flex-row -m-6 h-96 md:h-128">
      <div class="md:hidden w-full p-4 border-b border-base-300">
        <div class="flex justify-between items-center gap-4">
          <div class="flex items-center gap-3">
            <div class="radial-progress text-primary bg-secondary/10"
              :style="{ '--value': treeCompletion, '--size': '2rem', '--thickness': '4px', '--cap': 'round' }">
            </div>
            <div class="flex flex-col">
              <span class="text-lg font-semibold text-primary -mb-0.5">{{ treeCompletion }}%</span>
              <span class="text-xs text-base-content/60 -mt-0.5">Complete</span>
            </div>
          </div>
          <div class="dropdown dropdown-end mr-12">
            <button tabindex="0" class="btn btn-sm h-10 gap-2">
              {{ activeTab.charAt(0).toUpperCase() + activeTab.slice(1) }}
            </button>
            <ul tabindex="0" class="dropdown-content z-1 menu p-2 shadow bg-base-200 rounded-box w-52">
              <li><a @click="activeTab = 'general'">General</a></li>
              <li><a @click="activeTab = 'danger'" class="text-error">Danger</a></li>
            </ul>
          </div>
        </div>
      </div>

      <div class="hidden md:block w-56 bg-base-200/50 backdrop-blur-md p-4 rounded-l-box border-r border-base-300">
        <div class="mb-4">
          <div class="mt-2 flex items-center gap-3">
            <div class="radial-progress text-primary bg-secondary/10"
              :style="{ '--value': treeCompletion, '--size': '2rem', '--thickness': '4px', '--cap': 'round' }">
            </div>
            <div class="flex flex-col">
              <span class="text-lg font-semibold text-primary -mb-0.5">{{ treeCompletion }}%</span>
              <span class="text-xs text-base-content/60 -mt-0.5">Complete</span>
            </div>
          </div>
        </div>

        <div class="space-y-1">
          <button v-for="tab in ['general', 'danger']" :key="tab" @click="activeTab = tab"
            class="w-full px-4 py-2 rounded-box text-left font-medium transition-all duration-200 flex items-center gap-3"
            :class="activeTab === tab ?
              'bg-primary/10 text-primary shadow-sm' :
              'hover:bg-base-300/50 bg-transparent text-base-content/70 hover:text-base-content'">
            <MynauiTreeSolid v-if="tab === 'general'" class="w-5 h-5" />
            <MaterialSymbolsWarningRounded v-if="tab === 'danger'" class="w-5 h-5" />
            {{ tab.charAt(0).toUpperCase() + tab.slice(1) }}
          </button>
        </div>
      </div>

      <div class="flex-1 p-4 pt-0 md:p-6 overflow-y-auto">
        <div v-if="activeTab === 'general'" class="flex flex-col h-full justify-between">
          <div class="space-y-2">
            <h3 class="text-xl md:text-2xl font-bold text-base-content hidden md:block">General</h3>
            <div class="form-control">
              <label class="label">
                <span class="label-text font-medium">Tree Name</span>
              </label>
              <input v-model="treeNameEdit" type="text" class="input input-bordered bg-base-200/50 focus:bg-base-200"
                placeholder="Enter tree name" />
            </div>

            <div class="form-control">
              <label class="label">
                <span class="label-text font-medium">Icon URL</span>
              </label>
              <input v-model="treeIcon" type="text" class="input input-bordered bg-base-200/50 focus:bg-base-200"
                placeholder="Icon URL" />
            </div>
          </div>
          <button class="btn btn-primary w-full mt-4" @click="updateTreeName" :disabled="!treeNameEdit">
            Save Changes
          </button>
        </div>

        <div v-if="activeTab === 'danger'" class="flex flex-col h-full justify-between">
          <div class="space-y-2">
            <h3 class="text-xl md:text-2xl font-bold text-error hidden md:block">Danger</h3>

            <div class="form-control">
              <label class="label flex flex-col items-start">
                <span class="label-text font-medium">Reset Progress</span>
                <span class="label-text-alt text-base-content/70">This will reset all progress in this skill tree</span>
              </label>
              <div class="flex items-center gap-4">
                <button class="btn btn-error w-full" @click="handleReset">
                  Reset
                </button>
              </div>
            </div>

            <div class="form-control mt-6">
              <label class="label flex flex-col items-start">
                <span class="label-text font-medium">Delete Tree</span>
                <span class="label-text-alt text-base-content/70">This will permanently delete this skill tree</span>
              </label>
              <div class="flex items-center gap-4">
                <button class="btn btn-error w-full" @click="handleDeleteConfirm">
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <UniversalModal :is-open="dialogRef" :position="ModalPosition.Middle" @close="dialogRef = false">
      <div class="p-6 space-y-4">
        <h3 class="text-lg font-bold text-error">Confirm Reset</h3>
        <p class="text-base-content/80">Are you sure you want to reset all progress?</p>
        <div class="flex justify-end gap-2">
          <button class="btn btn-ghost" @click="dialogRef = false">Cancel</button>
          <button class="btn btn-error" @click="confirmReset">Reset</button>
        </div>
      </div>
    </UniversalModal>

    <UniversalModal :is-open="deleteDialogRef" :position="ModalPosition.Middle" @close="deleteDialogRef = false">
      <div class="p-6 space-y-4">
        <h3 class="text-lg font-bold text-error">Confirm Deletion</h3>
        <p class="text-base-content/80">Are you sure you want to delete this tree?</p>
        <div class="flex justify-end gap-2">
          <button class="btn btn-ghost" @click="deleteDialogRef = false">Cancel</button>
          <button class="btn btn-error" @click="handleDelete">Delete</button>
        </div>
      </div>
    </UniversalModal>
  </UniversalModal>
</template>