<script lang="ts" setup>
interface SkillCount {
	mastered: number;
	available: number;
	locked: number;
}

const props = defineProps<{
	treeName: string;
	skillCount: SkillCount;
	masteryLevel: string;
	masteryPercentage: number;
}>();
</script>

<template>
    <div class="relative pl-10 group cursor-pointer">
        <div
            class="absolute left-0 top-0 w-4 h-4 rounded-full transition-all duration-300 bg-base-100 ring-2 ring-offset-2 ring-offset-base-100 ring-primary/30 group-hover:ring-primary group-hover:ring-offset-base-200" />
        <div
            class="absolute left-[7px] top-5 max-sm:h-18 h-24 bottom-0 w-0.5 bg-gradient-to-b from-primary/20 to-transparent group-hover:from-primary/40" />

        <div
            class="relative overflow-hidden rounded-2xl shadow-md transition-all duration-300 mb-4 sm:mb-6 bg-gradient-to-br from-primary/3 bg-base-100 border border-secondary/10 group-hover:border-primary/20 group-hover:shadow-lg group-hover:shadow-primary/3">
            <div class="p-4 sm:p-5">
                <div class="flex items-center justify-between mb-2 sm:mb-4">
                    <h3
                        class="text-base sm:text-lg font-bold capitalize tracking-wide transition-colors group-hover:text-primary">
                        {{ treeName }}
                    </h3>
                    <span class="block px-2.5 py-0.5 text-xs font-medium rounded-full bg-primary/10 text-primary">
                        {{ masteryLevel }}
                    </span>
                </div>
                <div class="flex flex-row sm:items-center gap-2 sm:gap-6">
                    <div v-for="(value, type) in skillCount" :key="type" class="flex items-center gap-2">
                        <span class="w-2 h-2 rounded-full" :class="{
                            'bg-primary': type === 'mastered',
                            'bg-base-content/30': type === 'available',
                            'bg-base-content/20': type === 'locked'
                        }" />
                        <div class="flex items-baseline gap-1.5">
                            <span :class="{
                                'text-sm sm:text-base font-semibold text-primary': type === 'mastered',
                                'text-sm sm:text-base font-semibold text-base-content/70': type !== 'mastered'
                            }">
                                {{ value }}
                            </span>
                            <span class="text-xs text-base-content/50 capitalize">
                                {{ type }}
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div
                class="absolute inset-x-0 bottom-0 h-1 bg-gradient-to-r from-primary/0 via-primary to-primary/0 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        </div>
    </div>
</template>