<script lang="ts" setup>
import type { SkillCount } from "~/types/skills/skill";

const props = defineProps<{
	treeName: string;
	skillCount: SkillCount;
	masteryLevel: string;
	masteryPercentage: number;
}>();

const totalSkills = computed(() => {
	return Object.values(props.skillCount).reduce((acc, curr) => acc + curr, 0);
});
</script>

<template>
    <div
        class="group relative flex items-center gap-5 p-4 rounded-xl transition-all duration-300 ease-in-out cursor-pointer">
        <div
            class="absolute inset-0 bg-gradient-to-br from-primary/3 bg-base-100 rounded-2xl border border-secondary/10 transition-all duration-300 group-hover:border-primary/20 shadow-md group-hover:shadow-lg group-hover:shadow-primary/3" />
        <div class="relative flex items-center w-full gap-5 justify-between">
            <div class="flex items-center gap-3">
                <h3
                    class="text-base font-semibold capitalize tracking-wide transition-colors duration-300 group-hover:text-primary">
                    {{ treeName }}
                </h3>
                <span class="px-2.5 py-0.5 text-xs font-medium rounded-full bg-primary/10 text-primary">
                    {{ masteryLevel }}
                </span>
            </div>
            <div class="flex items-center gap-2">
                <span class="text-sm font-semibold text-primary">
                    {{ skillCount.mastered }}
                </span>
                <span class="text-xs text-base-content/60">/</span>
                <span class="text-sm text-base-content/60">
                    {{ totalSkills }}
                </span>
            </div>
        </div>
        <div
            class="absolute right-3 opacity-0 transform translate-x-2 transition-all duration-300 group-hover:opacity-100 group-hover:translate-x-0">
            <Icon name="heroicons:chevron-right" class="w-5 h-5 text-primary" />
        </div>
    </div>
</template>