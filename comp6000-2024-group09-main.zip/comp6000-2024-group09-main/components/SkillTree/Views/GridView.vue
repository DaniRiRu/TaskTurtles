<script lang="ts" setup>
import type { SkillCount } from "~/types/skills/skill";

const props = defineProps<{
	treeName: string;
	skillCount: SkillCount;
	masteryLevel: string;
	masteryPercentage: number;
}>();

const formattedPercentage = computed(() => {
	return Math.min(Math.max(props.masteryPercentage, 0), 100);
});
</script>

<template>
    <div
        class="relative overflow-hidden rounded-2xl shadow-md border border-secondary/10 bg-gradient-to-br from-primary/3 bg-base-100 transition-all duration-300 ease-in-out hover:shadow-lg hover:shadow-primary/3 hover:border-primary/20 group cursor-pointer">
        <div class="p-4 sm:p-6 space-y-4 sm:space-y-6">
            <div class="flex justify-between items-center">
                <h3 class="text-lg sm:text-2xl font-bold tracking-tight group-hover:text-primary transition-colors">
                    {{ treeName }}
                </h3>
                <span
                    class="px-3 sm:px-4 py-1 sm:py-1.5 rounded-full text-xs sm:text-sm font-medium bg-primary/10 text-primary">
                    {{ masteryLevel }}
                </span>
            </div>

            <div class="space-y-2">
                <div class="flex justify-between items-center text-xs sm:text-sm">
                    <span class="text-base-content/60 font-medium">Mastery Progress</span>
                    <span class="text-primary font-semibold">{{ formattedPercentage }}%</span>
                </div>
                <div class="relative h-2 w-full bg-base-300 rounded-full overflow-hidden">
                    <div class="absolute top-0 left-0 h-full bg-primary transition-all duration-500 ease-out"
                        :style="{ width: `${formattedPercentage}%` }" />
                </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-3 gap-2 sm:gap-4">
                <div v-for="(value, type) in skillCount" :key="type"
                    class="flex sm:flex-col items-center justify-between sm:justify-center p-3 sm:p-4 rounded-lg bg-base-300/30 transition-colors hover:bg-primary/5"
                    :class="type === 'mastered' ? 'text-primary' : 'text-base-content'">
                    <span class="text-lg sm:text-2xl font-bold sm:mb-1 order-2 sm:order-1">
                        {{ value }}
                    </span>
                    <span class="text-xs text-base-content/60 capitalize order-1 sm:order-2">{{ type }}</span>
                </div>
            </div>
        </div>

        <div
            class="absolute inset-x-0 bottom-0 h-1 bg-gradient-to-r from-primary/0 via-primary to-primary/0 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
    </div>
</template>