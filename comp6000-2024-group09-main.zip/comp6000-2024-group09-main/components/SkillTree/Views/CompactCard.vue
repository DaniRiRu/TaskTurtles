<script lang="ts" setup>
import type { SkillCount } from "~/types/skills/skill";

const props = defineProps<{
	treeName: string;
	skillCount: SkillCount;
	masteryLevel: string;
	masteryPercentage: number;
}>();

const formattedPercentage = computed(() =>
	Math.min(Math.max(props.masteryPercentage, 0), 100),
);

const isNavigating = ref(false);
const isHovered = ref(false);

const totalSkills = computed(
	() =>
		props.skillCount.mastered +
		props.skillCount.available +
		props.skillCount.locked,
);

const statusColor = computed(() =>
	props.masteryPercentage >= 80
		? "success"
		: props.masteryPercentage >= 50
			? "warning"
			: "error",
);
</script>

<template>
    <div @mouseenter="isHovered = true" @mouseleave="isHovered = false"
        class="relative flex flex-col gap-4 p-4 bg-gradient-to-br from-primary/3 bg-base-100 rounded-2xl shadow-md border border-secondary/10 transition-all duration-300 ease-out hover:scale-[1.02] hover:shadow-lg hover:shadow-primary/10 group cursor-pointer"
        :class="{ 'opacity-75 pointer-events-none': isNavigating }">
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="flex-1 space-y-2">
                <div class="flex flex-wrap items-center gap-2">
                    <h3
                        class="text-sm sm:text-lg font-bold capitalize tracking-wide group-hover:text-primary transition-colors">
                        {{ treeName }}
                    </h3>
                    <div
                        class="px-2 sm:px-3 py-1 text-xs sm:text-sm font-medium rounded-full bg-primary/10 text-primary">
                        {{ masteryLevel }}
                    </div>
                </div>
            </div>

            <div class="flex items-center gap-3">
                <span class="text-xs sm:text-sm font-bold text-primary whitespace-nowrap">
                    {{ formattedPercentage }}%
                </span>
                <div class="relative w-20 sm:w-32 h-2 bg-base-300 rounded-full overflow-hidden">
                    <div class="absolute top-0 left-0 h-full bg-gradient-to-r from-primary/80 to-primary transition-all duration-500 ease-out"
                        :style="{ width: `${masteryPercentage}%` }" />
                </div>
            </div>
        </div>

        <div class="flex gap-2 sm:gap-4">
            <div v-for="(value, key) in skillCount" :key="key"
                class="relative overflow-hidden rounded-xl bg-base-200/50 px-3 py-2 group/stat flex-1">
                <div
                    class="absolute inset-0 bg-primary/5 opacity-0 group-hover/stat:opacity-100 transition-opacity duration-300" />
                <div class="relative z-10">
                    <div class="text-xs sm:text-sm text-base-content/60 capitalize">{{ key }}</div>
                    <div class="text-xs sm:text-sm font-semibold"
                        :class="key === 'mastered' ? 'text-primary' : 'text-base-content/80'">
                        {{ value }}
                    </div>
                </div>
            </div>
        </div>

        <div
            class="absolute inset-x-0 bottom-0 h-1 bg-gradient-to-r from-primary/0 via-primary to-primary/0 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
    </div>
</template>