<script lang="ts" setup>
import type { SkillCount } from "~/types/skills/skill";

const props = defineProps<{
	treeName: string;
	skillCount: SkillCount;
	masteryLevel: string;
	masteryPercentage: number;
}>();

const formattedPercentage = computed(() => {
	return Math.min(Math.max(props.masteryPercentage, 0), 100);
});
</script>

<template>
    <div
        class="relative flex flex-col md:flex-row items-start md:items-center gap-4 md:gap-8 p-4 md:p-6 bg-gradient-to-br from-primary/3 bg-base-100 shadow-md border border-secondary/10 rounded-2xl transition-all duration-300 ease-in-out hover:shadow-lg hover:shadow-primary/3 group cursor-pointer">
        <div class="flex-1 space-y-2 md:space-y-4 w-full">
            <div class="flex flex-wrap items-center gap-2 md:gap-3">
                <h3
                    class="text-lg md:text-xl font-bold capitalize tracking-tight group-hover:text-primary transition-colors">
                    {{ treeName }}
                </h3>
                <span class="px-2 md:px-3 py-1 text-xs md:text-sm font-medium rounded-full bg-primary/10 text-primary">
                    {{ masteryLevel }}
                </span>
            </div>
            <div class="flex flex-wrap gap-4 md:gap-8">
                <div v-for="(stat, type) in skillCount" :key="type"
                    class="flex items-center gap-2 transition-colors hover:text-primary">
                    <span class="text-base-content/60 text-xs md:text-sm capitalize">{{ type }}</span>
                    <span class="text-xs md:text-sm" :class="{
                        'font-semibold text-primary': type === 'mastered',
                        'font-semibold text-base-content': type !== 'mastered'
                    }">
                        {{ stat }}
                    </span>
                </div>
            </div>
        </div>

        <div class="w-full md:w-56 shrink-0">
            <div class="flex justify-between items-center mb-2">
                <span class="text-xs md:text-sm text-base-content/60 font-medium">Mastery</span>
                <span class="text-xs md:text-sm font-semibold text-primary">
                    {{ formattedPercentage }}%
                </span>
            </div>
            <div class="relative h-2 w-full bg-base-300 rounded-full overflow-hidden">
                <div class="absolute top-0 left-0 h-full bg-gradient-to-r from-primary/80 to-primary transition-all duration-500 ease-out"
                    :style="{ width: `${formattedPercentage}%` }" />
            </div>
        </div>

        <div
            class="absolute inset-0 rounded-2xl border border-primary/0 transition-all duration-300 group-hover:border-primary/20" />
        <div
            class="absolute inset-x-0 bottom-0 h-1 bg-gradient-to-r from-primary/0 via-primary to-primary/0 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
    </div>
</template>