<script lang="ts" setup>
import { useSkillState } from "~/composables/skillTree/useSkillState";
import MaterialSymbolsAccountTreeRounded from "~icons/material-symbols/account-tree-rounded";

const skillStore = useSkillState();

const handleCreate = () => {
	skillStore.setCreateModalOpen(true);
};
</script>

<template>
    <ContentUnavailable :image="MaterialSymbolsAccountTreeRounded" title="No Trees Found"
        description="Start your learning journey by creating a new tree" :action="handleCreate"
        actionName="Create New Tree" />
</template>