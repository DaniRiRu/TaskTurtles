<script lang="ts" setup>
import { ModalPosition } from "~/enums/frontend/modal/ModalPosition";
import { useSkillTreeStore } from "~/stores/skilltree";
import type { TreeGenerationConfig } from "~/types/skills/creation";
import IcomoonFreeTree from "~icons/icomoon-free/tree";
import MaterialSymbolsErrorOutline from "~icons/material-symbols/error-outline";
import MaterialSymbolsSettingsOutline from "~icons/material-symbols/settings-outline";
import RiPlantLine from "~icons/ri/plant-line";

const store = useSkillTreeStore();
const { createSkillTree, doesTreeNameExist, getDefaultConfig } =
	useTreeCreation();
const { generateSuggestion, isGenerating: isAiGenerating } = useAiSuggestion();

const goals = ref<string[]>([""]);
const error = ref("");
const isLoading = ref(false);
const selectedSize = ref<"small" | "medium" | "large">("medium");
const config = ref<TreeGenerationConfig>(getDefaultConfig());
const name = ref("");
const currentStep = ref(0);

const steps = [
	{
		title: "What do you want to learn?",
		description:
			"Enter the main skill or topic you want to master. For example: 'Learning Spanish' or 'Web Development'",
	},
	{
		title: "What are your end goals?",
		description:
			"List what you want to achieve by the end. For example: 'Have basic conversations in Spanish' or 'Build a website'",
	},
	{
		title: "Choose your learning path size",
		description: "Select how detailed you want your learning journey to be",
	},
];

const sizeConfigs = {
	small: {
		config: {
			totalStartingSkills: 1,
			maxLevels: 4,
			minSkillsPerLevel: 1,
			maxSkillsPerLevel: 3,
			minDependencies: 1,
			maxDependencies: 2,
			maxDependentsPerSkill: 2,
		},
		title: "Quick Journey",
		description: "2-3 weeks learning path",
		badge: "Beginner",
		badgeClass: "badge-success",
		icon: RiPlantLine,
		iconClass: "text-success",
		bgClass: "bg-success/10",
		features: ["4-6 core skills to learn", "Perfect for single topic mastery"],
	},
	medium: {
		config: {
			totalStartingSkills: 1,
			maxLevels: 7,
			minSkillsPerLevel: 1,
			maxSkillsPerLevel: 3,
			minDependencies: 1,
			maxDependencies: 2,
			maxDependentsPerSkill: 3,
		},
		title: "Standard Journey",
		description: "1-2 months learning path",
		badge: "Balanced",
		badgeClass: "badge-primary",
		icon: IcomoonFreeTree,
		iconClass: "text-primary",
		bgClass: "bg-primary/10",
		features: ["8-12 skills to master", "Comprehensive learning experience"],
	},
	large: {
		config: {
			totalStartingSkills: 1,
			maxLevels: 10,
			minSkillsPerLevel: 1,
			maxSkillsPerLevel: 3,
			minDependencies: 1,
			maxDependencies: 2,
			maxDependentsPerSkill: 4,
		},
		title: "Deep Dive Journey",
		description: "3-6 months learning path",
		badge: "Advanced",
		badgeClass: "badge-warning",
		icon: MaterialSymbolsSettingsOutline,
		iconClass: "text-warning",
		bgClass: "bg-warning/10",
		features: ["15-20 detailed skills", "Complete subject mastery"],
	},
};

const addGoal = () => {
	goals.value.push("");
};

const removeGoal = (index: number) => {
	if (goals.value.length > 1) {
		goals.value = goals.value.filter((_, i) => i !== index);
	}
};

const updateConfigBasedOnSize = () => {
	config.value = sizeConfigs[selectedSize.value].config;
};

const aiSuggest = async () => {
	const title = name.value;

	const suggestion = await generateSuggestion(title).catch((e) => {
		error.value = (e as Error).message;
		return null;
	});

	if (suggestion && "objectives" in suggestion) {
		name.value = suggestion.name;
		goals.value = suggestion.objectives;
	}
};

const closeModal = () => {
	store.setCreateModalOpen(false);
	name.value = "";
	goals.value = [""];
	error.value = "";
	selectedSize.value = "medium";
	currentStep.value = 0;
	updateConfigBasedOnSize();
};

const handleCreate = async () => {
	const trimmedName = name.value?.trim();
	const trimmedGoals = goals.value.map((obj) => obj.trim()).filter(Boolean);

	if (!trimmedName || !trimmedGoals.length) return;

	try {
		isLoading.value = true;
		error.value = "";

		const exists = await doesTreeNameExist(trimmedName);
		if (exists) {
			error.value = "This learning path already exists";
			return;
		}

		const description = `Here are the goals the user wishes to achieve by the end of their learning journey: ${trimmedGoals.join(", ")}`;

		await createSkillTree(trimmedName, description, config.value);
		closeModal();
	} catch (e) {
		error.value = (e as Error).message;
	} finally {
		isLoading.value = false;
	}
};

const nextStep = () => {
	if (currentStep.value < steps.length - 1) {
		currentStep.value++;
	}
};

const prevStep = () => {
	if (currentStep.value > 0) {
		currentStep.value--;
	}
};

const canProceed = computed(() => {
	if (currentStep.value === 0) return name.value.trim().length > 0;
	if (currentStep.value === 1)
		return goals.value.some((goal) => goal.trim().length > 0);
	return true;
});

watch(selectedSize, updateConfigBasedOnSize);

onMounted(updateConfigBasedOnSize);
</script>

<template>
  <UniversalModal :is-open="store.isCreateModalOpen" :position="ModalPosition.Middle" @close="closeModal">
    <ClientOnly>
      <div class="max-h-[90vh] -m-6 p-6 flex flex-col overflow-y-auto">
        <div class="pb-6 flex flex-col gap-3">
          <div class="flex flex-col items-start gap-3 w-full">
            <div class="p-3 rounded-xl bg-primary/10">
              <IcomoonFreeTree class="w-8 h-8 text-primary" />
            </div>
            <h3 class="text-3xl font-bold text-base-content leading-tight">Create Your Learning Journey</h3>
            <p class="text-base-content/70">Let's break down your learning goal into manageable steps</p>
          </div>
        </div>

        <div class="flex items-center gap-2 mb-6">
          <div v-for="(step, index) in steps" :key="index" class="flex items-center">
            <div class="flex items-center gap-2">
              <div :class="[
                'w-8 h-8 rounded-full flex items-center justify-center font-semibold',
                currentStep === index ? 'bg-primary text-primary-content' : 
                currentStep > index ? 'bg-success text-success-content' : 'bg-base-200 text-base-content/70'
              ]">
                {{ index + 1 }}
              </div>
              <div v-if="index < steps.length - 1" class="w-12 h-1" :class="[
                currentStep > index ? 'bg-success' : 'bg-base-200'
              ]" />
            </div>
          </div>
        </div>

        <div v-if="error" class="p-4 mb-6 bg-error/10 rounded-xl text-error flex items-center gap-2">
          <MaterialSymbolsErrorOutline class="w-5 h-5 flex-shrink-0" />
          <p>{{ error }}</p>
        </div>

        <div class="flex flex-col gap-6 max-md:pb-12">
          <div v-show="currentStep === 0" class="flex flex-col gap-4">
            <div class="flex flex-col gap-2">
              <h4 class="text-xl font-bold">{{ steps[0].title }}</h4>
              <p class="text-base-content/70">{{ steps[0].description }}</p>
            </div>
            <input v-model="name" type="text" placeholder="e.g., Learning Spanish, Web Development, Digital Marketing"
              class="input input-bordered w-full" :class="{ 'input-error': error }" />
          </div>

          <div v-show="currentStep === 1" class="flex flex-col gap-4">
            <div class="flex flex-col gap-2">
              <h4 class="text-xl font-bold">{{ steps[1].title }}</h4>
              <p class="text-base-content/70">{{ steps[1].description }}</p>
            </div>

            <div class="flex flex-col gap-2">
              <div v-for="(_, index) in goals" :key="index" class="input input-bordered flex flex-row items-center gap-4">
                <div class="w-6 h-6 -ml-1 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
                  {{ index + 1 }}
                </div>
                <input v-model="goals[index]" type="text" placeholder="e.g., Have basic conversations in Spanish"
                  class="flex-1 bg-transparent border-none focus:outline-none" />
                <button @click="removeGoal(index)"
                  class="btn -mr-2 btn-sm p-0 btn-square btn-ghost text-error border-none hover:bg-error/10">
                  <MaterialSymbolsDeleteOutline class="w-5 h-5" />
                </button>
              </div>
              <div class="flex gap-2">
                <button @click="addGoal" class="btn gap-2 flex-1">
                  <MaterialSymbolsAddRounded class="w-5 h-5" />
                  <span class="font-semibold">Add Another Goal</span>
                </button>
                <button class="btn btn-primary gap-2" :class="{ loading: isAiGenerating }" @click="aiSuggest">
                  <MaterialSymbolsSmartToyOutline v-if="!isAiGenerating" class="w-5 h-5" />
                  {{ isAiGenerating ? "Thinking..." : "AI Suggest" }}
                </button>
              </div>
            </div>
          </div>

          <div v-show="currentStep === 2" class="flex flex-col gap-4">
            <div class="flex flex-col gap-2">
              <h4 class="text-xl font-bold">{{ steps[2].title }}</h4>
              <p class="text-base-content/70">{{ steps[2].description }}</p>
            </div>

            <div class="grid sm:grid-cols-3 gap-4">
              <button v-for="(sizeConfig, size) in sizeConfigs" :key="size"
                class="relative w-full p-4 border-2 rounded-xl transition-all duration-200 hover:scale-101" :class="[
                  selectedSize === size
                    ? 'bg-primary/5 border-primary'
                    : 'bg-base-200/50 border-base-200 hover:border-primary/20'
                ]" @click="selectedSize = size">
                <div class="flex flex-col gap-4">
                  <div :class="['rounded-lg p-4', sizeConfig.bgClass]">
                    <component :is="sizeConfig.icon" class="w-5 h-5" :class="sizeConfig.iconClass" />
                  </div>
                  <div class="flex flex-col gap-2 text-left">
                    <h3 class="text-lg font-medium text-base-content">
                      {{ sizeConfig.title }}
                    </h3>
                    <p class="text-sm text-base-content/60">{{ sizeConfig.description }}</p>
                    <ul class="flex flex-col gap-1">
                      <li v-for="feature in sizeConfig.features" :key="feature"
                        class="flex items-center text-sm text-base-content/60 gap-2">
                        <MaterialSymbolsCheckCircle class="w-4 h-4 text-primary" />
                        {{ feature }}
                      </li>
                    </ul>
                  </div>
                </div>
              </button>
            </div>
          </div>
        </div>

        <div
          class="max-md:fixed bottom-0 max-md:p-6 max-md:w-full max-md:-ml-6 max-md:bg-gradient-to-t max-md:from-base-100 max-md:via-base-100">
          <div class="flex justify-between mt-4">
            <button v-if="currentStep > 0" class="btn btn-sm h-10" @click="prevStep">
              Previous
            </button>
            <div class="flex-1" />
            <button v-if="currentStep < steps.length - 1" class="btn btn-sm h-10 btn-primary" :disabled="!canProceed"
              @click="nextStep">
              Next
            </button>
            <button v-else class="btn btn-sm h-10 btn-primary" :class="{ loading: isLoading }"
              :disabled="isLoading || !canProceed" @click="handleCreate">
              <RiPlantLine v-if="!isLoading" class="w-5 h-5" />
              {{ isLoading ? "Creating..." : "Start Learning Journey" }}
            </button>
          </div>
        </div>
      </div>
    </ClientOnly>
  </UniversalModal>
</template>