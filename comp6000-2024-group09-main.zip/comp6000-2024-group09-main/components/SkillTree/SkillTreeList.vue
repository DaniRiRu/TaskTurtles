<script lang="ts" setup>
import { useSkillMetrics } from "~/composables/skillTree/useSkillTreeMetrics";
import type { SkillTreeData } from "~/types/skills/skill";
import type { ViewType } from "~/types/skills/views";

const props = defineProps<{
	trees: SkillTreeData[];
	currentView: ViewType;
}>();

const router = useRouter();
const { getSkillCount, getMasteryLevel, calculateMasteryPercentage } =
	useSkillMetrics();

const layouts = {
	grid: "grid gap-4 grid-cols-1 md:grid-cols-[repeat(auto-fill,minmax(24rem,1fr))]",
	list: "flex flex-col gap-4",
	compact:
		"grid gap-4 grid-cols-1 sm:grid-cols-[repeat(auto-fill,minmax(22rem,1fr))]",
	timeline: "flex flex-col",
	compactcard:
		"grid gap-4 grid-cols-1 sm:grid-cols-[repeat(auto-fill,minmax(32rem,1fr))]",
} as const;

const layoutClass = computed(() => {
	return `${layouts[props.currentView] || layouts.grid} transition-all duration-300 ease-in-out`;
});

const handleNavigate = (treeName: string) => {
	const currentRoute = router.currentRoute.value.name?.toString();
	router.push(`${currentRoute}/${treeName}`);
};
</script>

<template>
	<div :class="layoutClass">
		<SkillTreeCard v-for="tree in trees" :key="tree.id" :tree-id="tree.id" :tree-name="tree.name"
			:tree-description="tree.description" :current-view="currentView" :skill-count="getSkillCount(tree)"
			:mastery-level="getMasteryLevel(calculateMasteryPercentage(tree))"
			:mastery-percentage="calculateMasteryPercentage(tree)" @click="handleNavigate(tree.name)"
			class="transform transition-all duration-300 ease-in-out hover:scale-103 hover:md:scale-101 motion-safe:hover:scale-102" />
	</div>
</template>