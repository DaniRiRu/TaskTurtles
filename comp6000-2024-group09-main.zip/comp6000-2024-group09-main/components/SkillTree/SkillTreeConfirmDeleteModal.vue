<script lang="ts" setup>
defineProps<{
	isOpen: boolean;
	treeName: string;
}>();

const emit = defineEmits<{
	close: [];
	confirm: [];
}>();
</script>

<template>
    <div v-show="isOpen" class="fixed inset-0 z-50 flex items-center justify-center" role="dialog" aria-modal="true">
        <Transition
            enter-active-class="transition-opacity duration-300"
            enter-from-class="opacity-0"
            enter-to-class="opacity-100"
            leave-active-class="transition-opacity duration-200"
            leave-from-class="opacity-100"
            leave-to-class="opacity-0"
        >
            <div v-show="isOpen" class="fixed inset-0 bg-black/30 backdrop-blur-sm" @click="emit('close')" />
        </Transition>
        
        <Transition
            enter-active-class="transition-all duration-300"
            enter-from-class="opacity-0 scale-95"
            enter-to-class="opacity-100 scale-100"
            leave-active-class="transition-all duration-200"
            leave-from-class="opacity-100 scale-100"
            leave-to-class="opacity-0 scale-95"
        >
            <div v-show="isOpen" class="relative w-full max-w-md rounded-lg bg-base-100 p-6 shadow-xl">
                <h3 class="text-lg font-bold text-error">Delete Skill Tree</h3>
                <p class="py-4">
                    Are you sure you want to delete "{{ treeName }}" skill tree? This action
                    cannot be undone.
                </p>
                <div class="flex justify-end gap-2">
                    <button class="btn btn-ghost" @click="emit('close')">
                        Cancel
                    </button>
                    <button class="btn btn-error" @click="emit('confirm')">
                        Delete
                    </button>
                </div>
            </div>
        </Transition>
    </div>
</template>