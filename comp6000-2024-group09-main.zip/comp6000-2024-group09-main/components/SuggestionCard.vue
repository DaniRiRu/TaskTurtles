<script setup lang="ts">
</script>

<template>
  <div class="rounded-box bg-gradient-to-br from-primary/7 to-secondary/5 backdrop-blur-2xl shadow-md bg-base-100/90 backdrop-blur-2xl ring-1 ring-secondary/20">
    <slot></slot>
  </div>
</template>