<script lang="ts" setup>
import type { Achievement } from "~/types/frontend/achievement";

const props = defineProps<{
	achievement: Achievement;
}>();
</script>

<template>
  <div class="bg-base-100 rounded-box shadow-sm hover:shadow-xl hover:scale-101 transition-all duration-200 p-4">
    <div class="flex flex-col md:flex-row items-start md:space-x-4">
      <div :class="[
        'rounded-full p-2',
        achievement.unlocked ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
      ]">
        <MaterialSymbolsTrophy class="h-5 w-5" />
      </div>
      <div class="flex flex-col w-full items-start mt-4 md:mt-0">
        <h3 class="font-semibold">{{ achievement.title }}</h3>
        <p class="opacity-60 truncate">{{ achievement.description }}</p>
        <div v-if="achievement.unlocked" class="opacity-50 text-xs mt-2">
          Unlocked {{ achievement.unlockedAt }}
        </div>
      </div>
    </div>
    <div v-if="!achievement.unlocked" class="flex items-center justify-between md:ml-13 mt-4 md:mt-2">
      <progress class="progress progress-primary w-full" :value="achievement.progress" :max="achievement.maxProgress"></progress>
    </div>
  </div>
</template>