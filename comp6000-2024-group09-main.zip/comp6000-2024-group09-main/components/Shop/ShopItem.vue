<script setup lang="ts">
import { ModalPosition } from "~/enums/frontend/modal/ModalPosition";
import type { WalletData } from "~/types/backend/meta/wallet";
import type { ShopItem } from "~/types/backend/shop/item";
import Fa6SolidCheck from "~icons/fa6-solid/check";
import Fa6SolidCoins from "~icons/fa6-solid/coins";
import Fa6SolidGem from "~icons/fa6-solid/gem";
import Fa6SolidX from "~icons/fa6-solid/x";
import CursorPreview from "./Cursors/CursorPreview.vue";
import ThemePreview from "./Themes/ThemePreview.vue";

const props = defineProps<{
	isOpen: boolean;
	selectedItem: ShopItem | null;
	wallet: WalletData;
}>();

const emit = defineEmits(["close", "purchase"]);

const item = computed(() => props.selectedItem);

const canAfford = computed(() => {
	if (!item.value) return false;

	const { price } = item.value;

	if (price.coins && props.wallet.coins < price.coins) return false;
	if (price.diamonds && props.wallet.diamonds < price.diamonds) return false;

	return true;
});

const purchaseButtonClasses = computed(() => {
	return canAfford.value ? "btn btn-primary" : "btn btn-disabled";
});

const handlePurchase = () => {
	if (canAfford.value && item.value) {
		emit("purchase", item.value);
	}
};

const closeModal = () => {
	emit("close");
};
</script>

<template>
  <UniversalModal :is-open="isOpen" :position="ModalPosition.Middle" @close="closeModal">
    <template #title>
      <h2 class="text-2xl font-bold mb-4">Item Details</h2>
    </template>

    <div v-if="item" class="space-y-6">
      <div>
        <ThemePreview v-if="item.type === 'theme'" :item="item" preview-only />
        <CursorPreview v-else-if="item.type === 'cursor'" :item="item" preview-only />
        <div v-else class="p-4 rounded-lg bg-base-200">
          <img :src="item.image" :alt="item.name" class="h-48 w-full object-cover rounded-md" />
        </div>
      </div>
      <div class="space-y-3">
        <div class="badge badge-sm badge-outline">{{ item.type }}</div>
        <h3 class="text-xl font-bold">{{ item.name }}</h3>
        <p class="text-base-content/80">{{ item.description }}</p>
      </div>
      <div class="flex items-center gap-3">
        <div v-if="item.price?.coins" class="flex items-center gap-2 bg-base-200 px-3 py-2 rounded-full">
          <span class="font-semibold">{{ item.price.coins }}</span>
          <Fa6SolidCoins class="w-5 h-5 text-yellow-400" />
          <div v-if="item.price.coins > wallet.coins" class="ml-1 badge badge-error badge-sm gap-1">
            <Fa6SolidX class="w-3 h-3" />
            Not enough
          </div>
          <div v-else class="ml-1 badge badge-success badge-sm gap-1">
            <Fa6SolidCheck class="w-3 h-3" />
            Available
          </div>
        </div>
        
        <div v-if="item.price?.diamonds" class="flex items-center gap-2 bg-base-200 px-3 py-2 rounded-full">
          <span class="font-semibold">{{ item.price.diamonds }}</span>
          <Fa6SolidGem class="w-5 h-5 text-blue-400" />
          <div v-if="item.price.diamonds > wallet.diamonds" class="ml-1 badge badge-error badge-sm gap-1">
            <Fa6SolidX class="w-3 h-3" />
            Not enough
          </div>
          <div v-else class="ml-1 badge badge-success badge-sm gap-1">
            <Fa6SolidCheck class="w-3 h-3" />
            Available
          </div>
        </div>
      </div>
      <div class="flex items-center gap-4 bg-base-200 rounded-lg p-3">
        <p class="text-base-content/70 text-sm">Your balance:</p>
        <div class="flex items-center gap-2">
          <Fa6SolidCoins class="w-5 h-5 text-yellow-400" />
          <span class="font-semibold">{{ wallet.coins }}</span>
        </div>
        <div class="flex items-center gap-2">
          <Fa6SolidGem class="w-5 h-5 text-blue-400" />
          <span class="font-semibold">{{ wallet.diamonds }}</span>
        </div>
      </div>
      <div class="flex justify-between gap-4 mt-6">
        <button @click="closeModal" class="btn btn-outline flex-1">
          Cancel
        </button>
        <button 
          :class="purchaseButtonClasses" 
          @click="handlePurchase" 
          class="flex-1">
          {{ canAfford ? 'Purchase' : 'Not enough resources' }}
        </button>
      </div>
    </div>
  </UniversalModal>
</template>