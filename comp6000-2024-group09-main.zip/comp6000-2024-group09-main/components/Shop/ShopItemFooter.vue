<script setup lang="ts">
import type { InventoryItem, ShopItem } from "~/types/backend/shop/item";
import Fa6SolidCheck from "~icons/fa6-solid/check";
import Fa6SolidCircleCheck from "~icons/fa6-solid/circle-check";
import Fa6SolidCoins from "~icons/fa6-solid/coins";
import Fa6SolidGem from "~icons/fa6-solid/gem";
import Fa6SolidPaintbrush from "~icons/fa6-solid/paintbrush";
import Fa6SolidPalette from "~icons/fa6-solid/palette";
import Fa6SolidStar from "~icons/fa6-solid/star";
import MaterialSymbolsMouseOutline from "~icons/material-symbols/mouse-outline";

const props = defineProps<{
	item: (ShopItem | InventoryItem) & {
		isOwned?: boolean;
		isActive?: boolean;
		rating?: number;
		season?: string;
	};
	showApplyButton?: boolean;
	onApply?: () => void;
	onPreview?: (event: Event) => void;
}>();

const isShopItem = computed(() => {
	return "price" in props.item;
});

const typeIcon = computed(() => {
	if (props.item.type === "theme") {
		return Fa6SolidPalette;
	}
	if (props.item.type === "cursor") {
		return MaterialSymbolsMouseOutline;
	}
	return Fa6SolidPaintbrush;
});

const typeColor = computed(() => {
	if (props.item.type === "theme") {
		return "badge-primary";
	}
	if (props.item.type === "cursor") {
		return "badge-secondary";
	}
	return "badge-outline";
});
</script>

<template>
  <div class="card-body p-0 pt-2 relative flex flex-col p-4">
    <div v-if="showApplyButton" class="flex justify-between items-center">
      <h3 class="font-bold">{{ item.name }}</h3>
      <button 
        class="btn btn-primary gap-2 shadow-md hover:shadow-lg transition-all" 
        @click.stop="onApply && onApply()"
      >
        <component :is="typeIcon" class="w-4 h-4" />
        <span v-if="item.isActive">Active</span>
        <span v-else>Apply</span>
      </button>
    </div>
    
    <template v-else>
      <div class="flex flex-wrap gap-2 mb-2">
        <div class="badge badge-sm flex items-center gap-1" :class="typeColor">
          <component :is="typeIcon" class="w-3 h-3" />
          {{ item.type }}
        </div>
        <div v-if="item.season" class="badge badge-sm badge-ghost">{{ item.season }}</div>
        <div v-if="item.isActive" class="badge badge-sm badge-accent gap-1">
          <Fa6SolidCheck class="w-3 h-3" /> Active
        </div>
      </div>
      
      <h3 class="font-bold text-lg mb-1 line-clamp-1">{{ item.name }}</h3>
      <p class="text-sm text-base-content/70 line-clamp-2 mb-3">{{ item.description }}</p>
      
      <div class="flex items-center justify-between mt-auto">
        <div v-if="item.isOwned" class="badge badge-lg badge-success gap-1 shadow-sm">
          <Fa6SolidCircleCheck class="w-3 h-3" /> Owned
        </div>
        <div v-else-if="isShopItem && (item as ShopItem).price" class="flex items-center gap-2">
          <div 
            v-if="(item as ShopItem).price?.coins" 
            class="flex items-center gap-1 text-sm font-bold bg-base-200 py-1 px-2 rounded-full shadow-sm"
          >
            {{ (item as ShopItem).price.coins }}
            <Fa6SolidCoins class="w-4 h-4 text-yellow-400" />
          </div>
          <div 
            v-if="(item as ShopItem).price?.diamonds" 
            class="flex items-center gap-1 text-sm font-bold bg-base-200 py-1 px-2 rounded-full shadow-sm"
          >
            {{ (item as ShopItem).price.diamonds }}
            <Fa6SolidGem class="w-4 h-4 text-blue-400" />
          </div>
        </div>
        
        <div class="flex items-center gap-2">
          <div v-if="item.rating" class="flex items-center gap-1">
            <Fa6SolidStar class="w-3.5 h-3.5 text-yellow-400" />
            <span class="text-xs font-medium">{{ item.rating }}/5</span>
          </div>
          
          <button 
            v-if="onPreview"
            class="btn btn-circle btn-sm" 
            :class="item.type === 'theme' ? 'btn-primary' : 'btn-secondary'"
            data-tip="Preview"
            @click.stop="(e) => onPreview && onPreview(e)"
          >
            <Fa6SolidEye />
          </button>
        </div>
      </div>
    </template>
  </div>
</template>