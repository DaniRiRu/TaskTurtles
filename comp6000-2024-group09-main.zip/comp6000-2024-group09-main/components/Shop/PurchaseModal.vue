<script setup lang="ts">
import { ModalPosition } from "~/enums/frontend/modal/ModalPosition";
import type { WalletData } from "~/types/backend/meta/wallet";
import type { ShopItem } from "~/types/backend/shop/item";
import Fa6SolidCartShopping from "~icons/fa6-solid/cart-shopping";
import Fa6SolidCoins from "~icons/fa6-solid/coins";
import Fa6SolidGem from "~icons/fa6-solid/gem";
import MaterialSymbolsMouseOutline from "~icons/material-symbols/mouse-outline";

const props = defineProps<{
	isOpen: boolean;
	selectedItems: ShopItem[];
	wallet: WalletData;
}>();

const emit = defineEmits<{
	close: [];
	purchase: [items: { id: string; quantity: number }[]];
}>();

const isPurchasing = ref(false);

const totalPrice = computed(() => {
	return props.selectedItems.reduce(
		(acc, item) => ({
			coins: acc.coins + (item.price.coins || 0),
			diamonds: acc.diamonds + (item.price.diamonds || 0),
		}),
		{ coins: 0, diamonds: 0 },
	);
});

const canAfford = computed(() => {
	return (
		props.wallet.coins >= totalPrice.value.coins &&
		props.wallet.diamonds >= totalPrice.value.diamonds
	);
});

const walletAfterPurchase = computed(() => {
	return {
		coins: props.wallet.coins - totalPrice.value.coins,
		diamonds: props.wallet.diamonds - totalPrice.value.diamonds,
	};
});

const processPurchase = async () => {
	isPurchasing.value = true;
	try {
		await new Promise((resolve) => setTimeout(resolve, 1000));
		const items = props.selectedItems.map((item) => ({
			id: item.id,
			quantity: 1,
		}));
		emit("purchase", items);
		emit("close");
	} finally {
		isPurchasing.value = false;
	}
};

const closeModal = () => {
	emit("close");
};
</script>

<template>
  <UniversalModal
    :is-open="isOpen"
    :position="ModalPosition.Middle"
    @close="closeModal"
    class="backdrop-blur-sm"
  >
    <div 
      class="max-w-3xl mx-auto bg-base-100 overflow-hidden"
    >
      <div class="bg-base-100 p-6 border-b border-base-200">
        <div class="flex items-center justify-between">
          <h2 class="text-2xl font-bold flex items-center gap-2">
            <Fa6SolidCartShopping class="w-6 h-6" />
            Shopping Cart
          </h2>
          
          <div class="flex items-center gap-3">
            <div class="flex items-center gap-2 bg-base-200 py-1.5 px-3 rounded-full">
              <Fa6SolidCoins class="w-5 h-5 text-yellow-400" />
              <span class="font-bold">{{ wallet.coins }}</span>
            </div>
            <div class="flex items-center gap-2 bg-base-200 py-1.5 px-3 rounded-full">
              <Fa6SolidGem class="w-5 h-5 text-blue-400" />
              <span class="font-bold">{{ wallet.diamonds }}</span>
            </div>
          </div>
        </div>
      </div>
      <div v-if="selectedItems.length === 0" class="flex flex-col items-center justify-center py-12 px-4">
        <div class="w-24 h-24 bg-base-200 rounded-full flex items-center justify-center mb-4">
          <Fa6SolidCartShopping class="w-12 h-12 opacity-30" />
        </div>
        <h3 class="text-xl font-bold mb-2">Your cart is empty</h3>
        <p class="text-base-content/60 text-center mb-6 max-w-md">
          Looks like you haven't added any items to your cart yet.
          Browse the shop to find items you like.
        </p>
        <button class="btn btn-primary" @click="closeModal">
          Return to Shop
        </button>
      </div>
      <div v-else class="p-6">
        <div class="grid gap-4">
          <div 
            v-for="item in selectedItems"
            :key="item.id"
            class="flex gap-4 bg-base-200 p-4 rounded-xl transition-all duration-200"
          >
            <div 
              class="rounded-lg w-20 h-20 overflow-hidden flex items-center justify-center bg-base-100 shadow"
            >
              <div 
                v-if="item.type === 'theme'" 
                class="w-full h-full" 
                :data-theme="item.id"
              >
                <div class="w-full h-full grid grid-cols-3 grid-rows-2 gap-1 p-2 bg-base-100">
                  <div class="rounded bg-primary"></div>
                  <div class="rounded bg-secondary"></div>
                  <div class="rounded bg-accent"></div>
                  <div class="rounded bg-neutral"></div>
                  <div class="rounded bg-info"></div>
                  <div class="rounded bg-success"></div>
                </div>
              </div>
              <div 
                v-else-if="item.type === 'cursor'" 
                class="bg-gradient-to-br from-base-100 to-base-200 w-full h-full flex items-center justify-center"
              >
                <MaterialSymbolsMouseOutline class="w-10 h-10" />
              </div>
              <img 
                v-else
                :src="item.image"
                :alt="item.name"
                class="w-full h-full object-cover"
              />
            </div>
            <div class="flex-1">
              <div>
                <h3 class="font-bold text-lg">{{ item.name }}</h3>
                <p class="text-sm text-base-content/70 line-clamp-2">{{ item.description }}</p>
              </div>
              
              <div class="flex items-center gap-3 mt-2">
                <div v-if="item.price?.coins" class="flex items-center gap-1.5">
                  <span class="font-bold">{{ item.price.coins }}</span>
                  <Fa6SolidCoins class="w-4 h-4 text-yellow-400" />
                </div>
                <div v-if="item.price?.diamonds" class="flex items-center gap-1.5">
                  <span class="font-bold">{{ item.price.diamonds }}</span>
                  <Fa6SolidGem class="w-4 h-4 text-blue-400" />
                </div>
                <div class="badge badge-sm">{{ item.type }}</div>
              </div>
            </div>
          </div>
        </div>
        <div class="mt-6 bg-base-200 rounded-xl p-4">
          <h3 class="font-bold mb-3">Order Summary</h3>
          
          <div class="flex justify-between items-center mb-2">
            <span class="text-base-content/70">Items</span>
            <span>{{ selectedItems.length }}</span>
          </div>
          
          <div class="flex justify-between items-center mb-2" v-if="totalPrice.coins > 0">
            <span class="text-base-content/70">Total Coins</span>
            <div class="flex items-center gap-2">
              <span class="font-bold">{{ totalPrice.coins }}</span>
              <Fa6SolidCoins class="w-4 h-4 text-yellow-400" />
            </div>
          </div>
          
          <div class="flex justify-between items-center mb-2" v-if="totalPrice.diamonds > 0">
            <span class="text-base-content/70">Total Diamonds</span>
            <div class="flex items-center gap-2">
              <span class="font-bold">{{ totalPrice.diamonds }}</span>
              <Fa6SolidGem class="w-4 h-4 text-blue-400" />
            </div>
          </div>
          
          <div class="divider my-2"></div>
          
          <div class="flex justify-between items-center font-bold">
            <span>Remaining Balance</span>
            <div class="flex items-center gap-3">
              <div class="flex items-center gap-2" v-if="wallet.coins > 0 || totalPrice.coins > 0">
                <span :class="{ 'text-error': walletAfterPurchase.coins < 0 }">
                  {{ walletAfterPurchase.coins }}
                </span>
                <Fa6SolidCoins class="w-4 h-4 text-yellow-400" />
              </div>
              <div class="flex items-center gap-2" v-if="wallet.diamonds > 0 || totalPrice.diamonds > 0">
                <span :class="{ 'text-error': walletAfterPurchase.diamonds < 0 }">
                  {{ walletAfterPurchase.diamonds }}
                </span>
                <Fa6SolidGem class="w-4 h-4 text-blue-400" />
              </div>
            </div>
          </div>
          
          <div v-if="!canAfford" class="mt-4 p-3 bg-error/10 text-error rounded-lg flex items-center gap-2 text-sm">
            <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="12" cy="12" r="10" />
              <line x1="12" y1="8" x2="12" y2="12" />
              <line x1="12" y1="16" x2="12.01" y2="16" />
            </svg>
            You don't have enough currency to complete this purchase
          </div>
        </div>
        <div class="mt-6 grid grid-cols-2 gap-4">
          <button 
            class="btn btn-outline" 
            @click="closeModal"
          >
            Cancel
          </button>
          <button
            class="btn btn-primary"
            :class="{ 'loading': isPurchasing }"
            :disabled="!canAfford || isPurchasing"
            @click="processPurchase"
          >
            <span v-if="!isPurchasing">
              {{ canAfford ? "Complete Purchase" : "Insufficient Funds" }}
            </span>
          </button>
        </div>
      </div>
    </div>
  </UniversalModal>
</template>