<script setup lang="ts">
import type { ShopItem } from "~/types/backend/shop/item";

interface Props {
	items: (ShopItem & { isOwned?: boolean })[];
	category: string;
	onItemClick: (item: ShopItem & { isOwned?: boolean }) => void;
}

const props = defineProps<Props>();

const isItemPurchasable = (item: ShopItem & { isOwned?: boolean }) => {
	return !item.isOwned;
};
</script>

<template>
  <div class="space-y-4">
    <h2 class="text-2xl font-bold capitalize">{{ category }}</h2>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      <ThemePreview 
        v-for="item in items.filter(i => i.type === 'theme')" 
        :key="item.id" 
        :item="item" 
        :onClick="isItemPurchasable(item) ? () => onItemClick(item) : undefined" 
        :class="{ 'opacity-60 hover:opacity-80': !isItemPurchasable(item) }"
      />
      
      <CursorPreview 
        v-for="item in items.filter(i => i.type === 'cursor')" 
        :key="item.id" 
        :item="item" 
        :onClick="isItemPurchasable(item) ? () => onItemClick(item) : undefined" 
        :class="{ 'opacity-60 hover:opacity-80': !isItemPurchasable(item) }"
      />
      
      <div 
        v-for="item in items.filter(i => i.type === 'consumable')"
        :key="item.id"
        class="card bg-base-100 shadow-sm transition-all duration-200 overflow-hidden"
        :class="{ 
          'hover:shadow-lg hover:scale-[1.01] cursor-pointer': isItemPurchasable(item), 
          'opacity-60': !isItemPurchasable(item) 
        }"
        @click="isItemPurchasable(item) && onItemClick(item)">
        <figure>
          <img :src="item.image" :alt="item.name" class="h-48 w-full object-cover" />
        </figure>
        <div class="card-body p-4">
          <div class="badge badge-sm badge-outline">{{ item.type }}</div>
          <h3 class="font-bold text-lg">{{ item.name }}</h3>
          <p class="text-sm text-base-content/70 line-clamp-2">{{ item.description }}</p>
          <div class="flex items-center gap-2 mt-4">
            <div v-if="item.isOwned" class="badge badge-primary">Owned</div>
            <template v-else>
              <div v-if="item.price?.coins" class="flex items-center gap-1 text-sm font-bold bg-base-200 py-1 px-2 rounded-full shadow-sm">
                {{ item.price.coins }}
                <Fa6SolidCoins class="w-4 h-4 text-yellow-400" />
              </div>
              <div v-if="item.price?.diamonds" class="flex items-center gap-1 text-sm font-bold bg-base-200 py-1 px-2 rounded-full shadow-sm">
                {{ item.price.diamonds }}
                <Fa6SolidGem class="w-4 h-4 text-blue-400" />
              </div>
            </template>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>