<script setup lang="ts">
import type { InventoryItem, ShopItem } from "~/types/backend/shop/item";
import Fa6RegularCircle from "~icons/fa6-regular/circle";
import Fa6SolidCircle from "~icons/fa6-solid/circle";
import Fa6SolidLeftLong from "~icons/fa6-solid/left-long";
import Fa6SolidRightLong from "~icons/fa6-solid/right-long";
import MaterialSymbolsMouseOutline from "~icons/material-symbols/mouse-outline";

const props = defineProps<{
	item: ShopItem | InventoryItem;
	onClick?: () => void;
	onApply?: () => void;
	showApplyButton?: boolean;
}>();

const isActive = computed(() => {
	return "isActive" in props.item && props.item.isActive;
});

const isOwned = computed(() => {
	return "isOwned" in props.item && props.item.isOwned;
});

const cursorVariants = ref<{ filename: string; url: string }[]>([]);
const hasFetchedCursors = ref(false);
const activeCursorIndex = ref(0);
const isLoading = ref(true);
const autoplayInterval = ref<number | null>(null);
const error = ref<string | null>(null);
const isHovering = ref(false);
const showZoomed = ref(false);
const previewEl = ref<HTMLDivElement | null>(null);
const cursorPreviewMode = ref<"grid" | "single" | "slider">("grid");

async function fallbackToDefaultCursors() {
	const commonCursorNames = [
		"pointer.cur",
		"normal.cur",
		"default.cur",
		"arrow.cur",
		"text.cur",
		"wait.cur",
		"busy.cur",
		"progress.cur",
		"help.cur",
		"crosshair.cur",
		"precision.cur",
		"grab.cur",
		"hand.cur",
		"grabbing.cur",
		"move.cur",
		"not-allowed.cur",
		"no-drop.cur",
		"forbidden.cur",
		"resize.cur",
		"resize-h.cur",
		"resize-v.cur",
		"resize-nwse.cur",
		"link.cur",
		"alias.cur",
		"copy.cur",
		"zoom-in.cur",
		"zoom-out.cur",
	];

	const variants = [];

	for (const filename of commonCursorNames) {
		const url = `/images/shop/cursors/${props.item.id}/${filename}`;
		try {
			const response = await fetch(url, { method: "HEAD" });
			if (response.ok) {
				variants.push({ filename, url });
			}
		} catch (error) {
			// Ignore errors for files that don't exist
		}
	}

	cursorVariants.value = variants;
}

async function discoverCursorFiles() {
	try {
		isLoading.value = true;
		const variants = [];

		try {
			const indexResponse = await fetch(
				`/images/shop/cursors/${props.item.id}/index.json`,
			);
			if (indexResponse.ok) {
				const indexData = await indexResponse.json();
				if (Array.isArray(indexData.files)) {
					for (const filename of indexData.files) {
						if (filename.endsWith(".cur")) {
							variants.push({
								filename,
								url: `/images/shop/cursors/${props.item.id}/${filename}`,
							});
						}
					}

					cursorVariants.value = variants;
					hasFetchedCursors.value = true;

					isLoading.value = false;
					return;
				}
			}
		} catch (error) {
			// Proceed to fallback if index.json doesn't exist or has issues
		}

		await fallbackToDefaultCursors();
		hasFetchedCursors.value = true;
	} catch (err) {
		error.value =
			err instanceof Error ? err.message : "Unknown error loading cursors";
		console.error("Error discovering cursor files:", err);
	} finally {
		isLoading.value = false;

		if (cursorVariants.value.length <= 1) {
			cursorPreviewMode.value = "single";
		} else if (cursorVariants.value.length <= 3) {
			cursorPreviewMode.value = "slider";
		} else {
			cursorPreviewMode.value = "grid";
		}
	}
}

function stopAutoplay() {
	if (autoplayInterval.value) {
		clearInterval(autoplayInterval.value);
		autoplayInterval.value = null;
	}
}

function selectCursor(index: number) {
	activeCursorIndex.value = index;
	stopAutoplay();
}

function getFilenamePretty(filename: string): string {
	return filename
		.replace(/\.cur$/i, "")
		.replace(/[-_]/g, " ")
		.replace(/\b\w/g, (char) => char.toUpperCase());
}

function handleMouseEnter() {
	isHovering.value = true;
	stopAutoplay();
}

function handleMouseLeave() {
	isHovering.value = false;
	showZoomed.value = false;
}

function nextCursor() {
	selectCursor((activeCursorIndex.value + 1) % cursorVariants.value.length);
}

function prevCursor() {
	selectCursor(
		(activeCursorIndex.value - 1 + cursorVariants.value.length) %
			cursorVariants.value.length,
	);
}

function toggleZoom() {
	showZoomed.value = !showZoomed.value;
}

function togglePreviewMode() {
	const modes: ("grid" | "single" | "slider")[] = ["single", "slider", "grid"];
	const currentIndex = modes.indexOf(cursorPreviewMode.value);
	cursorPreviewMode.value = modes[(currentIndex + 1) % modes.length];
}

onMounted(() => {
	discoverCursorFiles();
});

onBeforeUnmount(() => {
	stopAutoplay();
});

const gridLayout = computed(() => {
	const count = cursorVariants.value.length;
	if (count <= 1) return "grid-cols-1";
	if (count <= 4) return "grid-cols-2";
	if (count <= 9) return "grid-cols-3";
	return "grid-cols-4";
});

const currentCursor = computed(() => {
	if (
		cursorVariants.value.length > 0 &&
		activeCursorIndex.value < cursorVariants.value.length
	) {
		return cursorVariants.value[activeCursorIndex.value];
	}
	return null;
});
</script>

<template>
  <div 
    class="card bg-base-100 shadow-xl transition-all duration-300 overflow-hidden relative border border-base-300 hover:border-base-200"
    :class="{ 
      'hover:shadow-2xl hover:scale-[1.01] cursor-pointer': !!props.onClick,
      'border-2 border-primary': isActive
    }"
    @click="props.onClick && props.onClick()"
  >
    <div 
      ref="previewEl"
      class="h-60 w-full bg-gradient-to-br from-neutral-100 to-base-200 dark:from-neutral-900 dark:to-base-900 relative overflow-hidden"
      @mouseenter="handleMouseEnter"
      @mouseleave="handleMouseLeave"
    >
      <div v-if="isLoading" class="absolute inset-0 flex items-center justify-center">
        <span class="loading loading-spinner loading-md text-primary"></span>
      </div>
      
      <div v-else-if="error" class="absolute inset-0 flex items-center justify-center p-4 text-center">
        <div class="flex flex-col items-center">
          <MaterialSymbolsMouseOutline class="w-12 h-12 opacity-40 mb-2" />
          <p class="text-sm opacity-60">Could not load cursor files</p>
        </div>
      </div>
      
      <div 
        v-else-if="hasFetchedCursors && cursorVariants.length === 0" 
        class="absolute inset-0 flex flex-col items-center justify-center p-4 text-center"
      >
        <MaterialSymbolsMouseOutline class="w-12 h-12 opacity-40 mb-2" />
        <p class="text-sm opacity-60">No cursor files found</p>
      </div>
      
      <div 
        v-else-if="cursorPreviewMode === 'single'" 
        class="absolute inset-0 flex items-center justify-center"
      >
        <div class="relative flex flex-col items-center">
          <img 
            v-if="currentCursor"
            :src="currentCursor.url" 
            :alt="currentCursor ? getFilenamePretty(currentCursor.filename) : 'Cursor'" 
            class="w-32 h-32 object-contain drop-shadow-lg transition-all duration-300"
            :class="{ 'animate-pulse': !isHovering, 'scale-125': isHovering }"
          />
          
          <div class="mt-4 bg-base-100/80 backdrop-blur-sm rounded-full px-4 py-1.5 text-sm font-medium shadow-sm">
            {{ currentCursor ? getFilenamePretty(currentCursor.filename) : '' }}
          </div>
          
          <div v-if="cursorVariants.length > 1" class="flex justify-center mt-3 gap-1.5">
            <button 
              v-for="(_, index) in cursorVariants" 
              :key="index"
              @click.stop="selectCursor(index)" 
              class="transition-all duration-200"
            >
              <Fa6SolidCircle v-if="index === activeCursorIndex" class="w-2.5 h-2.5 text-primary" />
              <Fa6RegularCircle v-else class="w-2.5 h-2.5 opacity-50 hover:opacity-80" />
            </button>
          </div>
        </div>
      </div>
      
      <div 
        v-else-if="cursorPreviewMode === 'slider'" 
        class="absolute inset-0 flex items-center justify-center"
      >
        <div class="relative w-full h-full flex items-center justify-center">
          <div class="w-40 h-40 flex items-center justify-center">
            <img 
              v-if="currentCursor"
              :src="currentCursor.url" 
              :alt="currentCursor ? getFilenamePretty(currentCursor.filename) : 'Cursor'" 
              class="w-32 h-32 object-contain drop-shadow-lg transition-transform duration-300"
              :class="{ 'scale-110': isHovering }"
            />
          </div>
          
          <button 
            v-if="cursorVariants.length > 1"
            @click.stop="prevCursor" 
            class="absolute left-2 bg-base-100/70 hover:bg-base-100 backdrop-blur-sm rounded-full p-2 transition-all duration-200 shadow-md"
          >
            <Fa6SolidLeftLong class="w-4 h-4" />
          </button>
          
          <button 
            v-if="cursorVariants.length > 1"
            @click.stop="nextCursor" 
            class="absolute right-2 bg-base-100/70 hover:bg-base-100 backdrop-blur-sm rounded-full p-2 transition-all duration-200 shadow-md"
          >
            <Fa6SolidRightLong class="w-4 h-4" />
          </button>
          
          <div class="absolute bottom-4 inset-x-0 flex justify-center">
            <div class="bg-base-100/70 backdrop-blur-sm rounded-full px-4 py-1.5 text-sm font-medium shadow-sm">
              {{ currentCursor ? getFilenamePretty(currentCursor.filename) : '' }}
            </div>
          </div>
        </div>
      </div>
      
      <div 
        v-else-if="cursorPreviewMode === 'grid'" 
        class="absolute inset-0 p-4"
      >
        <div 
          class="grid h-full gap-3"
          :class="gridLayout"
        >
          <div 
            v-for="(cursor, index) in cursorVariants" 
            :key="cursor.filename"
            class="flex flex-col items-center justify-center bg-base-100/60 backdrop-blur-sm rounded-lg p-3 transition-all duration-200 group hover:bg-base-100/80 shadow-sm"
            :class="{ 'ring-2 ring-primary bg-primary/10': index === activeCursorIndex }"
            @click.stop="selectCursor(index)"
          >
            <div class="flex-1 flex items-center justify-center">
              <img 
                :src="cursor.url" 
                :alt="getFilenamePretty(cursor.filename)" 
                class="w-12 h-12 object-contain transition-transform duration-200 group-hover:scale-125"
              />
            </div>
            
            <div class="text-xs text-center truncate w-full mt-2 font-medium">
              {{ getFilenamePretty(cursor.filename) }}
            </div>
          </div>
        </div>
      </div>

    </div>
    
    <ShopItemFooter
      :item="props.item"
      :show-apply-button="showApplyButton"
      :on-apply="onApply"
    />
  </div>
</template>