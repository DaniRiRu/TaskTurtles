<script setup lang="ts">
import type { WalletData } from "~/types/backend/meta/wallet";
import type { InventoryItem, ShopItem } from "~/types/backend/shop/item";
import Fa6SolidBagShopping from "~icons/fa6-solid/bag-shopping";
import Fa6SolidBox from "~icons/fa6-solid/box";
import Fa6SolidCoins from "~icons/fa6-solid/coins";
import Fa6SolidGem from "~icons/fa6-solid/gem";
import CursorPreview from "./Cursors/CursorPreview.vue";
import PurchaseModal from "./PurchaseModal.vue";
import ThemePreview from "./Themes/ThemePreview.vue";

definePageMeta({
	layout: "dashboard",
	title: "Shop",
	meta: [
		{
			name: "description",
			content: "Shop for items and themes to customise your experience.",
		},
	],
});

const backend = useBackend();

const activeTab = ref("shop");
const activeShopFilter = ref("all");
const activeCategory = ref("all");
const selectedItem = ref<ShopItem | null>(null);
const isPurchaseModalOpen = ref(false);

const tabs = [
	{ id: "shop", label: "Shop", icon: Fa6SolidBagShopping },
	{ id: "inventory", label: "Inventory", icon: Fa6SolidBox },
];

const shopFilters = [
	{ id: "all", label: "All Items" },
	{ id: "consumable", label: "Consumables" },
	{ id: "theme", label: "Themes" },
	{ id: "cursor", label: "Cursor" },
];

const categoryFilters = computed(() => {
	const categories = [
		"all",
		...new Set(shopItems.value.map((item) => item.category)),
	];
	return categories.map((category) => ({
		id: category,
		label:
			category === "all"
				? "All Categories"
				: category.charAt(0).toUpperCase() + category.slice(1),
	}));
});

const wallet = ref({
	coins: 0,
	diamonds: 0,
});

const shopItems = ref<ShopItem[]>([]);
const inventory = ref<InventoryItem[]>([]);

const filteredShopItems = computed(() => {
	let filtered = shopItems.value;

	if (activeShopFilter.value !== "all") {
		filtered = filtered.filter((item) => item.type === activeShopFilter.value);
	}

	if (activeCategory.value !== "all") {
		filtered = filtered.filter(
			(item) => item.category === activeCategory.value,
		);
	}

	const itemsWithOwnership = filtered.map((item) => ({
		...item,
		isOwned:
			item.type !== "consumable" &&
			inventory.value.some((invItem) => invItem.id === item.id),
	}));

	return itemsWithOwnership.sort((a, b) => {
		if (a.isOwned && !b.isOwned) return 1;
		if (!a.isOwned && b.isOwned) return -1;
		return 0;
	});
});

const groupedShopItems = computed(() => {
	const grouped = filteredShopItems.value.reduce(
		(acc, item) => {
			if (!acc[item.category]) {
				acc[item.category] = [];
			}
			acc[item.category].push(item);
			return acc;
		},
		{} as Record<string, typeof filteredShopItems.value>,
	);

	return Object.entries(grouped).sort((a, b) => a[0].localeCompare(b[0]));
});

const inventoryThemes = computed(() => {
	return inventory.value.filter((item) => item.type === "theme");
});

const inventoryCursors = computed(() => {
	return inventory.value.filter((item) => item.type === "cursor");
});

const inventoryConsumables = computed(() => {
	return inventory.value.filter((item) => item.type === "consumable");
});

const theme = useCookie<string>(COOKIE_NAMES.THEME, {
	default: () => DEFAULT_THEME,
});

async function fetchData() {
	const walletData = (await backend.progress.fetchWallet()) as WalletData;
	const shopData = (await backend.shop.fetchItems()) as ShopItem[];
	const inventoryData =
		(await backend.shop.fetchInventory()) as InventoryItem[];

	wallet.value = walletData;
	shopItems.value = shopData;
	inventory.value = inventoryData;
}

async function purchaseItem(itemId: string) {
	await backend.shop.purchaseItem(itemId, 1);
	await fetchData();
	selectedItem.value = null;
	isPurchaseModalOpen.value = false;
}

function askToPurchaseItem(item: ShopItem) {
	purchaseConfirmation.value = item;
}

async function useItem(itemId: string) {
	const item = inventory.value.find((item) => item.id === itemId);

	if (item?.type === "theme") {
		theme.value = item.id;
		return;
	}

	if (item?.type === "consumable") {
		await backend.shop.useItem(itemId);
		await fetchData();
	}
}

function canAfford(item: ShopItem) {
	if (item.price.coins && wallet.value.coins < item.price.coins) return false;
	if (item.price.diamonds && wallet.value.diamonds < item.price.diamonds)
		return false;
	return true;
}

function formatNumber(num: number) {
	return num >= 1000 ? `${(num / 1000).toFixed(1).replace(/\.0$/, "")}k` : num;
}

const purchaseConfirmation = ref<ShopItem | undefined>(undefined);

const isItemPurchasable = (item: ShopItem & { isOwned?: boolean }) => {
	return !item.isOwned;
};

const openPurchaseModal = (item: ShopItem & { isOwned?: boolean }) => {
	if (!isItemPurchasable(item)) return;
	selectedItem.value = item;
	isPurchaseModalOpen.value = true;
};

onMounted(() => {
	fetchData();
});
</script>

<template>
  <div class="min-h-full w-full mb-7">
    <div
      class="transition-all duration-300 ease-in-out fixed top-0 h-45 left-0 w-full bg-gradient-to-b from-base-200 from-70% z-2">
    </div>

    <div class="rounded-btn top-20 sticky z-5">
      <div class="flex flex-row justify-between items-start md:items-center gap-4">
        <div class="flex flex-row items-start md:items-center bg-base-100 shadow-sm rounded-btn join">
          <div class="dropdown join-item">
            <label tabindex="0" class="btn btn-ghost gap-2 join-item">
              <component :is="tabs.find(t => t.id === activeTab)?.icon" class="w-4 h-4" />
              <span class="max-md:hidden">
                {{tabs.find(t => t.id === activeTab)?.label}}
              </span>
              <MaterialSymbolsKeyboardArrowDown class="w-4 h-4 max-md:hidden" />
            </label>
            <ul tabindex="0" class="dropdown-content z-1 mt-1 menu p-2 gap-1 shadow bg-base-100 rounded-box w-52">
              <li v-for="tab in tabs" :key="tab.id">
                <a :class="{ 'active': activeTab === tab.id }" @click="activeTab = tab.id">
                  <component :is="tab.icon" class="w-4 h-4" />
                  {{ tab.label }}
                </a>
              </li>
            </ul>
          </div>

          <div v-if="activeTab === 'shop'" class="dropdown join-item">
            <label tabindex="0" class="btn btn-ghost join-item">
              {{shopFilters.find(f => f.id === activeShopFilter)?.label}}
              <MaterialSymbolsKeyboardArrowDown class="w-4 h-4 max-md:hidden" />
            </label>
            <ul tabindex="0" class="dropdown-content z-1 menu gap-1 mt-1 p-2 shadow bg-base-100 rounded-box w-52">
              <li v-for="filter in shopFilters" :key="filter.id">
                <a :class="{ 'active': activeShopFilter === filter.id }" @click="activeShopFilter = filter.id">
                  {{ filter.label }}
                </a>
              </li>
            </ul>
          </div>

          <div v-if="activeTab === 'shop'" class="dropdown join-item">
            <label tabindex="0" class="btn btn-ghost join-item">
              {{categoryFilters.find(f => f.id === activeCategory)?.label}}
              <MaterialSymbolsKeyboardArrowDown class="w-4 h-4 max-md:hidden" />
            </label>
            <ul tabindex="0" class="dropdown-content z-1 menu gap-1 mt-1 p-2 shadow bg-base-100 rounded-box w-52">
              <li v-for="filter in categoryFilters" :key="filter.id">
                <a :class="{ 'active': activeCategory === filter.id }" @click="activeCategory = filter.id">
                  {{ filter.label }}
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div class="flex items-center gap-4 bg-base-100 shadow-sm rounded-btn h-12 px-4">
          <div class="flex items-center gap-2">
            <Fa6SolidCoins class="w-5 h-5 text-yellow-400" />
            <span class="font-semibold">{{ formatNumber(wallet.coins) }}</span>
          </div>
          <div class="flex items-center gap-2">
            <Fa6SolidGem class="w-5 h-5 text-blue-400" />
            <span class="font-semibold">{{ formatNumber(wallet.diamonds) }}</span>
          </div>
        </div>
      </div>
    </div>

    <div class="pt-8">
      <div v-if="activeTab === 'shop'" class="space-y-12">
        <div v-for="[category, items] in groupedShopItems" :key="category" class="space-y-4">
          <h2 class="text-2xl font-bold capitalize">{{ category }}</h2>
          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            <ThemePreview 
              v-for="item in items.filter(i => i.type === 'theme')" 
              :key="item.id" 
              :item="item" 
              :onClick="isItemPurchasable(item) ? () => openPurchaseModal(item) : undefined" 
              :class="{ 'opacity-60 hover:opacity-80': !isItemPurchasable(item) }"
            />
            
            <CursorPreview 
              v-for="item in items.filter(i => i.type === 'cursor')" 
              :key="item.id" 
              :item="item" 
              :onClick="isItemPurchasable(item) ? () => openPurchaseModal(item) : undefined" 
              :class="{ 'opacity-60 hover:opacity-80': !isItemPurchasable(item) }"
            />
            
            <div 
              v-for="item in items.filter(i => i.type === 'consumable')"
              :key="item.id"
              class="card bg-base-100 shadow-sm transition-all duration-200 overflow-hidden"
              :class="{ 
                'hover:shadow-lg hover:scale-[1.01] cursor-pointer': isItemPurchasable(item), 
                'opacity-60': !isItemPurchasable(item) 
              }"
              @click="isItemPurchasable(item) && openPurchaseModal(item)">
              <figure>
                <img :src="item.image" :alt="item.name" class="h-48 w-full object-cover" />
              </figure>
              <div class="card-body p-4">
                <div class="badge badge-sm badge-outline">{{ item.type }}</div>
                <h3 class="font-bold text-lg">{{ item.name }}</h3>
                <p class="text-sm text-base-content/70 line-clamp-2">{{ item.description }}</p>
                <div class="flex items-center gap-2 mt-4">
                  <div v-if="item.isOwned" class="badge badge-primary">Owned</div>
                  <template v-else>
                    <div v-if="item.price?.coins" class="flex items-center gap-1 text-sm font-bold bg-base-200 py-1 px-2 rounded-full shadow-sm">
                      {{ item.price.coins }}
                      <Fa6SolidCoins class="w-4 h-4 text-yellow-400" />
                    </div>
                    <div v-if="item.price?.diamonds" class="flex items-center gap-1 text-sm font-bold bg-base-200 py-1 px-2 rounded-full shadow-sm">
                      {{ item.price.diamonds }}
                      <Fa6SolidGem class="w-4 h-4 text-blue-400" />
                    </div>
                  </template>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div v-if="!filteredShopItems.length" class="py-8">
          <ContentUnavailable 
            :image="Fa6SolidBagShopping" 
            title="No Items Found"
            description="There are no items available in this category." 
          />
        </div>
      </div>

      <div v-else-if="activeTab === 'inventory'" class="space-y-8">
        <div v-if="inventoryThemes.length > 0">
          <h2 class="text-2xl font-bold mb-4">Themes</h2>
          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            <ThemePreview 
              v-for="item in inventoryThemes" 
              :key="item.id" 
              :item="item" 
              showApplyButton 
              :onApply="() => useItem(item.id)" 
            />
          </div>
        </div>

        <div v-if="inventoryCursors.length > 0">
          <h2 class="text-2xl font-bold mb-4">Cursors</h2>
          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            <CursorPreview 
              v-for="item in inventoryCursors" 
              :key="item.id" 
              :item="item" 
              showApplyButton 
              :onApply="() => useItem(item.id)" 
            />
          </div>
        </div>

        <div v-if="inventoryConsumables.length > 0">
          <h2 class="text-2xl font-bold mb-4">Consumables</h2>
          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            <div v-for="item in inventoryConsumables" :key="item.id" class="card bg-base-100 shadow-sm transition-all duration-200 hover:shadow-md">
              <div class="card-body p-4">
                <div class="badge badge-sm badge-outline">
                  x{{ item.quantity }}
                </div>
                <h3 class="font-bold">{{ item.name }}</h3>
                <p class="text-sm text-base-content/70">
                  {{ item.description }}
                </p>
                <button class="btn btn-primary btn-sm w-full mt-4 gap-2" @click="useItem(item.id)">
                  <Fa6SolidBox class="w-4 h-4" />
                  Use Item
                </button>
              </div>
            </div>
          </div>
        </div>

        <div v-if="!inventoryConsumables.length && !inventoryThemes.length && !inventoryCursors.length" class="py-8">
          <ContentUnavailable 
            :image="Fa6SolidBox" 
            title="No Items Found"
            description="You don't have any items in your inventory." 
            :action="() => activeTab = 'shop'"
            action-name="Go to Shop" 
          />
        </div>
      </div>
    </div>

    <PurchaseModal 
      :is-open="isPurchaseModalOpen" 
      :selected-items="selectedItem ? [selectedItem] : []" 
      :wallet="wallet"
      @close="isPurchaseModalOpen = false" 
      @purchase="(items) => purchaseItem(items[0].id)" 
    />
  </div>
</template>