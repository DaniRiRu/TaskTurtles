<script setup lang="ts">
import { ref, shallowRef } from "vue";
import type { InventoryItem, ShopItem } from "~/types/backend/shop/item";
import { customThemes } from "~/utils/themes";
import MdiEyeCircle from "~icons/mdi/eye-circle";
import DetailedPreview from "./DetailedPreview.vue";

const props = defineProps<{
	item: (ShopItem | InventoryItem) & { isOwned?: boolean };
	onClick?: () => void;
	showApplyButton?: boolean;
	onApply?: () => void;
}>();

const showPreview = ref(false);
const currentTheme = shallowRef("");
const backgroundImage = shallowRef("");

function togglePreview(event: Event) {
	event.stopPropagation();

	if (!showPreview.value) {
		currentTheme.value =
			document.documentElement.getAttribute("data-theme") || "light";
		document.documentElement.setAttribute("data-theme", props.item.id);

		const themeConfig =
			customThemes[props.item.id as keyof typeof customThemes];
		if (themeConfig?.background) {
			backgroundImage.value = themeConfig.background;
		} else {
			backgroundImage.value = "";
		}
	} else {
		document.documentElement.setAttribute("data-theme", currentTheme.value);
	}

	showPreview.value = !showPreview.value;
}

function closePreview() {
	if (showPreview.value && currentTheme.value) {
		document.documentElement.setAttribute("data-theme", currentTheme.value);
	}
	showPreview.value = false;
}

function handleCardClick(event: Event) {
	if (!showPreview.value && props.onClick) {
		props.onClick();
	}
}

onUnmounted(() => {
	if (showPreview.value && currentTheme.value) {
		document.documentElement.setAttribute("data-theme", currentTheme.value);
	}
});
</script>

<template>
  <div 
    class="card bg-base-100 shadow-xl transition-transform duration-300 overflow-hidden border border-base-300 hover:shadow-2xl group"
    :class="{ 'cursor-pointer hover:-translate-y-1': onClick }"
    @click="handleCardClick">
    
    <DetailedPreview
      v-if="showPreview"
      :is-open="showPreview" 
      :item="item" 
      :on-apply="onApply"
      :background-image="backgroundImage"
      @close="closePreview" 
    />
    
    <div class="relative flex flex-col p-4" :data-theme="item.id">
      <div class="relative h-52 w-full rounded-2xl overflow-hidden mb-6 flex items-center justify-center shadow-inner group-hover:shadow-[inset_0_0_30px_rgba(0,0,0,0.1)]">
        <div class="absolute inset-0 bg-gradient-to-br from-base-300 via-base-200 to-base-300 rounded-2xl"></div>
        
        <button 
          @click="togglePreview"
          class="absolute top-2 right-2 z-1 w-8 h-8 bg-base-100/70 backdrop-blur-sm rounded-full flex items-center justify-center shadow-md hover:scale-110 transition-transform duration-200 border border-base-300/50"
        >
          <MdiEyeCircle class="w-5 h-5 text-base-content opacity-80" />
        </button>
      
        <div 
          v-if="customThemes[item.id as keyof typeof customThemes]?.background" 
          class="absolute inset-0 rounded-2xl overflow-hidden"
        >
          <img 
            :src="customThemes[item.id as keyof typeof customThemes]?.background" 
            alt="Theme background" 
            loading="lazy"
            class="w-full h-full object-cover opacity-40"
          />
        </div>
        
        <div class="absolute inset-0 opacity-15 rounded-2xl overflow-hidden">
          <div class="absolute h-20 w-20 rounded-full bg-primary/30 -top-5 -left-5 blur-md animate-blob"></div>
          <div class="absolute h-32 w-32 rounded-full bg-secondary/30 bottom-10 right-10 blur-md animate-blob [animation-delay:2000ms]"></div>
          <div class="absolute h-24 w-24 rounded-full bg-accent/30 bottom-20 left-20 blur-md animate-blob [animation-delay:4000ms]"></div>
          
          <div class="absolute inset-0 bg-[radial-gradient(circle,_transparent_20%,_#00000005_20%,_#00000005_calc(20%_+_1px),_transparent_calc(20%_+_1px))] bg-[length:24px_24px] opacity-40"></div>
        </div>
        
        <div class="relative w-32 h-40 mx-auto transform group-hover:scale-110 transition-transform duration-500 group-hover:rotate-[5deg]">
          <div class="absolute w-full h-full rounded-[45%] bg-gradient-to-br from-base-100 via-base-100 to-base-200 transform rotate-12 shadow-[0_10px_25px_rgba(0,0,0,0.2),inset_0_5px_10px_rgba(255,255,255,0.5)]">
            <div class="absolute top-[10%] left-[15%] w-16 h-16 rounded-full bg-primary/20 blur-sm animate-pulse"></div>
            <div class="absolute top-[35%] left-[30%] w-14 h-14 rounded-full bg-secondary/20 blur-sm animate-pulse [animation-delay:700ms]"></div>
            <div class="absolute top-[55%] left-[20%] w-18 h-14 rounded-full bg-accent/20 blur-sm animate-pulse [animation-delay:1300ms]"></div>
            
            <div class="absolute top-[5%] left-[25%] w-4 h-20 bg-white/40 rounded-full rotate-[30deg] blur-sm"></div>
            
            <div class="absolute top-[30%] left-[45%] w-[1px] h-14 bg-primary/40 rounded-full rotate-[65deg]"></div>
            <div class="absolute top-[25%] left-[47%] w-[1px] h-8 bg-primary/40 rounded-full rotate-[45deg]"></div>
          </div>
          
          <div class="absolute w-5 h-5 rounded-full bg-primary/80 animate-orbit blur-[2px] opacity-70" style="--orbit-offset: 0deg"></div>
          <div class="absolute w-4 h-4 rounded-full bg-secondary/80 animate-orbit blur-[2px] opacity-70 [animation-delay:300ms]" style="--orbit-offset: 90deg"></div>
          <div class="absolute w-6 h-6 rounded-full bg-accent/80 animate-orbit blur-[2px] opacity-70 [animation-delay:500ms]" style="--orbit-offset: 180deg"></div>
          <div class="absolute w-3 h-3 rounded-full bg-neutral/80 animate-orbit blur-[2px] opacity-70 [animation-delay:800ms]" style="--orbit-offset: 270deg"></div>
          
          <div class="absolute top-0 left-[40%] w-1 h-1 bg-white rounded-full animate-twinkle"></div>
          <div class="absolute top-[30%] right-0 w-1 h-1 bg-white rounded-full animate-twinkle [animation-delay:300ms]"></div>
          <div class="absolute bottom-[20%] left-[10%] w-1 h-1 bg-white rounded-full animate-twinkle [animation-delay:700ms]"></div>
        </div>
        
        <div class="absolute bottom-14 inset-x-0 flex justify-center">
          <div class="px-4 py-1.5 bg-base-100/80 backdrop-blur-sm rounded-xl shadow-lg flex items-center gap-4 border border-base-300/50">
            <div class="w-4 h-4 rounded-full bg-primary"></div>
            <div class="w-4 h-4 rounded-full bg-secondary"></div>
            <div class="w-4 h-4 rounded-full bg-accent"></div>
            <div class="w-4 h-4 rounded-full bg-neutral"></div>
          </div>
        </div>
        
        <div class="absolute bottom-0 inset-x-0">
          <div class="bg-gradient-to-t from-base-100 to-transparent pt-10 pb-3">
            <div class="flex flex-col items-center">
              <h3 class="font-bold text-base-content text-center text-lg tracking-wide px-4 py-1.5 rounded-full bg-base-300/40 backdrop-blur-sm shadow-sm border border-base-200">
                {{ item.name }}
              </h3>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div :data-theme="item.id">
      <ShopItemFooter 
        :item="item"
        :show-apply-button="showApplyButton"
        :on-apply="onApply"
      />
    </div>
  </div>
</template>