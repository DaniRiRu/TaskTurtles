<script setup lang="ts">
import { ModalPosition } from "~/enums/frontend/modal/ModalPosition";
import type { InventoryItem, ShopItem } from "~/types/backend/shop/item";
import IcRoundCheck from "~icons/ic/round-check";
import MdiImageFilter from "~icons/mdi/image-filter";

const props = defineProps<{
	isOpen: boolean;
	item: (ShopItem | InventoryItem) & { isOwned?: boolean };
	onApply?: () => void;
	backgroundImage?: string;
}>();

const emit = defineEmits<{
	close: [];
}>();

function closePreview() {
	emit("close");
}

const orbs = [
	{
		color: "primary",
		size: "w-16 h-16",
		left: "left-[35%]",
		top: "top-[25%]",
		delay: "0s",
	},
	{
		color: "secondary",
		size: "w-12 h-12",
		left: "left-[60%]",
		top: "top-[35%]",
		delay: "0.5s",
	},
	{
		color: "accent",
		size: "w-14 h-14",
		left: "left-[47%]",
		top: "top-[60%]",
		delay: "1s",
	},
	{
		color: "neutral",
		size: "w-10 h-10",
		left: "left-[30%]",
		top: "top-[55%]",
		delay: "1.5s",
	},
];

const elements = ref<SVGElement | null>(null);

onMounted(() => {
	if (elements.value) {
		const svgElement = elements.value;
		const paths = svgElement.querySelectorAll("path");

		for (const path of paths) {
			const length = path.getTotalLength();
			path.style.strokeDasharray = `${length}`;
			path.style.strokeDashoffset = `${length}`;

			const animation = document.createElementNS(
				"http://www.w3.org/2000/svg",
				"animate",
			);
			animation.setAttribute("attributeName", "stroke-dashoffset");
			animation.setAttribute("from", `${length}`);
			animation.setAttribute("to", "0");
			animation.setAttribute("dur", "2s");
			animation.setAttribute("begin", "0s");
			animation.setAttribute("fill", "freeze");

			path.appendChild(animation);
		}
	}
});

const timelineItems = [
	{ color: "primary", description: "Cohesive palette" },
	{ color: "secondary", description: "Legible interfaces" },
	{ color: "accent", description: "Visual harmony" },
];

const showColorInfo = ref(false);
const activeColor = ref<string | null>(null);

function toggleColorInfo(color: string) {
	if (activeColor.value === color) {
		activeColor.value = null;
		showColorInfo.value = false;
	} else {
		activeColor.value = color;
		showColorInfo.value = true;
	}
}

const colorDescriptions = {
	primary: "Main brand color, used for primary actions and focus elements",
	secondary: "Complementary color for secondary actions and accents",
	accent: "Highlight color for important notifications and features",
	neutral: "Balanced tone for text and subtle UI elements",
};
</script>

<template>
  <Universal-Modal :is-open="isOpen" :position="ModalPosition.Middle" @close="closePreview">
    <template #title>
      <div class="flex items-center gap-2 mb-5">
        <div class="flex space-x-1">
          <div v-for="color in ['primary', 'secondary', 'accent', 'neutral']" :key="color" 
               class="w-2.5 h-2.5 rounded-full" :class="`bg-${color}`"></div>
        </div>
        <h2 class="text-xl font-bold">{{ item.name }} Theme</h2>
      </div>
    </template>
    
    <div :data-theme="item.id" class="overflow-hidden rounded-xl">
      <div class="relative h-56 rounded-xl overflow-hidden bg-gradient-to-br from-base-200 to-base-300">
        <div v-if="backgroundImage" class="absolute inset-0 w-full h-full">
          <img :src="backgroundImage" alt="Theme background" class="w-full h-full object-cover opacity-40" />
          <div class="absolute inset-0 bg-base-300/50"></div>
        </div>
        
        <svg class="absolute inset-0 w-full h-full opacity-5" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
          <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
            <path d="M 10 0 L 0 0 0 10" fill="none" stroke="currentColor" stroke-width="0.5" />
          </pattern>
          <rect width="100" height="100" fill="url(#grid)" />
        </svg>
        
        <div class="absolute w-full h-full">
          <div class="absolute -left-8 -top-8 w-32 h-32 rounded-full bg-primary/10 blur-xl"></div>
          <div class="absolute right-10 bottom-8 w-36 h-36 rounded-full bg-secondary/10 blur-xl"></div>
          <div class="absolute right-20 top-4 w-24 h-24 rounded-full bg-accent/10 blur-xl"></div>
        </div>
        
        <div v-for="(orb, i) in orbs" :key="i" 
             class="absolute rounded-full blur-sm animate-pulse"
             :class="`${orb.size} ${orb.left} ${orb.top} bg-${orb.color}/70`"
             :style="`animation-delay: ${orb.delay}`">
        </div>

        <div class="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-44 h-44 flex flex-col items-center">
          <div class="w-40 h-52 rounded-2xl bg-base-100 shadow-2xl overflow-hidden transform -rotate-3 relative">
            <div class="h-5 w-full bg-base-300 flex items-center px-2">
              <div class="flex space-x-1">
                <div class="w-1.5 h-1.5 rounded-full bg-error"></div>
                <div class="w-1.5 h-1.5 rounded-full bg-warning"></div>
                <div class="w-1.5 h-1.5 rounded-full bg-success"></div>
              </div>
            </div>
            
            <div class="flex h-[calc(100%-1.25rem)]">
              <div class="w-7 bg-base-200 h-full flex flex-col items-center pt-2 gap-2">
                <div class="w-4 h-4 rounded-full bg-primary/70"></div>
                <div class="w-4 h-4 rounded-md bg-secondary/70"></div>
                <div class="w-4 h-4 rounded-md bg-base-300"></div>
                <div class="w-4 h-4 rounded-md bg-base-300"></div>
              </div>
              
              <div class="flex-1 p-2">
                <div class="w-full h-3 bg-base-200 rounded-sm mb-2"></div>
                
                <div class="space-y-1.5">
                  <div class="flex items-center gap-1.5">
                    <div class="w-3 h-3 rounded-sm bg-primary"></div>
                    <div class="w-16 h-2 bg-base-300 rounded-sm"></div>
                  </div>
                  <div class="flex items-center gap-1.5">
                    <div class="w-3 h-3 rounded-sm bg-secondary"></div>
                    <div class="w-14 h-2 bg-base-300 rounded-sm"></div>
                  </div>
                  <div class="flex items-center gap-1.5">
                    <div class="w-3 h-3 rounded-sm bg-accent"></div>
                    <div class="w-18 h-2 bg-base-300 rounded-sm"></div>
                  </div>
                  
                  <div class="w-full h-10 mt-2 flex items-end justify-around">
                    <div class="w-2 bg-primary rounded-t" style="height: 40%"></div>
                    <div class="w-2 bg-primary rounded-t" style="height: 70%"></div>
                    <div class="w-2 bg-secondary rounded-t" style="height: 50%"></div>
                    <div class="w-2 bg-secondary rounded-t" style="height: 90%"></div>
                    <div class="w-2 bg-accent rounded-t" style="height: 60%"></div>
                    <div class="w-2 bg-accent rounded-t" style="height: 40%"></div>
                  </div>
                  
                  <div class="mt-2 w-full flex justify-center">
                    <div class="w-16 h-4 rounded-md bg-primary flex items-center justify-center">
                      <div class="w-8 h-1 bg-primary-content/30 rounded-sm"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div class="absolute inset-0 bg-gradient-to-br from-base-100/20 to-transparent pointer-events-none"></div>
          </div>
        </div>
        
        <div class="absolute top-3.5 left-3.5 flex gap-2">
          <div class="badge badge-primary badge-sm shadow-md">Theme</div>
          <div class="badge badge-outline badge-sm shadow-md">{{ item.name }}</div>
        </div>
        
        <div class="absolute bottom-3 right-3 flex flex-col items-end gap-1.5">
          <div v-for="(item, index) in timelineItems" :key="index" 
               class="flex items-center gap-1.5 backdrop-blur-sm bg-base-100/40 px-2 py-0.5 rounded-l-full">
            <div class="w-2 h-2 rounded-full" :class="`bg-${item.color}`"></div>
            <span class="text-[0.6rem] font-medium">{{ item.description }}</span>
          </div>
        </div>
      </div>
      
      <div v-if="backgroundImage" class="mt-3 p-2 bg-base-200 rounded-lg">
        <div class="text-xs font-semibold mb-2 flex items-center gap-1.5">
          <MdiImageFilter class="w-4 h-4 text-primary" />
          Theme Background
        </div>
        <div class="relative h-20 rounded-md overflow-hidden group">
          <img :src="backgroundImage" alt="Theme background" class="w-full h-full object-cover" />
          <div class="absolute inset-0 bg-gradient-to-t from-base-300/70 to-transparent"></div>
          <div class="absolute inset-0 flex items-end justify-start p-2">
            <div class="badge badge-sm badge-primary gap-1">
              <IcRoundCheck class="w-3 h-3" />
              Custom Background
            </div>
          </div>
          <div class="absolute inset-0 bg-primary/0 group-hover:bg-primary/10 transition-colors duration-300"></div>
        </div>
      </div>
      
      <div class="mt-3 relative">
        <div class="grid grid-cols-4 gap-3">
          <div v-for="(color, i) in ['primary', 'secondary', 'accent', 'neutral']" :key="i"
               class="flex flex-col items-center gap-1" @click="toggleColorInfo(color)">
            <div class="relative group cursor-pointer">
              <div class="w-12 h-12 rounded-xl ring-2 ring-base-200 shadow-md flex items-center justify-center transform transition-transform group-hover:scale-105"
                  :class="`bg-${color}`">
                <div class="w-6 h-6 rounded-md opacity-20 transform rotate-45"
                    :class="`bg-${color}-content`"></div>
              </div>
              <div class="absolute -top-1 -right-1 w-3 h-3 rounded-full border-2 border-base-100" 
                  :class="`bg-${color}`"></div>
            </div>
            <span class="text-xs font-medium capitalize">{{ color }}</span>
          </div>
        </div>
        
        <div v-if="showColorInfo && activeColor" 
             class="mt-2 p-2 rounded-lg bg-base-200 text-xs animate-fadeIn">
          <div class="flex items-center gap-2">
            <div class="w-3 h-3 rounded-full" :class="`bg-${activeColor}`"></div>
            <span class="font-medium capitalize">{{ activeColor }}</span>
          </div>
          <p class="mt-1">{{ colorDescriptions[activeColor as keyof typeof colorDescriptions] }}</p>
        </div>
      </div>
      
      <div class="grid grid-cols-2 gap-3 mt-3">
        <div class="rounded-lg bg-base-200 p-2 flex flex-col gap-2">
          <div class="text-xs font-semibold flex items-center gap-1.5">
            <div class="w-1 h-3 rounded-full bg-primary"></div>
            Buttons
          </div>
          <div class="flex flex-wrap gap-1.5">
            <button class="btn btn-primary btn-xs">Primary</button>
            <button class="btn btn-secondary btn-xs">Secondary</button>
            <button class="btn btn-accent btn-xs">Accent</button>
          </div>
        </div>
        
        <div class="rounded-lg bg-base-200 p-2 flex flex-col gap-2">
          <div class="text-xs font-semibold flex items-center gap-1.5">
            <div class="w-1 h-3 rounded-full bg-secondary"></div>
            Controls
          </div>
          <div class="flex flex-col gap-1.5">
            <input type="text" class="input input-xs input-bordered w-full" placeholder="Input field" />
            <div class="flex items-center gap-1.5">
              <input type="checkbox" class="checkbox checkbox-xs checkbox-primary" checked />
              <input type="radio" class="radio radio-xs radio-secondary" checked />
              <div class="rating rating-xs">
                <input type="radio" class="mask mask-star-2 bg-accent" checked />
                <input type="radio" class="mask mask-star-2 bg-accent" />
                <input type="radio" class="mask mask-star-2 bg-accent" />
              </div>
            </div>
          </div>
        </div>
        
        <div class="rounded-lg bg-base-200 p-2 flex flex-col gap-1.5">
          <div class="text-xs font-semibold flex items-center gap-1.5">
            <div class="w-1 h-3 rounded-full bg-accent"></div>
            Alerts
          </div>
          <div class="alert alert-info py-1 min-h-0">
            <span class="text-[0.65rem]">Info alert message</span>
          </div>
          <div class="alert alert-success py-1 min-h-0">
            <span class="text-[0.65rem]">Success alert</span>
          </div>
        </div>
        
        <div class="rounded-lg bg-base-200 p-2">
          <div class="text-xs font-semibold flex items-center gap-1.5 mb-1.5">
            <div class="w-1 h-3 rounded-full bg-neutral"></div>
            Base Colors
          </div>
          <div class="flex flex-wrap gap-1">
            <div v-for="i in 4" :key="i" class="w-6 h-6 rounded-md flex items-center justify-center relative group" 
                 :class="`bg-base-${i * 100}`">
              <span class="text-[0.65rem] font-medium">{{ i * 100 }}</span>
              <div class="absolute inset-0 rounded-md opacity-0 group-hover:opacity-10 bg-primary transition-opacity"></div>
            </div>
          </div>
          <div class="flex justify-between mt-1">
            <span class="text-[0.6rem]">Lightest</span>
            <span class="text-[0.6rem]">Darkest</span>
          </div>
        </div>
      </div>

      <div class="mt-3" v-if="onApply">
        <button class="btn btn-primary w-full gap-2 relative overflow-hidden group" 
                @click.stop="onApply && onApply()">
          <span class="absolute inset-0 w-full h-full bg-white/20 transform -translate-x-full 
                      group-hover:translate-x-0 transition-transform duration-300"></span>
          <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                  d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" />
          </svg>
          Apply {{ item.name }} Theme
        </button>
      </div>
    </div>
  </Universal-Modal>
</template>