<script lang="ts" setup>
interface InventoryItem {
	id: string;
	name: string;
	type: string;
	rarity: "common" | "rare" | "epic" | "legendary";
	quantity: number;
	emoji: string;
	equippable: boolean;
	equipped: boolean;
	description: string;
}

const inventory = ref<InventoryItem[]>([
	{
		id: "1",
		name: "Focus Crystal",
		type: "boost",
		rarity: "rare",
		quantity: 3,
		emoji: "💎",
		equippable: true,
		equipped: true,
		description: "+25% Focus for 2 hours",
	},
	{
		id: "2",
		name: "Time Potion",
		type: "consumable",
		rarity: "epic",
		quantity: 5,
		emoji: "⌛",
		equippable: false,
		equipped: false,
		description: "Adds 30 minutes to your day",
	},
	{
		id: "3",
		name: "Lucky Charm",
		type: "artifact",
		rarity: "legendary",
		quantity: 1,
		emoji: "🍀",
		equippable: true,
		equipped: false,
		description: "+15% Reward Bonus",
	},
	{
		id: "4",
		name: "Energy Drink",
		type: "consumable",
		rarity: "common",
		quantity: 10,
		emoji: "🥤",
		equippable: false,
		equipped: false,
		description: "Instant energy boost",
	},
]);

const inventoryStats = ref([
	{
		label: "Items",
		value: "19",
		trend: 3,
		color: "text-primary",
	},
	{
		label: "Equipped",
		value: "2",
		trend: 1,
		color: "text-success",
	},
	{
		label: "Slots",
		value: "8/10",
		trend: -2,
		color: "text-warning",
	},
]);

const getRarityColor = (rarity: string) => {
	const colors = {
		common: "text-base-content",
		rare: "text-primary",
		epic: "text-secondary",
		legendary: "text-warning",
	};
	return colors[rarity as keyof typeof colors];
};

const getTypeColor = (type: string) => {
	const colors = {
		boost: "text-success",
		consumable: "text-info",
		artifact: "text-warning",
	};
	return colors[type as keyof typeof colors];
};

const router = useRouter();

function navigateToInventory() {
	router.push("/inventory");
}
</script>

<template>
  <DashboardContainer
    title="Inventory"
    subtitle="Your magical items and artifacts"
    :stats="inventoryStats"
    variant="glass"
    accent-color="primary"
  >
    <template #header-action>
      <button class="btn btn-ghost btn-sm" @click="navigateToInventory">
        <MajesticonsOpen />
      </button>
    </template>

    <div class="grid gap-2">
      <div
        v-for="item in inventory"
        :key="item.id"
        class="group relative flex items-center p-3 rounded-lg bg-base-200/50 hover:bg-base-200 transition-all duration-200"
      >
        <div
          class="relative w-10 h-10 rounded-lg bg-base-300/50 flex items-center justify-center text-xl"
        >
          {{ item.emoji }}
          <div
            v-if="item.equipped"
            class="absolute -top-1 -right-1 w-3 h-3 bg-success rounded-full border-2 border-base-100"
          />
        </div>

        <div class="ml-3 flex-1 min-w-0">
          <div class="flex items-center gap-2">
            <h3 
              class="font-medium text-sm truncate"
              :class="getRarityColor(item.rarity)"
            >
              {{ item.name }}
            </h3>
            <span 
              class="badge badge-xs" 
              :class="getTypeColor(item.type)"
            >
              {{ item.type }}
            </span>
          </div>
          <p class="text-xs text-base-content/70 truncate mt-0.5">
            {{ item.description }}
          </p>
        </div>

        <div class="ml-3 flex items-center gap-2">
          <span class="text-xs font-medium">x{{ item.quantity }}</span>
          <button 
            class="btn btn-ghost btn-xs"
            :class="{ 'btn-disabled': !item.equippable }"
          >
            {{ item.equipped ? 'Unequip' : (item.equippable ? 'Equip' : 'Use') }}
          </button>
        </div>
      </div>
    </div>

    <template #footer>
      <div class="flex items-center justify-between text-sm text-base-content/70">
        <span>{{ inventory.length }} items found</span>
        <span>Storage: 8/10</span>
      </div>
    </template>
  </DashboardContainer>
</template>