<script lang="ts" setup>
import type { Reward } from "~/types/rewards/rewards";
import Fa6SolidCoins from "~icons/fa6-solid/coins";
import Fa6SolidGem from "~icons/fa6-solid/gem";
import FluentGift24Filled from "~icons/fluent/gift-24-filled";
import MdiStars from "~icons/mdi/stars";
import MiClose from "~icons/mi/close";

const props = defineProps<{
	reward: Reward;
}>();

const emit = defineEmits<{
	dismiss: [];
}>();

const handleDismiss = () => {
	emit("dismiss");
};
</script>

<template>
  <div class="alert bg-gradient-to-r from-base-100 to-base-200 shadow-lg rounded-lg p-5 border border-opacity-20 border-primary relative">
    <div class="flex items-center w-full">
      <div class="flex-none mr-4">
        <div class="w-12 h-12 bg-primary bg-opacity-10 rounded-full flex items-center justify-center">
          <FluentGift24Filled class="text-primary text-2xl" />
        </div>
      </div>
      <div class="flex-1">
        <h3 class="font-bold text-lg flex items-center gap-2">
          <Icon name="ph:confetti" class="text-yellow-500" />
          Daily Reward Claimed!
        </h3>
        <div class="text-sm mt-2 flex flex-wrap gap-2">
          <div v-if="reward.coins" class="badge badge-warning gap-1 py-3 text-neutral">
            <Fa6SolidCoins class="w-4 h-4" />
            {{ reward.coins }} Coins
          </div>
          <div v-if="reward.diamonds" class="badge badge-info gap-1 py-3">
            <Fa6SolidGem class="w-4 h-4 text-neutral" />
            {{ reward.diamonds }} Diamonds
          </div>
          <div v-if="reward.xp" class="badge badge-secondary gap-1 py-3">
            <MdiStars class="w-4 h-4 text-neutral" />
            {{ reward.xp }} XP
          </div>
        </div>
      </div>
      <button 
        class="btn btn-circle btn-ghost absolute top-2 right-2"
        @click="handleDismiss"
        aria-label="Close"
      >
        <MiClose class="text-lg" />
      </button>
    </div>
  </div>
</template>