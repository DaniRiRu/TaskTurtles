<script setup lang="ts">
import MajesticonsOpen from "~icons/majesticons/open";
import IconEdit from "~icons/material-symbols/edit";

interface Event {
	id: number;
	title: string;
	description?: string;
	startTime: number;
	priority: "high" | "medium" | "low";
}

const todayEvents = ref<Event[]>([
	{
		id: 1,
		title: "Team Meeting",
		description: "Weekly sync with development team",
		startTime: new Date().setHours(9, 0),
		priority: "high",
	},
	{
		id: 2,
		title: "Lunch Break",
		description: "Lunch with colleagues",
		startTime: new Date().setHours(12, 30),
		priority: "medium",
	},
	{
		id: 3,
		title: "Client Call",
		description: "Project update discussion",
		startTime: new Date().setHours(14, 0),
		priority: "high",
	},
	{
		id: 4,
		title: "Code Review",
		description: "Review pull requests",
		startTime: new Date().setHours(15, 30),
		priority: "low",
	},
]);

const formatTime = (timestamp: number) => {
	const date = new Date(timestamp);
	return date.toLocaleTimeString("en-US", {
		hour: "2-digit",
		minute: "2-digit",
		hour12: true,
	});
};

const getPriorityColor = (priority: "high" | "medium" | "low") => {
	const colors = {
		high: "text-error",
		medium: "text-warning",
		low: "text-info",
	};
	return (
		colors[priority.toLowerCase() as "high" | "medium" | "low"] ||
		"text-base-content"
	);
};

const stats = [
	{
		label: "Total Events",
		value: todayEvents.value.length,
		color: "text-primary",
	},
	{
		label: "High Priority",
		value: todayEvents.value.filter((e) => e.priority === "high").length,
		color: "text-error",
	},
	{
		label: "Upcoming",
		value: todayEvents.value.filter((e) => e.startTime > Date.now()).length,
		color: "text-success",
	},
];

const router = useRouter();

function navigateToCalendar() {
	router.push("/calendar");
}
</script>

<template>
  <DashboardContainer
    title="Today's Schedule"
    subtitle="Your upcoming events and meetings"
    :stats="stats"
    variant="glass"
    accentColor="primary"
  >
    <template #header-action>
      <button class="btn btn-ghost btn-sm" @click="navigateToCalendar">
        <MajesticonsOpen />
      </button>
    </template>

    <div v-if="todayEvents.length === 0" class="text-center text-base-content/60 py-4">
      No events scheduled for today
    </div>
    
    <div v-for="event in todayEvents" :key="event.id" 
      class="group flex items-start gap-4 p-3 rounded-lg hover:bg-base-content/5 transition-colors duration-200">
      <div class="flex-shrink-0 pt-1">
        <span class="text-sm font-medium text-base-content/70">
          {{ formatTime(event.startTime) }}
        </span>
      </div>
      
      <div class="flex-grow min-w-0">
        <div class="flex items-center gap-2">
          <h3 class="font-medium truncate">{{ event.title }}</h3>
          <span :class="`text-xs font-medium px-2 py-0.5 rounded-full bg-base-content/5 ${getPriorityColor(event.priority)}`">
            {{ event.priority }}
          </span>
        </div>
        <p v-if="event.description" class="text-sm text-base-content/60 mt-0.5 truncate">
          {{ event.description }}
        </p>
      </div>
      
      <button class="btn btn-ghost btn-xs opacity-0 group-hover:opacity-100 transition-opacity duration-200">
        <IconEdit class="w-4 h-4" />
      </button>
    </div>

    <template #footer>
      <div class="flex justify-between items-center">
        <span class="text-sm text-base-content/60">
          Showing {{ todayEvents.length }} events
        </span>
      </div>
    </template>
  </DashboardContainer>
</template>