<script lang="ts" setup>
interface ProductBoost {
	id: string;
	name: string;
	description: string;
	powerLevel: number;
	goldCost: number;
	saleGoldCost: number;
	salePercentage: number;
	emoji: string;
	duration: string;
	type: "productivity" | "focus" | "automation" | "power";
	boost: string;
}

const powerUps = ref<ProductBoost[]>([
	{
		id: "1",
		name: "Time Bender",
		description: "Extend your daily task completion time by 25%",
		powerLevel: 4,
		goldCost: 300,
		saleGoldCost: 200,
		salePercentage: 33,
		emoji: "⏰",
		duration: "24h",
		type: "productivity",
		boost: "+25% Time",
	},
	{
		id: "2",
		name: "Focus Shield",
		description: "Block all distractions for enhanced concentration",
		powerLevel: 5,
		goldCost: 500,
		saleGoldCost: 350,
		salePercentage: 30,
		emoji: "🛡️",
		duration: "12h",
		type: "focus",
		boost: "+40% Focus",
	},
	{
		id: "3",
		name: "Auto-Pilot",
		description: "Automate repetitive tasks with AI assistance",
		powerLevel: 3,
		goldCost: 400,
		saleGoldCost: 250,
		salePercentage: 38,
		emoji: "🤖",
		duration: "48h",
		type: "automation",
		boost: "+30% Speed",
	},
]);

const boostStats = ref([
	{
		label: "Power Level",
		value: "142",
		trend: 8,
		color: "text-primary",
	},
	{
		label: "Active Boosts",
		value: "3",
		trend: 2,
		color: "text-success",
	},
	{
		label: "Boost Points",
		value: "2,459",
		trend: 15,
		color: "text-secondary",
	},
]);

const formatGold = (amount: number) => {
	return `${amount.toLocaleString()} 🪙`;
};

const getTypeColor = (type: string) => {
	const colors = {
		productivity: "text-primary",
		focus: "text-secondary",
		automation: "text-accent",
		power: "text-success",
	};
	return colors[type as keyof typeof colors] || "text-primary";
};

const getPowerLevel = (level: number) => {
	return Array.from({ length: 5 }, (_, i) => i < level);
};

const router = useRouter();

function navigateToShop() {
	router.push("/shop");
}
</script>

<template>
  <DashboardContainer
    title="Magic Shop"
    subtitle="Enhance your journey with magical boosts"
    :stats="boostStats"
    variant="glass"
    accent-color="secondary"
    max-height="400px"
  >
    <template #header-action>
      <div class="flex items-center gap-2">
        <div class="flex items-center gap-1">
          <span class="text-warning font-bold">2,450 🪙</span>
        </div>
        <button class="btn btn-ghost btn-sm" @click="navigateToShop">
          <MajesticonsOpen />
        </button>
      </div>
    </template>

    <div class="grid gap-3">
      <div
        v-for="power in powerUps"
        :key="power.id"
        class="group relative flex items-center p-3 rounded-xl bg-base-200/50 hover:bg-base-200 transition-all duration-200"
      >
        <div
          class="relative w-12 h-12 rounded-xl bg-base-300/50 flex items-center justify-center text-2xl"
        >
          {{ power.emoji }}
        </div>

        <div class="ml-3 flex-1 min-w-0">
          <div class="flex items-center gap-2">
            <h3 class="font-bold text-sm truncate">{{ power.name }}</h3>
            <div class="flex items-center gap-1">
              <div
                v-for="(filled, index) in getPowerLevel(power.powerLevel)"
                :key="index"
                class="w-1.5 h-1.5 rounded-full"
                :class="filled ? 'bg-secondary' : 'bg-base-300'"
              />
            </div>
          </div>
          <p class="text-xs text-base-content/70 truncate">
            {{ power.description }}
          </p>
          <div class="flex items-center gap-2 mt-1">
            <span class="badge badge-xs" :class="getTypeColor(power.type)">{{
              power.boost
            }}</span>
            <span class="badge badge-xs badge-outline">{{ power.duration }}</span>
          </div>
        </div>

        <div class="ml-3 text-right">
          <div class="flex items-center justify-end gap-2 mb-1">
            <span class="text-primary text-sm font-bold">{{
              formatGold(power.saleGoldCost)
            }}</span>
            <span class="text-base-content/50 line-through text-xs">{{
              formatGold(power.goldCost)
            }}</span>
          </div>
          <button class="btn btn-secondary btn-xs">View</button>
        </div>
      </div>
    </div>
  </DashboardContainer>
</template>