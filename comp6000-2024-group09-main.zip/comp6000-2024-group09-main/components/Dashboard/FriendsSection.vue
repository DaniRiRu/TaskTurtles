<!-- components/Dashboard/SidebarSection.vue -->
<script lang="ts" setup>
import MajesticonsOpen from "~icons/majesticons/open";
import MaterialSymbolsArrowForward from "~icons/material-symbols/arrow-forward";

const stats = [
	{
		label: "Online",
		value: "2",
		color: "text-success",
	},
	{
		label: "Busy",
		value: "2",
		color: "text-warning",
	},
	{
		label: "Offline",
		value: "1",
		color: "text-error",
	},
];

const router = useRouter();

function navigateToFriends() {
	router.push("/friends");
}
</script>

<template>
  <DashboardContainer 
    title="Friends" 
    subtitle="2 of 5 friends online"
    :stats="stats"
    max-height="400px"
  >
    <template #header-action>
      <button class="btn btn-ghost btn-sm" @click="navigateToFriends">
        <MajesticonsOpen />
      </button>
    </template>

    <div class="divide-y divide-base-200">
      <div 
        v-for="(status, i) in ['Working on tasks', 'In a meeting', 'Gaming', 'Taking a break', 'Offline', 'Playing games', 'Sleeping']" 
        :key="i"
        class="group p-4 hover:bg-base-200/50 transition-colors duration-200 cursor-pointer"
      >
        <div class="flex items-center justify-between min-w-0">
          <div class="flex items-center gap-3 min-w-0">
            <div class="avatar">
              <div class="w-10 rounded-full ring ring-base-200">
                <img 
                  :src="`https://api.dicebear.com/6.x/bottts/svg?seed=${i}`" 
                  alt="avatar" 
                />
              </div>
            </div>
            <div class="min-w-0">
              <div class="flex items-center gap-2">
                <h3 class="text-sm font-medium truncate">User_{{ (i + 1) * 123 }}</h3>
                <div 
                  class="badge badge-sm" 
                  :class="{
                    'badge-success': i < 2,
                    'badge-warning': i >= 2 && i < 4,
                    'badge-error': i >= 4
                  }"
                >
                  {{ i < 2 ? 'Online' : i >= 4 ? 'Offline' : 'Busy' }}
                </div>
              </div>
              <div class="flex items-center gap-2 mt-1">
                <p class="text-xs text-base-content/70 truncate">{{ status }}</p>
                <span class="text-xs text-base-content/50">•</span>
                <p class="text-xs text-base-content/50">{{ ['VS Code', 'Zoom', 'Steam', 'Spotify', ''][i] }}</p>
              </div>
            </div>
          </div>
          <div class="flex items-center gap-2">
            <div 
              class="w-2 h-2 rounded-full" 
              :class="{
                'bg-success animate-pulse': i < 2,
                'bg-warning': i >= 2 && i < 4,
                'bg-error': i >= 4
              }" 
            />
          </div>
        </div>
      </div>
    </div>

    <template #footer>
      <div class="join w-full">
        <input 
          type="text" 
          placeholder="Enter friend code..."
          class="input input-bordered join-item w-full" 
        />
        <button class="btn join-item btn-primary">
          <MaterialSymbolsArrowForward class="h-5 w-5" />
        </button>
      </div>
    </template>
  </DashboardContainer>
</template>