<script lang="ts" setup>
import Fa6SolidCoins from "~icons/fa6-solid/coins";
import Fa6SolidGem from "~icons/fa6-solid/gem";

interface Props {
	coins: number;
	diamonds: number;
}

const props = defineProps<Props>();
</script>

<template>
  <div class="flex flex-col gap-2">
    <div class="bg-base-100/80 backdrop-blur-md rounded-box px-3 py-2 flex items-center gap-3 shadow-md">
      <div class="flex items-center gap-2">
        <Fa6SolidCoins class="w-5 h-5 text-warning" />
        <span class="font-semibold">{{ coins }}</span>
      </div>
      <div class="h-4 w-px bg-base-content/20"></div>
      <div class="flex items-center gap-2">
        <Fa6SolidGem class="w-5 h-5 text-primary" />
        <span class="font-semibold">{{ diamonds }}</span>
      </div>
    </div>
  </div>
</template>