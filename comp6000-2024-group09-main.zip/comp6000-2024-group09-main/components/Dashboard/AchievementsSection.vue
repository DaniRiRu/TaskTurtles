<template>
  <DashboardContainer 
    title="Achievements" 
    subtitle="Track your productivity milestones"
    variant="glass"
    accentColor="success"
    :stats="[
      { label: 'UNLOCKED', value: unlockedCount, color: 'text-success' },
      { label: 'TOTAL', value: achievements.length },
      { label: 'COMPLETION', value: `${completionRate}%`, trend: weeklyTrend }
    ]"
  >
    <template #header-action>
      <button class="btn btn-ghost btn-sm" @click="navigateToAchievements">
        <MajesticonsOpen />
      </button>
    </template>

    <div class="grid grid-cols-1 gap-3 pb-4">
      <div v-for="(achievement, index) in achievements" :key="index"
        class="group flex items-center gap-4 p-3 rounded-xl transition-all duration-200"
        :class="achievement.unlocked ? 'bg-success/5' : 'bg-base-200/50'"
      >
        <div class="w-10 h-10 flex items-center justify-center rounded-lg"
          :class="achievement.unlocked ? 'bg-success/10' : 'bg-base-300/50'"
        >
          <span class="text-xl" :class="achievement.unlocked ? 'text-success' : 'text-base-content/50'">
            {{ achievement.icon }}
          </span>
        </div>

        <div class="flex-1 min-w-0">
          <div class="flex items-center gap-2">
            <h3 class="font-medium truncate">{{ achievement.title }}</h3>
            <div class="hidden group-hover:flex items-center gap-1 text-xs text-base-content/60">
              <span>{{ achievement.points }}</span>
              <span class="text-[10px]">PTS</span>
            </div>
          </div>
          <p class="text-sm text-base-content/60 truncate">{{ achievement.description }}</p>
        </div>

        <div class="flex items-center gap-2">
          <div class="progress-ring relative" v-if="!achievement.unlocked">
            <svg class="w-8 h-8">
              <circle
                class="text-base-300"
                stroke-width="2"
                stroke="currentColor"
                fill="transparent"
                r="15"
                cx="16"
                cy="16"
              />
              <circle
                class="text-success"
                stroke-width="2"
                stroke="currentColor"
                fill="transparent"
                r="15"
                cx="16"
                cy="16"
                :stroke-dasharray="94.2"
                :stroke-dashoffset="94.2 - (94.2 * achievement.progress) / 100"
              />
            </svg>
            <span class="absolute inset-0 flex items-center justify-center text-[10px] font-medium">
              {{ achievement.progress }}%
            </span>
          </div>
          <div v-else class="w-8 h-8 flex items-center justify-center text-success">
            <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
            </svg>
          </div>
        </div>
      </div>
    </div>

    <template #footer>
      <div class="flex items-center justify-between">
        <span class="text-sm text-base-content/60">Total Points: {{ totalPoints }}</span>
        <button class="btn btn-sm btn-ghost" @click="navigateToAchievements">View All</button>
      </div>
    </template>
  </DashboardContainer>
</template>

<script setup>
import MajesticonsOpen from "~icons/majesticons/open";

const router = useRouter();

function navigateToAchievements() {
	router.push("/achievements");
}

const achievements = ref([
	{
		icon: "🎯",
		title: "Task Master",
		description: "Complete 100 tasks",
		unlocked: true,
		points: 500,
		progress: 100,
	},
	{
		icon: "⚡",
		title: "Speed Demon",
		description: "Complete 10 tasks in one day",
		unlocked: true,
		points: 200,
		progress: 100,
	},
	{
		icon: "🌟",
		title: "Perfect Week",
		description: "Complete all planned tasks for 7 days straight",
		unlocked: false,
		points: 300,
		progress: 71,
	},
	{
		icon: "🏆",
		title: "Productivity Champion",
		description: "Maintain 90% completion rate for a month",
		unlocked: false,
		points: 1000,
		progress: 45,
	},
]);

const unlockedCount = computed(
	() => achievements.value.filter((a) => a.unlocked).length,
);

const completionRate = computed(() =>
	Math.round((unlockedCount.value / achievements.value.length) * 100),
);

const totalPoints = computed(() =>
	achievements.value
		.filter((a) => a.unlocked)
		.reduce((sum, achievement) => sum + achievement.points, 0),
);

const weeklyTrend = ref(5);
</script>