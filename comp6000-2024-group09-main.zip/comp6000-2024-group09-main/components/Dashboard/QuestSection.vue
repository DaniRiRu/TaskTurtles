<script setup>
import MaterialSymbolsCalendarMonth from "~icons/material-symbols/calendar-month";
import MaterialSymbolsStar from "~icons/material-symbols/star";

const questTemplates = [
	{
		type: "tasks",
		titleTemplate: "Complete {target} tasks",
		minTarget: 2,
		maxTarget: 5,
	},
	{
		type: "pomodoro",
		titleTemplate: "Complete {target} pomodoro sessions",
		minTarget: 2,
		maxTarget: 4,
	},
	{
		type: "notes",
		titleTemplate: "Create {target} notes",
		minTarget: 1,
		maxTarget: 3,
	},
	{
		type: "focus",
		titleTemplate: "Maintain {target} minutes of focus time",
		minTarget: 30,
		maxTarget: 120,
	},
];

const difficulties = ["easy", "medium", "hard"];

const generateDailyQuests = () => {
	const selectedTemplates = [...questTemplates]
		.sort(() => Math.random() - 0.5)
		.slice(0, 3);

	return selectedTemplates.map((template, index) => {
		const target =
			Math.floor(
				Math.random() * (template.maxTarget - template.minTarget + 1),
			) + template.minTarget;
		const difficulty =
			difficulties[Math.floor(Math.random() * difficulties.length)];

		return {
			id: index + 1,
			type: template.type,
			title: template.titleTemplate.replace("{target}", target),
			target,
			currentProgress: 0,
			reward: calculateReward(difficulty, target),
			difficulty,
			completed: false,
		};
	});
};

const calculateReward = (difficulty, target) => {
	const baseReward = {
		easy: 50,
		medium: 100,
		hard: 150,
	};
	return baseReward[difficulty] * target;
};

const dailyQuests = ref(generateDailyQuests());
const lastRefresh = ref(new Date().setHours(0, 0, 0, 0));
const timeUntilTomorrow = ref("");

const completedQuestCount = computed(() => {
	return dailyQuests.value.filter((quest) => quest.completed).length;
});

const questsByDifficulty = computed(() => {
	return dailyQuests.value.reduce(
		(acc, quest) => {
			acc[quest.difficulty] = (acc[quest.difficulty] || 0) + 1;
			return acc;
		},
		{ easy: 0, medium: 0, hard: 0 },
	);
});

const stats = computed(() => [
	{
		label: "Easy",
		value: questsByDifficulty.value.easy,
	},
	{
		label: "Medium",
		value: questsByDifficulty.value.medium,
	},
	{
		label: "Hard",
		value: questsByDifficulty.value.hard,
	},
]);

const subtitle = computed(
	() =>
		`${completedQuestCount.value} of ${dailyQuests.value.length} quests completed`,
);

const updateTimeUntilTomorrow = () => {
	const now = new Date();
	const tomorrow = new Date(now);
	tomorrow.setDate(tomorrow.getDate() + 1);
	tomorrow.setHours(0, 0, 0, 0);

	const diff = tomorrow - now;
	const hours = Math.floor(diff / (1000 * 60 * 60));
	const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

	timeUntilTomorrow.value = `${hours}h ${minutes}m`;
};

const checkAndRefreshQuests = () => {
	const now = new Date();
	const currentDay = now.setHours(0, 0, 0, 0);

	if (currentDay > lastRefresh.value) {
		dailyQuests.value = generateDailyQuests();
		lastRefresh.value = currentDay;
	}
};

const toggleQuest = (questId) => {
	const quest = dailyQuests.value.find((q) => q.id === questId);
	if (quest) {
		quest.completed = !quest.completed;
		if (quest.completed) {
			quest.currentProgress = quest.target;
		} else {
			quest.currentProgress = 0;
		}
	}
};

onMounted(() => {
	checkAndRefreshQuests();
	updateTimeUntilTomorrow();
	const timer = setInterval(() => {
		checkAndRefreshQuests();
		updateTimeUntilTomorrow();
	}, 60000);

	onUnmounted(() => {
		clearInterval(timer);
	});
});
</script>

<template>
  <DashboardContainer 
    title="Daily Quests" 
    :subtitle="subtitle"
    :stats="stats"
    max-height="300px"
  >
    <template #header-action>
      <div class="flex items-center gap-2 text-sm text-base-content/70">
        <MaterialSymbolsCalendarMonth class="w-4 h-4" />
        <span>{{ timeUntilTomorrow }}</span>
      </div>
    </template>

    <div class="divide-y divide-base-200">
      <div 
        v-for="quest in dailyQuests" 
        :key="quest.id" 
        class="group p-4 hover:bg-base-200/50 transition-colors duration-200 cursor-pointer"
        @click="toggleQuest(quest.id)"
      >
        <div class="flex items-center justify-between min-w-0">
          <div class="flex items-center gap-3 min-w-0">
            <div 
              class="checkbox checkbox-sm" 
              :class="{
                'checkbox-success': quest.completed
              }"
              :checked="quest.completed"
            />
            <div class="min-w-0">
              <h3 class="text-sm font-medium">{{ quest.title }}</h3>
              <div class="w-32 bg-base-300 rounded-full h-1.5 mt-2">
                <div 
                  class="bg-primary h-1.5 rounded-full transition-all duration-300"
                  :class="{ 'bg-success': quest.completed }"
                  :style="{ width: `${(quest.currentProgress / quest.target) * 100}%` }"
                />
              </div>
            </div>
          </div>
          <div class="flex items-center gap-2">
            <span class="badge badge-sm badge-ghost gap-1">
              <MaterialSymbolsStar class="w-3 h-3" />
              {{ quest.reward }}xp
            </span>
            <span 
              class="badge badge-sm shrink-0" 
              :class="{
                'badge-success': quest.difficulty === 'easy',
                'badge-warning': quest.difficulty === 'medium',
                'badge-error': quest.difficulty === 'hard'
              }"
            >
              {{ quest.difficulty }}
            </span>
          </div>
        </div>
      </div>
    </div>
  </DashboardContainer>
</template>