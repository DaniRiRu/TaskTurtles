<script lang="ts" setup>
interface Props {
	title: string;
	subtitle?: string;
	stats?: Array<{
		label: string;
		value: string | number;
		color?: string;
		trend?: number;
		icon?: string;
	}>;
	containerClass?: string;
	showHeader?: boolean;
	maxHeight?: string;
	variant?: "default" | "glass" | "accent" | "neutral";
	accentColor?: string;
}

const props = withDefaults(defineProps<Props>(), {
	subtitle: "",
	stats: () => [],
	containerClass: "",
	showHeader: true,
	maxHeight: "300px",
	variant: "default",
	accentColor: "primary",
});

const containerStyles = computed(() => ({
	glass: "bg-base-100/80 backdrop-blur-xl border border-base-200",
	accent: `bg-gradient-to-r from-${props.accentColor}/10 via-base-100 to-${props.accentColor}/5 border border-${props.accentColor}/20`,
	neutral: "bg-neutral/5 border border-neutral/20",
	default: "bg-base-100 shadow-sm",
}));
</script>

<template>
  <div
    class="rounded-xl transition-all duration-300 group hover:shadow-xl relative overflow-hidden w-full h-full flex flex-col"
    :class="[containerStyles[variant], containerClass]"
  >
    <div
      class="absolute inset-0 opacity-[0.03] bg-[radial-gradient(circle_at_1px_1px,base-content_1px,transparent_0)]"
      style="background-size: 12px 12px;"
    />

    <div class="relative flex flex-col h-full">
      <div v-if="showHeader" class="p-4 flex-none">
        <div class="flex items-start justify-between gap-4">
          <div class="flex-1 min-w-0">
            <div class="flex items-center gap-3">
              <div
                :class="`w-2 h-2 rounded-full bg-${accentColor} ring-2 ring-${accentColor}/20`"
              />
              <h2 class="text-lg font-medium tracking-tight truncate">
                {{ title }}
              </h2>
            </div>
            <p
              v-if="subtitle"
              class="mt-1 text-sm text-base-content/60 tracking-wide"
            >
              {{ subtitle }}
            </p>
          </div>

          <div class="flex items-center gap-2">
            <slot name="header-action" />
          </div>
        </div>

        <div
          v-if="stats.length > 0"
          class="grid grid-cols-2 sm:grid-cols-3 gap-4 mt-4"
        >
          <div
            v-for="(stat, index) in stats"
            :key="index"
            class="card bg-base-200/50 hover:bg-base-200 transition-colors duration-200 p-3"
          >
            <div class="flex items-center justify-between mb-2">
              <span
                class="text-xs uppercase tracking-wider text-base-content/50 font-medium"
              >
                {{ stat.label }}
              </span>
              <div
                v-if="stat.trend"
                :class="`flex items-center text-xs font-medium px-2 py-1 rounded-full ${
                  stat.trend > 0
                    ? 'bg-success/10 text-success'
                    : 'bg-error/10 text-error'
                }`"
              >
                {{ stat.trend > 0 ? '↑' : '↓' }}
                {{ Math.abs(stat.trend) }}%
              </div>
            </div>
            <div class="flex items-baseline gap-2">
              <span
                class="text-2xl font-bold"
                :class="stat.color || `text-${accentColor}`"
              >
                {{ stat.value }}
              </span>
            </div>
          </div>
        </div>

        <slot name="header-extra" />
      </div>

      <div
        :class="`px-4 overflow-y-auto scrollbar-thin scrollbar-track-transparent scrollbar-thumb-${accentColor}/20 hover:scrollbar-thumb-${accentColor}/30 flex-1`"
        :style="{ maxHeight }"
      >
        <slot />
      </div>

      <div
        v-if="$slots['footer']"
        class="px-4 py-3 border-t border-base-content/10 bg-base-content/[0.02] mt-auto flex-none"
      >
        <slot name="footer" />
      </div>
    </div>

    <div
      class="absolute inset-0 rounded-xl ring-1 ring-inset ring-base-content/[0.05] pointer-events-none transition-colors duration-300 group-hover:ring-base-content/10"
    />
  </div>
</template>