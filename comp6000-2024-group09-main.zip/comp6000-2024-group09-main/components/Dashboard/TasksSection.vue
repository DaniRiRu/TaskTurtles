<script lang="ts" setup>
import type { Priority } from "~/types/core/priority";
import type { Task } from "~/types/core/task";
import { TaskStatus } from "~/types/core/task";
import MajesticonsOpen from "~icons/majesticons/open";
import MaterialSymbolsArrowForward from "~icons/material-symbols/arrow-forward";
import MaterialSymbolsCalendarMonth from "~icons/material-symbols/calendar-month";
import MaterialSymbolsClose from "~icons/material-symbols/close";

const backend = useBackend();
const newTaskTitle = ref("");

const { data: tasks, refresh } = await useAsyncData("tasks", async () => {
	const response = await backend.tasks.list();
	if ("error" in response) {
		console.error(response.error);
		return [];
	}
	return response.tasks;
});

const tasksByStatus = computed(() => {
	if (!tasks.value)
		return {
			[TaskStatus.Todo]: 0,
			[TaskStatus.InProgress]: 0,
			[TaskStatus.Done]: 0,
		};

	return tasks.value.reduce(
		(acc, task) => {
			acc[task.status as TaskStatus] =
				(acc[task.status as TaskStatus] || 0) + 1;
			return acc;
		},
		{} as Record<TaskStatus, number>,
	);
});

const stats = computed(() => [
	{
		label: "To Do",
		value: tasksByStatus.value[TaskStatus.Todo] || 0,
	},
	{
		label: "In Progress",
		value: tasksByStatus.value[TaskStatus.InProgress] || 0,
	},
	{
		label: "Done",
		value: tasksByStatus.value[TaskStatus.Done] || 0,
	},
]);

const subtitle = computed(
	() =>
		`${tasksByStatus.value[TaskStatus.Done] || 0} of ${Object.values(tasksByStatus.value).reduce((a, b) => a + b, 0)} tasks completed`,
);

const recentTasks = computed(() => {
	if (!tasks.value) return [];

	return [...tasks.value]
		.sort(
			(a, b) => new Date(b.dueDate).getTime() - new Date(a.dueDate).getTime(),
		)
		.slice(0, 10);
});

async function addTask() {
	if (!newTaskTitle.value.trim()) return;

	const newTask: Task = {
		id: "",
		title: newTaskTitle.value,
		description: "",
		dueDate: new Date(),
		status: TaskStatus.Todo,
		priority: undefined,
		tags: [],
	};

	await backend.tasks.add(newTask);
	newTaskTitle.value = "";
	refresh();
}

async function deleteTask(event: Event, task: Task) {
	event.stopPropagation();
	await backend.tasks.delete(task);
	refresh();
}

const router = useRouter();

function navigateToTasks() {
	router.push("/tasks");
}

function formatDate(date: Date) {
	const taskDate = new Date(date);
	const today = new Date();
	const tomorrow = new Date(today);
	tomorrow.setDate(tomorrow.getDate() + 1);

	if (taskDate.toDateString() === today.toDateString()) {
		return "Today";
	}
	if (taskDate.toDateString() === tomorrow.toDateString()) {
		return "Tomorrow";
	}

	const diffTime = Math.abs(taskDate.getTime() - today.getTime());
	const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

	if (diffDays <= 7) {
		return taskDate.toLocaleDateString("en-US", { weekday: "long" });
	}

	return taskDate.toLocaleDateString("en-US", {
		month: "short",
		day: "numeric",
		year:
			today.getFullYear() !== taskDate.getFullYear() ? "numeric" : undefined,
	});
}
</script>

<template>
  <DashboardContainer 
    title="Tasks Overview" 
    :subtitle="subtitle"
    :stats="stats"
    max-height="200px"
  >
    <template #header-action>
      <button class="btn btn-ghost btn-sm" @click="navigateToTasks">
        <MajesticonsOpen />
      </button>
    </template>

    <div v-if="recentTasks.length === 0" class="text-center py-8">
      <p class="text-base-content/70">No tasks available</p>
      <p class="text-sm text-base-content/50 mt-1">Add a task below to get started</p>
    </div>
    <div v-else class="divide-y divide-base-200">
      <div 
        v-for="task in recentTasks" 
        :key="task.id"
        class="group p-4 hover:bg-base-200/50 transition-colors duration-200 cursor-pointer"
        @click="navigateToTasks"
      >
        <div class="flex items-center justify-between min-w-0">
          <div class="flex items-center gap-3 min-w-0">
            <div 
              class="w-2 h-2 rounded-full shrink-0"
              :style="{ backgroundColor: (task.priority as Priority)?.color || '#888' }" 
            />
            <div class="min-w-0">
              <h3 class="text-sm font-medium truncate">{{ task.title }}</h3>
              <div class="flex gap-1 mt-1">
                <span 
                  v-for="tag in task.tags" 
                  :key="tag.id"
                  class="badge badge-sm badge-ghost"
                >
                  {{ tag.title }}
                </span>
              </div>
            </div>
          </div>
          <div class="flex items-center gap-2">
            <div class="flex items-center text-xs text-base-content/70">
              <MaterialSymbolsCalendarMonth class="w-4 h-4 mr-1" />
              {{ formatDate(task.dueDate) }}
            </div>
            <span 
              class="badge badge-sm shrink-0 ml-2" 
              :class="{
                'badge-error': task.status === TaskStatus.Todo,
                'badge-warning': task.status === TaskStatus.InProgress,
                'badge-success': task.status === TaskStatus.Done,
              }"
            >
              {{ task.status.replace(/-/g, ' ') }}
            </span>
            <button 
              class="btn btn-ghost btn-xs opacity-0 group-hover:opacity-100 transition-opacity duration-200 text-error" 
              @click="(e) => deleteTask(e, task)"
            >
              <MaterialSymbolsClose />
            </button>
          </div>
        </div>
      </div>
    </div>

    <template #footer>
      <div class="join w-full">
        <input 
          v-model="newTaskTitle" 
          type="text" 
          placeholder="Add a new task..."
          class="input input-bordered join-item w-full" 
          @keyup.enter="addTask" 
        />
        <button 
          class="btn join-item btn-primary" 
          @click="addTask" 
          :disabled="!newTaskTitle.trim()"
        >
          <MaterialSymbolsArrowForward class="h-5 w-5" />
        </button>
      </div>
    </template>
  </DashboardContainer>
</template>