<script lang="ts" setup>
const { getDailyQuote } = useQuotes();
const dailyQuote = ref(getDailyQuote());
</script>
<template>
  <DashboardContainer
    title="Daily Motivation"
    subtitle="Your daily dose of productivity inspiration"
    variant="glass"
    :max-height="'300px'"
  >
    <div class="flex flex-col items-center justify-center h-full py-4">
      <div class="relative w-full max-w-xl px-6">
        <div class="flex flex-col items-center space-y-4 pt-2">
          <p class="text-lg md:text-xl font-serif italic text-center leading-relaxed text-base-content/90 px-4">
            {{ dailyQuote.quote }}
          </p>
          <div class="flex flex-col items-center">
            <p class="text-base font-semibold text-primary hover:text-primary/80 transition-colors duration-300">
              {{ dailyQuote.author }}
            </p>
            <div class="flex items-center gap-2 mt-1">
              <div class="badge badge-primary badge-outline badge-sm">Quote #{{ dailyQuote.index + 1 }}</div>
              <div class="badge badge-ghost badge-sm">{{ dailyQuote.formattedDate }}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </DashboardContainer>
</template>