<script lang="ts" setup>
import MajesticonsOpen from "~icons/majesticons/open";
import MaterialSymbolsCalendarMonth from "~icons/material-symbols/calendar-month";
import MaterialSymbolsClose from "~icons/material-symbols/close";
import MaterialSymbolsEdit from "~icons/material-symbols/edit";
import MaterialSymbolsStar from "~icons/material-symbols/star";
import MaterialSymbolsStarOutline from "~icons/material-symbols/star-outline";

const newEntryContent = ref("");
const showNewEntryForm = ref(false);

const entries = ref([
	{
		id: "1",
		content:
			"Had a productive meeting with the team today. We finalized the new feature specs.",
		createdAt: new Date(),
		isStarred: true,
		mood: "happy",
	},
	{
		id: "2",
		content:
			"Started learning Nuxt 3 and Firebase. The combination seems powerful!",
		createdAt: new Date(Date.now() - 86400000),
		isStarred: true,
		mood: "excited",
	},
	{
		id: "3",
		content: "Remember to call mom tomorrow and wish her happy birthday",
		createdAt: new Date(Date.now() - 172800000),
		isStarred: false,
		mood: "neutral",
	},
	{
		id: "4",
		content:
			"Great workout session at the gym. New personal record on deadlifts!",
		createdAt: new Date(Date.now() - 259200000),
		isStarred: false,
		mood: "energetic",
	},
	{
		id: "5",
		content:
			"Found an interesting article about productivity techniques. Need to implement some of these.",
		createdAt: new Date(Date.now() - 345600000),
		isStarred: false,
		mood: "focused",
	},
]);

const stats = computed(() => {
	const totalEntries = entries.value.length;
	const starredEntries = entries.value.filter(
		(entry) => entry.isStarred,
	).length;
	const thisWeekEntries = entries.value.filter((entry) => {
		const entryDate = new Date(entry.createdAt);
		const today = new Date();
		const weekAgo = new Date(today.setDate(today.getDate() - 7));
		return entryDate >= weekAgo;
	}).length;

	return [
		{
			label: "Total",
			value: totalEntries,
		},
		{
			label: "This Week",
			value: thisWeekEntries,
		},
		{
			label: "Starred",
			value: starredEntries,
		},
	];
});

const subtitle = computed(() => {
	if (!entries.value?.length) return "Start your journaling journey";
	return `${entries.value.length} entries in your journal`;
});

const recentEntries = computed(() => {
	return [...entries.value]
		.sort(
			(a, b) =>
				new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
		)
		.slice(0, 5);
});

function addEntry() {
	if (!newEntryContent.value.trim()) return;

	const newEntry = {
		id: crypto.randomUUID(),
		content: newEntryContent.value,
		createdAt: new Date(),
		isStarred: false,
		mood: "neutral",
	};

	entries.value.unshift(newEntry);
	newEntryContent.value = "";
	showNewEntryForm.value = false;
}

function deleteEntry(event: Event, entry: { id: string }) {
	event.stopPropagation();
	entries.value = entries.value.filter((e) => e.id !== entry.id);
}

function toggleStar(event: Event, entry: { id: string; isStarred: boolean }) {
	event.stopPropagation();
	const targetEntry = entries.value.find((e) => e.id === entry.id);
	if (targetEntry) {
		targetEntry.isStarred = !targetEntry.isStarred;
	}
}

const router = useRouter();

function navigateToJournal() {
	router.push("/journal");
}

function formatDate(date: Date) {
	return new Date(date).toLocaleDateString("en-US", {
		month: "short",
		day: "numeric",
	});
}

function formatTime(date: Date) {
	return new Date(date).toLocaleTimeString("en-US", {
		hour: "2-digit",
		minute: "2-digit",
	});
}
</script>

<template>
  <DashboardContainer title="Daily Journal" :subtitle="subtitle" :stats="stats">
    <template #header-action>
      <button class="btn btn-ghost btn-sm" @click="navigateToJournal">
        <MajesticonsOpen />
      </button>
    </template>

    <div v-if="recentEntries.length === 0" class="flex flex-col items-center justify-center space-y-4 py-8">
      <MaterialSymbolsEdit class="w-12 h-12 text-base-content/30" />
      <div class="text-center">
        <p class="text-base-content/70">Your Journal Awaits</p>
        <p class="text-sm text-base-content/50 mt-1">Start documenting your journey today</p>
      </div>
    </div>

    <div v-else class="space-y-3">
      <div v-for="entry in recentEntries" :key="entry.id"
        class="card bg-base-200 shadow-sm hover:shadow-md transition-all duration-200 cursor-pointer"
        @click="navigateToJournal">
        <div class="card-body p-4">
          <div class="flex items-start justify-between gap-4">
            <div class="flex-1 min-w-0">
              <p class="text-sm line-clamp-2">{{ entry.content }}</p>
              <div class="flex items-center gap-2 mt-2">
                <MaterialSymbolsCalendarMonth class="w-4 h-4 text-base-content/50" />
                <span class="text-xs text-base-content/50">{{ formatDate(entry.createdAt) }} at {{
                  formatTime(entry.createdAt) }}</span>
              </div>
            </div>
            <div class="flex flex-col gap-2">
              <button class="btn btn-ghost btn-xs" @click="(e) => toggleStar(e, entry)">
                <MaterialSymbolsStar v-if="entry.isStarred" class="text-warning" />
                <MaterialSymbolsStarOutline v-else />
              </button>
              <button
                class="btn btn-ghost btn-xs opacity-0 group-hover:opacity-100 transition-opacity duration-200 text-error"
                @click="(e) => deleteEntry(e, entry)">
                <MaterialSymbolsClose />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <template #footer>
      <div v-if="!showNewEntryForm" class="flex justify-center">
        <button class="btn btn-primary btn-sm gap-2" @click="showNewEntryForm = true">
          <MaterialSymbolsEdit class="w-4 h-4" />
          New Entry
        </button>
      </div>

      <div v-else class="space-y-2">
        <textarea v-model="newEntryContent" rows="2" placeholder="What's on your mind?"
          class="textarea textarea-bordered w-full resize-none" @keyup.enter="addEntry" />
        <div class="flex justify-end gap-2">
          <button class="btn btn-ghost btn-sm" @click="showNewEntryForm = false">Cancel</button>
          <button class="btn btn-primary btn-sm" @click="addEntry" :disabled="!newEntryContent.trim()">
            Save Entry
          </button>
        </div>
      </div>
    </template>
  </DashboardContainer>
</template>