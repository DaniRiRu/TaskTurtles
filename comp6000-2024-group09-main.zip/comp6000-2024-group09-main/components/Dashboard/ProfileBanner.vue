<script lang="ts" setup>
import type { UserProgress } from "~/types/backend/meta/progress";
import ProfileWallet from "./ProfileWallet.vue";

interface Props {
	userPhotoURL: string | null;
	userDisplayName: string | null;
	joinDate: string;
	totalProjects: number;
	totalTasks: number;
	completionRate: number;
	progress: UserProgress;
	wallet: {
		coins: number;
		diamonds: number;
	};
	isLoading: boolean;
}

const props = defineProps<Props>();

const levelData = computed(() => ({
	currentLevel: Math.floor(props.progress.xp / 1000) + 1,
	currentXP: props.progress.xp,
	nextLevelXP: Math.floor(props.progress.xp / 1000 + 1) * 1000,
}));

const xpProgress = computed(() => {
	return (levelData.value.currentXP / levelData.value.nextLevelXP) * 100;
});

const userRank = computed(() => {
	if (levelData.value.currentLevel < 5) return "Novice Explorer";
	if (levelData.value.currentLevel < 10) return "Rising Star";
	if (levelData.value.currentLevel < 15) return "Task Master";
	if (levelData.value.currentLevel < 20) return "Productivity Guru";
	return "Legendary Achiever";
});

const rankColor = computed(() => {
	if (levelData.value.currentLevel < 5) return "accent";
	if (levelData.value.currentLevel < 10) return "primary";
	if (levelData.value.currentLevel < 15) return "secondary";
	if (levelData.value.currentLevel < 20) return "info";
	return "warning";
});

const streak = computed(() => {
	const sortedDates = [...props.progress.loginHistory]
		.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
		.map((login) => new Date(login.date).toISOString().split("T")[0]);

	if (sortedDates.length === 0) return 0;

	const today = new Date().toISOString().split("T")[0];
	const yesterday = new Date(Date.now() - 86400000).toISOString().split("T")[0];

	if (sortedDates[0] !== today && sortedDates[0] !== yesterday) return 0;

	let currentStreak = 1;
	for (let i = 1; i < sortedDates.length; i++) {
		const currentDate = new Date(sortedDates[i - 1]);
		const previousDate = new Date(sortedDates[i]);

		const diffDays = Math.floor(
			(currentDate.getTime() - previousDate.getTime()) / (1000 * 60 * 60 * 24),
		);

		if (diffDays === 1) {
			currentStreak += 1;
		} else {
			break;
		}
	}

	return currentStreak;
});
</script>

<template>
  <div>
    <div class="transition-all duration-300 ease-in-out fixed top-0 h-18 left-0 w-full bg-gradient-to-b from-base-200 from-70% z-2"></div>
    <div class="relative w-full py-3 sm:py-5">
      <div class="relative h-32 sm:h-40 md:h-52 lg:h-64 w-full rounded-xl bg-base-300 overflow-hidden shadow-xl">
        <img src="public/images/banner.png" alt="Profile Banner" class="w-full h-full object-cover" />
        <div class="absolute inset-0 bg-gradient-to-t from-base-300/90 to-transparent"></div>
        <div class="absolute top-4 right-4 flex items-center gap-3">
          <div v-if="isLoading" class="skeleton w-32 h-12"></div>
          <ProfileWallet v-else :coins="wallet.coins" :diamonds="wallet.diamonds" />
        </div>
      </div>
      <div class="absolute -bottom-14 sm:-bottom-16 md:-bottom-20 left-4 sm:left-8 flex items-end gap-4 sm:gap-6">
        <div class="relative group">
          <div class="avatar">
            <div class="w-24 sm:w-32 md:w-36 lg:w-40 rounded-full ring ring-2 ring-primary ring-offset-4 ring-offset-base-100 shadow-2xl transition-all duration-300 group-hover:ring-4">
              <div v-if="isLoading" class="skeleton w-full h-full rounded-full"></div>
              <img v-else :src="userPhotoURL || ''" :alt="`${userDisplayName || 'User'}'s profile picture`" class="group-hover:scale-105 transition-transform duration-300" />
            </div>
          </div>
          <div v-if="!isLoading" class="absolute -bottom-2 -right-2 bg-gradient-to-r from-primary to-secondary rounded-lg px-1.5 py-1 sm:px-2 sm:py-1.5 flex items-center gap-1 sm:gap-1.5 shadow-lg border-2 border-base-100 transform transition-all duration-300 group-hover:scale-105 group-hover:shadow-2xl">
            <div class="flex flex-col items-center">
              <span class="font-bold text-primary-content text-sm sm:text-base">{{ levelData.currentLevel }}</span>
            </div>
            <div class="h-5 sm:h-6 w-0.5 bg-primary-content/20"></div>
            <div class="flex flex-col items-start">
              <div class="w-10 sm:w-12 h-1 bg-primary-content/30 rounded-full overflow-hidden">
                <div class="h-full bg-primary-content rounded-full transition-all duration-300" :style="{ width: `${xpProgress}%` }"></div>
              </div>
              <span class="text-[6px] sm:text-[8px] text-primary-content/80 mt-0.5">{{ levelData.currentXP }}/{{ levelData.nextLevelXP }} XP</span>
            </div>
          </div>
        </div>
        <div class="hidden sm:flex flex-col gap-2 mb-8">
          <div v-if="isLoading" class="skeleton w-48 h-10"></div>
          <h1 v-else class="text-3xl sm:text-4xl lg:text-5xl font-bold">{{ userDisplayName || "Anonymous User" }}</h1>
          <div class="flex items-center gap-3 flex-wrap">
            <div v-if="isLoading" class="skeleton w-32 h-8"></div>
            <div v-else :class="`badge badge-${rankColor} badge-lg p-3 sm:p-4 text-sm sm:text-base font-semibold`">{{ userRank }}</div>
            <div v-if="!isLoading" class="flex items-center gap-2">
              <div class="tooltip tooltip-bottom" data-tip="Active streak of daily logins">
                <div class="badge badge-neutral gap-1">
                  <span class="text-warning">🔥</span>
                  {{ streak }} days
                </div>
              </div>
              <span class="text-base-content/50">•</span>
              <p class="text-sm sm:text-base text-base-content/70">Joined {{ joinDate }}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="mt-20 sm:mt-24 md:mt-28 px-4 sm:px-8">
      <div class="sm:hidden flex flex-col gap-2 mb-6">
        <div v-if="isLoading" class="skeleton w-48 h-8"></div>
        <h1 v-else class="text-2xl font-bold">{{ userDisplayName || "Anonymous User" }}</h1>
        <div class="flex items-center gap-2 flex-wrap">
          <div v-if="isLoading" class="skeleton w-24 h-6"></div>
          <template v-else>
            <div :class="`badge badge-${rankColor} badge-lg text-sm`">{{ userRank }}</div>
            <p class="text-xs text-base-content/70">Joined {{ joinDate }}</p>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>