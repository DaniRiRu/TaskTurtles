<script lang="ts" setup>
const props = defineProps<{
	image?: Component;
	title?: string;
	description?: string;
	actionName?: string;
	action?: () => void;
}>();
</script>

<template>
    <div class="flex items-center justify-center h-80vh">
        <div class="text-center max-w-xs">
            <div v-if="image" class="mb-4">
                <component :is="image" class="w-20 h-20 mx-auto opacity-20" />
            </div>

            <div v-if="title" class="text-lg font-semibold">
                {{ title }}
            </div>

            <div v-if="description" class="text-sm opacity-60">
                {{ description }}
            </div>

            <button v-if="actionName && action" @click="action" class="mt-8 btn btn-primary">
                <div class="flex items-center space-x-2">
                    <component v-if="image" :is="image" class="w-5 h-5" />
                    <span>{{ actionName }}</span>
                </div>
            </button>
        </div>
    </div>
</template>