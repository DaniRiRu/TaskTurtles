<!-- <script setup lang="ts">
import { useScroll } from "@vueuse/core";

type Page = {
	url: string;
	title: string;
};

defineProps<{
	pages: Page[];
	currentIndex: number;
}>();

const emit = defineEmits<(e: "update:currentIndex", value: number) => void>();

const iframeContainer = ref<HTMLElement | null>(null);
const { y: scrollY } = useScroll(window);
const startOffset = ref(0);
const currentProgress = ref(0);

onMounted(() => {
	startOffset.value = window.innerHeight * 0.5;
});

watch(
	scrollY,
	() => {
		if (!startOffset.value) return;
		const targetProgress = Math.max(
			0,
			Math.min(1, scrollY.value / startOffset.value),
		);
		const t = targetProgress;
		currentProgress.value = t < 0.5 ? 4 * t * t * t : 1 - (-2 * t + 2) ** 3 / 2;
	},
	{ immediate: true },
);

const transform = computed(() => {
	const rotateX = 6 * (1 - currentProgress.value);
	const rotateZ = -14 * (1 - currentProgress.value);
	const scale = 1 + 0.2 * (1 - currentProgress.value);

	return `perspective(1000px) rotateX(${rotateX}deg) rotateZ(${rotateZ}deg) scale(${scale})`;
});
</script>

<template>
  <div ref="iframeContainer" :style="{ transform }" class="relative z-10 w-full h-[85vh] max-h-3xl transform-gpu">
    <div class="flex w-full h-full justify-center overflow-visible max-lg:-mt-94">
      <div class="w-full max-w-7xl flex gap-8">
        <iframe v-for="(page, idx) in pages" :key="idx"  :class="[
          'w-full h-full rounded-3xl shadow-xl bg-base-100 shrink-0 transition-all duration-500 ease-in-out pointer-events-none',
          'transform-gpu backface-hidden preserve-3d will-change-transform',
          { 'translate-x-[calc(-100%)]': idx > currentIndex }
        ]"
         :style="{
          transform: `translateX(calc(-${currentIndex * 100}% - ${currentIndex * 2}rem))`
        }" tabindex="-1" loading="lazy"></iframe>
      </div>
    </div>
    <nav class="flex gap-2 absolute left-1/2 transform -translate-x-1/2 p-2 rounded-full bg-secondary/5 backdrop-blur-lg -mt-6" role="tablist">
      <div v-for="(page, idx) in pages" :key="idx">
        <button type="button" class="flex items-center gap-2 px-4 py-2 rounded-full transition-all duration-300 bg-secondary/10 hover:bg-secondary/20" :class="[currentIndex === idx && '!bg-primary text-primary-content']" @click="emit('update:currentIndex', idx)">
          <span class="text-sm font-medium">{{ page.title }}</span>
        </button>
      </div>
    </nav>
  </div>
</template> -->
<script setup lang="ts">
import { useScroll, useWindowSize } from "@vueuse/core";

type Page = {
	url: string;
  image: string;
	title: string;
};

defineProps<{
	pages: Page[];
	currentIndex: number;
}>();

const emit = defineEmits<(e: "update:currentIndex", value: number) => void>();

const {width} = useWindowSize();

const iframeContainer = ref<HTMLElement | null>(null);
const { y: scrollY } = useScroll(window);
const startOffset = ref(0);
const currentProgress = ref(0);

onMounted(() => {
	startOffset.value = window.innerHeight * 0.5;
});

watch(
	scrollY,
	() => {
		if (!startOffset.value) return;
		const targetProgress = Math.max(
			0,
			Math.min(1, scrollY.value / startOffset.value),
		);
		const t = targetProgress;
		currentProgress.value = t < 0.5 ? 4 * t * t * t : 1 - (-2 * t + 2) ** 3 / 2;
	},
	{ immediate: true },
);

const transform = computed(() => {
  if(width.value < 768) return '';

	const rotateX = 6 * (1 - currentProgress.value);
	const rotateZ = -14 * (1 - currentProgress.value);
	const scale = 1 + 0.2 * (1 - currentProgress.value);

	return `perspective(1000px) rotateX(${rotateX}deg) rotateZ(${rotateZ}deg) scale(${scale})`;
});
</script>

<template>
  <div id="features" ref="iframeContainer" :style="{ transform }" class="relative z-10 w-full max-h-[85vh] max-h-3xl transform-gpu">
    <div class="md:flex w-full h-full justify-center overflow-visible max-lg:-mt-94">
      <div class="w-full max-w-7xl flex gap-8">
        <!-- <iframe v-for="(page, idx) in pages" :key="idx"  :class="[
          'w-full h-full rounded-3xl shadow-xl bg-base-100 shrink-0 transition-all duration-500 ease-in-out pointer-events-none',
          'transform-gpu backface-hidden preserve-3d will-change-transform',
          { 'translate-x-[calc(-100%)]': idx > currentIndex }
        ]"
         :style="{
          transform: `translateX(calc(-${currentIndex * 100}% - ${currentIndex * 2}rem))`
        }" tabindex="-1" loading="lazy"></iframe> -->
        <img v-for="(page, idx) in pages" :key="idx" :class="[
          'w-full rounded-3xl shadow-xl bg-base-100 shrink-0 transition-all duration-500 ease-in-out pointer-events-none',
          'transform-gpu backface-hidden preserve-3d will-change-transform',
          { 'translate-x-[calc(-100%)]': idx > currentIndex }
        ]"
         :style="{
          transform: `translateX(calc(-${currentIndex * 100}% - ${currentIndex * 2}rem))`
        }" tabindex="-1" loading="lazy" :src="page.image"></img>
      </div>
    </div>
    <nav class="flex gap-2 absolute left-1/2 transform -translate-x-1/2 p-2 rounded-full bg-secondary/5 backdrop-blur-lg -mt-6" role="tablist">
      <div v-for="(page, idx) in pages" :key="idx">
        <button type="button" class="flex items-center gap-2 px-4 py-2 rounded-full transition-all duration-300 bg-secondary/10 hover:bg-secondary/20" :class="[currentIndex === idx && '!bg-primary text-primary-content']" @click="emit('update:currentIndex', idx)">
          <span class="text-sm font-medium">{{ page.title }}</span>
        </button>
      </div>
    </nav>
  </div>
</template>