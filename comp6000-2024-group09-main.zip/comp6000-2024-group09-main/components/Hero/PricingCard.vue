<script lang="ts" setup>
import type { PricingPlan } from "~/types/frontend";

defineProps<{
	plan: PricingPlan;
}>();
</script>
<template>
    <div class="card-body gap-4 justify-between">
      <div class="flex flex-col">
        <h4 class="tracking-wide opacity-50 font-bold">{{ plan.name }} Plan</h4>
        <div>
          <span class="text-4xl font-black">${{ plan.price }}</span>
          <span class="opacity-50">/month</span>
        </div>
      </div>
      <div class="flex flex-col my-2 gap-2">
        <div 
          v-for="(feature, index) in plan.features" 
          :key="index"
          class="flex gap-4 items-center"
        >
          <MaterialSymbolsCheckCircleRounded class="text-green" />
          <span>
            {{ feature.text }}
          </span>
        </div>
      </div>
      <button class="btn btn-primary">Buy Now</button>
    </div>
</template>