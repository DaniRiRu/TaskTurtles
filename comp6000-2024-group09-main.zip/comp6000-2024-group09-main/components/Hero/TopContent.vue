<script setup>
const isVisible = ref(false);

const handleGetStarted = () => {
	navigateTo("/dashboard");
};

onMounted(() => {
	setTimeout(() => {
		isVisible.value = true;
	}, 50);
});
</script>

<template>
    <div class="grid space-y-6 text-start max-lg:text-center">
        <Transition appear enter-from-class="opacity-0 translate-y-16"
            enter-active-class="transition duration-1000 ease-out" enter-to-class="opacity-100 translate-y-0">
            <h1 v-show="isVisible"
                class="text-5xl sm:text-6xl font-bold text-base-content opacity-0 transform tracking-tight">
                <span>
                    Your Life,
                </span>
                <br />
                <span class="underline decoration-secondary/40">Organized.</span>
            </h1>
        </Transition>

        <Transition appear enter-from-class="opacity-0 translate-y-8"
            enter-active-class="transition duration-1000 ease-out delay-300" enter-to-class="opacity-100 translate-y-0">
            <p v-show="isVisible" class="text-xl sm:text-2xl text-base-content leading-relaxed opacity-0 transform tracking-tight">
                Organize your tasks, projects, and events with ease.
            </p>
        </Transition>

        <Transition appear enter-from-class="opacity-0 translate-y-8"
            enter-active-class="transition duration-1000 ease-out delay-600" enter-to-class="opacity-100 translate-y-0">
            <div v-show="isVisible" class="flex gap-3 max-lg:justify-center opacity-0 transform">
                <CoreUiAnimatedButton text="Begin Adventure"
                    className="text-primary-content hover:shadow-lg bg-primary border-0 hover:border-2 hover:bg-primary/10 hover:text-primary transition-all duration-200 rounded-xl" @click="handleGetStarted" />
            </div>
        </Transition>
    </div>
</template>