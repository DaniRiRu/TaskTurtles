<script lang="ts" setup>
type Feature = {
	title1: string;
	title2: string;
	description: string;
	pageIndex: number;
};

const props = defineProps<{
	features: Feature[];
	currentIndex: number;
}>();

const groupedFeatures = computed(() => {
	return props.features.reduce(
		(acc, feature) => {
			if (!acc[feature.pageIndex]) {
				acc[feature.pageIndex] = [];
			}
			acc[feature.pageIndex].push(feature);
			return acc;
		},
		{} as Record<number, Feature[]>,
	);
});
</script>

<template>
  <div class="relative w-full max-w-7xl mx-auto pt-16">
    <div class="flex w-full justify-center overflow-visible">
      <div class="w-full flex gap-8">
        <div 
          v-for="pageIndex in Object.keys(groupedFeatures).length" 
          :key="pageIndex"
          class="w-full shrink-0 grid grid-cols-1 md:grid-cols-2 gap-6 transition-all duration-500 ease-in-out"
          :class="{
            'opacity-0': currentIndex !== pageIndex - 1,
            'opacity-100': currentIndex === pageIndex - 1
          }"
          :style="{
            transform: `translateX(calc(-${currentIndex * 100}% - ${currentIndex * 2}rem))`
          }"
        >
          <HeroFeatureCard 
            v-for="(feature, index) in groupedFeatures[pageIndex - 1]" 
            :key="feature.title1" 
            :feature="feature" 
            :class="[
              '!bg-secondary/5 !p-0 transition-all duration-300 hover:scale-[1.01]',
              { 'md:col-span-2': index % 3 === 2 }
            ]" 
          />
        </div>
      </div>
    </div>
  </div>
</template>