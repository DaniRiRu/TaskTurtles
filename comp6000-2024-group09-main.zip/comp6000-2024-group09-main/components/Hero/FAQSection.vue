<script setup lang="ts">
const { faqs } = useFAQs();
</script>

<template>
  <section class="text-start" id="faq">
    <h2 class="text-4xl font-bold mb-8 ml-2">Frequently Asked Questions</h2>
    <div class="space-y-4 max-w-7xl mx-auto">
      <div
        v-for="faq in faqs"
        :key="faq.question"
        class="collapse collapse-arrow bg-secondary/5 rounded-3xl"
      >
        <input type="radio" name="faq-accordion" />
        <div class="collapse-title text-xl font-medium">
          {{ faq.question }}
        </div>
        <div class="collapse-content">
          <p>{{ faq.answer }}</p>
        </div>
      </div>
    </div>
  </section>
</template>