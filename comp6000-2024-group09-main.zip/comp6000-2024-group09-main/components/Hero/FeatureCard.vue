<script lang="ts" setup>
type Feature = {
	title1: string;
	title2: string;
	description: string;
};

defineProps<{
	feature: Feature;
}>();
</script>
<template>
    <div
        class="w-full flex flex-col justify-between items-center mx-auto bg-base-200 rounded-3xl max-lg:p-8 max-lg:py-10 gap-8">
        <div class="p-8 rounded-3xl w-full h-full flex flex-col justify-between">
              <h1 class="text-3xl font-bold mb-8">
                {{ feature.title1 }}
                <br />
                <span class="underline decoration-4 decoration-secondary/40">
                  {{ feature.title2 }}
                </span>
              </h1>
              <p class="text-md text-base-content/70 mb-4">
                {{ feature.description }}
              </p>
              <a href="#" class="text-primary hover:underline inline-flex items-center gap-2">
                Explore {{ feature.title2 }} →
              </a>
            </div>
    </div>
</template>