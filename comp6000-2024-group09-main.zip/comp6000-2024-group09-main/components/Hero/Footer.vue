<template>
<footer class="footer !max-md:grid-flow-row !max-sm:grid-cols-1 !max-md:grid-cols-3 bg-base-200 text-base-content p-10 rounded-3xl max-w-7xl mx-auto">
  <aside class="flex flex-col justify-between h-full !max-sm:col-span-1 max-md:col-span-3">
    <MdiTurtle class="w-16 h-16 text-primary" />
    <h1 class="text-2xl font-semibold text-base-content tracking-tight underline decoration-wavy decoration-secondary/40 decoration-3">
      TaskTurtles
    </h1>
  </aside>
  <nav>
    <h6 class="footer-title">Services</h6>
    <a class="link link-hover">Branding</a>
    <a class="link link-hover">Design</a>
    <a class="link link-hover">Marketing</a>
    <a class="link link-hover">Advertisement</a>
  </nav>
  <nav>
    <h6 class="footer-title">Company</h6>
    <a class="link link-hover">About us</a>
    <a class="link link-hover">Contact</a>
    <a class="link link-hover">Jobs</a>
    <a class="link link-hover">Press kit</a>
  </nav>
  <nav>
    <h6 class="footer-title">Legal</h6>
    <a class="link link-hover">Terms of use</a>
    <a class="link link-hover">Privacy policy</a>
    <a class="link link-hover">Cookie policy</a>
  </nav>
</footer>
</template>