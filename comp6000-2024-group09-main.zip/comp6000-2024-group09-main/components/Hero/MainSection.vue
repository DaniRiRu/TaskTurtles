<script setup lang="ts">
const { features, currentIndex } = useFeatures();
const { pages } = usePages();
</script>

<template>
  <section class="pt-32 lg:pt-48">
    <div class="flex max-lg:flex-col items-center justify-center gap-16 mb-16">
      <div class="w-md max-lg:p-12">
        <HeroTopContent />
      </div>
      <div class="w-3xl h-full w-full rounded-3xl flex-1 min-h-88 aspect-w-16 aspect-h-9" />
    </div>
    <HeroIframeCarousel v-model:currentIndex="currentIndex" :pages="pages" />
    <HeroFeatureCarousel v-model:currentIndex="currentIndex" :features="features" />
  </section>
</template>