<script setup lang="ts">
const { steps } = useHowItWorks();
</script>

<template>
  <section id="how-it-works" class="text-start">
    <h2 class="text-4xl font-bold mb-8 ml-2">How It Works</h2>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div
        v-for="step in steps"
        :key="step.number"
        class="p-8 rounded-3xl bg-secondary/5 backdrop-blur-lg transition-all duration-300 hover:scale-[1.02]"
      >
        <div class="text-secondary/60 font-bold text-5xl mb-4">{{ step.number }}</div>
        <h3 class="text-xl font-semibold mb-3">{{ step.title }}</h3>
        <p class="text-base-content/80">{{ step.description }}</p>
      </div>
    </div>
  </section>
</template>