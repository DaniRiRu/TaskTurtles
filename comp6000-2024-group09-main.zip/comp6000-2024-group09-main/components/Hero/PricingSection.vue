<script setup lang="ts">
const { plans } = usePricing();
</script>

<template>
  <section id="pricing" class="text-start">
    <h2 class="text-4xl font-bold mb-8 ml-2">Pricing</h2>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div
        v-for="plan in plans"
        :key="plan.name"
        class="card card-border border-base-300 rounded-3xl bg-secondary/5 backdrop-blur-lg transition-all duration-300 hover:scale-[1.02]"
        :class="{ 'border-2 border-primary': plan.popular }"
      >
        <HeroPricingCard :plan="plan" />
      </div>
    </div>
  </section>
</template>