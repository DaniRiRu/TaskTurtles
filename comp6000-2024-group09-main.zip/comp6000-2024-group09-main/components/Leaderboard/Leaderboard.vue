<template>
  <div class="min-h-screen pt-24 pb-10">
    <div v-if="loading" class="flex justify-center items-center py-12">
      <span class="loading loading-spinner loading-lg text-primary"></span>
    </div>

    <div v-else-if="error" class="alert alert-error shadow-lg max-w-2xl mx-auto">
      <span>Failed to load leaderboard</span>
      <button class="btn btn-sm btn-ghost" @click="fetchLeaderboard">Retry</button>
    </div>

    <div v-else class="container mx-auto px-4 space-y-12">
      <div class="text-center mb-16">
        <h1 class="text-4xl font-black mb-8">Global Rankings</h1>
        <div class="stats shadow bg-base-100 w-full max-w-3xl mx-auto">
          <div class="stat p-6">
            <div class="stat-title text-lg mb-2">Total Players</div>
            <div class="stat-value text-primary text-4xl">{{ totalEntries }}</div>
          </div>
          <div class="stat p-6">
            <div class="stat-title text-lg mb-2">Your Rank</div>
            <div class="stat-value text-accent text-4xl">#{{ userRank || '—' }}</div>
          </div>
          <div class="stat p-6">
            <div class="stat-title text-lg mb-2">Your Score</div>
            <div class="stat-value text-secondary text-4xl">{{ userScore.toLocaleString() }}</div>
          </div>
        </div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 relative">
        <div v-if="displayLeaderboard.length >= 2" 
          class="card bg-base-100 shadow-2xl lg:translate-y-8 transform transition-all duration-300 hover:scale-105">
          <div class="relative">
            <div class="absolute -top-4 left-1/2 -translate-x-1/2 bg-gray-400 text-white w-12 h-12 rounded-full flex items-center justify-center text-2xl font-bold shadow-lg">
              2
            </div>
          </div>
          <div class="card-body items-center text-center p-8">
            <div class="avatar -mt-20">
              <div class="w-24 h-24 rounded-full ring ring-gray-400 ring-offset-base-100 ring-offset-4 shadow-xl">
                <img
                  v-if="displayLeaderboard[1].avatar"
                  :src="displayLeaderboard[1].avatar"
                  :alt="displayLeaderboard[1].displayName"
                  class="object-cover"
                />
                <div v-else
                  class="w-full h-full bg-gradient-to-br from-gray-400 to-gray-500 flex items-center justify-center text-3xl font-bold text-white">
                  {{ displayLeaderboard[1].displayName.charAt(0).toUpperCase() }}
                </div>
              </div>
            </div>
            <h2 class="card-title mt-6 text-2xl">{{ displayLeaderboard[1].displayName }}</h2>
            <div class="text-5xl font-black font-mono text-gray-400 mt-4">
              {{ displayLeaderboard[1].score.toLocaleString() }}
            </div>
          </div>
        </div>

        <div v-if="displayLeaderboard.length >= 1" 
          class="card bg-base-100 shadow-2xl transform transition-all duration-300 hover:scale-105">
          <div class="relative">
            <div class="absolute -top-4 left-1/2 -translate-x-1/2 bg-yellow-500 text-white w-14 h-14 rounded-full flex items-center justify-center text-3xl font-bold shadow-lg">
              1
            </div>
          </div>
          <div class="card-body items-center text-center p-8">
            <div class="avatar -mt-20">
              <div class="w-32 h-32 rounded-full ring ring-yellow-500 ring-offset-base-100 ring-offset-4 shadow-xl">
                <img
                  v-if="displayLeaderboard[0].avatar"
                  :src="displayLeaderboard[0].avatar"
                  :alt="displayLeaderboard[0].displayName"
                  class="object-cover"
                />
                <div v-else
                  class="w-full h-full bg-gradient-to-br from-yellow-400 to-yellow-600 flex items-center justify-center text-4xl font-bold text-white">
                  {{ displayLeaderboard[0].displayName.charAt(0).toUpperCase() }}
                </div>
              </div>
            </div>
            <h2 class="card-title mt-6 text-3xl">{{ displayLeaderboard[0].displayName }}</h2>
            <div class="text-6xl font-black font-mono text-yellow-500 mt-4">
              {{ displayLeaderboard[0].score.toLocaleString() }}
            </div>
          </div>
        </div>

        <div v-if="displayLeaderboard.length >= 3" 
          class="card bg-base-100 shadow-2xl lg:translate-y-8 transform transition-all duration-300 hover:scale-105">
          <div class="relative">
            <div class="absolute -top-4 left-1/2 -translate-x-1/2 bg-amber-600 text-white w-12 h-12 rounded-full flex items-center justify-center text-2xl font-bold shadow-lg">
              3
            </div>
          </div>
          <div class="card-body items-center text-center p-8">
            <div class="avatar -mt-20">
              <div class="w-24 h-24 rounded-full ring ring-amber-600 ring-offset-base-100 ring-offset-4 shadow-xl">
                <img
                  v-if="displayLeaderboard[2].avatar"
                  :src="displayLeaderboard[2].avatar"
                  :alt="displayLeaderboard[2].displayName"
                  class="object-cover"
                />
                <div v-else
                  class="w-full h-full bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center text-3xl font-bold text-white">
                  {{ displayLeaderboard[2].displayName.charAt(0).toUpperCase() }}
                </div>
              </div>
            </div>
            <h2 class="card-title mt-6 text-2xl">{{ displayLeaderboard[2].displayName }}</h2>
            <div class="text-5xl font-black font-mono text-amber-600 mt-4">
              {{ displayLeaderboard[2].score.toLocaleString() }}
            </div>
          </div>
        </div>
      </div>

      <div class="card bg-base-100 shadow-xl overflow-x-auto mt-20">
        <div class="overflow-x-auto">
          <table class="table table-zebra w-full">
            <thead>
              <tr class="bg-base-100">
                <th class="py-6 px-6 text-lg font-bold w-24">Rank</th>
                <th class="py-6 px-6 text-lg font-bold">Player</th>
                <th class="py-6 px-6 text-lg font-bold text-right">Score</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(entry, index) in displayLeaderboard.slice(3)"
                :key="entry.userId"
                class="hover:bg-base-200/50 transition-colors duration-200"
                :class="{ 'bg-primary/10': entry.userId === currentUserId }">
                <td class="py-6 px-6">
                  <div class="flex items-center gap-2">
                    <span class="font-mono font-bold text-lg">#{{ entry.rank }}</span>
                  </div>
                </td>
                <td class="py-6 px-6">
                  <div class="flex items-center gap-4">
                    <div class="avatar">
                      <div class="w-16 h-16 rounded-full ring-2 ring-base-300">
                        <img v-if="entry.avatar" :src="entry.avatar" :alt="entry.displayName" class="object-cover" />
                        <div v-else
                          class="w-full h-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-2xl font-bold text-white">
                          {{ entry.displayName.charAt(0).toUpperCase() }}
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="font-bold text-lg">{{ entry.displayName }}</div>
                      <div v-if="entry.userId === currentUserId"
                        class="text-sm text-primary font-semibold flex items-center gap-2">
                        <span class="inline-block w-2 h-2 bg-primary rounded-full animate-pulse"></span>
                        You
                      </div>
                    </div>
                  </div>
                </td>
                <td class="py-6 px-6 text-right">
                  <div class="font-mono text-xl font-bold">{{ entry.score.toLocaleString() }}</div>
                  <div class="text-xs opacity-70">score</div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import type {
	LeaderboardEntry,
	LeaderboardResults,
} from "~/types/backend/leaderboard/leaderboard";

const backend = useBackend();
const user = useCurrentUser();

const loading = ref(true);
const error = ref(false);
const leaderboard = ref<LeaderboardEntry[]>([]);
const totalEntries = ref(0);
const userRank = ref(0);
const userScore = ref(0);

const currentUserId = computed(() => user.value?.uid || "");
const currentUserName = computed(() => user.value?.displayName || "Anonymous");
const currentUserAvatar = computed(() => user.value?.photoURL);

const displayLeaderboard = computed(() => {
	const list = [...leaderboard.value];

	const userInList = list.some((entry) => entry.userId === currentUserId.value);

	if (!userInList && userRank.value > 0) {
		list.push({
			userId: currentUserId.value,
			displayName: currentUserName.value,
			avatar: currentUserAvatar.value || "",
			score: userScore.value,
			rank: userRank.value,
		});

		list.sort((a, b) => b.score - a.score);
	}

	return list;
});

const fetchLeaderboard = async () => {
	try {
		loading.value = true;
		error.value = false;

		const response = (await backend.leaderboard.list()) as LeaderboardResults;

		if (response) {
			leaderboard.value = response.leaderboard;
			totalEntries.value = response.totalEntries;
			userRank.value = response.userRank || 0;
			userScore.value = response.userScore || 0;
		} else {
			error.value = true;
		}
	} catch (e) {
		error.value = true;
	} finally {
		loading.value = false;
	}
};

onMounted(() => {
	fetchLeaderboard();
});
</script>