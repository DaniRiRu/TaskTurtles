<template>
    <div class="w-full flex items-start gap-2">
        <div class="w-8 h-8 flex-shrink-0 rounded-full overflow-hidden">
            <div class="w-full h-full bg-primary/10 flex items-center justify-center">
                <GameIconsTurtleShell />
            </div>
        </div>
        <div
            class="inline-block px-3 py-1.5 rounded-lg text-sm leading-relaxed break-words whitespace-pre-wrap bg-base-200/80 text-base-content/90 rounded-bl-sm max-w-fit">
            <span class="inline-flex gap-1">
                <span class="w-1.5 h-1.5 bg-current rounded-full animate-bounce" style="animation-delay: 0ms;"></span>
                <span class="w-1.5 h-1.5 bg-current rounded-full animate-bounce" style="animation-delay: 150ms;"></span>
                <span class="w-1.5 h-1.5 bg-current rounded-full animate-bounce" style="animation-delay: 300ms;"></span>
            </span>
        </div>
    </div>
</template>

<script setup lang="ts">
import GameIconsTurtleShell from "~icons/game-icons/turtle-shell";
</script>