<script setup lang="ts">
import { watch } from "vue";

const { messages, chatContainer } = useChat();
const isResetting = ref(false);

const quickActions = [
	"How do I get started?",
	"Show me some examples",
	"What can you help me with?",
	"Show keyboard shortcuts",
];

const scrollToBottom = () => {
	if (chatContainer.value) {
		chatContainer.value.scrollTop = chatContainer.value.scrollHeight;
	}
};

watch(
	messages,
	() => {
		nextTick(() => {
			scrollToBottom();
		});
	},
	{ deep: true },
);

const currentUser = useCurrentUser();
const firstName = computed(() => {
	if (!currentUser.value?.displayName) return "";
	return currentUser.value.displayName.split(" ")[0];
});
</script>

<template>
  <div v-if="messages.length === 0" class="px-4 pb-24 pt-4 text-left font-semibold flex flex-col -space-y-2">
    <h2 class="text-2xl text-base-content mb-2">
      Hello {{ firstName || 'there' }}
    </h2>
    <p class="text-xl text-base-content/70">What can I help you with today?</p>
  </div>

  <div ref="chatContainer" class="flex-1 overflow-y-auto max-h-[calc(500px-4rem)] h-full px-3 py-2 space-y-2">
    <div
      v-if="isResetting"
      class="flex items-center justify-center w-full h-full"
    >
      <span class="loading loading-spinner loading-lg text-primary" />
    </div>
    <template v-else>
      <AiChatBotChatQuickActions
        v-if="messages.length === 0"
        :actions="quickActions"
      />
      <AiChatBotChatMessage
        v-for="(message, index) in messages"
        :key="index"
        :message="message"
      />
    </template>
  </div>
</template>