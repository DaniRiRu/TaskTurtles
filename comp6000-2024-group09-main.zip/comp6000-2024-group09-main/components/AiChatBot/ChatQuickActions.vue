<script setup lang="ts">
defineProps<{
	actions: string[];
}>();

const { sendMessage } = useChat();
</script>

<template>
    <div class="space-y-2">
        <div class="flex flex-wrap gap-2">
            <button v-for="action in actions" :key="action" @click="() => sendMessage(action)"
                class="px-4 py-2 text-sm bg-base-200/80 hover:bg-base-200 text-base-content/80 rounded-lg transition-colors shadow-sm">
                {{ action }}
            </button>
        </div>
    </div>
</template>