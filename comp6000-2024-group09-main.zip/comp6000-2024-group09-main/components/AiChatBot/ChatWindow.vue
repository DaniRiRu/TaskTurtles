<!-- components/AiChatBot/ChatWindow.vue -->
<script setup lang="ts">
defineProps<{
	onClose: () => void;
}>();
</script>

<template>
  <div class="fixed top-16 right-4 w-[420px] max-h-[70vh] bg-base-100 shadow-xl flex flex-col
      overflow-hidden border border-base-200/40 mt-4 rounded-box animate-slide-in z-50">
    <AiChatBotChatHeader :onClose="onClose" />
    <div class="flex-1 overflow-hidden max-h-[500px]">
      <AiChatBotChatMessages />
    </div>
    <AiChatBotChatInput />
  </div>
</template>

<style scoped>
@keyframes slide-in {
    from {
        opacity: 0;
        transform: translateY(20px);

  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.animate-slide-in {
  animation: slide-in 0.2s ease-out forwards;
}
</style>