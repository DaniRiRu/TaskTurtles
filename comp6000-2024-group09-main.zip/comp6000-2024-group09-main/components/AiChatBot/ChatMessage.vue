<!-- components/AiChatBot/ChatMessage.vue -->
<script setup lang="ts">
import type { Message } from "~/types/chat";
import GameIconsTurtleShell from "~icons/game-icons/turtle-shell";

const props = defineProps<{
	message: Message;
}>();

const userPhotoURL = computed(() => useCurrentUser().value?.photoURL || "");

const processedContent = computed(() => {
	if (!props.message.content) return "";

	let content = props.message.content;

	if (props.message.embeds?.length) {
		for (const embed of props.message.embeds) {
			if (embed.url) {
				content = content.replace(
					embed.url,
					`<a href="${embed.url}" target="_blank" class="text-primary underline">${embed.url}</a>`,
				);
			}
		}
	}

	const urlRegex = /(https?:\/\/[^\s<]+[^<.,:;"')\]\s])/g;
	content = content.replace(urlRegex, (url) => {
		return `<a href="${url}" target="_blank" class="text-primary underline">${url}</a>`;
	});

	return content;
});

const isTyping = computed(() => {
	return (
		!props.message.isUser &&
		props.message.isTyping &&
		props.message.content === ""
	);
});
</script>

<template>
  <div class="w-full flex items-start gap-2" :class="message.isUser ? 'flex-row-reverse' : 'flex-row'">
    <div class="w-8 h-8 flex-shrink-0 rounded-full overflow-hidden">
      <template v-if="message.isUser">
        <img v-if="userPhotoURL" :src="userPhotoURL" alt="User profile" class="w-full h-full object-cover" />
        <div v-else class="w-full h-full bg-primary/20 flex items-center justify-center">
          <div class="w-5 h-5 text-primary/70">
            <GameIconsTurtleShell />
          </div>
        </div>
      </template>
      <div v-else class="w-full h-full bg-primary/10 flex items-center justify-center">
        <div class="w-5 h-5">
          <GameIconsTurtleShell />
        </div>
      </div>
    </div>
    <div class="inline-block px-3 py-1.5 rounded-3xl text-sm leading-relaxed break-words whitespace-pre-wrap overflow-none" :class="[
      message.isUser
        ? 'bg-primary/90 text-primary-content !rounded-br-lg'
        : 'bg-base-200/80 text-base-content/90 !rounded-bl-md',
      message.content.length < 20 ? 'max-w-fit' : 'max-w-[85%]',
    ]">
      <template v-if="isTyping">
        <span class="typing-indicator inline-flex gap-1">
          <span class="w-1 h-1 rounded-full bg-current animate-bounce"></span>
          <span class="w-1 h-1 rounded-full bg-current animate-bounce [animation-delay:0.2s]"></span>
          <span class="w-1 h-1 rounded-full bg-current animate-bounce [animation-delay:0.4s]"></span>
        </span>
      </template>
      <template v-else>
        <span v-html="processedContent"></span>

        <template v-if="message.embeds">
          <template v-for="(embed, index) in message.embeds" :key="index">
            <AiChatBotEmbedsChatUrlEmbed v-if="embed.type === 'url'" :url="embed.url" :title="embed.title"
              :description="embed.description" :thumbnail="embed.thumbnail" />
            <AiChatBotEmbedsChatVideoEmbed v-else-if="embed.type === 'video'" :url="embed.url" />
          </template>
        </template>
      </template>
    </div>
  </div>
</template>