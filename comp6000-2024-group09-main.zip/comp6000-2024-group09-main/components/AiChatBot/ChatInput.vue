<script setup lang="ts">
import MaterialSymbolsArrowForwardRounded from "~icons/material-symbols/arrow-forward-rounded";
import MaterialSymbolsDeleteOutline from "~icons/material-symbols/delete-outline";

const {
	newMessage,
	sendMessage,
	resetChat,
	isProcessing,
	isBotTyping,
	isResetting,
} = useChat();

const handleSend = async () => {
	if (!newMessage.value.trim() || isProcessing.value) return;

	try {
		const message = newMessage.value;
		newMessage.value = "";
		await sendMessage(message);
	} catch (error) {
		console.error("Failed to send message:", error);
	}
};

const handleReset = async () => {
	if (isProcessing.value) return;
	await resetChat();
};

const handleKeydown = async (e: KeyboardEvent) => {
	if (e.key === "Enter" && !e.shiftKey) {
		e.preventDefault();
		await handleSend();
	}
};
</script>

<template>
  <div class="p-4 backdrop-blur-sm">
    <div class="flex items-center gap-3 max-w-4xl mx-auto">
      <div class="flex-1 relative">
        <textarea
          v-model="newMessage"
          rows="1"
          placeholder="Message Turtle Assistant..."
          @keydown="handleKeydown"
          class="w-full h-10 pl-4 pr-24 bg-base-200 rounded-2xl resize-none text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 placeholder:text-base-content/40 transition-all duration-200 backdrop-blur-sm flex items-center leading-[2.5rem]"
        />
        <div class="absolute right-1 top-1/2 -translate-y-1/2 flex items-center gap-1">
          <button
            @click="handleSend"
            class="p-2 bg-primary hover:bg-primary-focus active:scale-95 rounded-xl text-primary-content transition-all duration-200 disabled:opacity-50 disabled:hover:bg-primary group disabled:!bg-gray/50"
            :disabled="!newMessage.trim() || isProcessing"
            title="Send Message"
          >
            <MaterialSymbolsArrowForwardRounded
              class="w-4 h-4 transition-transform group-hover:scale-110"
            />
          </button>
          <button
            @click="handleReset"
            class="p-2 btn btn-error btn-sm btn-square rounded-xl transition-all duration-200 disabled:opacity-50 group"
            :disabled="isProcessing"
            title="Reset Chat"
          >
            <MaterialSymbolsDeleteOutline
              class="w-4 h-4 transition-transform group-hover:scale-110"
            />
          </button>
        </div>
      </div>
    </div>
  </div>
</template>