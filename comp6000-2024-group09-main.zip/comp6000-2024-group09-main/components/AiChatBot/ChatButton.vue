<!-- components/AiChatBot/ChatButton.vue -->
<script setup lang="ts">
import { computed } from "vue";
import MingcuteAiFill from "~icons/mingcute/ai-fill";

const emit = defineEmits<(e: "toggleChat") => void>();

const toggleChat = () => {
	emit("toggleChat");
};

const buttonClasses = computed(() => [
	"absolute bottom-4 right-4 w-16 z-10 h-16 bg-gradient-to-br from-secondary to-secondary-100 rounded-full flex items-center justify-center cursor-pointer transition-all duration-300 ease-in-out shadow-lg hover:shadow-xl hover:scale-105",
]);
</script>

<template>
  <div class="fixed bottom-0 right-0 w-40 h-40 brightness-100">
    <div :class="buttonClasses" @click="toggleChat" class="p-4">
      <MingcuteAiFill class="w-full h-full text-white" />
    </div>
  </div>
</template>