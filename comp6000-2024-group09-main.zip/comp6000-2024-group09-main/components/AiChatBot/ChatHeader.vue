<!-- components/AiChatBot/ChatHeader.vue -->
<script setup lang="ts">
import MdiTurtle from "~icons/mdi/turtle";
import MingcuteCloseFill from "~icons/mingcute/close-fill";

defineProps<{
	onClose: () => void;
}>();
</script>

<template>
  <div class="flex flex-col">
    <div class="px-3 pt-2.5 flex items-center justify-between">
      <div class="flex items-center space-x-2">
        <MdiTurtle class="w-4 h-4 text-primary" />
        <span class="font-medium text-sm text-base-content/90">Turtle Assistant</span>
      </div>
      <div class="flex items-center space-x-1">
        <button @click="onClose" class="p-0 btn btn-sm btn-circle btn-ghost border-0"
          title="Close">
          <MingcuteCloseFill class="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  </div>
</template>