<script setup lang="ts">
defineProps<{
	url: string;
	title?: string;
	description?: string;
	thumbnail?: string;
}>();
</script>

<template>
  <a :href="url" target="_blank" rel="noopener noreferrer"
    class="block mt-2 p-3 rounded-lg bg-base-200/50 hover:bg-base-200 transition-colors">
    <div class="flex gap-3">
      <img v-if="thumbnail" :src="thumbnail" class="w-16 h-16 object-cover rounded-md" alt="Link preview" />
      <div class="flex-1 min-w-0">
        <div class="text-sm font-medium text-base-content/90 truncate">
          {{ title || url }}
        </div>
        <div v-if="description" class="text-xs text-base-content/60 line-clamp-2 mt-1">
          {{ description }}
        </div>
        <div class="text-xs text-base-content/50 mt-1 truncate">
          {{ url }}
        </div>
      </div>
    </div>
  </a>
</template>