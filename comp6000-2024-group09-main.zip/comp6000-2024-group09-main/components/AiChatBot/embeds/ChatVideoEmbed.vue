<script setup lang="ts">
const props = defineProps<{
	url: string;
}>();

const videoId = computed(() => {
	const ytRegex =
		/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/;
	const match = props.url.match(ytRegex);
	return match?.[1] || null;
});
</script>

<template>
    <div v-if="videoId" class="mt-2 rounded-lg overflow-hidden aspect-video">
        <iframe :src="`https://www.youtube.com/embed/${videoId}`" class="w-full h-full" frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen></iframe>
    </div>
</template>