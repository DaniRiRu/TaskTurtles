<script lang="ts" setup>
import type { AnyCalendarEvent } from "~/types/calendar/events";

const props = defineProps<{
	calendarEvent: AnyCalendarEvent;
	isCompact?: boolean;
}>();

const showDetails = ref(false);

function formattedDate(time?: string): string {
	if (!time) return "";
	const date = new Date(time);
	return date.toLocaleTimeString("en-US", {
		hour: "2-digit",
		minute: "2-digit",
		hour12: false,
	});
}

const isAllDay = computed(() => {
	return !props.calendarEvent.start.dateTime && props.calendarEvent.start.date;
});

const eventStatus = computed(() => {
	switch (props.calendarEvent.status) {
		case "confirmed":
			return "bg-success/10 border-success/20 hover:bg-success/20";
		case "tentative":
			return "bg-warning/10 border-warning/20 hover:bg-warning/20";
		case "cancelled":
			return "bg-error/10 border-error/20 hover:bg-error/20";
		default:
			return "bg-primary/10 border-primary/20 hover:bg-primary/20";
	}
});

const eventUrl = computed(() => {
	switch (props.calendarEvent.provider) {
		case "google":
			return props.calendarEvent.htmlLink;
		case "outlook":
			return props.calendarEvent.webLink;
		default:
			return props.calendarEvent.url;
	}
});

const handleClick = (e: Event) => {
	e.stopPropagation();
	showDetails.value = true;
};
</script>

<template>
  <div @click="handleClick" :class="[
    'transition-colors duration-200 cursor-pointer',
    isCompact
      ? 'rounded-btn text-xs px-2 py-1 bg-secondary/10 hover:bg-primary/60'
      : [
        'rounded-md hover:!bg-secondary/10 p-3 !bg-base-100'
      ],
  ]">
    <div v-if="isCompact" :key="calendarEvent.id" class="truncate">
      {{ calendarEvent.summary }}
    </div>
    <div v-else class="flex gap-2 justify-between items-center">
      <div class="flex gap-3">
        <span :class="[
          'rounded-full size-7 text-xs flex items-center justify-center',
          eventStatus,
        ]"></span>
        <div class="flex flex-col">
          <h1 class="font-medium">
            {{ calendarEvent.summary }}
          </h1>
        </div>
      </div>
      <div class="flex flex-col gap-2">
        <div class="flex items-center bg-primary/10 rounded-full px-2 h-7 text-sm">
          <div class="text-xs opacity-60">
            {{ formattedDate(calendarEvent.start.dateTime) }}
          </div>
          <div v-if="calendarEvent.end.dateTime" class="text-xs opacity-60 ml-1">
            - {{ formattedDate(calendarEvent.end.dateTime) }}
          </div>
          <div v-else-if="isAllDay" class="text-xs opacity-60 ml-1 truncate min-w-10">
            All day
          </div>
        </div>
        <div v-if="calendarEvent.attendees"
          class="text-xs flex gap-0 items-center bg-accent text-accent-content rounded-full px-2 h-7">
          <MaterialSymbolsPerson class="size-5 p-1 -ml-1" />
          {{ calendarEvent.attendees.length }}
        </div>
      </div>
    </div>
  </div>
</template>