<script lang="ts" setup>
import { ModalPosition } from "~/enums/frontend/modal/ModalPosition";
import Icons8RightArrow from "~icons/icons8/right-arrow";
import LogosGoogleIcon from "~icons/logos/google-icon";
import VscodeIconsFileTypeOutlook from "~icons/vscode-icons/file-type-outlook";

const isOpen = defineModel<boolean>("isOpen");
const calendarUrl = ref("");
const changedProvider = ref<"google" | "outlook" | null>(null);

const googleProvider = useCalendarProvider("google");
const outlookProvider = useCalendarProvider("outlook");

const isGoogleConnected = ref(false);
const isOutlookConnected = ref(false);

const googleUserInfo = computed(() => googleProvider.getUserInfo());
const outlookUserInfo = computed(() => outlookProvider.getUserInfo());

const fetchCalendarEvents = async (provider: "google" | "outlook") => {
	try {
		const now = new Date();
		const thirtyDaysFromNow = new Date(
			now.getTime() + 30 * 24 * 60 * 60 * 1000,
		);
		const currentProvider =
			provider === "google" ? googleProvider : outlookProvider;
		const events = await currentProvider.getCalendarEvents(
			now,
			thirtyDaysFromNow,
		);
		console.log(`${provider} Calendar Events:`, events);
		return events;
	} catch (err) {
		console.error(`Failed to fetch ${provider} calendar events:`, err);
		return [];
	}
};

const checkConnection = async (provider: "google" | "outlook") => {
	try {
		const currentProvider =
			provider === "google" ? googleProvider : outlookProvider;
		const isConnected = await currentProvider.checkConnection();
		if (provider === "google") {
			isGoogleConnected.value = isConnected;
		} else {
			isOutlookConnected.value = isConnected;
		}
	} catch (err) {
		console.error(`Failed to check ${provider} connection:`, err);
	}
};

const checkInitialConnections = async () => {
	try {
		const googleConnected = await googleProvider.checkConnection();
		isGoogleConnected.value = googleConnected;

		await nextTick();

		const outlookConnected = await outlookProvider.checkConnection();
		isOutlookConnected.value = outlookConnected;
	} catch (err) {
		console.error("Failed to check initial connections:", err);
	}
};

const handleGoogleCalendar = async () => {
	try {
		changedProvider.value = "google";
		if (isGoogleConnected.value) {
			await googleProvider.disconnect();
			isGoogleConnected.value = false;
			return;
		}
		const connected = await googleProvider.connectCalendar();
		isGoogleConnected.value = await googleProvider.checkConnection();
		if (connected && isGoogleConnected.value) {
			await fetchCalendarEvents("google");
			isOpen.value = false;
		}
	} catch (err) {
		console.error("Failed to handle Google Calendar:", err);
	}
};

const handleOutlookCalendar = async () => {
	try {
		changedProvider.value = "outlook";
		if (isOutlookConnected.value) {
			await outlookProvider.disconnect();
			isOutlookConnected.value = false;
			return;
		}
		const connected = await outlookProvider.connectCalendar();
		isOutlookConnected.value = await outlookProvider.checkConnection();
		if (connected && isOutlookConnected.value) {
			await fetchCalendarEvents("outlook");
			isOpen.value = false;
		}
	} catch (err) {
		console.error("Failed to handle Outlook Calendar:", err);
	}
};

const handleICalSubscription = async () => {
	try {
		if (!calendarUrl.value) return;
		const urlPattern =
			/^(https?:\/\/)?([\w-])+\.{1}([a-zA-Z]{2,63})([/\w-]*)*\/?\??([^#\n\r]*)?#?([^\n\r]*)$/;
		if (!urlPattern.test(calendarUrl.value)) {
			console.error("Invalid URL format");
			return;
		}
		const backend = useBackend();
		await backend.calendar.ical.connection.updateConnection(calendarUrl.value);
		isOpen.value = false;
	} catch (err) {
		console.error("Failed to subscribe to iCal:", err);
	}
};

const handleClose = () => {
	isOpen.value = false;
	calendarUrl.value = "";
};

watch(isOpen, async (newValue) => {
	if (newValue) {
		await checkInitialConnections();
	} else if (changedProvider.value) {
		await checkConnection(changedProvider.value);
		changedProvider.value = null;
	}
});

onUnmounted(() => {
	if (googleProvider.error.value) googleProvider.disconnect();
	if (outlookProvider.error.value) outlookProvider.disconnect();
});
</script>

<template>
  <UniversalModal :isOpen="isOpen ?? false" :position="ModalPosition.Middle" @close="handleClose">
    <template #title>
      <h3 class="text-3xl font-bold text-base-content leading-tight">
        Connect Your<br />Calendar
      </h3>
      <p class="mt-2 text-base text-base-content/60">
        Choose your preferred calendar provider
      </p>
    </template>

    <template #default>
      <div v-if="googleProvider.error" class="mb-4 text-error text-sm">
        {{ googleProvider.error }}
      </div>
      <div v-if="outlookProvider.error" class="mb-4 text-error text-sm">
        {{ outlookProvider.error }}
      </div>
      <div v-if="googleProvider.success || outlookProvider.success" class="mb-4 text-success text-sm">
        {{ googleProvider.success || outlookProvider.success }}
      </div>

      <div class="space-y-8">
        <div class="space-y-4">
          <button @click="handleGoogleCalendar" :disabled="googleProvider.isLoading.value" :class="{
            'bg-success/10 hover:bg-error/10 border-success': isGoogleConnected,
            'hover:bg-primary/5': !isGoogleConnected
          }"
            class="w-full group p-4 rounded-box bg-secondary/5 border border-secondary/10 transition-all duration-200 flex items-center justify-between disabled:opacity-50 disabled:cursor-not-allowed">
            <div class="flex items-center gap-4">
              <LogosGoogleIcon class="size-8" />
              <div class="text-left">
                <div class="flex items-center gap-2">
                  <p class="font-semibold text-base text-base-content">Google Calendar</p>
                  <div v-if="isGoogleConnected"
                    class="px-2 py-0.5 rounded-full bg-success/20 text-success text-2xs font-medium">
                    Connected
                  </div>
                </div>
                <p v-if="isGoogleConnected" class="text-sm text-success">
                  {{ googleUserInfo?.email }}
                </p>
                <p v-else class="text-sm text-base-content/60">
                  Connect with Google
                </p>
              </div>
            </div>
            <div v-if="isGoogleConnected" class="flex items-center gap-1 text-xs text-error">
              <span>Disconnect</span>
              <span class="text-lg">×</span>
            </div>
            <Icons8RightArrow v-else
              class="size-5 text-base-content/30 group-hover:text-primary group-hover:translate-x-1 transition-all" />
          </button>

          <button @click="handleOutlookCalendar" :disabled="outlookProvider.isLoading.value" :class="{
            'bg-success/10 hover:bg-error/10 border-success': isOutlookConnected,
            'hover:bg-primary/5': !isOutlookConnected
          }"
            class="w-full group p-4 rounded-box border bg-secondary/5 border-secondary/10 transition-all duration-200 flex items-center justify-between">
            <div class="flex items-center gap-4">
              <VscodeIconsFileTypeOutlook class="size-8" />
              <div class="text-left">
                <div class="flex items-center gap-2">
                  <p class="font-semibold text-base text-base-content">Outlook Calendar</p>
                  <div v-if="isOutlookConnected"
                    class="px-2 py-0.5 rounded-full bg-success/20 text-success text-2xs font-medium">
                    Connected
                  </div>
                </div>
                <p v-if="isOutlookConnected" class="text-sm text-success">
                  {{ outlookUserInfo?.email }}
                </p>
                <p v-else class="text-sm text-base-content/60">
                  Coming Soon
                </p>
              </div>
            </div>
            <div v-if="isOutlookConnected" class="flex items-center gap-1 text-xs text-error">
              <span>Disconnect</span>
              <span class="text-lg">×</span>
            </div>
            <Icons8RightArrow v-else
              class="size-5 text-base-content/30 group-hover:text-primary group-hover:translate-x-1 transition-all" />
          </button>
        </div>

        <div class="space-y-4">
          <div class="flex items-center gap-3">
            <div class="h-px flex-1 bg-base-300"></div>
            <span class="text-sm text-base-content/50">or use calendar URL</span>
            <div class="h-px flex-1 bg-base-300"></div>
          </div>

          <div class="space-y-2">
            <input v-model="calendarUrl" type="url" placeholder="Paste your calendar URL here"
              class="input input-lg input-bordered w-full bg-base-200/50 placeholder:text-base-content/30 focus:outline-none focus:ring-2 focus:ring-primary/20 text-base" />
            <p class="text-xs text-base-content/50 px-1">
              Supports iCal (.ics) format
            </p>
          </div>

          <button @click="handleICalSubscription"
            class="flex justify-between btn btn-lg w-full"
            :class="{ 'btn-primary hover:border-2 hover:border-primary hover:bg-secondary/20 hover:text-base-content': calendarUrl }"
            :disabled="!calendarUrl">
            Connect Calendar
            <Icons8RightArrow class="size-5 ml-2" />
          </button>
        </div>
      </div>
    </template>
  </UniversalModal>
</template>