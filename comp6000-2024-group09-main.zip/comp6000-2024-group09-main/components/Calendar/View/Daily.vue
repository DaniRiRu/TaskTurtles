<script lang="ts" setup>
import type { CalendarHour } from "~/types/calendar";
import type { AnyCalendarEvent } from "~/types/calendar/events";

interface Props {
	currentDate: Date;
	events: AnyCalendarEvent[];
	hours: CalendarHour[];
}

const props = defineProps<Props>();
const emit = defineEmits<{
	addEvent: [];
	openEventDetails: [event: AnyCalendarEvent];
}>();

// Memoize the current date string for comparison
const currentDateString = computed(() => props.currentDate.toDateString());

function isFullDayForDate(event: AnyCalendarEvent, date: Date) {
	const eventStart = new Date(event.start.dateTime || event.start.date || "");
	const eventEnd = new Date(event.end.dateTime || event.end.date || "");

	// If it's an all-day event, it's always full day
	if (!event.start.dateTime) return true;

	const currentDate = new Date(date);
	currentDate.setHours(0, 0, 0, 0);
	const nextDate = new Date(currentDate);
	nextDate.setDate(nextDate.getDate() + 1);

	// If this is the start date, check if it starts at 00:00
	if (eventStart.toDateString() === date.toDateString()) {
		return eventStart.getHours() === 0 && eventStart.getMinutes() === 0;
	}

	// If this is the end date, check if it ends at 00:00 of the next day
	if (eventEnd.toDateString() === date.toDateString()) {
		return eventEnd.getHours() === 0 && eventEnd.getMinutes() === 0;
	}

	// For dates in between, it's always a full day
	return eventStart < currentDate && eventEnd >= nextDate;
}

const dailyAllDayEvents = computed(() => {
	return props.events.filter((event) => {
		const eventStart = new Date(event.start.dateTime || event.start.date || "");
		const eventEnd = new Date(event.end.dateTime || event.end.date || "");

		// Check if the current date falls within the event's duration
		const currentDate = new Date(props.currentDate);
		currentDate.setHours(0, 0, 0, 0);
		const startDate = new Date(eventStart);
		startDate.setHours(0, 0, 0, 0);
		const endDate = new Date(eventEnd);
		endDate.setHours(0, 0, 0, 0);

		const isWithinEventDuration =
			currentDate >= startDate && currentDate <= endDate;

		return isWithinEventDuration && isFullDayForDate(event, props.currentDate);
	});
});

const dailyTimeEvents = computed(() => {
	return props.events.filter((event) => {
		const eventStart = new Date(event.start.dateTime || event.start.date || "");
		const eventEnd = new Date(event.end.dateTime || event.end.date || "");

		// Check if the current date falls within the event's duration
		const currentDate = new Date(props.currentDate);
		currentDate.setHours(0, 0, 0, 0);
		const startDate = new Date(eventStart);
		startDate.setHours(0, 0, 0, 0);
		const endDate = new Date(eventEnd);
		endDate.setHours(0, 0, 0, 0);

		const isWithinEventDuration =
			currentDate >= startDate && currentDate <= endDate;

		// Only show in time grid if it's not a full day event
		return (
			isWithinEventDuration &&
			event.start.dateTime &&
			!isFullDayForDate(event, props.currentDate)
		);
	});
});

// Pre-calculate event times for better performance
const eventTimes = computed(() => {
	return dailyTimeEvents.value
		.map((event) => ({
			event,
			start: new Date(event.start.dateTime || event.start.date || ""),
			end: new Date(event.end.dateTime || event.end.date || ""),
		}))
		.sort((a, b) => a.start.getTime() - b.start.getTime());
});

const eventColumns = computed(() => {
	const timeSlots: { [key: string]: AnyCalendarEvent[][] } = {};
	const buffer = 5 * 60 * 1000;

	for (const { event, start: eventStart, end: eventEnd } of eventTimes.value) {
		let foundSlot = false;

		for (const slotKey in timeSlots) {
			const slot = timeSlots[slotKey];
			let hasOverlap = false;

			for (const column of slot) {
				for (const existingEvent of column) {
					const existingStart = new Date(
						existingEvent.start.dateTime || existingEvent.start.date || "",
					);
					const existingEnd = new Date(
						existingEvent.end.dateTime || existingEvent.end.date || "",
					);

					if (
						eventStart.getTime() - buffer <= existingEnd.getTime() &&
						eventEnd.getTime() + buffer >= existingStart.getTime()
					) {
						hasOverlap = true;
						break;
					}
				}
				if (hasOverlap) break;
			}

			if (hasOverlap) {
				let placed = false;
				for (const column of slot) {
					let canPlace = true;

					for (const existingEvent of column) {
						const existingStart = new Date(
							existingEvent.start.dateTime || existingEvent.start.date || "",
						);
						const existingEnd = new Date(
							existingEvent.end.dateTime || existingEvent.end.date || "",
						);

						if (
							eventStart.getTime() - buffer <= existingEnd.getTime() &&
							eventEnd.getTime() + buffer >= existingStart.getTime()
						) {
							canPlace = false;
							break;
						}
					}

					if (canPlace) {
						column.push(event);
						placed = true;
						foundSlot = true;
						break;
					}
				}

				if (!placed) {
					slot.push([event]);
					foundSlot = true;
				}
			}
		}

		if (!foundSlot) {
			const slotKey = `slot_${eventStart.getTime()}`;
			timeSlots[slotKey] = [[event]];
		}
	}

	return eventTimes.value.map(({ event }) => {
		for (const slot of Object.values(timeSlots)) {
			let columnIndex = -1;
			const totalColumns = slot.length;

			for (let i = 0; i < slot.length; i++) {
				const column = slot[i];
				const eventIndex = column.findIndex((e) => e.id === event.id);
				if (eventIndex !== -1) {
					columnIndex = i;
					break;
				}
			}

			if (columnIndex !== -1) {
				return {
					event,
					columnIndex,
					totalColumns,
				};
			}
		}

		return {
			event,
			columnIndex: 0,
			totalColumns: 1,
		};
	});
});

function calcEventTop(event: AnyCalendarEvent) {
	const startDate = new Date(event.start.dateTime || event.start.date || "");

	// If the event starts before the current day, start from 00:00
	if (startDate.toDateString() !== currentDateString.value) {
		return 0;
	}

	const startMinutes = startDate.getHours() * 60 + startDate.getMinutes();
	return (startMinutes / 1440) * 100;
}

function calcEventHeight(event: AnyCalendarEvent) {
	const startDate = new Date(event.start.dateTime || event.start.date || "");
	const endDate = new Date(event.end.dateTime || event.end.date || "");

	let startMinutes: number;
	let endMinutes: number;

	// If event starts before current day, use 00:00 as start
	if (startDate.toDateString() !== currentDateString.value) {
		startMinutes = 0;
	} else {
		startMinutes = startDate.getHours() * 60 + startDate.getMinutes();
	}

	// If event ends after current day, use 23:59 as end
	if (endDate.toDateString() !== currentDateString.value) {
		endMinutes = 24 * 60;
	} else {
		endMinutes = endDate.getHours() * 60 + endDate.getMinutes();
	}

	const heightPercent = ((endMinutes - startMinutes) / 1440) * 100;
	return Math.max(heightPercent, (5 / 1440) * 100);
}

function calcEventLeft(columnIndex: number, totalColumns: number) {
	const columnWidth = 100 / totalColumns;
	return columnIndex * columnWidth;
}

function calcEventWidth(totalColumns: number) {
	return 100 / totalColumns;
}

function calcEventZIndex(event: AnyCalendarEvent) {
	const startDate = new Date(event.start.dateTime || event.start.date || "");
	return startDate.getTime();
}

const getDailyHourClasses = (index: number) => [
	index === 0 ? "!rounded-t-box" : "",
	index === 23 ? "!rounded-b-box" : "",
	"!border-x-0",
];
</script>

<template>
	<div class="flex flex-col h-full">
		<div class="flex flex-col gap-1 mb-3" v-if="dailyAllDayEvents.length">
			<div class="flex flex-col w-full rounded-t-box rounded-b-md overflow-scroll bg-base-100">
				<div class="flex justify-between w-full p-4 pb-3 items-center text-md font-medium text-lg">
					{{ dailyAllDayEvents.length }} all-day event{{ dailyAllDayEvents.length != 1 ? 's' : '' }}
				</div>
			</div>
			<div class="flex flex-col gap-1 rounded-b-box overflow-scroll">
				<CalendarEvent v-for="event in dailyAllDayEvents" :key="event.id" :calendar-event="event"
					:is-compact="false" @click="emit('openEventDetails', event)" />
			</div>
		</div>

		<div class="relative flex-1 z-1">
			<div class="relative h-full">
				<CalendarHour v-for="(calendarHour, index) in hours" :key="index" :calendarHour="calendarHour"
					:showHour="true" :events="[]" :class="getDailyHourClasses(index)" />
				<div class="absolute inset-0 pointer-events-none right-12 top-2 bottom-2 left-24">
					<div v-for="{ event, columnIndex, totalColumns } in eventColumns" :key="event.id"
						class="absolute pointer-events-auto" :style="{
							top: `${calcEventTop(event)}%`,
							height: `${calcEventHeight(event)}%`,
							left: `${calcEventLeft(columnIndex, totalColumns)}%`,
							width: `${calcEventWidth(totalColumns)}%`,
							zIndex: calcEventZIndex(event)
						}">
						<CalendarEvent :calendar-event="event" :is-compact="true"
							class="h-full !min-h-6 !rounded-lg mx-1 cursor-pointer hover:opacity-90 transition-all duration-200"
							@click="emit('openEventDetails', event)" />
					</div>
				</div>
			</div>
		</div>
	</div>
</template>