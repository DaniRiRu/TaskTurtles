<script lang="ts" setup>
import type { CalendarHour } from "~/types/calendar";
import type { AnyCalendarEvent } from "~/types/calendar/events";

interface Props {
	currentDate: Date;
	events: AnyCalendarEvent[];
	hours: CalendarHour[];
	days: string[];
}

const props = defineProps<Props>();
const emit = defineEmits<{
	addEvent: [];
	openEventDetails: [event: AnyCalendarEvent];
}>();

const startOfWeek = computed(() => {
	const start = new Date(props.currentDate);
	start.setDate(start.getDate() - start.getDay());
	return start;
});

const weekDates = computed(() => {
	return props.days.map((_, index) => {
		const date = new Date(startOfWeek.value);
		date.setDate(date.getDate() + index);
		return date;
	});
});

function isFullDayForDate(event: AnyCalendarEvent, date: Date) {
	const eventStart = new Date(event.start.dateTime || event.start.date || "");
	const eventEnd = new Date(event.end.dateTime || event.end.date || "");

	if (!event.start.dateTime) return true;

	const currentDate = new Date(date);
	currentDate.setHours(0, 0, 0, 0);
	const nextDate = new Date(currentDate);
	nextDate.setDate(nextDate.getDate() + 1);

	if (eventStart.toDateString() === date.toDateString()) {
		return eventStart.getHours() === 0 && eventStart.getMinutes() === 0;
	}

	if (eventEnd.toDateString() === date.toDateString()) {
		return eventEnd.getHours() === 0 && eventEnd.getMinutes() === 0;
	}

	return eventStart < currentDate && eventEnd >= nextDate;
}

const weeklyAllDayEvents = computed(() => {
	const eventsByDay: { [key: string]: AnyCalendarEvent[] } = {};

	for (const date of weekDates.value) {
		const dateKey = date.toDateString();
		eventsByDay[dateKey] = props.events.filter((event) => {
			const eventStart = new Date(
				event.start.dateTime || event.start.date || "",
			);
			const eventEnd = new Date(event.end.dateTime || event.end.date || "");

			const currentDate = new Date(date);
			currentDate.setHours(0, 0, 0, 0);
			const startDate = new Date(eventStart);
			startDate.setHours(0, 0, 0, 0);
			const endDate = new Date(eventEnd);
			endDate.setHours(0, 0, 0, 0);

			const isWithinEventDuration =
				currentDate >= startDate && currentDate <= endDate;

			return isWithinEventDuration && isFullDayForDate(event, date);
		});
	}

	return eventsByDay;
});

const weeklyEvents = computed(() => {
	const eventsByDay: { [key: string]: AnyCalendarEvent[] } = {};

	for (const date of weekDates.value) {
		const dateKey = date.toDateString();
		eventsByDay[dateKey] = props.events.filter((event) => {
			const eventStart = new Date(
				event.start.dateTime || event.start.date || "",
			);
			const eventEnd = new Date(event.end.dateTime || event.end.date || "");

			const currentDate = new Date(date);
			currentDate.setHours(0, 0, 0, 0);
			const startDate = new Date(eventStart);
			startDate.setHours(0, 0, 0, 0);
			const endDate = new Date(eventEnd);
			endDate.setHours(0, 0, 0, 0);

			const isWithinEventDuration =
				currentDate >= startDate && currentDate <= endDate;

			return (
				isWithinEventDuration &&
				event.start.dateTime &&
				!isFullDayForDate(event, date)
			);
		});
	}

	return eventsByDay;
});

const processedEventsByDay = computed(() => {
	const processed: {
		[key: string]: {
			event: AnyCalendarEvent;
			columnIndex: number;
			totalColumns: number;
		}[];
	} = {};

	for (const [dateKey, dayEvents] of Object.entries(weeklyEvents.value)) {
		const timeSlots: { [key: string]: AnyCalendarEvent[][] } = {};
		const buffer = 5 * 60 * 1000;

		const sortedEvents = [...dayEvents].sort((a, b) => {
			const aStart = new Date(a.start.dateTime || a.start.date || "");
			const bStart = new Date(b.start.dateTime || b.start.date || "");
			return aStart.getTime() - bStart.getTime();
		});

		for (const event of sortedEvents) {
			const eventStart = new Date(
				event.start.dateTime || event.start.date || "",
			);
			const eventEnd = new Date(event.end.dateTime || event.end.date || "");
			let foundSlot = false;

			for (const slotKey in timeSlots) {
				const slot = timeSlots[slotKey];
				let hasOverlap = false;

				for (const column of slot) {
					for (const existingEvent of column) {
						const existingStart = new Date(
							existingEvent.start.dateTime || existingEvent.start.date || "",
						);
						const existingEnd = new Date(
							existingEvent.end.dateTime || existingEvent.end.date || "",
						);

						if (
							eventStart.getTime() - buffer <= existingEnd.getTime() &&
							eventEnd.getTime() + buffer >= existingStart.getTime()
						) {
							hasOverlap = true;
							break;
						}
					}
					if (hasOverlap) break;
				}

				if (hasOverlap) {
					let placed = false;
					for (const column of slot) {
						let canPlace = true;

						for (const existingEvent of column) {
							const existingStart = new Date(
								existingEvent.start.dateTime || existingEvent.start.date || "",
							);
							const existingEnd = new Date(
								existingEvent.end.dateTime || existingEvent.end.date || "",
							);

							if (
								eventStart.getTime() - buffer <= existingEnd.getTime() &&
								eventEnd.getTime() + buffer >= existingStart.getTime()
							) {
								canPlace = false;
								break;
							}
						}

						if (canPlace) {
							column.push(event);
							placed = true;
							foundSlot = true;
							break;
						}
					}

					if (!placed) {
						slot.push([event]);
						foundSlot = true;
					}
				}
			}

			if (!foundSlot) {
				const slotKey = `slot_${eventStart.getTime()}`;
				timeSlots[slotKey] = [[event]];
			}
		}

		processed[dateKey] = sortedEvents.map((event) => {
			for (const slot of Object.values(timeSlots)) {
				let columnIndex = -1;
				const totalColumns = slot.length;

				for (let i = 0; i < slot.length; i++) {
					const column = slot[i];
					const eventIndex = column.findIndex((e) => e.id === event.id);
					if (eventIndex !== -1) {
						columnIndex = i;
						break;
					}
				}

				if (columnIndex !== -1) {
					return {
						event,
						columnIndex,
						totalColumns,
					};
				}
			}

			return {
				event,
				columnIndex: 0,
				totalColumns: 1,
			};
		});
	}

	return processed;
});

function calcEventTop(event: AnyCalendarEvent, date: Date) {
	const eventStart = new Date(event.start.dateTime || event.start.date || "");

	if (eventStart.toDateString() !== date.toDateString()) {
		return 0;
	}

	const startMinutes = eventStart.getHours() * 60 + eventStart.getMinutes();
	return (startMinutes / 1440) * 100;
}

function calcEventHeight(event: AnyCalendarEvent, date: Date) {
	const eventStart = new Date(event.start.dateTime || event.start.date || "");
	const eventEnd = new Date(event.end.dateTime || event.end.date || "");

	let startMinutes = 0;
	let endMinutes = 0;

	if (eventStart.toDateString() !== date.toDateString()) {
		startMinutes = 0;
	} else {
		startMinutes = eventStart.getHours() * 60 + eventStart.getMinutes();
	}

	if (eventEnd.toDateString() !== date.toDateString()) {
		endMinutes = 24 * 60;
	} else {
		endMinutes = eventEnd.getHours() * 60 + eventEnd.getMinutes();
	}

	const heightPercent = ((endMinutes - startMinutes) / 1440) * 100;
	return Math.max(heightPercent, (5 / 1440) * 100);
}

function calcEventLeft(columnIndex: number, totalColumns: number) {
	const columnWidth = 100 / totalColumns;
	return columnIndex * columnWidth;
}

function calcEventWidth(totalColumns: number) {
	return 100 / totalColumns;
}

function calcEventZIndex(event: AnyCalendarEvent) {
	const startDate = new Date(event.start.dateTime || event.start.date || "");
	return startDate.getTime();
}

const getWeeklyHourClasses = (index: number, dayIndex: number) => [
	index === 0 ? "!rounded-t-box" : "",
	index === 23 ? "!rounded-b-box" : "",
	dayIndex % 2 === 0 ? "" : "!bg-opacity-60",
	dayIndex % 7 === 6 ? "!border-r-0" : "",
];

const maxAllDayEvents = computed(() => {
	let maxEvents = 0;
	for (const date of weekDates.value) {
		const dateKey = date.toDateString();
		const eventsCount = weeklyAllDayEvents.value[dateKey]?.length || 0;
		maxEvents = Math.max(maxEvents, eventsCount);
	}
	return maxEvents;
});

function getAllDayEventsHeight() {
	if (maxAllDayEvents.value === 0) return 0;

	const eventHeight = 28;
	const maxVisibleEvents = 3;

	if (maxAllDayEvents.value <= maxVisibleEvents) {
		return maxAllDayEvents.value * eventHeight;
	}

	return (maxVisibleEvents - 0.5) * eventHeight;
}
</script>

<template>
	<div class="grid grid-cols-7">
		<div class="flex flex-col justify-center items-center tracking-wider text-sm" v-for="(day, dayIndex) in days"
			:key="day">
			<div
				class="py-2 pb-3 text-center uppercase text-xs lg:text-sm font-medium flex items-center justify-center gap-2">
				<span class="opacity-60">{{ day.slice(0, 3) }}</span>
				<span class="flex items-center text-md justify-center size-6 rounded-full" :class="weekDates[dayIndex].toDateString() === new Date().toDateString()
					? 'bg-primary text-primary-content'
					: 'opacity-60'
					">
					{{ weekDates[dayIndex].getDate() }}
				</span>
			</div>

			<div class="w-full px-1 mb-1" :style="{ height: `${getAllDayEventsHeight()}px` }">
				<div class="flex flex-col gap-1 h-full overflow-y-auto scrollbar-thin scrollbar-thumb-base-300 scrollbar-track-transparent"
					v-if="weeklyAllDayEvents[weekDates[dayIndex].toDateString()]?.length">
					<div v-for="event in weeklyAllDayEvents[weekDates[dayIndex].toDateString()]" :key="event.id"
						class="w-full">
						<CalendarEvent :calendar-event="event" :is-compact="true"
							class="!min-h-6 !rounded-md cursor-pointer hover:opacity-90 transition-all duration-200 !py-0.5"
							@click="emit('openEventDetails', event)" />
					</div>
				</div>
			</div>

			<div class="relative flex-1 w-full h-full">
				<div class="relative h-full !w-full">
					<CalendarHour v-for="(calendarHour, index) in hours" :key="index" :calendarHour="calendarHour"
						:showHour="dayIndex === 0" :events="[]" :class="getWeeklyHourClasses(index, dayIndex)" />
					<div class="absolute inset-0 pointer-events-none right-1.5 top-1.5 bottom-1.5 left-1 z-[1]">
						<template
							v-for="{ event, columnIndex, totalColumns } in processedEventsByDay[weekDates[dayIndex].toDateString()] || []"
							:key="event.id">
							<div class="absolute pointer-events-auto" :style="{
								top: `${calcEventTop(event, weekDates[dayIndex])}%`,
								height: `${calcEventHeight(event, weekDates[dayIndex])}%`,
								left: `${calcEventLeft(columnIndex, totalColumns)}%`,
								width: `${calcEventWidth(totalColumns)}%`,
								zIndex: calcEventZIndex(event)
							}">
								<CalendarEvent :calendar-event="event" :is-compact="true"
									class="h-full !min-h-6 !rounded-lg mx-0.5 cursor-pointer hover:opacity-90 transition-all duration-200"
									@click="emit('openEventDetails', event)" />
							</div>
						</template>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>