<script lang="ts" setup>
import type { CalendarDate } from "~/types/calendar";
import type { AnyCalendarEvent } from "~/types/calendar/events";

const props = defineProps<{
	currentDate: Date;
	events: AnyCalendarEvent[];
	dates: CalendarDate[];
	days: string[];
}>();

const emit = defineEmits<{
	addEvent: [date: Date];
	openEventDetails: [event: AnyCalendarEvent];
}>();

function createModifiedEvent(
	originalEvent: AnyCalendarEvent,
	start: Date,
	end: Date,
): AnyCalendarEvent {
	return {
		...originalEvent,
		start: {
			dateTime: start.toISOString(),
		},
		end: {
			dateTime: end.toISOString(),
		},
	};
}

function splitMultiDayEvent(
	event: AnyCalendarEvent,
	currentDate: Date,
): AnyCalendarEvent {
	const eventStart = new Date(event.start.dateTime || event.start.date || "");
	const eventEnd = new Date(event.end.dateTime || event.end.date || "");

	const dayStart = new Date(currentDate);
	dayStart.setHours(0, 0, 0, 0);

	const dayEnd = new Date(currentDate);
	dayEnd.setHours(23, 59, 59, 999);

	if (!event.start.dateTime) {
		return event;
	}

	const startDay = new Date(eventStart).setHours(0, 0, 0, 0);
	const endDay = new Date(eventEnd).setHours(0, 0, 0, 0);

	if (startDay === endDay) {
		return event;
	}

	if (eventStart.toDateString() === currentDate.toDateString()) {
		const endOfDay = new Date(currentDate);
		endOfDay.setHours(23, 59, 59, 999);
		return createModifiedEvent(event, eventStart, endOfDay);
	}

	if (eventEnd.toDateString() === currentDate.toDateString()) {
		const startOfDay = new Date(currentDate);
		startOfDay.setHours(0, 0, 0, 0);
		return createModifiedEvent(event, startOfDay, eventEnd);
	}

	return {
		...event,
		start: { date: currentDate.toISOString().split("T")[0] },
		end: {
			date: new Date(currentDate.getTime() + 86400000)
				.toISOString()
				.split("T")[0],
		},
	};
}

function getDateKey(date: Date) {
	return `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`;
}

const processedEventsByDate = computed(() => {
	const mapped: Record<string, AnyCalendarEvent[]> = {};

	for (const event of props.events) {
		const eventStart = new Date(event.start.dateTime || event.start.date || "");
		const eventEnd = new Date(event.end.dateTime || event.end.date || "");

		let currentDate = new Date(eventStart);
		while (currentDate <= eventEnd) {
			const dateKey = getDateKey(currentDate);

			if (!mapped[dateKey]) {
				mapped[dateKey] = [];
			}

			const processedEvent = splitMultiDayEvent(event, currentDate);
			mapped[dateKey].push(processedEvent);

			currentDate = new Date(currentDate);
			currentDate.setDate(currentDate.getDate() + 1);
		}
	}

	for (const dateKey of Object.keys(mapped)) {
		mapped[dateKey].sort((a, b) => {
			if (!a.start.dateTime && b.start.dateTime) return -1;
			if (a.start.dateTime && !b.start.dateTime) return 1;

			const aStart = new Date(a.start.dateTime || a.start.date || "");
			const bStart = new Date(b.start.dateTime || b.start.date || "");
			return aStart.getTime() - bStart.getTime();
		});
	}

	return mapped;
});

const getCalendarDayClasses = (index: number) => [
	index === 0 ? "!rounded-tl-box" : "",
	index === 6 ? "!rounded-tr-box" : "",
	index === 35 ? "!rounded-bl-box" : "",
	index === 41 ? "!rounded-br-box" : "",
	index % 7 === 6 ? "!border-r-0" : "",
];
</script>

<template>
    <div class="flex flex-col">
        <div class="grid grid-cols-7">
            <div v-for="day in days" :key="day"
                class="lg:text-sm tracking-wider my-2.5 text-center opacity-60 uppercase text-xs font-medium h-6">
                {{ day.slice(0, 3) }}
            </div>
        </div>
        <div class="grid grid-cols-7 rounded-box overflow-scroll h-[calc(100vh-13rem)]">
            <CalendarDay v-for="(calendarDate, index) in dates" :key="index" :calendarDate="calendarDate"
                :events="processedEventsByDate[getDateKey(calendarDate.date)] || []"
                :class="getCalendarDayClasses(index)" @add-event="emit('addEvent', $event)"
                @open-event-details="emit('openEventDetails', $event)" />
        </div>
    </div>
</template>