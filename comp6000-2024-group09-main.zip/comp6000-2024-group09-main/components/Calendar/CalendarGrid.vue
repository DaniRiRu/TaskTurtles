<script lang="ts" setup>
import { breakpointsTailwind, useBreakpoints } from "@vueuse/core";
import type { AnyCalendarEvent } from "~/types/calendar/events";
import { CalendarView } from "~/types/calendar/views";

const { view, days, dates, hours, currentDate, setView } = useCalendar();
const { events, refreshEvents } = useCalendarEvents();

const breakpoints = useBreakpoints(breakpointsTailwind);
const smallScreen = breakpoints.smaller("sm");

const previousView = ref<CalendarView | null>(null);
const showAddEventModal = ref(false);
const showEventDetails = ref(false);
const selectedEvent = ref<AnyCalendarEvent | undefined>(undefined);

watchEffect(() => {
	if (smallScreen.value) {
		if (view.value === CalendarView.WEEKLY) {
			previousView.value = view.value;
			setView(CalendarView.DAILY);
		}
	} else {
		if (previousView.value === CalendarView.WEEKLY) {
			setView(CalendarView.WEEKLY);
			previousView.value = null;
		}
	}
});

function getDateKey(date: Date) {
	return `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`;
}

function openEventDetails(event: AnyCalendarEvent) {
	selectedEvent.value = event;
	showEventDetails.value = true;
}

function closeEventDetails() {
	showEventDetails.value = false;
	setTimeout(() => {
		selectedEvent.value = undefined;
	}, 200);
}

const eventsByDate = computed(() => {
	const mapped: Record<string, AnyCalendarEvent[]> = {};

	events.value.map((event) => {
		const startDate = new Date(event.start.dateTime || event.start.date || "");
		const dateKey = getDateKey(startDate);

		if (!mapped[dateKey]) {
			mapped[dateKey] = [];
		}
		mapped[dateKey].push(event);
	});

	return mapped;
});

const datesWithEvents = computed(() => {
	return dates.value.filter(
		(date) => eventsByDate.value[getDateKey(date.date)],
	);
});

onMounted(() => {
	refreshEvents();
});

watch(
	() => view.value,
	async () => {
		await refreshEvents();
	},
);

watch(
	() => currentDate.value,
	async () => {
		await refreshEvents();
	},
);
</script>

<template>
	<CalendarViewMonthly v-if="view === CalendarView.MONTHLY" :current-date="currentDate" :events="events"
		:dates="dates" :days="days" @add-event="showAddEventModal = true" @open-event-details="openEventDetails" />

	<CalendarDaySchedule v-else-if="view === CalendarView.SCHEDULE" v-for="date in datesWithEvents"
		:key="getDateKey(date.date)" :calendarDate="date" :currentDate="date.date"
		:events="eventsByDate[getDateKey(date.date)]" @addEvent="showAddEventModal = true" />

	<CalendarViewWeekly v-else-if="view === CalendarView.WEEKLY" :current-date="currentDate" :events="events"
		:hours="hours" :days="days" @add-event="showAddEventModal = true" @open-event-details="openEventDetails" />

	<CalendarViewDaily v-else-if="view === CalendarView.DAILY" :current-date="currentDate" :events="events"
		:hours="hours" @add-event="showAddEventModal = true" @open-event-details="openEventDetails" />

	<CalendarHeaderEventModal :is-open="showAddEventModal" @close="showAddEventModal = false" />
	<CalendarEventDetails :is-open="showEventDetails" :event="selectedEvent" @close="closeEventDetails" />
</template>