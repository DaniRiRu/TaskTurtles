<script lang="ts" setup>
import type { AnyCalendarEvent } from "~/types/calendar/events";

const props = defineProps<{
	currentDate: Date;
	events: AnyCalendarEvent[];
}>();
</script>

<template>
    <div class="flex flex-col gap-1 pb-2">
        <div class="flex flex-col w-full rounded-t-box rounded-b-md overflow-scroll bg-base-100 h-full overflow-hidden">
            <div class="flex justify-between w-full p-4 pb-3 items-center">
                <div class="flex flex-row gap-2 items-center justify-center h-full">
                    <div
                        class="flex flex-col items-center justify-center size-8 rounded-full bg-primary text-primary-content font-bold text-lg">
                        {{ currentDate.getDate() }}
                    </div>
                    <div class="flex flex-col">
                        <div class="text-md font-medium">
                            {{ currentDate.toLocaleString("default", { weekday: "long" }) }}
                        </div>
                        <div class="text-xs font-normal opacity-60">
                            {{ currentDate.toLocaleString("default", { month: "long" }) }}
                        </div>
                    </div>
                </div>
                <div class="flex flex-row gap-4 items-center justify-end w-full h-full">
                    <div class="text-md font-medium opacity-60">
                        {{ events.length }} event{{ events.length != 1 ? 's' : '' }}
                    </div>

                    <button
                        class="size-7 rounded-full flex items-center justify-center bg-base-200/60 shadow hover:bg-base-200 transition-all duration-200"
                        @click="$emit('addEvent', currentDate)">
                        <MaterialSymbolsAdd />
                    </button>
                </div>
            </div>
        </div>
        <div class="flex flex-col h-full gap-1 rounded-b-box overflow-scroll mb-1">
            <CalendarEvent v-for="(event, index) in events" :key="index" :calendarEvent="event" />
        </div>
    </div>
</template>