<script lang="ts" setup>
import { breakpointsTailwind, useBreakpoints } from "@vueuse/core";

const breakpoints = useBreakpoints(breakpointsTailwind);
const mobileView = breakpoints.smaller("xl");
</script>
<template>
    <details v-if="mobileView">
        <summary>
            Filter
        </summary>
    </details>
    <div v-else class="dropdown dropdown-end join-item">
        <label tabindex="0" class="btn btn-ghost join-item">
            <MaterialSymbolsFilterAlt class="h-5 w-5" />
            <span class="hidden xl:inline">Filter</span>
            <MaterialSymbolsArrowDropDown class="h-5 w-5 hidden xl:inline" />
        </label>
    </div>
</template>