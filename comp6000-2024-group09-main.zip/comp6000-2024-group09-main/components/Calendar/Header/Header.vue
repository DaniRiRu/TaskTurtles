<script lang="ts" setup>
import { CalendarView } from "~/types/calendar/views";

const { navigate, view, currentMonth, currentYear, currentDay } = useCalendar();
const isSubscribeModalOpen = ref(false);

const handleSubscribe = () => {
	isSubscribeModalOpen.value = true;
};
</script>
<template>
  <div class="rounded-btn top-20 sticky flex justify-between z-5 h-12">
    <div class="flex items-center bg-base-100 rounded-btn shadow-sm">
      <h2 class="text-2xl font-bold text-center mr-4 mx-5">
        <span v-if="view == CalendarView.DAILY">{{ currentDay }}</span>
        {{ currentMonth }}
        <span class="text-base-content/70">{{ currentYear }}</span>
      </h2>
    </div>
    <CalendarHeaderMenu :navigate="navigate" @subscribe="handleSubscribe" />
    <CalendarSubscribeModal v-model:isOpen="isSubscribeModalOpen" />
  </div>
</template>