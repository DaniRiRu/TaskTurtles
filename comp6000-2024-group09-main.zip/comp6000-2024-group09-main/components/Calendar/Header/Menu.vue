<script lang="ts" setup>
const props = defineProps<{
	navigate: (direction: "prev" | "next" | "today") => void;
}>();

const sidebarOpen = useCookie("sidebar", {
	default: () => false,
});

const showSubscribeModal = ref(false);
const showAddEventModal = ref(false);

const handleSubscribe = () => {
	showSubscribeModal.value = true;
};

const handleAdd = () => {
	showAddEventModal.value = true;
};
</script>

<template>
  <div>
    <div class="dropdown dropdown-end xl-hidden">
      <label tabindex="0" class="btn btn-ghost min-w-12 max-w-12 p-0 bg-base-100 rounded-btn shadow-sm">
        <MaterialSymbolsMoreVert class="h-6 w-6" />
      </label>
      <ul tabindex="0" class="dropdown-content menu p-2 mt-2 shadow bg-base-100 rounded-box w-64">
        <li><CalendarHeaderTodaySwitcher :navigate="navigate" /></li>
        <div class="divider my-0 mx-2"></div>
        <li><CalendarHeaderViewDropdown /></li>
        <!-- <li><CalendarHeaderSortDropdown /></li> -->
        <!-- <li><CalendarHeaderFilterDropdown /></li> -->
        <li><a @click="handleSubscribe" class="flex items-center">Subscribe</a></li>
        <li><a @click="handleAdd">Add Event</a></li>
      </ul>
    </div>
    <div class="hidden space-x-2 xl:flex">
      <div class="flex items-center join bg-base-100 rounded-btn shadow-sm">
        <CalendarHeaderTodaySwitcher :navigate="navigate" />
      </div>
      <div class="flex items-center join bg-base-100 rounded-btn shadow-sm">
        <CalendarHeaderViewDropdown />
        <!-- <CalendarHeaderSortDropdown /> -->
        <!-- <CalendarHeaderFilterDropdown /> -->
      </div>
      <button @click="handleSubscribe" class="btn btn-ghost min-w-12 max-w-12 p-0 bg-base-100 rounded-btn shadow-sm">
        <MaterialSymbolsCalendarAddOnRounded class="h-6 w-6" />
      </button>
      <button @click="handleAdd" class="btn btn-ghost min-w-12 max-w-12 p-0 bg-base-100 rounded-btn shadow-sm">
        <MaterialSymbolsAdd class="h-6 w-6" />
      </button>
    </div>

    <CalendarSubscribeModal v-model:is-open="showSubscribeModal" />
    <CalendarHeaderEventModal v-model:is-open="showAddEventModal" />
  </div>
</template>