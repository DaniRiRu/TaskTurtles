<script lang="ts" setup>
import { ModalPosition } from "~/enums/frontend/modal/ModalPosition";
import type { CustomCalendarEvent } from "~/types/calendar/events";
import PhCalendarBlankFill from "~icons/ph/calendar-blank-fill";
import PhTextAlignLeft from "~icons/ph/text-align-left";
import PhTextBold from "~icons/ph/text-bold";

const isOpen = defineModel<boolean>("isOpen");
const backend = useBackend();

const formData = reactive({
	summary: "",
	description: "",
	isAllDay: false,
	startDateTime: "",
	endDateTime: "",
	startDate: "",
	endDate: "",
	location: "",
});

const isLoading = ref(false);
const error = ref<string | null>(null);

const handleSubmit = async () => {
	try {
		isLoading.value = true;
		error.value = null;

		if (
			!formData.summary ||
			(!formData.isAllDay &&
				(!formData.startDateTime || !formData.endDateTime)) ||
			(formData.isAllDay && (!formData.startDate || !formData.endDate))
		) {
			error.value = "Please fill in all required fields";
			return;
		}

		let startDateTime: Date;
		let endDateTime: Date;

		if (formData.isAllDay) {
			startDateTime = new Date(formData.startDate);
			endDateTime = new Date(formData.endDate);
		} else {
			startDateTime = new Date(formData.startDateTime);
			endDateTime = new Date(formData.endDateTime);
		}

		if (endDateTime < startDateTime) {
			error.value = "End date must be after start date";
			return;
		}

		const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;

		const customEvent: CustomCalendarEvent = {
			id: crypto.randomUUID(),
			provider: "custom",
			summary: formData.summary,
			description: formData.description || undefined,
			location: formData.location || undefined,
			start: {
				dateTime: !formData.isAllDay ? startDateTime.toISOString() : undefined,
				date: formData.isAllDay ? startDateTime.toISOString() : undefined,
				timeZone,
			},
			end: {
				dateTime: !formData.isAllDay ? endDateTime.toISOString() : undefined,
				date: formData.isAllDay ? endDateTime.toISOString() : undefined,
				timeZone,
			},
			status: "confirmed",
			createdAt: new Date(),
			updatedAt: new Date(),
			syncedAt: new Date(),
		};

		await backend.calendar.custom.events.createEvent(customEvent);
		const { refreshEvents } = useCalendarEvents();
		await refreshEvents(true);
		handleClose();
	} catch (err) {
		console.error("Failed to create event:", err);
		error.value = "Failed to create event. Please try again.";
	} finally {
		isLoading.value = false;
	}
};

const handleClose = () => {
	isOpen.value = false;
	formData.summary = "";
	formData.description = "";
	formData.isAllDay = false;
	formData.startDateTime = "";
	formData.endDateTime = "";
	formData.startDate = "";
	formData.endDate = "";
	formData.location = "";
	error.value = null;
};

onMounted(() => {
	const now = new Date();
	formData.startDateTime = now.toISOString().slice(0, 16);
	formData.endDateTime = now.toISOString().slice(0, 16);
	formData.startDate = now.toISOString().slice(0, 10);
	formData.endDate = now.toISOString().slice(0, 10);
});
</script>

<template>
  <UniversalModal :isOpen="isOpen ?? false" :position="ModalPosition.Middle" @close="handleClose">
    <template #title>
      <h3 class="text-3xl font-bold text-base-content leading-tight mb-4">
        Create Event
      </h3>
    </template>

    <template #default>
      <form @submit.prevent="handleSubmit" class="space-y-3">
        <div
          class="card bg-primary/5 transition-all duration-300 p-4 rounded-box border border-primary/20 gap-4 shadow">
          <div class="flex gap-4 items-start">
            <div class="w-10 h-10 flex items-center justify-center rounded-btn bg-primary/10 ring-2 ring-primary/20">
              <PhTextBold class="w-6 h-6 text-primary" />
            </div>
            <div class="flex-1 space-y-2">
              <div class="flex flex-col gap-1">
                <label class="text-sm font-medium text-base-content/70">Event Title</label>
                <p class="text-xs text-base-content/50">A clear title helps attendees quickly understand your event</p>
              </div>
            </div>
          </div>
          <input v-model="formData.summary" type="text" placeholder="What's your event called? (required)"
            class="input rounded-lg border bg-primary/5 border-primary/10 shadow w-full placeholder:text-base-content/30 focus:input-primary"
            required />
        </div>

        <div
          class="card bg-secondary/5 transition-all duration-300 p-4 rounded-box border border-secondary/20 gap-4 shadow">
          <div class="flex items-start gap-4">
            <div class="w-10 h-10 flex items-center justify-center rounded-btn bg-secondary/10 ring-2 ring-secondary/20">
              <PhCalendarBlankFill class="w-6 h-6 text-secondary" />
            </div>
            <div class="flex-1 space-y-2">
              <div class="flex flex-col gap-1">
                <label class="text-sm font-medium text-base-content/70">Date & Time</label>
                <p class="text-xs text-base-content/50">Select when your event starts and ends</p>
              </div>
            </div>
          </div>
          <div class="grid grid-cols-2 gap-3">
            <div class="px-3 col-span-2 w-full flex justify-between items-center align-middle h-12 rounded-lg border bg-secondary/5 border-secondary/10 shadow w-full placeholder:text-base-content/30 focus:input-success">
              <label class="text-sm text-base-content checkmark">All Day</label>
              <input v-model="formData.isAllDay" type="checkbox" :checked="formData.isAllDay"
                class="checkbox checkbox-primary" />
            </div>

            <!-- Date-only inputs for all-day events -->
            <div class="space-y-1" v-if="formData.isAllDay">
              <label class="text-xs text-base-content/70">Starts</label>
              <input v-model="formData.startDate" type="date"
                class="input rounded-lg border bg-secondary/5 border-secondary/10 shadow w-full placeholder:text-base-content/30 focus:input-success"
                required />
            </div>
            <div class="space-y-1" v-if="formData.isAllDay">
              <label class="text-xs text-base-content/70">Ends</label>
              <input v-model="formData.endDate" type="date"
                class="input rounded-lg border bg-secondary/5 border-secondary/10 shadow w-full placeholder:text-base-content/30 focus:input-success"
                required />
            </div>

            <!-- DateTime inputs for regular events -->
            <div class="space-y-1" v-if="!formData.isAllDay">
              <label class="text-xs text-base-content/70">Starts</label>
              <input v-model="formData.startDateTime" type="datetime-local"
                class="input rounded-lg border bg-secondary/5 border-secondary/10 shadow w-full placeholder:text-base-content/30 focus:input-success"
                required />
            </div>
            <div class="space-y-1" v-if="!formData.isAllDay">
              <label class="text-xs text-base-content/70">Ends</label>
              <input v-model="formData.endDateTime" type="datetime-local"
                class="input rounded-lg border bg-secondary/5 border-secondary/10 shadow w-full placeholder:text-base-content/30 focus:input-success"
                required />
            </div>
          </div>
        </div>

        <div
          class="card bg-accent/5 transition-all duration-300 p-4 rounded-box border border-accent/20 gap-4 shadow">
          <div class="flex items-start gap-4">
            <div class="w-10 h-10 flex items-center justify-center rounded-btn bg-accent/10 ring-2 ring-accent/20">
              <MaterialSymbolsLocationOn class="w-6 h-6 text-accent" />
            </div>
            <div class="flex-1 space-y-2">
              <div class="flex flex-col gap-1">
                <label class="text-sm font-medium text-base-content/70">Location</label>
                <p class="text-xs text-base-content/50">Add physical location or virtual meeting link</p>
              </div>
            </div>
          </div>
          <input v-model="formData.location" type="text" placeholder="Where is this happening?"
            class="input rounded-lg border bg-accent/5 border-accent/10 w-full placeholder:text-base-content/30 focus:input-primary" />
        </div>

        <div
          class="card bg-success/5 transition-all duration-300 p-4 rounded-box border border-success/20 gap-4 shadow">
          <div class="flex items-start gap-4">
            <div class="w-10 h-10 flex items-center justify-center rounded-btn bg-success/10 ring-2 ring-success/20">
              <PhTextAlignLeft class="w-6 h-6 text-success" />
            </div>
            <div class="flex-1 space-y-2">
              <div class="flex flex-col gap-1">
                <label class="text-sm font-medium text-base-content/70">Description</label>
                <p class="text-xs text-base-content/50">Add details like agenda, requirements, or special instructions
                </p>
              </div>
            </div>
          </div>
          <textarea v-model="formData.description" placeholder="Tell people more about your event..."
            class="textarea !h-32 rounded-lg border bg-success/5 border-success/10 shadow w-full placeholder:text-base-content/30 focus:input-primary"></textarea>
        </div>

        <div v-if="error" class="alert alert-error rounded-btn">
          <MaterialSymbolsError class="w-6 h-6 mr-2" />
          <span>{{ error }}</span>
        </div>

        <button type="submit"
          class="btn btn-primary hover:border-2 hover:border-primary hover:bg-secondary/20 hover:text-base-content w-full rounded-btn text-base gap-2 hover:gap-3 transition-all duration-300 flex justify-between items-center shadow"
          :class="{ 'loading': isLoading }" :disabled="isLoading">
          {{ isLoading ? 'Creating Event...' : 'Create Event' }}
          <Icons8RightArrow v-if="!isLoading" class="size-6" />
        </button>
      </form>
    </template>
  </UniversalModal>
</template>