<script lang="ts" setup>
import { breakpointsTailwind, useBreakpoints } from "@vueuse/core";
import { CalendarView } from "~/types/calendar/views";

const { setView } = useCalendar();

const breakpoints = useBreakpoints(breakpointsTailwind);
const smallScreen = breakpoints.smaller("sm");

const calendarViews = computed(() => {
	if (smallScreen.value) {
		return Object.values(CalendarView).filter(
			(view) => view !== CalendarView.WEEKLY,
		);
	}
	return Object.values(CalendarView);
});
</script>

<template>
    <details class="xl:hidden dropdown dropdown-end">
        <summary>View</summary>
        <ul>
            <li v-for="viewOption in calendarViews" :key="viewOption">
                <a @click="setView(viewOption)" class="capitalize">{{ viewOption }}</a>
            </li>
        </ul>
    </details>
    <div class="dropdown dropdown-start join-item max-xl:hidden">
        <label tabindex="0" class="btn btn-ghost join-item">
            <MaterialSymbolsCalendarMonth class="h-5 w-5" />
            <span class="hidden xl:inline">View</span>
            <MaterialSymbolsArrowDropDown class="h-5 w-5" />
        </label>
        <ul tabindex="0" class="dropdown-content menu p-2 mt-2 shadow bg-base-100 rounded-box w-52 capitalize">
            <li v-for="viewOption in calendarViews" :key="viewOption">
                <a @click="setView(viewOption)">{{ viewOption }}</a>
            </li>
        </ul>
    </div>
</template>