<script lang="ts" setup>
const props = defineProps<{
	navigate: (direction: "prev" | "next" | "today") => void;
}>();
</script>
<template>
  <div class="flex items-center xl:join justify-between h-12 xl:h-auto">
    <button
      @click="props.navigate('prev')"
      class="btn border-none hover:bg-transparent btn-ghost min-w-12 max-w-12 px-0 xl:p-0 join-item"
    >
      <MaterialSymbolsChevronLeft class="h-6 w-6" />
    </button>

    <button 
      @click="props.navigate('today')" 
      class="btn btn-ghost hover:bg-transparent border-none join-item" >
      Today
    </button>

    <button
      @click="props.navigate('next')"
      class="btn border-none hover:bg-transparent btn-ghost min-w-12 max-w-12 px-0 xl:p-0 join-item"
    >
      <MaterialSymbolsChevronRight class="h-6 w-6" />
    </button>
  </div>
</template>