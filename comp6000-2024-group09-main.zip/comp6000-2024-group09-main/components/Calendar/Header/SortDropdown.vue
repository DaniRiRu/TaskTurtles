<script lang="ts" setup>
import { breakpointsTailwind, useBreakpoints } from "@vueuse/core";
import type { CalendarView } from "~/types/calendar/views";

const { setView } = useCalendar();

const breakpoints = useBreakpoints(breakpointsTailwind);
const mobileView = breakpoints.smaller("xl");

const setActiveTab = (tab: string) => {
	setView(tab as CalendarView);
};
</script>
<template>
    <details v-if="mobileView">
        <summary>Sort</summary>
         <ul>
            <li><a @click="setActiveTab('ascending')">Ascending</a></li>
            <li><a @click="setActiveTab('descending')">Descending</a></li>
            <li><a @click="setActiveTab('highPriority')">High Priority</a></li>
            <li><a @click="setActiveTab('lowPriority')">Low Priority</a></li>
        
        </ul>
    </details>
    <div v-else class="dropdown join-item">
        <label tabindex="0" class="btn btn-ghost join-item">
            <MaterialSymbolsSort class="h-5 w-5" />
            <span class="hidden xl:inline">Sort</span>
            <MaterialSymbolsArrowDropDown class="h-5 w-5 hidden xl:inline" />
        </label>
        <ul tabindex="0" class="dropdown-content menu p-2 mt-2 shadow bg-base-100 rounded-box w-52">
            <li><a @click="setActiveTab('ascending')">Ascending</a></li>
            <li><a @click="setActiveTab('descending')">Descending</a></li>
            <li><a @click="setActiveTab('highPriority')">High Priority</a></li>
            <li><a @click="setActiveTab('lowPriority')">Low Priority</a></li>
        </ul>
    </div>
</template>