<script lang="ts" setup>
import type { CalendarHour } from "~/types/calendar";
// import type { AnyCalendarEvent } from "~/types/calendar/events";

const props = defineProps<{
	calendarHour: CalendarHour;
	showHour: boolean;
	// events?: AnyCalendarEvent[];
}>();

const handleSelectDate = () => {};
</script>

<template>
  <div :class="[
    'min-h-[100px] transition-colors duration-200 border-b-3 border-r-3 border-base-200 rounded-md',
    'hover:bg-secondary/10 relative group',
    calendarHour.isSelected ? 'bg-secondary/10' : 'bg-base-100',
    calendarHour.isCurrentHour ? 'bg-secondary/15 hover:!bg-secondary/20' : '',
  ]" @click="handleSelectDate">
    <div class="p-3 flex flex-col h-full">
      <div class="flex items-center justify-between">
        <span :class="[
          'inline-flex items-center justify-center rounded-full px-3 h-7 text-sm',
          calendarHour.isCurrentHour
            ? 'bg-primary text-primary-content font-medium'
            : 'text-base-content/70',
          showHour ? '' : 'invisible',
        ]">
          {{ calendarHour.time }}
        </span>
        <button
          class="w-7 h-7 p-0 rounded-full flex items-center justify-center bg-base-200/60 shadow hover:bg-base-200 opacity-0 group-hover:opacity-100 transition-all duration-200"
          @click="$emit('addEvent', calendarHour)">
          <MaterialSymbolsAdd />
        </button>
      </div>
    </div>
  </div>
</template>