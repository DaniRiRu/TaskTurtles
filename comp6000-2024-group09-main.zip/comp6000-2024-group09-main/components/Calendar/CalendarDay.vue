<script lang="ts" setup>
import type { CalendarDate } from "~/types/calendar";
import type { AnyCalendarEvent } from "~/types/calendar/events";

const props = defineProps<{
	calendarDate: CalendarDate;
	events?: AnyCalendarEvent[];
}>();

const { selectDate } = useCalendarSelection();

const handleSelectDate = () => {
	selectDate(props.calendarDate.date);
};
</script>

<template>
  <div class="border-r-3 border-b-3 border-base-200">
    <div @click="handleSelectDate"
      class="relative min-h-[120px] rounded-md h-full bg-base-100 transition-colors duration-200 group hover:bg-secondary/10"
      :class="[
        !calendarDate.isCurrentMonth ? 'bg-base-100/40' : '',
        calendarDate.isToday && calendarDate.isCurrentMonth ? 'bg-secondary/15 hover:!bg-secondary/20' : ''
      ]">
      <div class="p-2 flex flex-col h-full">
        <div class="flex items-center md:justify-between max-md:justify-center mb-2">
          <span class="inline-flex items-center justify-center w-7 h-7 rounded-full text-sm" :class="[
            calendarDate.isToday ? 'bg-primary text-primary-content font-medium' : !calendarDate.isCurrentMonth ? 'opacity-40' : ''
          ]">
            {{ calendarDate.date.getDate() }}
          </span>
          <button
            class="max-md:hidden w-7 h-7 p-0 rounded-full flex items-center justify-center bg-base-200/60 shadow hover:bg-base-200 opacity-0 group-hover:opacity-100 transition-all duration-200"
            @click="$emit('addEvent', calendarDate)">
            <MaterialSymbolsAdd />
          </button>
        </div>

        <div class="space-y-1">
          <CalendarEvent v-for="(event, index) in events" :key="index" :calendar-event="event" :is-compact="true"
            :class="calendarDate.isCurrentMonth ? '' : 'opacity-40'" @click="$emit('openEventDetails', event)" />
        </div>

        <div
          class="hidden max-md:flex items-center max-sm:justify-center justify-between w-full h-6 rounded-btn bg-base-200 transition-all duration-200 group-hover:opacity-100 opacity-0 px-2 mt-1"
          @click="$emit('addEvent', calendarDate)">
          <span class="text-xs max-sm:hidden">
            Add
          </span>
          <MaterialSymbolsAdd class="size-5" />
        </div>

      </div>
    </div>
  </div>
</template>