<script lang="ts" setup>
</script>
<template>
	<div
		class="transition-all duration-300 ease-in-out fixed top-0 h-38 left-0 w-full bg-gradient-to-b from-base-200 from-60% z-2">
	</div>
	<div class="w-full flex flex-col mb-7">
		<CalendarHeader class="mb-6"/>
		<CalendarGrid/>
	</div>
</template>
