<script lang="ts" setup>
import { ModalPosition } from "~/enums/frontend/modal/ModalPosition";
import type {
	AnyCalendarEvent,
	CalendarAttendee,
} from "~/types/calendar/events";
import FamiconsCalendar from "~icons/famicons/calendar";
import HeroiconsArrowTopRightOnSquare from "~icons/heroicons/arrow-top-right-on-square";
import MapMapPin from "~icons/map/map-pin";
import PhUsersFill from "~icons/ph/users-fill";
import SolarDocumentTextBold from "~icons/solar/document-text-bold";

const props = defineProps<{
	event?: AnyCalendarEvent;
}>();

const isOpen = defineModel<boolean>("isOpen");

const formatDateTime = (dateTime?: string, date?: string) => {
	if (!dateTime && !date) return "";
	const d = new Date(dateTime || date || "");
	return d.toLocaleString("en-US", {
		weekday: "long",
		year: "numeric",
		month: "long",
		day: "numeric",
		hour: dateTime ? "2-digit" : undefined,
		minute: dateTime ? "2-digit" : undefined,
		hour12: true,
	});
};

const getDuration = (start?: string, end?: string) => {
	if (!start || !end) return "";
	const startDate = new Date(start);
	const endDate = new Date(end);
	const diffInHours =
		(endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60);
	return `${diffInHours.toFixed(1)} hours`;
};

const handleClose = () => {
	isOpen.value = false;
};

const getStatusColor = computed(() => {
	switch (props.event?.status) {
		case "confirmed":
			return "text-success bg-success/10";
		case "tentative":
			return "text-warning bg-warning/10";
		case "cancelled":
			return "text-error bg-error/10";
		default:
			return "text-primary bg-primary/10";
	}
});

const getStatusText = computed(() => {
	switch (props.event?.status) {
		case "confirmed":
			return "Confirmed";
		case "tentative":
			return "Tentative";
		case "cancelled":
			return "Cancelled";
		default:
			return "Unknown";
	}
});

const isAllDay = computed(() => {
	return !props.event?.start.dateTime && props.event?.start.date;
});

const getResponseStatusBadge = (status: CalendarAttendee["responseStatus"]) => {
	const baseClasses = "badge text-xs font-medium";
	switch (status) {
		case "accepted":
			return `${baseClasses} badge-success`;
		case "declined":
			return `${baseClasses} badge-error`;
		case "tentative":
			return `${baseClasses} badge-warning`;
		default:
			return `${baseClasses} badge-ghost`;
	}
};

const getEventUrl = computed(() => {
	if (!props.event) return null;
	switch (props.event.provider) {
		case "google":
			return props.event.htmlLink;
		case "outlook":
			return props.event.webLink;
		default:
			return props.event.url;
	}
});

const getProviderName = computed(() => {
	if (!props.event) return "";
	switch (props.event.provider) {
		case "google":
			return "Google Calendar";
		case "outlook":
			return "Outlook Calendar";
		case "ical":
			return "Calendar";
		case "custom":
			return "Calendar";
		default:
			return "Calendar";
	}
});

const hasAttendees = computed(() => {
	return props.event?.attendees && props.event.attendees.length > 0;
});

const location = computed(() => props.event?.location);
const description = computed(() => props.event?.description);
</script>

<template>
	<UniversalModal :isOpen="isOpen ?? false" :position="ModalPosition.Middle" @close="handleClose">
		<template #title>
			<div v-if="event" class="mb-4">
				<span
					:class="['inline-block px-3 py-1 rounded-full text-xs font-medium mb-3', getStatusColor, 'bg-base-200/50']">
					{{ getStatusText }}
				</span>
				<h3 class="text-3xl font-bold text-base-content leading-tight">
					{{ event.summary }}
				</h3>
			</div>
		</template>

		<template #default>
			<div v-if="event" class="space-y-3">
				<div
					class="card bg-secondary/5 transition-all duration-300 p-4 rounded-box border border-secondary/20 gap-4 shadow">
					<div class="flex items-start gap-4">
						<div
							class="w-10 h-10 flex items-center justify-center rounded-btn bg-secondary/10 ring-2 ring-secondary/20">
							<FamiconsCalendar class="w-6 h-6 text-secondary" />
						</div>
						<div class="flex-1 space-y-2">
							<div class="flex flex-col gap-1">
								<label class="text-sm font-medium text-base-content/70">Date & Time</label>
								<p class="text-base-content">{{ formatDateTime(event.start.dateTime, event.start.date)
									}}</p>
								<div v-if="!isAllDay" class="text-base-content/70 text-sm">
									<p>
										to {{ formatDateTime(event.end.dateTime, event.end.date) }}
									</p>
									<div
										class="inline-block text-xs font-medium px-2 py-1 mt-2 rounded-full bg-base-300/50">
										{{ getDuration(event.start.dateTime, event.end.dateTime) }}
									</div>
								</div>
								<p v-else class="text-secondary font-medium">All Day Event</p>
							</div>
						</div>
					</div>
				</div>

				<div v-if="location"
					class="card bg-accent/5 transition-all duration-300 p-4 rounded-box border border-accent/20 gap-4 shadow">
					<div class="flex items-start gap-4">
						<div
							class="w-10 h-10 flex items-center justify-center rounded-btn bg-accent/10 ring-2 ring-accent/20">
							<MapMapPin class="w-6 h-6 text-accent" />
						</div>
						<div class="flex-1 -mt-1">
							<label class="text-sm font-medium text-base-content/70">Location</label>
							<p class="text-base-content">{{ location }}</p>
						</div>
					</div>
					<a :href="`https://maps.google.com/?q=${encodeURIComponent(location)}`" target="_blank"
						rel="noopener noreferrer"
						class="btn btn-primary bg-base-100 border-0 hover:border-2 border-base-100 hover:!border-blue-600 hover:bg-blue-600/20 text-base-content hover:text-base-content w-full rounded-btn text-base gap-2 hover:gap-3 transition-all duration-300 flex justify-between items-center">
						Open in Maps
						<MaterialSymbolsNavigation class="size-6" />
					</a>
				</div>

				<div v-if="description"
					class="card bg-success/5 transition-all duration-300 p-4 rounded-box border border-success/20 gap-4 shadow">
					<div class="flex items-start gap-4">
						<div
							class="w-10 h-10 flex items-center justify-center rounded-btn bg-success/10 ring-2 ring-success/20 aspect-ratio-1">
							<SolarDocumentTextBold class="w-6 h-6 text-success" />
						</div>
						<div class="flex-1 -mt-1">
							<label class="text-sm font-medium text-base-content/70">Description</label>
							<p class="text-base-content/70 whitespace-pre-wrap">{{ description }}</p>
						</div>
					</div>
				</div>

				<div v-if="hasAttendees"
					class="card bg-error/5 transition-all duration-300 p-4 rounded-box border border-error/20 gap-4 shadow">
					<div class="flex items-start gap-4">
						<div
							class="w-10 h-10 flex items-center justify-center rounded-btn bg-error/10 ring-2 ring-error/20">
							<PhUsersFill class="w-6 h-6 text-error" />
						</div>
						<div class="flex-1 space-y-2">
							<div class="flex flex-col gap-1">
								<label class="text-sm font-medium text-base-content/70">Attendees ({{
									event.attendees?.length }})</label>
								<div class="space-y-2">
									<div v-for="attendee in event.attendees" :key="attendee.email"
										class="flex items-center justify-between p-3 rounded-btn bg-base-200 transition-colors">
										<div class="flex items-center gap-3">
											<div class="avatar placeholder">
												<div class="w-8 rounded-full bg-base-300">
													<span class="text-xs font-medium">
														{{ (attendee?.displayName || attendee?.email ||
															'').charAt(0).toUpperCase() }}
													</span>
												</div>
											</div>
											<div>
												<p class="text-sm font-medium">{{ attendee.displayName || attendee.email
													}}</p>
												<p class="text-xs text-base-content/60">{{ attendee.email }}</p>
											</div>
										</div>
										<span :class="getResponseStatusBadge(attendee.responseStatus)">
											{{ attendee.responseStatus || 'No Response' }}
										</span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div v-if="getEventUrl" class="mt-6">
					<button
						class="btn btn-primary hover:border-2 hover:border-primary hover:bg-secondary/20 hover:text-base-content w-full rounded-btn text-base gap-2 hover:gap-3 transition-all duration-300 flex justify-between items-center shadow">
						Open in {{ getProviderName }}
						<HeroiconsArrowTopRightOnSquare class="size-6" />
					</button>
				</div>
			</div>
		</template>
	</UniversalModal>
</template>