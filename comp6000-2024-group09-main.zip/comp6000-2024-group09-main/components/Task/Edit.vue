<script lang="ts" setup>
import type { DocumentData } from "firebase/firestore";
import type { Priority } from "~/types/core/priority";
import type { Tag } from "~/types/core/tag";
import type { Task } from "~/types/core/task";
import { TaskStatus } from "~/types/core/task";

const props = defineProps<{
	task: DocumentData | null;
	priorities: Priority[];
	tags: Tag[];
}>();

const emit = defineEmits(["close"]);
const isAddMode = computed(() => !props.task);
const backend = useBackend();

const showDueDate = ref(!!props.task?.dueDate);

const taskForm = ref({
	title: props.task?.title || "",
	description: props.task?.description || "",
	priority: props.task?.priority || undefined,
	dueDate: props.task?.dueDate || new Date(),
	status: props.task?.status || TaskStatus.Todo,
	tags: props.task?.tags || [],
});

async function handleSubmit() {
	if (taskForm.value.tags) {
		taskForm.value.tags = taskForm.value.tags.map((tag: { id: string }) =>
			tag.id ? `/tags/${tag.id}` : undefined,
		);
	}

	if (taskForm.value.priority) {
		taskForm.value.priority = `/priorities/${taskForm.value.priority.id}`;
	}
	const taskToSave: Task = {
		title: taskForm.value.title,
		description: taskForm.value.description,
		priority: taskForm.value.priority,
		dueDate: showDueDate.value ? taskForm.value.dueDate : null,
		id: props.task?.id,
		tags: taskForm.value.tags,
		status: taskForm.value.status,
	};

	try {
		if (isAddMode.value) {
			await backend.tasks.add(taskToSave);
		} else {
			await backend.tasks.update(taskToSave);
		}

		emit("close");
	} catch (error) {
		console.error("Error saving task:", error);
	}
}
</script>

<template>
    <div class="flex flex-col h-full">
        <div class="flex-1 space-y-4 pt-2">
            <form class="space-y-4">
                <div class="bg-base-200 rounded-box border border-base-300 p-4">
                    <span class="text-xs uppercase tracking-wider text-base-content/50">Title</span>
                    <div class="mt-2">
                        <input v-model="taskForm.title" type="text"
                            class="w-full bg-transparent focus:outline-none text-sm" placeholder="Enter task title..."
                            required />
                    </div>
                </div>

                <div class="bg-base-200 rounded-box border border-base-300 p-4">
                    <span class="text-xs uppercase tracking-wider text-base-content/50">Description</span>
                    <div class="mt-2">
                        <textarea v-model="taskForm.description"
                            class="w-full bg-transparent focus:outline-none text-sm min-h-[100px] resize-none"
                            placeholder="Enter task description..." required></textarea>
                    </div>
                </div>

                <div
                    class="bg-base-200 rounded-box border border-base-300 p-2 px-4 h-12 flex justify-between items-center">
                    <div class="flex flex-row justify-between items-center w-full">
                        <span class="text-xs uppercase tracking-wider text-base-content/50">Due Date</span>
                        <div class="flex flex-row items-center space-x-2 -mr-1">
                            <input v-model="taskForm.dueDate" v-if="showDueDate" type="date"
                                class="w-full btn-sm btn !flex-shrink px-2 py-1 bg-base-300/80 focus:outline-none text-sm" />
                            <input type="checkbox" v-model="showDueDate" class="checkbox checkbox-sm" />
                        </div>
                    </div>
                </div>

                <div class="bg-base-200 rounded-box border border-base-300 p-2 px-4">
                    <div class="flex flex-row justify-between items-center">
                        <span class="text-xs uppercase tracking-wider text-base-content/50">Status</span>
                        <TaskDropdownStatus v-model="taskForm.status" />
                    </div>
                </div>

                <div class="bg-base-200 rounded-box border border-base-300 p-2 px-4">
                    <div class="flex flex-row justify-between items-center">
                        <span class="text-xs uppercase tracking-wider text-base-content/50">Priority</span>
                        <TaskDropdownPriority v-model="taskForm.priority" :priorities="props.priorities" />
                    </div>
                </div>

                <div class="bg-base-200 rounded-box border border-base-300 p-2 px-4">
                    <div class="flex flex-row justify-between items-center">
                        <span class="text-xs uppercase tracking-wider text-base-content/50">Tags</span>
                        <TaskDropdownTag v-model="taskForm.tags" :tags="props.tags" />
                    </div>
                </div>
            </form>
        </div>

        <div class="pt-4 -mb-2">
            <button type="submit" class="btn btn-primary w-full justify-between px-4 text-white" @click="handleSubmit"
                :disabled="!taskForm.title.trim()">
                {{ isAddMode ? 'Add Task' : 'Save Changes' }}
                <MaterialSymbolsAdd v-if="isAddMode" class="h-5 w-5" />
                <MaterialSymbolsSave v-else class="h-5 w-5" />
            </button>
        </div>
    </div>
</template>