<script lang="ts" setup>
import type { Priority } from "~/types/core/priority";
import type { Tag } from "~/types/core/tag";
import type { Task } from "~/types/core/task";
import { TaskStatus } from "~/types/core/task";

const props = defineProps<{
	priorities: Priority[];
	tags: Tag[];
}>();

const emit = defineEmits(["close", "refresh"]);
const backend = useBackend();

const showDueDate = ref(false);
const taskForm = ref({
	title: "",
	description: "",
	priority: undefined as Priority | undefined,
	dueDate: new Date(),
	status: TaskStatus.Todo,
	tags: [] as Tag[],
});

async function handleSubmit() {
	if (!taskForm.value.title.trim()) return;

	try {
		const formattedTags = taskForm.value.tags
			.map((tag: Tag) => (tag.id ? `/tags/${tag.id}` : null))
			.filter(Boolean) as string[];

		const formattedPriority = taskForm.value.priority
			? `/priorities/${taskForm.value.priority.id}`
			: undefined;

		const taskPayload: Task = {
			id: "",
			title: taskForm.value.title,
			description: taskForm.value.description,
			dueDate: taskForm.value.dueDate,
			priority: formattedPriority,
			tags: taskForm.value.tags,
			status: taskForm.value.status,
		};

		await backend.tasks.add(taskPayload);
		emit("close");
		emit("refresh");
	} catch (error) {
		console.error("Error adding task:", error);
	}
}
</script>

<template>
    <div class="flex flex-col h-full">
        <div class="pb-2 flex flex-col gap-3">
            <div class="flex flex-col items-start gap-3 w-full">
                <div class="p-3 rounded-xl bg-primary/10">
                    <MaterialSymbolsEditDocument class="w-8 h-8 text-primary" />
                </div>
                <h3 class="text-2xl font-bold text-base-content leading-tight">New Task</h3>
            </div>
        </div>

        <div class="flex flex-col gap-4 max-md:pb-12 pt-2">
            <div class="flex flex-col gap-2">
                <div class="flex gap-3 items-center">
                    <MaterialSymbolsTitle class="w-5 h-5 text-primary" />
                    <div class="text-lg font-semibold text-base-content">Title</div>
                </div>
                <input v-model="taskForm.title" type="text" placeholder="Enter task title..."
                    class="input input-bordered bg-base-200 w-full" required />
            </div>

            <div class="flex flex-col gap-2">
                <div class="flex gap-3 items-center">
                    <MaterialSymbolsDescription class="w-5 h-5 text-primary" />
                    <div class="text-lg font-semibold text-base-content">Description</div>
                </div>
                <textarea v-model="taskForm.description" placeholder="Enter task description..."
                    class="input input-bordered bg-base-200 w-full min-h-[100px] p-4"></textarea>
            </div>

            <div class="flex flex-col gap-2">
                <div class="flex gap-3 items-center">
                    <MaterialSymbolsCalendarMonth class="w-5 h-5 text-primary" />
                    <div class="text-lg font-semibold text-base-content">Due Date</div>
                </div>
                <div class="input input-bordered bg-base-200 w-full flex justify-between items-center px-4">
                    <div class="flex flex-row items-center space-x-2">
                        <input v-model="showDueDate" type="checkbox" class="checkbox checkbox-sm" />
                        <span>Set due date</span>
                    </div>
                    <input v-model="taskForm.dueDate" v-if="showDueDate" type="date"
                        class="bg-base-300/80 px-2 py-1 rounded" />
                </div>
            </div>

            <div class="flex flex-col gap-2">
                <div class="flex gap-3 items-center">
                    <MaterialSymbolsFlag class="w-5 h-5 text-primary" />
                    <div class="text-lg font-semibold text-base-content">Status</div>
                </div>
                <div class="input input-bordered bg-base-200 w-full flex items-center">
                    <TaskDropdownStatus v-model="taskForm.status" />
                </div>
            </div>

            <div class="flex flex-col gap-2">
                <div class="flex gap-3 items-center">
                    <MaterialSymbolsPriorityHigh class="w-5 h-5 text-primary" />
                    <div class="text-lg font-semibold text-base-content">Priority</div>
                </div>
                <div class="input input-bordered bg-base-200 w-full flex items-center">
                    <TaskDropdownPriority v-model="taskForm.priority" :priorities="props.priorities" />
                </div>
            </div>

            <div class="flex flex-col gap-2">
                <div class="flex gap-3 items-center">
                    <MaterialSymbolsTag class="w-5 h-5 text-primary" />
                    <div class="text-lg font-semibold text-base-content">Tags</div>
                </div>
                <div class="input input-bordered bg-base-200 w-full flex items-center">
                    <TaskDropdownTag v-model="taskForm.tags" :tags="props.tags" />
                </div>
            </div>
        </div>

        <div class="pt-4 flex justify-end">
            <button type="submit" class="btn btn-primary btn-sm gap-2" 
                @click="handleSubmit" 
                :disabled="!taskForm.title.trim()">
                Add Task
                <MaterialSymbolsAdd class="h-5 w-5" />
            </button>
        </div>
    </div>
</template>