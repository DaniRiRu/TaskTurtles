<script lang="ts" setup>
import type { DocumentData } from "firebase/firestore";
import { useTaskMode } from "~/composables/useTaskMode";
import { ModalPosition } from "~/enums/frontend/modal/ModalPosition";
import type { Priority } from "~/types/core/priority";
import type { Tag } from "~/types/core/tag";
import type { Task } from "~/types/core/task";

const props = defineProps<{
	task: Task | null;
	isAddMode: boolean;
	priorities: Priority[];
	tags: Tag[];
}>();

const emit = defineEmits(["close", "refresh"]);
const isClosing = ref(false);

const { viewMode, switchMode, resetState, persistedTask } = useTaskMode(
	toRef(props, "task"),
	toRef(props, "isAddMode"),
);

const taskForEdit = computed(() => {
	return persistedTask.value as Task;
});

async function closeTask() {
	isClosing.value = true;
	emit("close");
	isClosing.value = false;

	await new Promise((resolve) => setTimeout(resolve, 300));
	resetState();
}

useEscapeKey(closeTask);
</script>

<template>
	<UniversalSidebar :is-open="props.task !== null || props.isAddMode" @close="closeTask">
		<template #header>
			<h2 class="text-lg font-semibold w-full pl-4">
				{{ viewMode === 'add' ? 'Add Task' : viewMode === 'edit' ? 'Edit Task' : persistedTask?.title }}
			</h2>
			<button v-show="viewMode === 'view'" @click="switchMode('edit')"
				class="btn btn-ghost btn-square border-none min-w-auto min-h-auto max-h-6 max-w-6 -mr-1">
				<MaterialSymbolsEdit class="h-5 w-5" />
			</button>
		</template>

		<div class="px-4 h-full">
			<Transition mode="out-in" enter-active-class="transition-opacity duration-200 ease-in-out"
				leave-active-class="transition-opacity duration-200 ease-in-out" enter-from-class="opacity-0"
				leave-to-class="opacity-0">
				<TaskEdit v-if="viewMode === 'edit'" :task="persistedTask" :priorities="props.priorities"
					:tags="props.tags" @close="closeTask" />
				<TaskEdit v-else-if="viewMode === 'add'" :task="null" :priorities="props.priorities" :tags="props.tags"
					@close="closeTask" />
				<TaskView v-else :task="persistedTask" @edit="switchMode('edit')" @close="closeTask" />
			</Transition>
		</div>
	</UniversalSidebar>
</template>