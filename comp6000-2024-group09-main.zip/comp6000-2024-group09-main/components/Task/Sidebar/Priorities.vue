<script lang="ts" setup>
import type { Priority } from "~/types/core/priority";
import MaterialSymbolsExclamation from "~icons/material-symbols/exclamation";

const backend = useBackend();

const props = defineProps<{
	isOpen: boolean;
	priorities: Priority[] | null;
	refresh: () => void;
}>();

const showPriorityForm = ref(false);
const isEditing = ref(false);
const currentPriority = ref<Priority | null>(null);
const isLoading = ref(false);
const showDeleteConfirm = ref(false);
const priorityToDelete = ref<Priority | null>(null);
const errorMessage = ref("");
const localPriorities = ref(props.priorities || []);

watch(
	() => props.priorities,
	(newVal) => {
		localPriorities.value = newVal || [];
	},
);

const form = ref({
	int: 0,
	title: "",
	color: "#ffffff",
});

function openForm(priority: Priority | null = null) {
	showPriorityForm.value = true;
	errorMessage.value = "";

	if (priority) {
		isEditing.value = true;
		currentPriority.value = priority;
		form.value = {
			int: priority.int,
			title: priority.title,
			color: priority.color,
		};
	} else {
		isEditing.value = false;
		form.value = {
			int: 0,
			title: "",
			color: "#ffffff",
		};
	}

	nextTick(() => {
		const input = document.querySelector(
			'input[type="number"]',
		) as HTMLInputElement | null;
		if (input) input.focus();
	});
}

async function submitPriority() {
	try {
		isLoading.value = true;
		errorMessage.value = "";

		const payload = {
			id: isEditing.value ? currentPriority.value?.id : undefined,
			...form.value,
		};

		const response = isEditing.value
			? await backend.priorities.update(payload)
			: await backend.priorities.add(payload);

		if ("error" in response) {
			errorMessage.value = response.error;
			return;
		}

		props.refresh();
		showPriorityForm.value = false;
	} catch (error) {
		errorMessage.value = "An error occurred while saving the priority";
	} finally {
		isLoading.value = false;
	}
}

function confirmDelete(priority: Priority) {
	priorityToDelete.value = priority;
	showDeleteConfirm.value = true;
}

async function deletePriority() {
	if (!priorityToDelete.value) return;

	try {
		isLoading.value = true;
		errorMessage.value = "";

		const response = await backend.priorities.delete(priorityToDelete.value);

		if ("error" in response) {
			errorMessage.value = response.error;
			return;
		}

		props.refresh();
		showDeleteConfirm.value = false;
	} catch (error) {
		errorMessage.value = "An error occurred while deleting the priority";
	} finally {
		isLoading.value = false;
	}
}

function closeSidebar() {
	emit("close");
	resetForm();
}

function resetForm() {
	form.value = {
		int: 0,
		title: "",
		color: "#ffffff",
	};
	isEditing.value = false;
	showPriorityForm.value = false;
	errorMessage.value = "";
}

function handleKeyboardNavigation(event: KeyboardEvent) {
	if (event.key === "Escape") {
		closeSidebar();
	}
}

onMounted(() => {
	window.addEventListener("keydown", handleKeyboardNavigation);
});

onUnmounted(() => {
	window.removeEventListener("keydown", handleKeyboardNavigation);
});

const emit = defineEmits(["close"]);
</script>

<template>
  <UniversalSidebar :isOpen="props.isOpen" @close="closeSidebar">
    <template #header>
      <div class="flex items-center w-full justify-between ml-4">
        <h2 class="text-lg font-semibold">
          {{ showPriorityForm ? (isEditing ? "Edit Priority" : "Add Priority") : "Priorities" }}
        </h2>
        <button 
          class="btn btn-primary min-h-8 h-8 max-h-8 px-3 border-none outline-none"
          @click="openForm()"
          :class="{ 'opacity-0': showPriorityForm }"
          aria-label="Add new priority"
        >
          <MaterialSymbolsAdd class="h-5 w-5 -ml-1" />
          <span class="-ml-1">Add</span>
        </button>
      </div>
    </template>

    <div class="h-full justify-between flex flex-col">
      <div v-if="errorMessage" class="px-4 py-2 bg-error/20 text-error text-sm rounded-md mx-4 mt-2">
        {{ errorMessage }}
      </div>

      <div v-if="showPriorityForm" class="px-4 h-full">
        <form @submit.prevent="submitPriority" class="h-full flex flex-col justify-between">
          <div class="flex flex-row items-center justify-between mt-2 space-x-4">
            <input 
              v-model="form.int"
              type="number"
              class="input rounded-box w-16 bg-base-300 focus:ring-2 focus:ring-primary"
              required
              aria-label="Priority number"
            />
            <div class="form-control w-full">
              <input 
                v-model="form.title"
                type="text"
                class="input rounded-box bg-base-300 focus:ring-2 focus:ring-primary"
                required
                aria-label="Priority title"
              />
            </div>
            <div class="form-control">
              <input 
                v-model="form.color"
                type="color"
                class="rounded-full w-12 h-12 cursor-pointer focus:ring-2 focus:ring-primary"
                aria-label="Priority color"
              />
            </div>
          </div>

          <div class="grid grid-cols-2 mt-4 space-x-4">
            <button 
              type="button"
              class="btn btn-error border-none"
              @click="showPriorityForm = false"
              :disabled="isLoading"
            >
              <MaterialSymbolsCancel class="h-5 w-5" />
              Cancel
            </button>
            <button 
              type="submit"
              class="btn btn-primary border-none"
              :disabled="isLoading"
            >
              <MaterialSymbolsSave class="h-5 w-5" />
              {{ isLoading ? 'Saving...' : (isEditing ? 'Save' : 'Add') }}
            </button>
          </div>
        </form>
      </div>

      <div class="mt-2 overflow-y-scroll px-4 space-y-3" v-if="!showPriorityForm">
        <div
          v-for="priority in localPriorities"
          :key="priority.id"
          class="bg-base-200 flex justify-between rounded-box border border-base-300 p-2 px-4 hover:bg-gradient-to-br hover:bg-base-200/10 hover:shadow-lg transition-all duration-300 ease-in-out"
        >
          <div 
            class="flex flex-row items-center space-x-4"
            @click="openForm(priority)"
          >
            <div 
              class="w-3 h-3 rounded-full" 
              :style="{ backgroundColor: priority.color }"
              :aria-label="`Color: ${priority.color}`"
            ></div>
            <span class="text-ellipsis overflow-hidden">{{ priority.title }}</span>
          </div>
          <button 
            class="btn btn-sm btn-ghost btn-square p-0 focus:ring-2 focus:ring-primary"
            @click="confirmDelete(priority)"
            aria-label="Delete priority"
          >
            <MaterialSymbolsDelete class="h-5 w-5" />
          </button>
        </div>

        <div 
          v-if="localPriorities.length === 0 && !isEditing && !showPriorityForm"
          class="flex flex-col items-center justify-center col-span-2 p-4 space-y-2 fixed inset-0 pointer-events-none"
        >
          <ContentUnavailable 
            :image="MaterialSymbolsExclamation"
            title="No Priorities"
            description="You haven't added any priorities yet. Click the button above to add a new priority."
          />
        </div>
      </div>
    </div>

    <Dialog v-if="showDeleteConfirm" @close="showDeleteConfirm = false">
      <div class="p-4">
        <h3 class="text-lg font-semibold mb-2">Delete Priority</h3>
        <p>Are you sure you want to delete "{{ priorityToDelete?.title }}"?</p>
        <div class="flex justify-end space-x-2 mt-4">
          <button 
            class="btn btn-ghost"
            @click="showDeleteConfirm = false"
            :disabled="isLoading"
          >
            Cancel
          </button>
          <button 
            class="btn btn-error"
            @click="deletePriority"
            :disabled="isLoading"
          >
            {{ isLoading ? 'Deleting...' : 'Delete' }}
          </button>
        </div>
      </div>
    </Dialog>
  </UniversalSidebar>
</template>
