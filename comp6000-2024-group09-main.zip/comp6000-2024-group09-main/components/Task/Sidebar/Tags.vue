<script lang="ts" setup>
import type { Tag } from "~/types/core/tag";
import MaterialSymbolsExclamation from "~icons/material-symbols/exclamation";

const backend = useBackend();

const props = defineProps<{
	isOpen: boolean;
	tags: Tag[] | null;
	refresh: () => void;
}>();

const showTagForm = ref(false);
const isEditing = ref(false);
const currentTag = ref<Tag | null>(null);

const form = ref({
	int: 0,
	title: "",
	color: "#ffffff",
});

function openForm(tag: Tag | null = null) {
	showTagForm.value = true;
	if (tag) {
		isEditing.value = true;
		currentTag.value = tag;
		form.value.title = tag.title;
		form.value.color = tag.color;
	} else {
		isEditing.value = false;
		form.value.title = "";
		form.value.color = "#ffffff";
	}
}

async function submitTag() {
	const payload = {
		id: isEditing.value ? currentTag.value?.id : undefined,
		...form.value,
	};

	const response = isEditing.value
		? await backend.tags.update(payload)
		: await backend.tags.add(payload);

	if (!("error" in response)) {
		props.refresh();
	}

	showTagForm.value = false;
}

async function deleteTag(tag: Tag) {
	const response = await backend.tags.delete(tag);
	if (!("error" in response)) {
		props.refresh();
	}
}

function closeSidebar() {
	emit("close");

	form.value.int = 0;
	form.value.title = "";
	form.value.color = "#ffffff";
	isEditing.value = false;
	showTagForm.value = false;
}

const emit = defineEmits(["close"]);
</script>

<template>
  <UniversalSidebar :isOpen="props.isOpen" @close="closeSidebar">
    <template #header>
      <div class="flex items-center w-full justify-between ml-4">
        <h2 class="text-lg font-semibold">{{ showTagForm ? isEditing ? "Edit Tag" : "Add Tag" : "Tags" }}</h2>
        <button class="btn btn-primary min-h-8 h-8 max-h-8 px-3 border-none outline-none shadow-none"
          @click="openForm()" :class="{
            'opacity-0': showTagForm
          }">
          <MaterialSymbolsAdd class="h-5 w-5 -ml-1" />
          <span class="-ml-1">Add</span>
        </button>
      </div>
    </template>
    <div class="h-full justify-between flex flex-col">
      <div v-if="showTagForm" class="px-4 h-full">
        <form @submit.prevent="submitTag" class="h-full flex flex-col justify-between">
          <div class="flex justify-between flex-col">
            <div class="flex flex-row items-center justify-between mt-2 space-x-4">
              <div class="form-control w-full">
                <input v-model="form.title" type="text" class="input rounded-box bg-base-300" required />
              </div>
              <div class="form-control">
                <input v-model="form.color" type="color" class="rounded-full w-12 h-12" />
              </div>
            </div>
          </div>

          <div class="flex flex-col -mb-2">
            <div class="grid grid-cols-2 mt-4 space-x-4">
              <button type="button" class="btn btn-error border-none outline-none shadow-none"
                @click="showTagForm = false">
                <MaterialSymbolsCancel class="h-5 w-5" />
                Cancel
              </button>
              <button type="submit" class="btn btn-primary border-none outline-none shadow-none">
                <MaterialSymbolsSave class="h-5 w-5" />
                {{ isEditing ? "Save" : "Add" }}
              </button>
            </div>
          </div>
        </form>
      </div>

      <div class="mt-2 overflow-y-scroll px-4" v-if="!showTagForm">
        <div class="grid grid-cols-1 gap-3">
          <div
            class="bg-base-200 flex justify-between rounded-box border border-base-300 p-2 px-4 hover:bg-gradient-to-br hover:bg-base-200/10 hover:shadow-lg transition-all duration-300 ease-in-out"
            v-for="tag in tags" :key="tag.id" v-if="tags?.length !== 0 && tags" @click="openForm(tag)">
            <div class="flex flex-row items-center space-x-4">
              <div class="w-6 h-6 rounded-full" :style="{ backgroundColor: tag.color }"></div>
              <span class="text-ellipsis overflow-hidden">{{ tag.title }}</span>
            </div>
            <button class="btn btn-sm btn-ghost btn-square p-0" @click="deleteTag(tag)">
              <MaterialSymbolsDelete class="h-5 w-5" />
            </button>
          </div>
          <div v-else-if="tags?.length === 0 && !isEditing && !showTagForm"
            class="flex flex-col items-center justify-center col-span-2 p-4 space-y-2 fixed inset-0 pointer-events-none">
            <ContentUnavailable :image="MaterialSymbolsExclamation" title="No Tags"
              description="You haven't added any tags yet. Click the button above to add a new tag." />
          </div>
        </div>
      </div>
    </div>
  </UniversalSidebar>
</template>