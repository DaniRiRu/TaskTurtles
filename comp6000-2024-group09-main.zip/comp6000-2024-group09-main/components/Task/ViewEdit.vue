<script lang="ts" setup>
import { Timestamp } from "firebase/firestore";
import type { Priority } from "~/types/core/priority";
import type { Tag } from "~/types/core/tag";
import type { Task } from "~/types/core/task";
import { TaskStatus } from "~/types/core/task";
import { getTextColor } from "~/utils/getTextColor";

interface EditingState {
	title: boolean;
	description: boolean;
	dueDate: boolean;
	status: boolean;
	priority: boolean;
	tags: boolean;
	[key: string]: boolean;
}

interface TaskFormState {
	title: string;
	description: string;
	priority: Priority | undefined;
	dueDate: Date;
	status: TaskStatus;
	tags: Tag[];
	showDueDate: boolean;
}

interface HeightsState {
	title: string;
	description: string;
}

const props = defineProps<{
	task?: Task;
	priorities?: Priority[];
	tags?: Tag[];
}>();

const emit = defineEmits(["close", "refresh"]);
const backend = useBackend();

const editing = reactive<EditingState>({
	title: false,
	description: false,
	dueDate: false,
	status: false,
	priority: false,
	tags: false,
});

const taskForm = reactive<TaskFormState>({
	title: props.task?.title || "",
	description: props.task?.description || "",
	priority: props.task?.priority as Priority | undefined,
	dueDate: props.task?.dueDate || new Date(),
	status: props.task?.status || TaskStatus.Todo,
	tags: (props.task?.tags as Tag[]) || [],
	showDueDate: !!props.task?.dueDate,
});

const heights = reactive<HeightsState>({
	title: "auto",
	description: "auto",
});

watch(
	() => props.task,
	(newTask) => {
		if (newTask) {
			Object.assign(taskForm, {
				title: newTask.title || "",
				description: newTask.description || "",
				priority: newTask.priority as Priority | undefined,
				dueDate: newTask.dueDate || new Date(),
				status: newTask.status || TaskStatus.Todo,
				tags: (newTask.tags as Tag[]) || [],
				showDueDate: !!newTask.dueDate,
			});

			for (const key of Object.keys(editing)) {
				editing[key] = false;
			}
			updateHeights();
		}
	},
	{ immediate: true },
);

function formatDate(date: Date | Timestamp | undefined): string {
	if (!date) return "";
	const rawDate = toRaw(date);
	const jsDate =
		rawDate instanceof Timestamp ? rawDate.toDate() : new Date(rawDate);
	return jsDate.toLocaleDateString("en-UK", {
		day: "numeric",
		month: "long",
		year: "numeric",
	});
}

const isOverdue = computed(() => {
	if (!taskForm.dueDate || !taskForm.showDueDate) return false;
	const rawDate = toRaw(taskForm.dueDate);
	const jsDate =
		rawDate instanceof Timestamp ? rawDate.toDate() : new Date(rawDate);
	return jsDate < new Date();
});

async function handleDelete(event: Event): Promise<void> {
	event.preventDefault();
	try {
		if (props.task) {
			await backend.tasks.delete(props.task);
			emit("close");
			emit("refresh");
		}
	} catch (error) {
		console.error("Error deleting task:", error);
	}
}

async function saveTask(): Promise<void> {
	if (!taskForm.title.trim()) return;

	try {
		const formattedTags =
			taskForm.tags
				?.map((tag: Tag) => (tag.id ? `/tags/${tag.id}` : undefined))
				.filter(Boolean) || [];
		const formattedPriority = taskForm.priority
			? `/priorities/${taskForm.priority.id}`
			: undefined;

		const taskToSave: Task = {
			id: props.task?.id || "",
			title: taskForm.title.trim(),
			description: taskForm.description,
			priority: formattedPriority,
			dueDate: taskForm.dueDate,
			status: taskForm.status,
			tags: taskForm.tags,
		};

		await backend.tasks.update(taskToSave);
		emit("refresh");
	} catch (error) {
		console.error("Error saving task:", error);
	}
}

function handleFieldEdit(field: keyof EditingState): void {
	editing[field] = false;
	if (taskForm.title.trim()) saveTask();
}

function updateHeights(): void {
	nextTick(() => {
		const titleLines = taskForm.title.split("\n").length || 1;
		heights.title = `${Math.max(60, titleLines * 24 + 24)}px`;

		const descLines = taskForm.description
			? taskForm.description.split("\n").length
			: 2;
		heights.description = `${Math.max(100, (descLines + 2) * 20 + 20)}px`;
	});
}

watch(
	[
		() => taskForm.title,
		() => taskForm.description,
		() => taskForm.showDueDate,
	],
	updateHeights,
	{ deep: true },
);

onMounted(updateHeights);
</script>

<template>
  <div v-if="task" class="flex flex-col h-full">
    <div class="pb-2 flex flex-col gap-3">
      <div class="flex flex-col items-start gap-3 w-full">
        <div class="p-3 rounded-xl bg-primary/10">
          <MaterialSymbolsChecklistRounded class="w-8 h-8 text-primary" />
        </div>
        
        <div class="w-full" v-if="!editing.title">
          <div @click="editing.title = true" 
             class="text-2xl font-bold text-base-content leading-tight hover:bg-base-200 hover:cursor-text p-2 rounded-btn group"
             :style="{ minHeight: heights.title }">
            <div class="flex items-start">
              <span class="line-clamp-2">{{ taskForm.title }}</span>
              <MaterialSymbolsEdit class="ml-2 h-5 w-5 opacity-0 group-hover:opacity-50 shrink-0 self-start mt-1 transition-opacity" />
            </div>
          </div>
        </div>
        <div v-else class="w-full relative">
          <textarea v-model="taskForm.title" 
            class="text-2xl font-bold text-base-content leading-tight w-full input input-bordered bg-base-200 pr-12 resize-y min-h-[3rem] py-2 px-3 overflow-hidden" 
            v-focus
            :style="{ height: heights.title }"
            placeholder="Task title"></textarea>
          <button @click="handleFieldEdit('title')" 
            class="absolute right-3 top-3 text-white bg-primary hover:bg-primary-focus rounded-full w-7 h-7 flex items-center justify-center transition-colors">
            <MaterialSymbolsCheck class="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>

    <div class="flex flex-col gap-4 max-md:pb-12 pt-2">
      <div class="flex flex-col gap-2">
        <div class="flex gap-3 items-center">
          <MaterialSymbolsFlag class="w-5 h-5 text-primary" />
          <div class="text-lg font-semibold text-base-content">Status</div>
          <button class="ml-auto btn btn-ghost btn-xs" @click="editing.status = !editing.status">
            <MaterialSymbolsEdit v-if="!editing.status" class="h-4 w-4" />
            <MaterialSymbolsCheck v-else class="h-4 w-4 text-primary" />
          </button>
        </div>
        
        <div v-if="!editing.status" class="input input-bordered bg-base-200 w-full flex items-center px-4">
          <div class="h-2 w-2 rounded-full animate-pulse mr-2"
            :class="{
              'bg-blue-300': taskForm.status === 'todo',
              'bg-red-300': taskForm.status === 'in-progress',
              'bg-orange-300': taskForm.status === 'done'
            }">
          </div>
          <span>{{ taskForm.status.replace('-', ' ').replace(/\b\w/g, (c: string) => c.toUpperCase()) }}</span>
        </div>
        
        <div v-else class="input input-bordered bg-base-200 w-full flex items-center px-4">
          <TaskDropdownStatus v-model="taskForm.status" @update:modelValue="handleFieldEdit('status')" />
        </div>
      </div>

      <div class="flex flex-col gap-2">
        <div class="flex gap-3 items-center">
          <MaterialSymbolsCalendarMonth class="w-5 h-5 text-primary" />
          <div class="text-lg font-semibold text-base-content">Due Date</div>
          <button class="ml-auto btn btn-ghost btn-xs" @click="editing.dueDate = !editing.dueDate">
            <MaterialSymbolsEdit v-if="!editing.dueDate" class="h-4 w-4" />
            <MaterialSymbolsCheck v-else class="h-4 w-4 text-primary" />
          </button>
        </div>
        
        <div v-if="!editing.dueDate" class="input input-bordered bg-base-200 w-full flex items-center px-4">
          <span :class="{ 'text-error': isOverdue }" v-if="taskForm.showDueDate">
            {{ formatDate(taskForm.dueDate) }}
          </span>
          <span class="text-base-content/50" v-else>No due date</span>
        </div>
        
        <div v-else class="input input-bordered bg-base-200 w-full flex justify-between items-center px-4">
          <div class="flex flex-row items-center space-x-2">
            <input v-model="taskForm.showDueDate" type="checkbox" class="checkbox checkbox-sm" />
            <span>Set due date</span>
          </div>
          <div class="flex items-center">
            <input v-model="taskForm.dueDate" v-if="taskForm.showDueDate" type="date"
              class="bg-base-300/80 px-2 py-1" @change="handleFieldEdit('dueDate')" />
          </div>
        </div>
      </div>
      
      <div class="flex flex-col gap-2">
        <div class="flex gap-3 items-center">
          <MaterialSymbolsPriorityHigh class="w-5 h-5 text-primary" />
          <div class="text-lg font-semibold text-base-content">Priority</div>
          <button class="ml-auto btn btn-ghost btn-xs" @click="editing.priority = !editing.priority">
            <MaterialSymbolsEdit v-if="!editing.priority" class="h-4 w-4" />
            <MaterialSymbolsCheck v-else class="h-4 w-4 text-primary" />
          </button>
        </div>
        
        <div v-if="!editing.priority" class="input input-bordered bg-base-200 w-full flex items-center px-4">
          <span class="px-2 py-1 rounded-badge text-xs truncate"
            v-if="taskForm.priority"
            :style="{ backgroundColor: taskForm.priority.color, color: getTextColor(taskForm.priority.color) }">
            {{ taskForm.priority.title }}
          </span>
          <span class="text-base-content/50" v-else>No priority</span>
        </div>
        
        <div v-else class="input input-bordered bg-base-200 w-full flex items-center px-4">
          <TaskDropdownPriority v-model="taskForm.priority" :priorities="priorities || []" @update:modelValue="handleFieldEdit('priority')" />
        </div>
      </div>

      <div class="flex flex-col gap-2">
        <div class="flex gap-3 items-center">
          <MaterialSymbolsTag class="w-5 h-5 text-primary" />
          <div class="text-lg font-semibold text-base-content">Tags</div>
          <button class="ml-auto btn btn-ghost btn-xs" @click="editing.tags = !editing.tags">
            <MaterialSymbolsEdit v-if="!editing.tags" class="h-4 w-4" />
            <MaterialSymbolsCheck v-else class="h-4 w-4 text-primary" />
          </button>
        </div>
        
        <div v-if="!editing.tags" class="input input-bordered bg-base-200 w-full flex flex-wrap items-center gap-2 p-3 px-4">
          <span v-for="tag in taskForm.tags" :key="tag.id"
            class="px-2 py-1 rounded-badge text-xs font-medium whitespace-nowrap truncate"
            :style="{ backgroundColor: tag.color, color: getTextColor(tag.color) }">
            {{ tag.title }}
          </span>
          <span class="text-base-content/50" v-if="!taskForm.tags?.length">No tags</span>
        </div>
        
        <div v-else class="input input-bordered bg-base-200 w-full flex items-center px-4">
          <TaskDropdownTag v-model="taskForm.tags" :tags="tags || []" @update:modelValue="handleFieldEdit('tags')" />
        </div>
      </div>

      <div class="flex flex-col gap-2">
        <div class="flex gap-3 items-center">
          <MaterialSymbolsDescription class="w-5 h-5 text-primary" />
          <div class="text-lg font-semibold text-base-content">Description</div>
          <button class="ml-auto btn btn-ghost btn-xs" @click="editing.description = !editing.description">
            <MaterialSymbolsEdit v-if="!editing.description" class="h-4 w-4" />
            <MaterialSymbolsCheck v-else class="h-4 w-4 text-primary" />
          </button>
        </div>
        
        <div v-if="!editing.description" 
          class="input input-bordered bg-base-200 w-full flex items-start p-4 whitespace-pre-line"
          :style="{ height: heights.description }"
          @click="editing.description = true">
          <p v-if="taskForm.description">{{ taskForm.description }}</p>
          <p v-else class="text-base-content/50">No description</p>
        </div>
        
        <textarea v-else
          v-model="taskForm.description" 
          placeholder="Enter task description..."
          class="input input-bordered bg-base-200 w-full p-4 resize-y"
          :style="{ height: heights.description }"
          @blur="handleFieldEdit('description')"
          v-focus></textarea>
      </div>
    </div>

    <div class="pt-4 flex justify-end">
        <button type="submit" class="btn btn-error btn-sm gap-2" @click="handleDelete">
        Delete
        <MaterialSymbolsDelete class="h-5 w-5" />
      </button>
    </div>
  </div>
</template>
