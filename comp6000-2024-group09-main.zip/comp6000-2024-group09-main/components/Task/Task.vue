<script setup lang="ts">
import type { DocumentData } from "firebase/firestore";
import { Timestamp } from "firebase/firestore";
import { type Task, TaskStatus } from "~/types/core/task";
import { getTextColor } from "~/utils/getTextColor";

interface TaskProps {
	task: DocumentData;
}

const props = defineProps<TaskProps>();

const formatDueDate = (date: Timestamp | string) => {
	const rawDate = toRaw(date);
	const jsDate =
		rawDate instanceof Timestamp ? rawDate.toDate() : new Date(rawDate);

	return jsDate.toLocaleDateString("en-UK", {
		month: "short",
		day: "numeric",
	});
};

const backend = useBackend();

const handleClick = (e: MouseEvent) => {
	e.preventDefault();
	const newStatus =
		props.task.status === TaskStatus.Done ? TaskStatus.Todo : TaskStatus.Done;
	props.task.status = newStatus;

	const tags = props.task.tags.map((tag: { id: string }) =>
		tag.id ? `/tags/${tag.id}` : undefined,
	);

	const priority = props.task.priority.id
		? `/priorities/${props.task.priority.id}`
		: undefined;

	const task: Task = {
		id: props.task.id,
		title: props.task.title,
		description: props.task.description,
		dueDate: props.task.dueDate,
		priority: priority,
		tags: tags,
		status: newStatus,
	};

	backend.tasks.update(task);
};
</script>
<template>
    <div class="bg-base-100 rounded-box shadow-sm hover:shadow-lg transition-all hover:scale-[1.005] duration-200 p-4">
        <div class="flex items-start justify-between">
            <div class="flex flex-col gap-1 w-full">
                <div class="flex flex-row justify-between">
                    <h3 class="text-base font-medium truncate">{{ task.title }}</h3>
                    <input type="checkbox" :checked="props.task.status == TaskStatus.Done"
                        class="h-6 w-6 checkbox checkbox-accent" @click.stop="handleClick" />
                </div>
                <p class="text-sm text-base-content/60 line-clamp-2 pr-4" v-if="task.description">{{ task.description }}
                </p>
            </div>
        </div>
        <div class="flex items-center justify-between mt-3" v-if="task.priority || task.tags || task.dueDate">
            <div class="flex flex-wrap items-center gap-2">
                <span class="px-2 py-1 rounded-badge text-xs font-medium whitespace-nowrap truncate"
                    :style="{ backgroundColor: task.priority?.color, color: getTextColor(task.priority?.color || '#ffffff') }"
                    v-if="task.priority">
                    {{ task.priority.title }}
                </span>
                <span v-if="task.tags" v-for="tag in task.tags" :key="tag.id"
                    class="px-2 py-1 rounded-badge text-xs font-medium whitespace-nowrap truncate"
                    :style="{ backgroundColor: tag.color, color: getTextColor(tag.color) }">
                    {{ tag.title }}
                </span>
            </div>
            <div class="flex gap-2 items-center ml-2" v-if="task.dueDate">
                <span class="px-2 py-1 rounded-badge text-xs font-medium text-red-900 bg-red-100 whitespace-nowrap">
                    {{ formatDueDate(task.dueDate) }}
                </span>
            </div>
        </div>
    </div>
</template>