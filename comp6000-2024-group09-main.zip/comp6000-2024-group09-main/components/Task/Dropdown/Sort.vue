<script lang="ts" setup>
import { SortOptions } from "~/enums/frontend/tasks/SortOptions";
import { SortType } from "~/enums/frontend/tasks/SortType";

const sortTypes = Object.values(SortOptions);
const sortOrders = Object.values(SortType);

defineProps<{
	sortType: SortOptions;
	sortOrder: SortType;
}>();
</script>

<template>
    <div class="dropdown join-item">
        <label tabindex="0" class="btn btn-ghost join-item">
            <MaterialSymbolsSort class="h-5 w-5" />
            <span class="hidden md:inline">{{ sortType }}</span>
            <MaterialSymbolsArrowDropDown class="h-5 w-5 hidden md:inline" />
        </label>
        <ul tabindex="0" class="dropdown-content menu p-2 mt-2 shadow bg-base-100 rounded-box w-52">
            <li v-for="option in sortTypes" :key="option">
                <div @click="$emit('update:sortType', option)">
                    <span>{{ option }}</span>
                    <MaterialSymbolsCheck class="ml-auto h-5 w-5" v-if="sortType === option" />
                </div>
            </li>
            <div class="divider my-0"></div>
            <li v-for="option in sortOrders" :key="option">
                <div @click="$emit('update:sortOrder', option)">
                    <span>{{ option }}</span>
                    <MaterialSymbolsCheck class="ml-auto h-5 w-5" v-if="sortOrder === option" />
                </div>
            </li>
        </ul>
    </div>
</template>
