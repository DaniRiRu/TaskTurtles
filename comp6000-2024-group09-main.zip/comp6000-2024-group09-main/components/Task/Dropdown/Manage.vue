<script lang="ts" setup>
</script>
<template>
    <div class="dropdown join-item">
            <label tabindex="0" class="btn btn-ghost join-item">
                <MaterialSymbolsFolderManagedRounded class="h-5 w-5" />
                <span class="hidden md:inline">Manage</span>
                <MaterialSymbolsArrowDropDown class="h-5 w-5 hidden md:inline" />
            </label>
            <ul tabindex="0" class="dropdown-content menu p-2 mt-2 shadow bg-base-100 rounded-box w-52">
                <li>
                    <div class="flex flex-row space-x-2" @click="$emit('update:modalType', 'tags')">
                        <MaterialSymbolsTag class="h-5 w-5" />
                        <span>Tags</span>
                    </div>
                </li>
                <li>
                    <div class="flex space-x-2" @click="$emit('update:modalType', 'priorities')">
                        <MaterialSymbolsExclamation class="h-5 w-5" />
                        <span>Priorities</span>
                    </div>
                </li>
            </ul>
    </div>
</template>