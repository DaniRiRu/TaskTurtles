<script lang="ts" setup>
import { ViewMode } from "~/enums/frontend/tasks/ViewMode";

const viewModes = Object.values(ViewMode);

defineProps<{
	viewMode: ViewMode;
}>();
</script>

<template>
    <div class="dropdown dropdown-start join-item ">
        <label tabindex="0"
            class="btn btn-ghost opacity-40 lg:opacity-100 pointer-events-none lg:pointer-events-auto join-item">
            <MaterialSymbolsViewModule class="h-5 w-5" />
            <span class="hidden md:block">
                {{ viewMode }}
            </span>
            <MaterialSymbolsArrowDropDown class="h-5 w-5 hidden md:inline" />
        </label>
        <ul tabindex="0" class="dropdown-content menu p-2 mt-2 shadow bg-base-100 rounded-box w-52">
            <li v-for="mode in viewModes" :key="mode">
                <div @click="$emit('update:viewMode', mode)">
                    <span>{{ mode }}</span>
                    <MaterialSymbolsCheck class="ml-auto h-5 w-5" v-if="viewMode === mode" />
                </div>
            </li>
        </ul>
    </div>
</template>