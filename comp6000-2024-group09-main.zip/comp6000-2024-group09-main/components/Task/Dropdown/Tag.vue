<script lang="ts" setup>
import type { Tag } from "~/types/core/tag";

const selectedTags = defineModel<Tag[]>({
	default: [],
});

const props = defineProps<{
	tags: Tag[] | undefined;
}>();

const searchTerm = ref("");

const filteredTags = computed(() =>
	props.tags?.filter((tag: Tag) =>
		tag.title.toLowerCase().includes(searchTerm.value.toLowerCase()),
	),
);

const displayText = computed(() => {
	if (selectedTags.value.length === 0) return "None";
	if (selectedTags.value.length === 1) return selectedTags.value[0].title;
	return `${selectedTags.value.length} tags`;
});

function toggleTag(tag: Tag) {
	const index = selectedTags.value.findIndex((t) => t.id === tag.id);
	if (index >= 0) {
		selectedTags.value.splice(index, 1);
	} else {
		selectedTags.value.push(tag);
	}
}
</script>

<template>
    <div class="dropdown dropdown-start">
        <div tabindex="0" class="-mr-1 btn btn-sm bg-base-300/80">
            {{ displayText }}
        </div>
        <ul tabindex="0" class="shadow menu dropdown-content bg-base-100 rounded-box w-52 p-2 z-100">
            <div class="flex flex-row -m-2 items-center px-4 py-2 space-x-2 hover:bg-base-200/80">
                <MaterialSymbolsSearch class="h-5 w-5" />
                <input v-model="searchTerm" type="text" placeholder="Search tags"
                    class="w-full py-2 outline-none border-none bg-transparent" />
            </div>
            <div class="divider my-0"></div>

            <div class="max-h-96 w-48 flex flex-col overflow-y-scroll">
                <div v-if="tags?.length === 0" class="p-2 text-center">No tags</div>
                <div v-for="tag in filteredTags" :key="tag.title" @click="toggleTag(tag)"
                    class="p-2 hover:bg-base-200/80 rounded-box flex flex-row items-center space-x-2 cursor-pointer justify-between">
                    <div class="flex flex-row items-center space-x-2">
                        <div class="w-4 h-4 rounded-full" :style="{ backgroundColor: tag.color }" />
                        <span class="text-ellipsis overflow-hidden truncate max-w-38">{{ tag.title }}</span>
                    </div>
                    <MaterialSymbolsCheck class="ml-auto h-5 w-5" v-if="selectedTags.includes(tag)" />
                </div>
            </div>
        </ul>
    </div>
</template>