<script lang="ts" setup>
import { TaskStatus } from "~/types/core/task";

interface Status {
	name: string;
	color: string;
}

const selectedStatus = defineModel<string>({
	default: TaskStatus.Todo,
});

const searchTerm = ref("");

const statuses = ref<Status[]>([
	{ name: TaskStatus.Todo, color: "bg-blue-300" },
	{ name: TaskStatus.InProgress, color: "bg-red-300" },
	{ name: TaskStatus.Done, color: "bg-orange-300" },
]);

const filteredStatuses = computed(() =>
	statuses.value.filter((status) =>
		status.name.toLowerCase().includes(searchTerm.value.toLowerCase()),
	),
);

const formattedStatus = computed(() => formatStatusName(selectedStatus.value));

function formatStatusName(status: string) {
	return status.replace(/-/g, " ").replace(/\b\w/g, (l) => l.toUpperCase());
}
</script>

<template>
    <div class="dropdown dropdown-start">
        <div tabindex="0" class="-mr-1 btn btn-sm bg-base-300/80">
            {{ formattedStatus }}
        </div>
        <ul tabindex="0" class="shadow menu dropdown-content bg-base-100 rounded-box w-52 p-2 z-100">
            <div class="flex flex-row -m-2 items-center px-4 py-2 space-x-2 hover:bg-base-200/80">
                <MaterialSymbolsSearch class="h-5 w-5" />
                <input v-model="searchTerm" type="text" placeholder="Search statuses"
                    class="w-full py-2 outline-none border-none bg-transparent" />
            </div>
            <div class="divider my-0"></div>

            <div class="max-h-96 w-48 flex flex-col overflow-y-scroll">
                <div v-for="status in filteredStatuses" :key="status.name" @click="selectedStatus = status.name"
                    class="p-2 hover:bg-base-200/80 flex items-center space-x-2 cursor-pointer">
                    <div class="w-4 h-4 rounded-full" :class="status.color"></div>
                    <div class="flex justify-between w-full">
                        <span>{{ formatStatusName(status.name) }}</span>
                        <MaterialSymbolsCheck class="ml-auto h-5 w-5" v-if="selectedStatus === status.name" />
                    </div>
                </div>
            </div>
        </ul>
    </div>
</template>