<script lang="ts" setup>
import type { Priority } from "~/types/core/priority";

const selectedPriority = defineModel<Priority | null>({
	default: null,
});

const props = defineProps<{
	priorities: Priority[];
}>();

const searchTerm = ref("");

const filteredPriorities = computed(
	() =>
		props.priorities.filter((priority: Priority) =>
			priority.title.toLowerCase().includes(searchTerm.value.toLowerCase()),
		) || [],
);

function togglePriority(priority: Priority) {
	if (isPrioritySelected(priority.id ?? "")) {
		selectedPriority.value = null;
	} else {
		selectedPriority.value = priority;
	}
}

function isPrioritySelected(priorityId: string): boolean {
	return selectedPriority.value?.id === priorityId;
}
</script>

<template>
    <div class="dropdown dropdown-start">
        <div tabindex="0" class="-mr-1 btn btn-sm bg-base-300/80">
            {{ selectedPriority ? selectedPriority.title : "None" }}
        </div>

        <ul tabindex="0" class="shadow menu dropdown-content bg-base-100 rounded-box w-52 p-2 z-100">
            <div class="flex flex-row -m-2 items-center px-4 py-2 space-x-2 hover:bg-base-200/80">
                <MaterialSymbolsSearch class="h-5 w-5" />
                <input v-model="searchTerm" type="text" placeholder="Search priorities"
                    class="w-full py-2 outline-none border-none bg-transparent" />
            </div>
            <div class="divider my-0"></div>

            <div class="max-h-96 w-48 flex flex-col overflow-y-scroll">
                <div v-if="!priorities || priorities.length === 0" class="p-2 text-center">No priorities</div>
                <div v-for="priority in filteredPriorities" :key="priority.title"
                    class="p-2 hover:bg-base-200/80 rounded-box flex flex-row items-center space-x-2 cursor-pointer justify-between"
                    @click="togglePriority(priority)">
                    <div class="flex flex-row items-center space-x-2">
                        <div class="w-4 h-4 rounded-full" :style="{ backgroundColor: priority.color }" />
                        <span class="text-ellipsis overflow-hidden truncate max-w-38">{{ priority.title }}</span>
                    </div>
                    <MaterialSymbolsCheck class="ml-auto h-5 w-5" v-if="isPrioritySelected(priority.id ?? '')" />
                </div>
            </div>
        </ul>
    </div>
</template>