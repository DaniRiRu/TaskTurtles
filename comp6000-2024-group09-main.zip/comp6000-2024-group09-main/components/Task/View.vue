<script lang="ts" setup>
import type { DocumentData } from "firebase/firestore";
import { Timestamp } from "firebase/firestore";
import type { Task } from "~/types/core/task";
import { getTextColor } from "~/utils/getTextColor";

const props = defineProps<{
	task: DocumentData | null;
}>();

const emit = defineEmits(["close"]);
const backend = useBackend();

async function handleDelete(event: Event) {
	event.preventDefault();

	try {
		await backend.tasks.delete(props.task as Task);
		emit("close");
	} catch (error) {
		console.error("Error deleting task:", error);
	}
}

function formatDueDate(date: Timestamp | string) {
	const rawDate = toRaw(date);
	const jsDate =
		rawDate instanceof Timestamp ? rawDate.toDate() : new Date(rawDate);
	return jsDate.toLocaleDateString("en-UK", {
		day: "numeric",
		month: "long",
		year: "numeric",
	});
}

const isOverdue = computed(() => {
	const dueDate = props.task?.dueDate;
	if (!dueDate) return false;
	const rawDate = toRaw(dueDate);
	const jsDate =
		rawDate instanceof Timestamp ? rawDate.toDate() : new Date(rawDate);
	return jsDate < new Date();
});
</script>

<template>
  <div v-if="task" class="flex flex-col h-full">
    <div class="flex-1 space-y-4 pt-2">
      <div class="grid grid-cols-2 gap-4">
        <div class="bg-base-200 rounded-box border border-base-300 p-4">
          <span class="text-xs uppercase tracking-wider text-base-content/50">Status</span>
          <div class="mt-2 flex items-center gap-2">
            <div class="h-2 w-2 rounded-full animate-pulse"
              :class="{ 'bg-blue-300': task.status === 'todo', 'bg-red-300': task.status === 'in-progress', 'bg-orange-300': task.status === 'done' }">
            </div>
            <span class="text-sm">{{ task.status.replace('-', ' ').replace(/\b\w/g, (char: string) =>
              char.toUpperCase()) }}</span>
          </div>
        </div>

        <div class="bg-base-200 rounded-box border border-base-300 p-4">
          <span class="text-xs uppercase tracking-wider text-base-content/50">Due Date</span>
          <div class="mt-2 flex items-center gap-2">
            <span class="text-sm" :class="{ 'text-error': isOverdue }" v-if="task.dueDate">
              {{ formatDueDate(task.dueDate) }}
            </span>
            <span class="text-sm text-base-content/50" v-else>
              No due date
            </span>
          </div>
        </div>

      </div>
      
      <div class="bg-base-200 rounded-box border border-base-300 p-4">
        <span class="text-xs uppercase tracking-wider text-base-content/50">Priority</span>
        <div class="mt-2 flex items-center gap-2" v-if="task.priority">
          <span class="px-2 py-1 rounded-badge text-xs truncate"
            :style="{ backgroundColor: task.priority.color, color: getTextColor(task.priority.color) }">
            {{ task.priority.title }}
          </span>
        </div>
        <div class="mt-2 flex items-center gap-2" v-else>
          <span class="text-sm text-base-content/50">No priority</span>
        </div>
      </div>

      <div class="bg-base-200 rounded-box border border-base-300 p-4" v-if="task.tags">
        <span class="text-xs uppercase tracking-wider text-base-content/50">Tags</span>
        <div class="mt-2 flex items-center gap-2">
          <span v-for="tag in task.tags" :key="tag.id"
            class="px-2 py-1 rounded-badge text-xs font-medium whitespace-nowrap truncate"
            :style="{ backgroundColor: tag.color, color: getTextColor(tag.color) }">
            {{ tag.title }}
          </span>
        </div>
      </div>

      <div class="bg-base-200 rounded-box border border-base-300 p-4" v-if="task.description">
        <span class="text-xs uppercase tracking-wider text-base-content/50">Description</span>
        <div class="mt-2 flex items-center gap-2">
          <span class="text-sm">{{ task.description }}</span>
        </div>
      </div>
    </div>

    <div class="pt-4 -mb-2">
      <button type="button" class="btn btn-error w-full justify-between px-4 hover:text-white" @click="handleDelete">
        Delete Task
        <MaterialSymbolsDelete class="h-5 w-5" />
      </button>
    </div>
  </div>
</template>