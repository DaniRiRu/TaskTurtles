export enum ViewMode {
	Horizontal = "Horizontal",
	Vertical = "Vertical",
	List = "List",
}
