export enum SortType {
	Ascending = "Ascending",
	Descending = "Descending",
}
