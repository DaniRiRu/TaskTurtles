export enum SortOptions {
	Title = "Title",
	Status = "Status",
	Priority = "Priority",
	Tag = "Tag",
	DueDate = "Due Date",
}
