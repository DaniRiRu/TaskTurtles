export enum ModalType {
	None = "none",
	Tags = "tags",
	Priorities = "priorities",
}
