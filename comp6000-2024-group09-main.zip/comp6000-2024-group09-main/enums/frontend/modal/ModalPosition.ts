export enum ModalPosition {
	Middle = "middle",
	Bottom = "bottom",
}
