console.log("Hello from Tauri!");
