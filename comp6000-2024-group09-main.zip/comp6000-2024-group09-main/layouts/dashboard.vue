<script setup lang="ts">
import { breakpointsTailwind, useBreakpoints } from "@vueuse/core";
import { onErrorCaptured } from "vue";
import NotificationAlert from "~/components/Universal/NotificationAlert.vue";
import { INSUFFICIENT_TOKENS } from "~/types/backend/ai-service/requests";

const breakpoints = useBreakpoints(breakpointsTailwind);
const md = ref(false);
const showAiButton = ref(false);
const bgOpacity = ref(0.3);

const { showNotification } = useNotification();

onErrorCaptured((error, instance, info) => {
	console.log("Error captured:", error, instance, info);
	if (error.message === INSUFFICIENT_TOKENS) {
		showNotification("error", "Insufficient tokens available");
		return false;
	}
	showNotification("error", error.message);
	return true;
});

const theme = useCookie<string>(COOKIE_NAMES.THEME, {
	default: () => DEFAULT_THEME,
});

onMounted(() => {
	md.value = breakpoints.smaller("md").value;

	watchEffect(() => {
		md.value = breakpoints.smaller("md").value;
	});
});

const open = useCookie(COOKIE_NAMES.SIDEBAR, {
	default: () => false,
});

const sidebarClasses = computed(() => ({
	"fixed inset-y-0 left-0": md.value,
	"sticky top-0": !md.value,
	"-translate-x-full": !open.value,
}));

const bgStyle = computed(() => {
	const bgImage =
		customThemes[theme.value as keyof typeof customThemes]?.background;
	return {
		backgroundImage: `url(${bgImage})`,
		backgroundSize: "cover",
		backgroundPosition: "center",
		backgroundRepeat: "no-repeat",
		backgroundAttachment: "fixed",
		opacity: bgOpacity.value,
	};
});

function toggleAiButton() {
	showAiButton.value = !showAiButton.value;
}
</script>

<template>
  <div class="h-dvh relative bg-base-200">
    <NotificationAlert />
    <div class="fixed inset-0 z-0" :style="bgStyle"></div>
    
    <div class="relative z-10 h-full">
      <CoreSearchPalette />
      <div 
        class="fixed inset-0 bg-black/50 z-20 transition-opacity duration-300 ease-in-out"
        :class="{ 'opacity-0 pointer-events-none': !(md && open), 'opacity-100 pointer-events-auto': md && open }"
        @click="open = false"
      ></div>
      <div class="flex flex-row">
        <div 
          class="transition-transform duration-300 ease-in-out h-screen py-4 pl-4 z-40" 
          :class="sidebarClasses"
        >
          <CoreSidebar />
        </div>
        <div 
          class="flex-1" 
          :class="{ '-ml-68': !open && !md, 'transition-all duration-300 ease-in-out': !md }"
        >
          <div 
            class="fixed top-0 z-30 mx-4 transition-all duration-300 ease-in-out" 
            :class="{
              'w-[calc(100%-2rem)]': !open || md,
              'w-[calc(100%-19rem)]': open && !md,
            }"
          >
            <CoreNavbar @toggle-chat="toggleAiButton" />
          </div>
          <div class="px-7 h-full pt-16 relative z-10">
            <AiChatBotChatWindow
              v-if="showAiButton" 
              :onClose="toggleAiButton"
            />
            <slot />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>