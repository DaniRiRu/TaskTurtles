<script setup lang="ts">
const theme = useCookie<string>(COOKIE_NAMES.THEME, {
	default: () => DEFAULT_THEME,
});

const bgOpacity = ref(0.3);

const bgStyle = computed(() => {
	const bgImage =
		customThemes[theme.value as keyof typeof customThemes]?.background;
	return {
		backgroundImage: `url(${bgImage})`,
		backgroundSize: "cover",
		backgroundPosition: "center",
		backgroundRepeat: "no-repeat",
		backgroundAttachment: "fixed",
		opacity: bgOpacity.value,
	};
});
</script>

<template>
  <div>
    <div class="fixed inset-0 z-0" :style="bgStyle"></div>
    <NuxtLayout name="dashboard">
      <div class="w-full h-full mb-4 relative z-10">
        <SettingsHeader />
        <slot />
      </div>
    </NuxtLayout>
  </div>
</template>