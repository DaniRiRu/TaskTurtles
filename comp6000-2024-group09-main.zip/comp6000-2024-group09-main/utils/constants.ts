import type { Theme } from "daisyui";

export const COOKIE_NAMES = {
	THEME: "theme",
	SIDEBAR: "sidebar",
	SEARCH: "search",
	UI: {
		SKILL_TREE: {
			VIEW: "ui.skill_tree.view",
		},
	},
};

export const SESSION_STORAGE_NAMES = {
	UI: {
		SKILL_TREE: {
			VIEW: "ui.skill_tree.view",
		},
	},
};

export const AI_ASSISTANTS = {
	CHAT_BOT: "asst_Q2BOIUB0gkK33rzV3gBn1RK3",
};

export const DEFAULT_THEME: Theme = "forest";
