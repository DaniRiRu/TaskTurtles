import type { CalendarDate } from "~/types/calendar";

export function getMonthDates(currentDate: Date): CalendarDate[] {
	const year = currentDate.getFullYear();
	const month = currentDate.getMonth();
	const firstDay = new Date(year, month, 1);
	const lastDay = new Date(year, month + 1, 0);

	const daysArray: CalendarDate[] = [];
	const startingBlanks = firstDay.getDay();

	for (let i = 0; i < startingBlanks; i++) {
		const prevDate = new Date(year, month, -startingBlanks + i + 1);
		daysArray.push({
			date: prevDate,
			isCurrentMonth: false,
			isToday: isToday(prevDate),
			isSelected: false,
		});
	}

	for (let i = 1; i <= lastDay.getDate(); i++) {
		const date = new Date(year, month, i);
		daysArray.push({
			date,
			isCurrentMonth: true,
			isToday: isToday(date),
			isSelected: false,
		});
	}

	const totalCells = 42;
	const remainingDays = totalCells - daysArray.length;

	for (let i = 1; i <= remainingDays; i++) {
		const nextDate = new Date(year, month + 1, i);
		daysArray.push({
			date: nextDate,
			isCurrentMonth: false,
			isToday: isToday(nextDate),
			isSelected: false,
		});
	}

	return daysArray;
}

export function isToday(date: Date): boolean {
	const today = new Date();
	return date.toDateString() === today.toDateString();
}
