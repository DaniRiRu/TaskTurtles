import { StreamingError } from "~/errors/ai-chat/streaming";

/**
 * Creates a stream processor for handling streaming responses
 * @param body - The ReadableStream to process
 * @returns A generator function that yields parsed JSON chunks from the stream
 */
export function streamProcessor(body: ReadableStream) {
	const reader = body.getReader();
	const decoder = new TextDecoder();

	return async function* () {
		try {
			while (true) {
				const { done, value } = await reader.read();

				if (done) {
					break;
				}

				const chunk = decoder.decode(value);
				const lines = chunk.split("\n");

				for (const line of lines) {
					if (line.startsWith("data: ")) {
						const data = line.slice(6);
						if (data === "[DONE]") {
							return;
						}
						try {
							yield JSON.parse(data);
						} catch (error) {
							throw new StreamingError(
								`Failed to parse JSON: ${error instanceof Error ? error.message : "Unknown error"}`,
							);
						}
					}
				}
			}
		} finally {
			reader.releaseLock();
		}
	};
}
