import type { $Fetch, NitroFetchRequest } from "nitropack";
import type { CalendarProvider } from "~/types/backend/calendar/response";
import { TTBackendAccountService } from "./services/account";
import { TTBackendAiService } from "./services/ai-service";
import { TTBackendCalendarConnectionService } from "./services/calendar/connections";
import {
	TTBackendCalendarEventsService,
	TTBackendCalendarGlobalEventsService,
} from "./services/calendar/events";
import { TTBackendHabitsService } from "./services/habits/habits";
import { TTBackendJournalService } from "./services/journal";
import { TTBackendLeaderboardService } from "./services/leaderboard";
import { TTBackendPriorityService } from "./services/priorities";
import { TTBackendProfileService } from "./services/profile";
import { TTBackendMetaService } from "./services/progress";
import { TTBackendQuestService } from "./services/quest";
import { TTBackendShopService } from "./services/shop";
import { TTBackendSkillTreeDataService } from "./services/skill-tree/data";
import { TTBackendSkillTreeDetailsService } from "./services/skill-tree/details";
import { TTBackendSkillTreeProgressService } from "./services/skill-tree/progress";
import { TTBackendSkillTreeSkillsCreationService } from "./services/skill-tree/skills/creation";
import { TTBackendSkillTreeSuggestionsService } from "./services/skill-tree/suggestions";
import { TTBackendTagService } from "./services/tags";
import { TTBackendTaskService } from "./services/tasks";

export type ApiFetch = $Fetch<unknown, NitroFetchRequest>;

export class TTBackendSkillTreesSkillsService {
	constructor(private api: ApiFetch) {}

	get creation() {
		return new TTBackendSkillTreeSkillsCreationService(this.api);
	}

	complete(treeName: string, skillId: string) {
		return this.api(`/api/skill-trees/${treeName}/skills/${skillId}/complete`, {
			method: "POST",
		});
	}
}
export class TTBackendSkillTreesService {
	constructor(private api: ApiFetch) {}

	get details() {
		return new TTBackendSkillTreeDetailsService(this.api);
	}

	get progress() {
		return new TTBackendSkillTreeProgressService(this.api);
	}

	get skills() {
		return new TTBackendSkillTreesSkillsService(this.api);
	}

	get data() {
		return new TTBackendSkillTreeDataService(this.api);
	}

	get suggestions() {
		return new TTBackendSkillTreeSuggestionsService(this.api);
	}

	complete(treeName: string) {
		return this.api(`/api/skill-trees/${treeName}/complete`, {
			method: "POST",
		});
	}
}

export class TTBackendCalendarProviderService {
	constructor(
		private api: ApiFetch,
		private provider: CalendarProvider,
	) {}

	get events() {
		return TTBackendCalendarEventsService.forProvider(this.api, this.provider);
	}

	get connection() {
		return TTBackendCalendarConnectionService.forProvider(
			this.api,
			this.provider,
		);
	}
}

export class TTBackendCalendarService {
	constructor(private api: ApiFetch) {}

	forProvider(provider: CalendarProvider) {
		return new TTBackendCalendarProviderService(this.api, provider);
	}

	get google() {
		return this.forProvider("google");
	}

	get outlook() {
		return this.forProvider("outlook");
	}

	get ical() {
		return this.forProvider("ical");
	}

	get custom() {
		return this.forProvider("custom");
	}

	get global() {
		return new TTBackendCalendarGlobalEventsService(this.api);
	}

	complete(treeName: string) {
		return this.api(`/api/skill-trees/${treeName}/complete`, {
			method: "POST",
		});
	}
}

export class TTBackend {
	private api: ApiFetch;

	constructor() {
		this.api = $fetch.create({
			headers: {
				...useRequestHeaders(["Cookie"]),
			},
		});
	}

	get profile() {
		return new TTBackendProfileService(this.api);
	}

	get account() {
		return new TTBackendAccountService(this.api);
	}

	get tasks() {
		return new TTBackendTaskService(this.api);
	}

	get priorities() {
		return new TTBackendPriorityService(this.api);
	}

	get tags() {
		return new TTBackendTagService(this.api);
	}

	get quests() {
		return new TTBackendQuestService(this.api);
	}

	get progress() {
		return new TTBackendMetaService(this.api);
	}

	get shop() {
		return new TTBackendShopService(this.api);
	}

	get skilltrees() {
		return new TTBackendSkillTreesService(this.api);
	}

	get calendar() {
		return new TTBackendCalendarService(this.api);
	}

	get ai() {
		return new TTBackendAiService(this.api);
	}

	get habits() {
		return new TTBackendHabitsService(this.api);
	}

	get leaderboard() {
		return new TTBackendLeaderboardService(this.api);
	}
	get journal() {
		return new TTBackendJournalService(this.api);
	}
}
