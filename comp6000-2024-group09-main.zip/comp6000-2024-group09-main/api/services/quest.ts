import type { ApiResponse } from "~/types/backend";
import type { Quest, QuestDocument } from "~/types/quests/quests";
import { TTBackendService } from "./service";

export class TTBackendQuestService extends TTBackendService {
	async retrieveQuests(): Promise<ApiResponse<QuestDocument>> {
		return this.api<ApiResponse<QuestDocument>>("api/quests/retrieve", {
			method: "GET",
		}).catch(this.handleError);
	}

	async saveQuests(quests: Quest[]): Promise<ApiResponse<void>> {
		return this.api<ApiResponse<void>>("api/quests/save", {
			method: "POST",
			body: { quests },
		}).catch(this.handleError);
	}

	async updateProgress(
		questId: number,
		progress: number,
	): Promise<ApiResponse<void>> {
		return this.api<ApiResponse<void>>("api/quests/progress/update", {
			method: "POST",
			body: { questId, progress },
		}).catch(this.handleError);
	}

	async toggleQuest(questId: number): Promise<ApiResponse<void>> {
		return this.api<ApiResponse<void>>("api/quests/toggle", {
			method: "POST",
			body: { questId },
		}).catch(this.handleError);
	}

	async completeQuest(questId: number): Promise<ApiResponse<void>> {
		return this.api<ApiResponse<void>>("api/quests/complete", {
			method: "POST",
			body: { questId },
		}).catch(this.handleError);
	}

	async archiveQuests(questIds: number[]): Promise<ApiResponse<void>> {
		return this.api<ApiResponse<void>>("api/quests/archive", {
			method: "POST",
			body: { questIds },
		}).catch(this.handleError);
	}

	async refreshDaily(): Promise<ApiResponse<void>> {
		return this.api<ApiResponse<void>>("api/quests/daily/refresh", {
			method: "POST",
		}).catch(this.handleError);
	}
}
