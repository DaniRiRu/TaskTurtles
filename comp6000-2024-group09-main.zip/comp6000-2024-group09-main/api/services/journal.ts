import type { ApiResponse } from "~/types/backend";
import type {
	JournalCreateRequest,
	JournalCreateResponse,
} from "~/types/backend/journal/create";
import type { JournalListResponse } from "~/types/backend/journal/list";
import { TTBackendService } from "./service";

export class TTBackendJournalService extends TTBackendService {
	async create(entry: JournalCreateRequest) {
		return this.api<ApiResponse<JournalCreateResponse>>(
			"/api/journal/entries/create",
			{
				method: "POST",
				body: entry,
			},
		).catch(this.handleError);
	}
	async list() {
		return this.api<ApiResponse<JournalListResponse>>(
			"/api/journal/entries/list",
			{
				method: "GET",
			},
		).catch(this.handleError);
	}
}
