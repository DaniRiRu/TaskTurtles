import type { ApiResponse } from "~/types/backend";
import type { LeaderboardResults } from "~/types/backend/leaderboard/leaderboard";
import { TTBackendService } from "./service";

export class TTBackendLeaderboardService extends TTBackendService {
	async list() {
		return this.api<ApiResponse<LeaderboardResults>>("/api/leaderboard/list", {
			method: "GET",
		}).catch(this.handleError);
	}
}
