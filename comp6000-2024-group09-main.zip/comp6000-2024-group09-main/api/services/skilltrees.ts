import type { $Fetch, NitroFetchRequest } from "nitropack";
import { TTBackendSkillTreeDataService } from "./skill-tree/data";
import { TTBackendSkillTreeDetailsService } from "./skill-tree/details";
import { TTBackendSkillTreeProgressService } from "./skill-tree/progress";
import { TTBackendSkillTreeSuggestionsService } from "./skill-tree/suggestions";
import { TTBackendSkillTreesSkillsService } from "./skilltreeskills";

export type ApiFetch = $Fetch<unknown, NitroFetchRequest>;

export class TTBackendSkillTreesService {
	constructor(private api: ApiFetch) {}

	get details() {
		return new TTBackendSkillTreeDetailsService(this.api);
	}

	get progress() {
		return new TTBackendSkillTreeProgressService(this.api);
	}

	get skills() {
		return new TTBackendSkillTreesSkillsService(this.api);
	}

	get data() {
		return new TTBackendSkillTreeDataService(this.api);
	}

	get suggestions() {
		return new TTBackendSkillTreeSuggestionsService(this.api);
	}
}
