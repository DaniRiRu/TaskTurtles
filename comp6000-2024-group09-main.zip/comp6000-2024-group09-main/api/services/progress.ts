import type { ApiResponse } from "~/types/backend";
import type { UserProgress } from "~/types/backend/meta/progress";
import type { WalletData } from "~/types/backend/meta/wallet";
import type { Reward } from "~/types/rewards/rewards";
import { TTBackendService } from "./service";

export class TTBackendMetaService extends TTBackendService {
	async fetchProgress() {
		return this.api<ApiResponse<UserProgress>>("/api/meta/progress/fetch", {
			method: "GET",
		}).catch(this.handleError);
	}

	async modifyProgress(progress: Partial<UserProgress>) {
		return this.api<ApiResponse<UserProgress>>("/api/meta/progress/modify", {
			method: "POST",
			body: progress,
		}).catch(this.handleError);
	}

	async fetchWallet() {
		return this.api<ApiResponse<WalletData>>("/api/meta/wallet/fetch", {
			method: "GET",
		}).catch(this.handleError);
	}

	async modifyWallet(coins: number, diamonds: number) {
		return this.api<ApiResponse<WalletData>>("/api/meta/wallet/modify", {
			method: "POST",
			body: {
				coins,
				diamonds,
			},
		}).catch(this.handleError);
	}

	async claimDailyReward() {
		return this.api<ApiResponse<Reward>>("/api/rewards/daily", {
			method: "POST",
		}).catch(this.handleError);
	}
}
