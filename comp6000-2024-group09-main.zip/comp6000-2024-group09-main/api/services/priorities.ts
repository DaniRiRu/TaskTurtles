import type { ApiResponse } from "~/types/backend";
import type { PriorityAddResponse } from "~/types/backend/priorities/add";
import type { PriorityListResponse } from "~/types/backend/priorities/list";
import type { Priority } from "~/types/core/priority";
import { TTBackendService } from "./service";

export class TTBackendPriorityService extends TTBackendService {
	async list() {
		return this.api<ApiResponse<PriorityListResponse>>(
			"/api/priorities/list",
		).catch(this.handleError);
	}

	async add(priority: Priority) {
		return this.api<ApiResponse<PriorityAddResponse>>("api/priorities/add", {
			method: "POST",
			body: {
				priority,
			},
		}).catch(this.handleError);
	}

	async update(priority: Priority) {
		return this.api<ApiResponse<PriorityAddResponse>>("api/priorities/update", {
			method: "POST",
			body: {
				priority,
			},
		}).catch(this.handleError);
	}

	async delete(priority: Priority) {
		return this.api<ApiResponse<PriorityAddResponse>>("api/priorities/delete", {
			method: "POST",
			body: {
				priority,
			},
		}).catch(this.handleError);
	}
}
