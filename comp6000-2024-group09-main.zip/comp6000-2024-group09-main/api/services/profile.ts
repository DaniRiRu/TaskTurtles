import type { ApiResponse } from "~/types/backend";
import type { ProfileSetupResponse } from "~/types/backend/profile/setup";
import type { StoredUser } from "~/types/core/user";
import { TTBackendService } from "./service";

export class TTBackendProfileService extends TTBackendService {
	async setup(user: StoredUser) {
		return this.api<ApiResponse<ProfileSetupResponse>>("/api/profile/setup", {
			method: "POST",
			body: {
				user,
			},
		}).catch(this.handleError);
	}
}
