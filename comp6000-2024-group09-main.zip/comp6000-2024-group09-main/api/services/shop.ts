import type { ApiResponse } from "~/types/backend";
import type { InventoryItem, ShopItem } from "~/types/backend/shop/item";
import { TTBackendService } from "./service";

export class TTBackendShopService extends TTBackendService {
	async fetchItems() {
		return this.api<ShopItem[]>("/api/shop/items/fetch", {
			method: "GET",
		}).catch(this.handleError);
	}

	async purchaseItem(itemId: string, quantity = 1) {
		return this.api<ApiResponse<ShopItem>>("/api/shop/items/purchase", {
			method: "POST",
			body: {
				itemId,
				quantity,
			},
		}).catch(this.handleError);
	}

	async fetchInventory() {
		return this.api<InventoryItem[]>("/api/shop/inventory/fetch", {
			method: "GET",
		}).catch(this.handleError);
	}

	async useItem(itemId: string) {
		return this.api<{
			items: InventoryItem[];
			message: string;
		}>("api/shop/inventory/use-item", {
			method: "POST",
			body: {
				itemId,
			},
		}).catch(this.handleError);
	}
}
