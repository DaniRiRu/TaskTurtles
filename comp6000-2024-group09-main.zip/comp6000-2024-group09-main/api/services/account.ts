import type { ApiResponse } from "~/types/backend";
import type { SendPasswordResetResponse } from "~/types/backend/auth/passwordreset";
import type { StoredUser } from "~/types/core/user";
import { TTBackendService } from "./service";

export class TTBackendAccountService extends TTBackendService {
	async get() {
		return this.api<ApiResponse<StoredUser>>("/api/account/get", {
			method: "GET",
		}).catch(this.handleError);
	}

	async update(data: Partial<StoredUser>) {
		return this.api<ApiResponse<StoredUser>>("/api/account/update", {
			method: "PATCH",
			body: data,
		}).catch(this.handleError);
	}

	async delete() {
		return this.api<ApiResponse<null>>("/api/account/delete", {
			method: "DELETE",
		}).catch(this.handleError);
	}

	async changePassword(data: { password: string }) {
		return this.api<ApiResponse<null>>("/api/account/update", {
			method: "PATCH",
			body: data,
		}).catch(this.handleError);
	}

	async sendPasswordReset(data: { email: string }) {
		return this.api<ApiResponse<SendPasswordResetResponse>>(
			"/api/account/password/reset",
			{
				method: "POST",
				body: data,
			},
		).catch(this.handleError);
	}
}
