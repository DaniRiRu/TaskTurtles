import type { $Fetch, NitroFetchRequest } from "nitropack";
import { TTBackendSkillTreeSkillsCreationService } from "./skill-tree/skills/creation";

export type ApiFetch = $Fetch<unknown, NitroFetchRequest>;

export class TTBackendSkillTreesSkillsService {
	constructor(private api: ApiFetch) {}

	get creation() {
		return new TTBackendSkillTreeSkillsCreationService(this.api);
	}
}
