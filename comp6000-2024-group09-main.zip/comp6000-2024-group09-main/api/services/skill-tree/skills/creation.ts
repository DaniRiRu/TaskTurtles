import type { ApiResponse } from "~/types/backend";
import type { Skill } from "~/types/skills/skill";
import type { ApiFetch } from "../../..";

export class TTBackendSkillTreeSkillsCreationService {
	constructor(private api: ApiFetch) {}

	async generate(treeName: string, skillId: string) {
		return this.api<ApiResponse<Skill>>(
			`/api/skill-trees/${treeName}/skills/${skillId}/generate`,
			{
				method: "GET",
			},
		);
	}
}
