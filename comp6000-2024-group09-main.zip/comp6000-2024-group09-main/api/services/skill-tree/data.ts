import type { ApiResponse } from "~/types/backend";
import type { SkillTreeData } from "~/types/skills/skill";
import type { ApiFetch } from "../..";

export class TTBackendSkillTreeDataService {
	constructor(private api: ApiFetch) {}

	async getTreeFromName(treeName: string) {
		return this.api<ApiResponse<SkillTreeData>>(
			`/api/skill-trees/${treeName}`,
			{
				method: "GET",
			},
		);
	}
}
