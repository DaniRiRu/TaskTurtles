import type { ApiResponse } from "~/types/backend";
import type { ApiRequestSuccesful } from "~/types/backend/generic/success";
import type { ApiFetch } from "../..";

export class TTBackendSkillTreeProgressService {
	constructor(private api: ApiFetch) {}

	async reset(treeName: string) {
		return this.api<ApiResponse<ApiRequestSuccesful>>(
			`/api/skill-trees/${treeName}/progress/reset`,
		);
	}

	async delete(treeName: string) {
		return this.api<ApiResponse<ApiRequestSuccesful>>(
			`/api/skill-trees/${treeName}/progress/delete`,
		);
	}
}
