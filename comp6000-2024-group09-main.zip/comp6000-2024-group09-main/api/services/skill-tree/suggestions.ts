import type { ApiResponse } from "~/types/backend";
import type { AiSuggestionPrompt } from "~/types/skills/suggestions";
import type { ApiFetch } from "../..";

export class TTBackendSkillTreeSuggestionsService {
	constructor(private api: ApiFetch) {}

	async recommend(title?: string) {
		return this.api<ApiResponse<AiSuggestionPrompt>>(
			"/api/skill-trees/suggestions",
			{
				method: "GET",
				params: title ? { title } : undefined,
			},
		);
	}
}
