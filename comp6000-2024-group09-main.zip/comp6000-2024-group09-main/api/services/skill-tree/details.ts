import type { ApiResponse } from "~/types/backend";
import type { SkillTreeUpdateResponse } from "~/types/backend/skill-tree/update";
import type { SkillTreeData } from "~/types/skills/skill";
import type { ApiFetch } from "../..";

export class TTBackendSkillTreeDetailsService {
	constructor(private api: ApiFetch) {}

	async updateTreeDetails(treeName: string, updates: Partial<SkillTreeData>) {
		return this.api<ApiResponse<SkillTreeUpdateResponse>>(
			`/api/skill-trees/${treeName}`,
			{
				method: "PATCH",
				body: updates,
			},
		);
	}
}
