import type { ApiResponse } from "~/types/backend";
import type { TagAddResponse } from "~/types/backend/tags/add";
import type { TagListResponse } from "~/types/backend/tags/list";
import type { Tag } from "~/types/core/tag";
import { TTBackendService } from "./service";

export class TTBackendTagService extends TTBackendService {
	async list() {
		return this.api<ApiResponse<TagListResponse>>("/api/tags/list").catch(
			this.handleError,
		);
	}

	async add(tag: Tag) {
		return this.api<ApiResponse<TagAddResponse>>("api/tags/add", {
			method: "POST",
			body: {
				tag,
			},
		}).catch(this.handleError);
	}

	async update(tag: Tag) {
		return this.api<ApiResponse<TagAddResponse>>("api/tags/update", {
			method: "POST",
			body: {
				tag,
			},
		}).catch(this.handleError);
	}

	async delete(tag: Tag) {
		return this.api<ApiResponse<TagAddResponse>>("api/tags/delete", {
			method: "POST",
			body: {
				tag,
			},
		}).catch(this.handleError);
	}
}
