import type { ApiResponse } from "~/types/backend";
import type { TaskAddResponse } from "~/types/backend/tasks/add";
import type { TaskListResponse } from "~/types/backend/tasks/list";
import type { Task } from "~/types/core/task";
import { TTBackendService } from "./service";

export class TTBackendTaskService extends TTBackendService {
	async list() {
		return this.api<ApiResponse<TaskListResponse>>("/api/tasks/list").catch(
			this.handleError,
		);
	}

	async add(task: Task) {
		return this.api<ApiResponse<TaskAddResponse>>("/api/tasks/add", {
			method: "POST",
			body: {
				task,
			},
		}).catch(this.handleError);
	}

	async update(task: Task) {
		return this.api<ApiResponse<TaskAddResponse>>("/api/tasks/update", {
			method: "POST",
			body: {
				task,
			},
		}).catch(this.handleError);
	}

	async delete(task: Task) {
		return this.api<ApiResponse<TaskAddResponse>>("/api/tasks/delete", {
			method: "POST",
			body: {
				task,
			},
		}).catch(this.handleError);
	}
}
