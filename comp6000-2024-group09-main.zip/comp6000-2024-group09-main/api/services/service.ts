import type { FetchError } from "ofetch";
import type { ApiFetch } from "..";

export abstract class TTBackendService {
	constructor(protected api: ApiFetch) {}

	handleError = async (error: FetchError) => {
		let message: string = error.message;

		if (error.response?.headers.get("content-type") === "application/json") {
			if ("error" in error.data) {
				message = error.data.message || error.data.error;
			}
		}

		return {
			error: message,
		};
	};
}
