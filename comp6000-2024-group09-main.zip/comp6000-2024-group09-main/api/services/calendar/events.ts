import type { ApiResponse } from "~/types/backend";
import type {
	CalendarEventResponse,
	CalendarEventsResponse,
	CalendarProvider,
	CalendarSyncResponse,
} from "~/types/backend/calendar/response";
import type { AnyCalendarEvent } from "~/types/calendar/events";
import type { ApiFetch } from "../..";

export class TTBackendCalendarGlobalEventsService {
	constructor(private api: ApiFetch) {}

	async getEvents() {
		return this.api<ApiResponse<CalendarEventsResponse>>(
			"/api/calendar/events",
			{
				method: "GET",
			},
		);
	}
}

export class TTBackendCalendarEventsService {
	constructor(
		private api: ApiFetch,
		private provider: CalendarProvider,
	) {}

	async getEvents(timeMin: Date, timeMax: Date) {
		return this.api<ApiResponse<CalendarEventsResponse>>(
			`/api/calendar/${this.provider}/events`,
			{
				method: "GET",
				query: {
					timeMin: timeMin.toISOString(),
					timeMax: timeMax.toISOString(),
				},
			},
		);
	}

	async createEvent(event: AnyCalendarEvent) {
		return this.api<ApiResponse<CalendarEventResponse>>(
			`/api/calendar/${this.provider}/events`,
			{
				method: "POST",
				body: {
					event: {
						...event,
						provider: this.provider,
					},
				},
			},
		);
	}

	async updateEvent(eventId: string, updates: Partial<AnyCalendarEvent>) {
		return this.api<ApiResponse<CalendarEventResponse>>(
			`/api/calendar/${this.provider}/events/${eventId}`,
			{
				method: "PATCH",
				body: {
					updates: {
						...updates,
						provider: this.provider,
					},
				},
			},
		);
	}

	async deleteEvent(eventId: string) {
		return this.api<ApiResponse<CalendarEventResponse>>(
			`/api/calendar/${this.provider}/events/${eventId}`,
			{
				method: "DELETE",
			},
		);
	}

	async syncEvents(events: AnyCalendarEvent[]) {
		return this.api<ApiResponse<CalendarSyncResponse>>(
			`/api/calendar/${this.provider}/events/sync`,
			{
				method: "POST",
				body: {
					events: events.map((event) => ({
						...event,
						provider: this.provider,
					})),
				},
			},
		);
	}

	static forProvider(api: ApiFetch, provider: CalendarProvider) {
		return new TTBackendCalendarEventsService(api, provider);
	}
}
