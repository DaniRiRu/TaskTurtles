// api/services/calendar/connections.ts

import type { ApiResponse } from "~/types/backend";
import type {
	CalendarConnectionResponse,
	CalendarProvider,
} from "~/types/backend/calendar/response";
import type { ApiFetch } from "../..";

export class TTBackendCalendarConnectionService {
	constructor(
		private api: ApiFetch,
		private provider: CalendarProvider,
	) {}

	async getConnection() {
		try {
			const response = await this.api<ApiResponse<CalendarConnectionResponse>>(
				`/api/calendar/${this.provider}/connection`,
				{
					method: "GET",
				},
			);
			return response;
		} catch (error) {
			console.error(`Failed to get ${this.provider} connection:`, error);
			return {
				isConnected: false,
				lastSync: null,
				connectionUrl: null,
			};
		}
	}

	async updateConnection(connectionUrl?: string) {
		try {
			const response = await this.api<ApiResponse<CalendarConnectionResponse>>(
				`/api/calendar/${this.provider}/connection`,
				{
					method: "POST",
					body: {
						connectionUrl: connectionUrl || null,
						isConnected: true,
						lastSync: new Date(),
					},
				},
			);
			return response;
		} catch (error) {
			console.error(`Failed to update ${this.provider} connection:`, error);
			throw error;
		}
	}

	async deleteConnection() {
		try {
			const response = await this.api<ApiResponse<CalendarConnectionResponse>>(
				`/api/calendar/${this.provider}/connection`,
				{
					method: "DELETE",
				},
			);
			return response;
		} catch (error) {
			console.error(`Failed to delete ${this.provider} connection:`, error);
			return {
				isConnected: false,
				lastSync: null,
				connectionUrl: null,
			};
		}
	}

	async checkConnection() {
		try {
			const connection =
				(await this.getConnection()) as CalendarConnectionResponse;
			return connection.isConnected;
		} catch (error) {
			console.error(`Failed to check ${this.provider} connection:`, error);
			return false;
		}
	}

	async refreshConnection() {
		try {
			const connection =
				(await this.getConnection()) as CalendarConnectionResponse;
			if (connection.isConnected) {
				await this.updateConnection(connection.connectionUrl || undefined);
			}
			return connection.isConnected;
		} catch (error) {
			console.error(`Failed to refresh ${this.provider} connection:`, error);
			return false;
		}
	}

	static forProvider(api: ApiFetch, provider: CalendarProvider) {
		return new TTBackendCalendarConnectionService(api, provider);
	}
}
