import type { ApiResponse } from "~/types/backend";
import type {
	HabitCompleteResponse,
	HabitDeleteResponse,
	HabitGetResponse,
	HabitUpdateResponse,
	HabitsCreateResponse,
	HabitsGetResponse,
} from "~/types/backend/habits/response";
import type { HabitData } from "~/types/habits/habits";
import type { ApiFetch } from "../..";

export class TTBackendHabitsService {
	constructor(private api: ApiFetch) {}

	async complete(habitId: string, data: { note?: string; mood?: string }) {
		console.log("test");
		return this.api<ApiResponse<HabitCompleteResponse>>(
			`/api/habits/${habitId}/complete`,
			{
				method: "POST",
				body: JSON.stringify(data),
			},
		);
	}

	async delete(habitId: string) {
		return this.api<ApiResponse<HabitDeleteResponse>>(
			`/api/habits/${habitId}`,
			{
				method: "DELETE",
			},
		);
	}

	async get(habitId: string) {
		return this.api<ApiResponse<HabitGetResponse>>(`/api/habits/${habitId}`, {
			method: "GET",
		});
	}

	async update(habitId: string, data: Partial<HabitData>) {
		return this.api<ApiResponse<HabitUpdateResponse>>(
			`/api/habits/${habitId}`,
			{
				method: "POST",
				body: JSON.stringify(data),
			},
		);
	}

	async getAll() {
		return this.api<ApiResponse<HabitsGetResponse>>("/api/habits", {
			method: "GET",
		});
	}

	async create(data: Partial<HabitData>) {
		return this.api<ApiResponse<HabitsCreateResponse>>("/api/habits", {
			method: "POST",
			body: JSON.stringify(data),
		});
	}
}
