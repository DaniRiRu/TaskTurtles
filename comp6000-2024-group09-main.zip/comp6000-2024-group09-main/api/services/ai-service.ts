import type { ApiResponse } from "~/types/backend";
import { InsufficientTokenError } from "~/types/backend/ai-service/errors";
import {
	type GenerateRequest,
	type GenerateResponse,
	INSUFFICIENT_TOKENS,
	type TokenInfoResponse,
} from "~/types/backend/ai-service/requests";
import { TTBackendService } from "./service";

export class TTBackendAiService extends TTBackendService {
	async generate(request: GenerateRequest): Promise<GenerateResponse> {
		const response = await this.api<ApiResponse<GenerateResponse>>(
			"/api/ai-service/generate",
			{
				method: "POST",
				body: request,
			},
		).catch(this.handleError);

		console.log("Response:", response);
		if ("error" in response) {
			if (response.error === INSUFFICIENT_TOKENS) {
				throw new InsufficientTokenError();
			}
			throw new Error(String(response.error));
		}

		return response;
	}

	async streamGenerate(
		request: GenerateRequest,
		onChunk: (chunk: { text: string; error?: string }) => void,
		onDone: () => void,
	): Promise<void> {
		const streamRequest = {
			...request,
			stream: true,
		};

		try {
			const response = await fetch("/api/ai-service/generate", {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
				},
				body: JSON.stringify(streamRequest),
			});

			console.log("Response:", response);
			if ("error" in response) {
				if (response.error === INSUFFICIENT_TOKENS) {
					throw new InsufficientTokenError();
				}
				throw new Error(String(response.error));
			}

			if (!response.ok) {
				throw new Error(`HTTP error! status: ${response.status}`);
			}

			if (!response.body) {
				throw new Error("Response body is null");
			}

			const reader = response.body.getReader();
			const decoder = new TextDecoder();

			while (true) {
				const { done, value } = await reader.read();

				if (done) {
					onDone();
					break;
				}

				const chunk = decoder.decode(value, { stream: true });

				const lines = chunk.split("\n\n");
				for (const line of lines) {
					if (!line.trim() || !line.startsWith("data: ")) continue;

					const data = line.replace("data: ", "").trim();

					if (data === "[DONE]") {
						onDone();
						return;
					}

					try {
						const parsedData = JSON.parse(data);
						onChunk(parsedData);
					} catch (e) {
						console.error("Error parsing chunk data:", e);
					}
				}
			}
		} catch (error) {
			console.error("Stream error:", error);
			onDone();
		}
	}

	async getTokenInfo(): Promise<TokenInfoResponse> {
		const response = await this.api<ApiResponse<TokenInfoResponse>>(
			"/api/ai-service/tokens/info",
			{
				method: "GET",
			},
		).catch(this.handleError);

		if ("error" in response) {
			throw new Error(response.error);
		}

		return response;
	}
}
