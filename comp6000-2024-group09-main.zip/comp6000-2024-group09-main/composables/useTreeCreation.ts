import {
	collection,
	doc,
	getDocs,
	query,
	setDoc,
	where,
} from "firebase/firestore";
import { AiContexts } from "~/types/ai-service/contexts";
import { ModelId } from "~/types/backend/ai-service/models";
import type { TreeGenerationConfig } from "~/types/skills/creation";
import type { Skill, SkillTreeData } from "~/types/skills/skill";
import { useSkillGeneration } from "./skillTree/useSkillGeneration";

const DEFAULT_TASK_NAME = "???";

export const useTreeCreation = () => {
	const db = useFirestore();
	const user = useCurrentUser();

	const generateRandomSkills = (config: TreeGenerationConfig) => {
		const skills: Record<string, Skill> = {};
		const skillLevels: string[][] = Array.from(
			{ length: config.maxLevels },
			() => [],
		);
		const dependentCount: Record<string, number> = {};

		const createSkill = (
			level: number,
			position: number,
			prerequisites: string[] = [],
		) => {
			const id = crypto.randomUUID();

			skills[id] = {
				id,
				name: DEFAULT_TASK_NAME,
				description: "Complete prerequisites to unlock this skill",
				prerequisites,
				revealed: false,
				position,
				tasks: [
					{
						id: crypto.randomUUID(),
						name: DEFAULT_TASK_NAME,
						description: "???",
						completed: false,
						difficulty: 1,
					},
				],
				icon: "❓",
				completed: false,
			};

			skillLevels[level].push(id);
			return id;
		};

		const canAddDependency = (prereqId: string): boolean => {
			return (
				!dependentCount[prereqId] ||
				dependentCount[prereqId] < config.maxDependentsPerSkill
			);
		};

		const addDependency = (prereqId: string) => {
			dependentCount[prereqId] = (dependentCount[prereqId] || 0) + 1;
		};

		const calculateDistance = (pos1: number, pos2: number): number => {
			return Math.abs(pos1 - pos2);
		};

		const findOptimalPrerequisites = (
			currentLevel: number,
			currentPosition: number,
			availablePrereqs: string[],
			desiredCount: number,
		): string[] => {
			const prereqsWithDistances = availablePrereqs.map((prereqId) => ({
				id: prereqId,
				distance: calculateDistance(currentPosition, skills[prereqId].position),
			}));

			prereqsWithDistances.sort((a, b) => a.distance - b.distance);

			return prereqsWithDistances
				.slice(0, desiredCount)
				.map((prereq) => prereq.id);
		};

		const buildSkillTree = () => {
			let skillsGenerated = 0;

			for (let i = 0; i < config.totalStartingSkills; i++) {
				skillsGenerated++;
				createSkill(0, skillsGenerated);
			}

			for (let level = 1; level < config.maxLevels; level++) {
				const skillCount =
					Math.floor(
						Math.random() *
							(config.maxSkillsPerLevel - config.minSkillsPerLevel + 1),
					) + config.minSkillsPerLevel;

				const horizontalSpacing = 100 / (skillCount + 1);

				for (let i = 0; i < skillCount; i++) {
					skillsGenerated++;
					const horizontalPosition = (i + 1) * horizontalSpacing;
					const prereqLevel = level - 1;
					const availablePrereqs =
						skillLevels[prereqLevel].filter(canAddDependency);

					if (availablePrereqs.length === 0) continue;

					const dependencyCount = Math.min(
						Math.floor(
							Math.random() *
								(config.maxDependencies - config.minDependencies + 1),
						) + config.minDependencies,
						availablePrereqs.length,
					);

					const prerequisites = findOptimalPrerequisites(
						level,
						horizontalPosition,
						availablePrereqs,
						dependencyCount,
					);

					if (prerequisites.length > 0) {
						prerequisites.forEach(addDependency);
						createSkill(level, skillsGenerated, prerequisites);
					}
				}

				if (skillLevels[level].length === 0) {
					break;
				}
			}
		};

		buildSkillTree();
		return skills;
	};

	const doesTreeNameExist = async (name: string): Promise<boolean> => {
		if (!user) return false;

		const treesCollection = collection(db, "skillTrees");
		const userTreesQuery = query(
			treesCollection,
			where("userId", "==", user.value?.uid),
			where("name", "==", name),
		);
		const snapshot = await getDocs(userTreesQuery);
		return !snapshot.empty;
	};

	const createSkillTree = async (
		name: string,
		description: string,
		config: TreeGenerationConfig,
		icon?: string,
	) => {
		if (!user.value?.uid) return;

		const exists = await doesTreeNameExist(name);
		if (exists) {
			throw new Error("A skill tree with this name already exists");
		}

		const id = crypto.randomUUID();
		const skills = generateRandomSkills(config);
		const { generateUndefinedSkill } = useSkillGeneration();

		const initialSkills = Object.values(skills).filter(
			(skill) => skill.prerequisites.length === 0,
		);

		const generatedSkills = { ...skills };

		await Promise.all(
			initialSkills.map(async (skill) => {
				if (!skill.id) return;
				generateUndefinedSkill();
			}),
		);

		const backend = useBackend();
		const totalSkillCount = Object.keys(skills).length;
		const skillLevels = config.maxLevels;

		const research = await backend.ai.generate({
			message: `I need to create a skill tree for: "${name}" with the following description: "${description}".
				The skill tree will have approximately ${totalSkillCount} skills across ${skillLevels} levels.`,
			model: ModelId.GPT_4O_SEARCH,
			context: AiContexts.TREE_RESEARCH,
			stream: false,
			webSearch: true,
			webSearchOptions: {
				searchContextSize: "high",
			},
		});

		if (!research) {
			throw new Error("Failed to generate research data");
		}

		const updatedDescription = `${description} \n\n Research data: ${research.text}`;

		const newTree: SkillTreeData = {
			id,
			name,
			description: updatedDescription,
			icon: icon || "🎯",
			skills: generatedSkills,
			userId: user.value.uid,
			createdAt: new Date().toISOString(),
			updatedAt: new Date().toISOString(),
			completed: false,
		};

		await setDoc(doc(db, "skillTrees", id), newTree);
		return id;
	};

	const getDefaultConfig = (): TreeGenerationConfig => ({
		totalStartingSkills: 1,
		maxLevels: 15,
		minSkillsPerLevel: 1,
		maxSkillsPerLevel: 3,
		minDependencies: 1,
		maxDependencies: 2,
		maxDependentsPerSkill: 2,
	});

	return {
		createSkillTree,
		doesTreeNameExist,
		getDefaultConfig,
		defaultTaskName: DEFAULT_TASK_NAME,
	};
};
