import type { NavItem } from "~/types/frontend/sidebar";

import MaterialSymbolsAccountTreeOutlineRounded from "~icons/material-symbols/account-tree-outline-rounded";
import MaterialSymbolsAccountTreeRounded from "~icons/material-symbols/account-tree-rounded";
import MaterialSymbolsBook4OutlineRounded from "~icons/material-symbols/book4-outline-rounded";
import MaterialSymbolsBook4Rounded from "~icons/material-symbols/book4-rounded";
import MaterialSymbolsCalendarTodayOutlineRounded from "~icons/material-symbols/calendar-today-outline-rounded";
import MaterialSymbolsCalendarTodayRounded from "~icons/material-symbols/calendar-today-rounded";
import MaterialSymbolsChatOutlineRounded from "~icons/material-symbols/chat-outline-rounded";
import MaterialSymbolsChatRounded from "~icons/material-symbols/chat-rounded";
import MaterialSymbolsGroupOutlineRounded from "~icons/material-symbols/group-outline-rounded";
import MaterialSymbolsGroupRounded from "~icons/material-symbols/group-rounded";
import MaterialSymbolsHomeOutlineRounded from "~icons/material-symbols/home-outline-rounded";
import MaterialSymbolsHomeRounded from "~icons/material-symbols/home-rounded";
import MaterialSymbolsLeaderboardOutlineRounded from "~icons/material-symbols/leaderboard-outline-rounded";
import MaterialSymbolsLeaderboardRounded from "~icons/material-symbols/leaderboard-rounded";
import MaterialSymbolsShoppingCartOutlineRounded from "~icons/material-symbols/shopping-cart-outline-rounded";
import MaterialSymbolsShoppingCartRounded from "~icons/material-symbols/shopping-cart-rounded";
import MaterialSymbolsTaskAltRounded from "~icons/material-symbols/task-alt-rounded";
import MaterialSymbolTrophyOutlineRounded from "~icons/material-symbols/trophy-outline-rounded";
import MaterialSymbolTrophyRounded from "~icons/material-symbols/trophy-rounded";
import MingcuteLeafFill from "~icons/mingcute/leaf-fill";
import MingcuteLeafLine from "~icons/mingcute/leaf-line";

export function useNavItems() {
	const navigationItems = ref<Record<string, NavItem>>({
		dashboard: {
			label: "Dashboard",
			icon: MaterialSymbolsHomeOutlineRounded,
			selectedIcon: MaterialSymbolsHomeRounded,
			to: "/dashboard",
		},
		tasks: {
			label: "Tasks",
			icon: MaterialSymbolsTaskAltRounded,
			selectedIcon: MaterialSymbolsTaskAltRounded,
			to: "/tasks",
		},
		quests: {
			label: "Quests",
			icon: MaterialSymbolsBook4OutlineRounded,
			selectedIcon: MaterialSymbolsBook4Rounded,
			to: "/quests",
		},
		calendar: {
			label: "Calendar",
			icon: MaterialSymbolsCalendarTodayOutlineRounded,
			selectedIcon: MaterialSymbolsCalendarTodayRounded,
			to: "/calendar",
		},
		habits: {
			label: "Habits",
			icon: MingcuteLeafLine,
			selectedIcon: MingcuteLeafFill,
			to: "/Habits",
		},
		progressionTree: {
			label: "Skills",
			icon: MaterialSymbolsAccountTreeOutlineRounded,
			selectedIcon: MaterialSymbolsAccountTreeRounded,
			to: "/skills",
		},
		achievements: {
			label: "Achievements",
			icon: MaterialSymbolTrophyOutlineRounded,
			selectedIcon: MaterialSymbolTrophyRounded,
			to: "/achievements",
		},
		friends: {
			label: "Friends",
			icon: MaterialSymbolsGroupOutlineRounded,
			selectedIcon: MaterialSymbolsGroupRounded,
			to: "/friends",
		},
		chat: {
			label: "Chat",
			icon: MaterialSymbolsChatOutlineRounded,
			selectedIcon: MaterialSymbolsChatRounded,
			to: "/chat",
		},
		leaderboard: {
			label: "Leaderboard",
			icon: MaterialSymbolsLeaderboardOutlineRounded,
			selectedIcon: MaterialSymbolsLeaderboardRounded,
			to: "/leaderboard",
		},
		journal: {
			label: "Journal",
			icon: MaterialSymbolsBook4OutlineRounded,
			selectedIcon: MaterialSymbolsBook4Rounded,
			to: "/journal",
		},
		shop: {
			label: "Shop",
			icon: MaterialSymbolsShoppingCartOutlineRounded,
			selectedIcon: MaterialSymbolsShoppingCartRounded,
			to: "/shop",
		},
	});

	return {
		navigationItems,
	};
}
export type { NavItem };
