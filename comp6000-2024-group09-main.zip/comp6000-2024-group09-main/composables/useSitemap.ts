import type { Command } from "~/types/frontend/command";
import MaterialSymbolsFindInPageOutlineRounded from "~icons/material-symbols/find-in-page-outline-rounded";

export function useSitemap() {
	const router = useRouter();
	const routes = router
		.getRoutes()
		.filter(
			(route) =>
				!route.path.includes(":") &&
				route.path !== "/" &&
				!["/login", "/signup", "/profile/setup", "/settings"].includes(
					route.path,
				),
		)
		.map((route) => {
			const title = route.path.split("/").pop() || "";
			const formattedTitle = title
				? title
						.split("-")
						.map((word) => word.charAt(0).toUpperCase() + word.slice(1))
						.join(" ")
				: "Home";
			return {
				id: route.path,
				title: formattedTitle === "" ? "Home" : formattedTitle,
				icon: MaterialSymbolsFindInPageOutlineRounded,
				path: route.path,
			};
		});

	const navigateTo = (command: Command) => {
		if (command.action) {
			command.action();
		} else if (command.path) {
			router.push(command.path);
		}
	};

	return {
		pages: routes,
		navigateTo,
	};
}
