import { useCalendarStore } from "~/stores/calendar";
import type { CalendarDate, CalendarHour } from "~/types/calendar";

export function useCalendar() {
	const store = useCalendarStore();

	const days = [
		"Sunday",
		"Monday",
		"Tuesday",
		"Wednesday",
		"Thursday",
		"Friday",
		"Saturday",
	];

	const months = [
		"January",
		"February",
		"March",
		"April",
		"May",
		"June",
		"July",
		"August",
		"September",
		"October",
		"November",
		"December",
	];

	const hrs = [
		...Array(24)
			.fill(0)
			.map((_, i) => `${i.toString().padStart(2, "0")}:00`),
	];

	const currentMonth = computed(() => months[store.currentMonth]);
	const currentYear = computed(() => store.currentYear);
	const currentHour = computed(() => store.currentHour);
	const currentDay = computed(() => store.currentDay);

	const dates = computed<CalendarDate[]>(() => {
		return getMonthDates(store.currentDate);
	});

	const hours = computed<CalendarHour[]>(() => {
		return hrs.map((time) => {
			const isCurrentHour =
				time === `${store.currentHour.toString().padStart(2, "0")}:00`;
			const isSelected = store.selectedDate
				? time ===
					`${store.selectedDate.getHours().toString().padStart(2, "0")}:00`
				: false;

			return { time, isCurrentHour, isSelected };
		});
	});

	return {
		currentDate: computed(() => store.currentDate),
		selectedDate: computed(() => store.selectedDate),
		view: computed(() => store.view),
		days,
		hours,
		months,
		currentHour,
		currentMonth,
		currentYear,
		currentDay,
		navigate: store.navigate,
		dates,
		setCurrentDate: store.setCurrentDate,
		setSelectedDate: store.setSelectedDate,
		setView: store.setView,
	};
}
