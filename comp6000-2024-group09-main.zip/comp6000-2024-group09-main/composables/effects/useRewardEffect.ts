import confetti from "canvas-confetti";

export function useRewardEffect() {
	const playRewardEffect = (x: number, y: number) => {
		const normalizedX = x / window.innerWidth;
		const normalizedY = y / window.innerHeight;

		const primaryColors = [
			"#FFD700",
			"#FFA500",
			"#FF8C00",
			"#FF4500",
			"#FFC0CB",
		];
		const secondaryColors = [
			"#87CEEB",
			"#4169E1",
			"#1E90FF",
			"#00BFFF",
			"#7B68EE",
		];
		const accentColors = [
			"#32CD32",
			"#98FB98",
			"#00FA9A",
			"#FF69B4",
			"#DDA0DD",
		];

		confetti({
			particleCount: 75,
			spread: 70,
			startVelocity: 45,
			decay: 0.95,
			gravity: 1.2,
			ticks: 250,
			origin: { x: normalizedX, y: normalizedY },
			colors: primaryColors,
			scalar: 1.2,
			shapes: ["star", "square"],
			drift: 1,
			angle: 90,
		});

		setTimeout(() => {
			confetti({
				particleCount: 50,
				spread: 55,
				startVelocity: 35,
				decay: 0.94,
				gravity: 1,
				ticks: 200,
				origin: { x: normalizedX, y: normalizedY },
				colors: secondaryColors,
				scalar: 1,
				shapes: ["circle"],
				drift: 0.5,
				angle: 120,
			});
		}, 150);

		setTimeout(() => {
			confetti({
				particleCount: 35,
				spread: 45,
				startVelocity: 30,
				decay: 0.92,
				gravity: 0.8,
				ticks: 180,
				origin: { x: normalizedX, y: normalizedY },
				colors: accentColors,
				scalar: 0.8,
				shapes: ["star"],
				drift: 0.3,
				angle: 60,
			});
		}, 250);

		setTimeout(() => {
			confetti({
				particleCount: 25,
				spread: 360,
				startVelocity: 25,
				decay: 0.91,
				gravity: 0.7,
				ticks: 150,
				origin: { x: normalizedX, y: normalizedY },
				colors: [...primaryColors, ...secondaryColors],
				scalar: 0.7,
				shapes: ["circle", "square"],
				drift: 0.2,
			});
		}, 350);
	};

	const playExplosiveEffect = (x: number, y: number) => {
		const normalizedX = x / window.innerWidth;
		const normalizedY = y / window.innerHeight;

		const explosiveColors = [
			"#FF0000",
			"#FFD700",
			"#FF8C00",
			"#FF4500",
			"#FF1493",
		];

		const angleStep = 45;
		for (let angle = 0; angle < 360; angle += angleStep) {
			confetti({
				particleCount: 15,
				angle,
				spread: 30,
				origin: { x: normalizedX, y: normalizedY },
				colors: explosiveColors,
				startVelocity: 45,
				gravity: 1,
				drift: 0.2,
				ticks: 300,
				scalar: 1.2,
				shapes: ["star"],
			});
		}
	};

	const playRainEffect = () => {
		const duration = 2000;
		const end = Date.now() + duration;

		const rainInterval = setInterval(() => {
			if (Date.now() > end) {
				return clearInterval(rainInterval);
			}

			confetti({
				particleCount: 2,
				angle: 270,
				spread: 25,
				origin: { x: Math.random(), y: -0.1 },
				colors: ["#1E90FF", "#00BFFF", "#87CEEB"],
				gravity: 0.8,
				drift: 1,
				ticks: 300,
				scalar: 1,
				shapes: ["circle"],
			});
		}, 50);
	};

	const playRandomEffect = () => {
		const x = Math.random() * window.innerWidth;
		const y = Math.random() * window.innerHeight;
		const effects = [playRewardEffect, playExplosiveEffect];
		const randomEffect = effects[Math.floor(Math.random() * effects.length)];
		randomEffect(x, y);
	};

	const playCenterEffect = () => {
		playRewardEffect(window.innerWidth / 2, window.innerHeight / 2);
		setTimeout(() => {
			playExplosiveEffect(window.innerWidth / 2, window.innerHeight / 2);
		}, 500);
	};

	const playMouseEffect = (event: MouseEvent) => {
		playRewardEffect(event.clientX, event.clientY);
	};

	return {
		playRewardEffect,
		playExplosiveEffect,
		playRainEffect,
		playRandomEffect,
		playCenterEffect,
		playMouseEffect,
	};
}
