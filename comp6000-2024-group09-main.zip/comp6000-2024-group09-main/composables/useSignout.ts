import { getAuth } from "firebase/auth";

export const useSignout = () => {
	return async () => {
		try {
			const auth = getAuth();
			await auth.signOut();
			return navigateTo("/login");
		} catch (error) {
			console.error("Signout error:", error);
			throw error;
		}
	};
};
