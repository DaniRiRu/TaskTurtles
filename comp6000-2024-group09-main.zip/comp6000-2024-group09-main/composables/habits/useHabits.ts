import type {
	HabitCompleteResponse,
	HabitGetResponse,
	HabitUpdateResponse,
	HabitsCreateResponse,
	HabitsGetResponse,
} from "~/types/backend/habits/response";
import type {
	HabitCompletion,
	HabitData,
	HabitFilter,
	HabitSort,
} from "~/types/habits/habits";

export function useHabits() {
	const backend = useBackend();
	const habits = ref<HabitData[]>([]);
	const loading = ref(false);
	const error = ref<string | null>(null);
	const cache = ref<Map<string, { data: HabitData; timestamp: number }>>(
		new Map(),
	);
	const CACHE_DURATION = 5 * 60 * 1000;

	const clearCache = () => {
		cache.value.clear();
	};

	const isCacheValid = (timestamp: number) => {
		return Date.now() - timestamp < CACHE_DURATION;
	};

	const updateLocalHabit = (
		habitId: string,
		updatedData: Partial<HabitData>,
	) => {
		const index = habits.value.findIndex((h) => h.id === habitId);
		if (index !== -1) {
			habits.value[index] = { ...habits.value[index], ...updatedData };
			cache.value.set(habitId, {
				data: habits.value[index],
				timestamp: Date.now(),
			});
		}
	};

	const fetchHabits = async (filter?: HabitFilter, sort?: HabitSort) => {
		loading.value = true;
		error.value = null;
		try {
			const response = (await backend.habits.getAll()) as HabitsGetResponse;
			habits.value = response;
			response.map((habit) => {
				cache.value.set(habit.id, {
					data: habit,
					timestamp: Date.now(),
				});
			});
			return habits.value;
		} catch (e) {
			error.value = e instanceof Error ? e.message : "Failed to fetch habits";
			return [];
		} finally {
			loading.value = false;
		}
	};

	const createHabit = async (habitData: Partial<HabitData>) => {
		const tempId = `temp-${Date.now()}`;
		const tempHabit = {
			...habitData,
			id: tempId,
			createdAt: new Date().toISOString(),
			updatedAt: new Date().toISOString(),
		} as HabitData;

		habits.value.push(tempHabit);

		try {
			const response = (await backend.habits.create(
				habitData,
			)) as HabitsCreateResponse;
			const index = habits.value.findIndex((h) => h.id === tempId);
			if (index !== -1) {
				habits.value[index] = response;
			}
			cache.value.set(response.id, {
				data: response,
				timestamp: Date.now(),
			});
			return response;
		} catch (e) {
			habits.value = habits.value.filter((h) => h.id !== tempId);
			error.value = e instanceof Error ? e.message : "Failed to create habit";
			return null;
		}
	};

	const updateHabit = async (
		habitId: string,
		habitData: Partial<HabitData>,
	) => {
		const originalHabit = { ...habits.value.find((h) => h.id === habitId) };
		updateLocalHabit(habitId, habitData);

		try {
			const response = (await backend.habits.update(
				habitId,
				habitData,
			)) as HabitUpdateResponse;
			updateLocalHabit(habitId, response.habitData);
			return response.habitData;
		} catch (e) {
			if (originalHabit) {
				updateLocalHabit(habitId, originalHabit);
			}
			error.value = e instanceof Error ? e.message : "Failed to update habit";
			return null;
		}
	};

	const deleteHabit = async (habitId: string) => {
		const originalHabits = [...habits.value];
		habits.value = habits.value.filter((h) => h.id !== habitId);
		cache.value.delete(habitId);

		try {
			await backend.habits.delete(habitId);
			return true;
		} catch (e) {
			habits.value = originalHabits;
			error.value = e instanceof Error ? e.message : "Failed to delete habit";
			return false;
		}
	};

	const getStreak = (completions: HabitCompletion[]) => {
		if (completions.length === 0) return 0;

		const sortedCompletions = [...completions].sort(
			(a, b) =>
				new Date(a.completedAt).getTime() - new Date(b.completedAt).getTime(),
		);

		let currentStreak = 1;
		let maxStreak = 1;
		let previousDate = new Date(sortedCompletions[0].completedAt);
		previousDate.setHours(0, 0, 0, 0);

		for (let i = 1; i < sortedCompletions.length; i++) {
			const currentDate = new Date(sortedCompletions[i].completedAt);
			currentDate.setHours(0, 0, 0, 0);

			const timeDiff = currentDate.getTime() - previousDate.getTime();
			const daysDiff = timeDiff / (1000 * 3600 * 24);

			if (daysDiff <= 1) {
				if (daysDiff === 1) {
					currentStreak++;
				}
			} else {
				maxStreak = Math.max(maxStreak, currentStreak);
				currentStreak = 1;
			}

			if (daysDiff > 0) {
				previousDate = currentDate;
			}
		}

		return Math.max(maxStreak, currentStreak);
	};

	const completeHabit = async (
		habitId: string,
		data: { note?: string; mood?: string },
	) => {
		const originalHabit = { ...habits.value.find((h) => h.id === habitId) };
		const streak = getStreak(originalHabit.completionHistory || []);

		const optimisticUpdate = {
			...originalHabit,
			lastCompleted: new Date().toISOString(),
			streak: streak + 1,
		};
		updateLocalHabit(habitId, optimisticUpdate);

		try {
			const response = (await backend.habits.complete(
				habitId,
				data,
			)) as HabitCompleteResponse;
			updateLocalHabit(habitId, response.habitData);
			return response;
		} catch (e) {
			if (originalHabit) {
				updateLocalHabit(habitId, originalHabit);
			}
			error.value = e instanceof Error ? e.message : "Failed to complete habit";
			return null;
		}
	};

	const getHabit = async (habitId: string) => {
		const cachedHabit = cache.value.get(habitId);
		if (cachedHabit && isCacheValid(cachedHabit.timestamp)) {
			return cachedHabit.data;
		}

		loading.value = true;
		error.value = null;
		try {
			const response = (await backend.habits.get(habitId)) as HabitGetResponse;
			cache.value.set(habitId, {
				data: response.habitData,
				timestamp: Date.now(),
			});
			return response.habitData;
		} catch (e) {
			error.value = e instanceof Error ? e.message : "Failed to fetch habit";
			return null;
		} finally {
			loading.value = false;
		}
	};

	watch(
		() => habits.value,
		() => {
			habits.value.map((habit) => {
				cache.value.set(habit.id, {
					data: habit,
					timestamp: Date.now(),
				});
			});
		},
	);

	onMounted(fetchHabits);

	return {
		habits,
		loading,
		error,
		getStreak,
		fetchHabits,
		createHabit,
		updateHabit,
		deleteHabit,
		completeHabit,
		getHabit,
		clearCache,
	};
}
