import type { FormField } from "~/types/frontend/settings";

export const useAccountFields = () => {
	const formFields: FormField[] = [
		{
			label: "Full Name",
			key: "name",
			type: "text",
			placeholder: "Full Name",
		},
		{
			label: "Gender",
			key: "gender",
			type: "select",
			placeholder: "Select Gender",
		},
		{
			label: "Date of Birth",
			key: "dob",
			type: "date",
			placeholder: "Date of Birth",
		},
		{
			label: "Mobile Number",
			key: "mobileNumber",
			type: "tel",
			placeholder: "+1234567890",
		},
		{
			label: "Occupation",
			key: "occupation",
			type: "text",
			placeholder: "Occupation",
		},
		{
			label: "Weekly Hours",
			key: "weeklyHours",
			type: "number",
			placeholder: "Weekly Hours (0-168)",
		},
	];

	return {
		formFields,
	};
};
