import type { StoredUser } from "~/types/core/user";
import { UserDataRequest } from "~/types/schemas/user";

export const useAccountForm = (
	accountStore: ReturnType<typeof useAccountStore>,
) => {
	const formData = ref<Partial<StoredUser>>({
		name: accountStore.data?.name || "",
		gender: accountStore.data?.gender || "",
		dob: accountStore.data?.dob || new Date(),
		occupation: accountStore.data?.occupation || "",
		weeklyHours: accountStore.data?.weeklyHours || 0,
	});

	const formErrors = ref<Record<string, string>>({});
	const touchedFields = ref<Set<string>>(new Set());
	const editedFields = ref<Set<string>>(new Set());
	const hasUnsavedChanges = ref(false);
	const isSaving = ref(false);
	const showSaveSuccess = ref(false);
	const isValid = ref(true);

	const validateForm = () => {
		try {
			const changedData = {} as Record<string, StoredUser[keyof StoredUser]>;
			for (const [key, value] of Object.entries(formData.value)) {
				if (
					JSON.stringify(value) !==
					JSON.stringify(accountStore.data?.[key as keyof StoredUser])
				) {
					changedData[key] = value;
				}
			}

			if (Object.keys(changedData).length === 0) {
				formErrors.value = {};
				isValid.value = true;
				return true;
			}

			const result = UserDataRequest.safeParse({
				user: changedData,
			});

			if (!result.success) {
				formErrors.value = {};
				for (const error of result.error.errors) {
					const field = error.path[1] as string;
					if (field) {
						formErrors.value[field] = error.message;
					}
				}
				isValid.value = false;
				return false;
			}

			formErrors.value = {};
			isValid.value = true;
			return true;
		} catch (error) {
			console.error("Validation error:", error);
			isValid.value = false;
			return false;
		}
	};

	const resetData = () => {
		formData.value = { ...accountStore.data } as Partial<StoredUser>;
		hasUnsavedChanges.value = false;
		formErrors.value = {};
		touchedFields.value.clear();
		editedFields.value.clear();
		validateForm();
	};

	watch(
		formData,
		() => {
			validateForm();
			hasUnsavedChanges.value =
				JSON.stringify(formData.value) !== JSON.stringify(accountStore.data);
		},
		{ deep: true },
	);

	return {
		formData,
		formErrors,
		touchedFields,
		editedFields,
		hasUnsavedChanges,
		isSaving,
		showSaveSuccess,
		isValid,
		validateForm,
		resetData,
	};
};
