import { isTauri } from "@tauri-apps/api/core";
import type { Auth, AuthProvider, UserCredential } from "firebase/auth";
import {
	signInWithCredential,
	signInWithPopup,
	signInWithRedirect,
} from "firebase/auth";

export async function signIn(auth: Auth, provider: AuthProvider) {
	let response: UserCredential;

	if (isTauri()) {
		const credential = await signInWithRedirect(auth, provider);
		response = await signInWithCredential(auth, credential);
	} else {
		response = await signInWithPopup(auth, provider);
	}

	if (response.user) navigateTo("/dashboard");
}
