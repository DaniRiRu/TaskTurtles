import {
	EmailAuthProvider,
	GoogleAuthProvider,
	getRedirectResult,
	reauthenticateWithCredential,
	reauthenticateWithRedirect,
} from "firebase/auth";
import type { StoredUser } from "~/types/core/user";

export const useAccountActions = () => {
	const backend = useBackend();
	const router = useRouter();
	const signout = useSignout();
	const accountStore = useAccountStore();
	const user = useCurrentUser();

	const confirmPassword = ref("");
	const passwordError = ref("");
	const isProcessing = ref(false);

	const checkReauthRedirectResult = async () => {
		const auth = useFirebaseAuth();
		if (!auth) return false;

		try {
			const result = await getRedirectResult(auth);
			if (result) {
				passwordError.value = "";
				return true;
			}
			return false;
		} catch (error) {
			passwordError.value = "Reauthentication failed";
			return false;
		} finally {
			isProcessing.value = false;
		}
	};

	const verifyPassword = async () => {
		if (!user.value) return false;

		try {
			isProcessing.value = true;

			const authProvider = user.value?.providerData[0]?.providerId || "";

			if (authProvider === "password") {
				if (!confirmPassword.value) {
					passwordError.value = "Password is required";
					return false;
				}

				const credential = EmailAuthProvider.credential(
					user.value.email || "",
					confirmPassword.value,
				);
				await reauthenticateWithCredential(user.value, credential);
			} else if (authProvider === "google.com") {
				const googleProvider = new GoogleAuthProvider();
				await reauthenticateWithRedirect(user.value, googleProvider);
				return true;
			} else {
				passwordError.value = "Unsupported authentication provider";
				return false;
			}

			passwordError.value = "";
			return true;
		} catch (error) {
			passwordError.value = "Reauthentication failed";
			return false;
		} finally {
			isProcessing.value = false;
		}
	};

	const saveChanges = async (
		formData: Partial<StoredUser>,
		validateForm: () => boolean,
		isSaving: Ref<boolean>,
		showSaveSuccess: Ref<boolean>,
		hasUnsavedChanges: Ref<boolean>,
		editedFields: Ref<Set<string>>,
	) => {
		if (!validateForm()) return;

		isSaving.value = true;
		try {
			const changedData = {} as Record<string, StoredUser[keyof StoredUser]>;
			for (const [key, value] of Object.entries(formData)) {
				if (
					JSON.stringify(value) !==
					JSON.stringify(accountStore.data?.[key as keyof StoredUser])
				) {
					changedData[key] = value;
				}
			}

			await backend.account.update(changedData);
			await accountStore.fetchAccountData();
			hasUnsavedChanges.value = false;
			editedFields.value.clear();
			showSaveSuccess.value = true;
			setTimeout(() => {
				showSaveSuccess.value = false;
			}, 2000);
		} catch (error) {
			console.error("Failed to save changes:", error);
		} finally {
			isSaving.value = false;
		}
	};

	const deleteAccount = async () => {
		if (!(await verifyPassword())) return;

		try {
			isProcessing.value = true;
			await backend.account.delete();
			await signout();
			router.push("/");
		} catch (error) {
			console.error("Failed to delete account:", error);
			passwordError.value = "Failed to delete account";
		} finally {
			isProcessing.value = false;
			confirmPassword.value = "";
		}
	};

	return {
		confirmPassword,
		passwordError,
		isProcessing,
		verifyPassword,
		checkReauthRedirectResult,
		saveChanges,
		deleteAccount,
	};
};
