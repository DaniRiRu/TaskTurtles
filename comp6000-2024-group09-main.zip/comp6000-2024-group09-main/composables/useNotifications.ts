type NotificationType = "success" | "error" | "warning" | "info";

interface NotificationState {
	type: NotificationType;
	message: string;
	visible: boolean;
}

export const useNotification = () => {
	const notification = useState<NotificationState>("notification", () => ({
		type: "info",
		message: "",
		visible: false,
	}));

	const showNotification = (type: NotificationType, message: string) => {
		notification.value = {
			type,
			message,
			visible: true,
		};

		setTimeout(() => {
			notification.value.visible = false;
		}, 5000);
	};

	return {
		notification,
		showNotification,
	};
};
