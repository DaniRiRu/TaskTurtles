import { ref } from "vue";
import { useCurrentUser } from "vuefire";
import { AiContexts } from "~/types/ai-service/contexts";
import { InsufficientTokenError } from "~/types/backend/ai-service/errors";
import type { GenerateResponse } from "~/types/backend/ai-service/requests";
import type {
	AiSuggestion,
	AiSuggestionPrompt,
} from "~/types/skills/suggestions";

export const useAiSuggestion = () => {
	const user = useCurrentUser();
	const isGenerating = ref(false);
	const error = ref<string | null>(null);
	const backend = useBackend();

	const generateSuggestion = async (
		title?: string,
	): Promise<AiSuggestion | Error> => {
		if (!user.value?.uid) {
			error.value = "User must be logged in";
			return new Error("User must be logged in");
		}

		isGenerating.value = true;
		error.value = null;

		try {
			const suggestion = (await backend.skilltrees.suggestions.recommend(
				title,
			)) as AiSuggestionPrompt;

			if (!suggestion) {
				isGenerating.value = false;
				error.value = "Failed to generate suggestion: No suggestion found";
				throw new Error("Failed to generate suggestion: No suggestion found");
			}

			const userPrompt = JSON.stringify({
				skill_name: suggestion.name,
				skill_description: suggestion.description,
			});

			const response = (await backend.ai.generate({
				message: userPrompt,
				context: AiContexts.SUGGESTIONS,
			})) as GenerateResponse;

			const data = response.text;

			if (!data) {
				isGenerating.value = false;
				error.value = "Failed to generate suggestion";
				throw new Error("Failed to generate suggestion");
			}

			const parsedData = JSON.parse(data);

			if (!parsedData) {
				isGenerating.value = false;
				error.value = "Failed to generate suggestion";
				throw new Error("Failed to generate suggestion");
			}

			const name = title ? title : parsedData.name;
			const objectives = parsedData.objectives;

			if (!name || !objectives) {
				isGenerating.value = false;
				error.value = "Failed to generate suggestion";
				throw new Error("Failed to generate suggestion");
			}

			const aiSuggestion: AiSuggestion = {
				name,
				objectives,
			};

			isGenerating.value = false;

			return aiSuggestion;
		} catch (e) {
			if (e instanceof InsufficientTokenError) {
				error.value = e.message;
				throw createError(new InsufficientTokenError());
			}
			if (e instanceof Error) {
				error.value = e.message;
				throw createError({
					statusCode: 500,
					message: e.message,
				});
			}
			error.value = "Failed to generate suggestion";
			throw createError({
				statusCode: 500,
				message: "Failed to generate suggestion",
			});
		} finally {
			isGenerating.value = false;
		}
	};

	return {
		generateSuggestion,
		isGenerating,
		error,
	};
};
