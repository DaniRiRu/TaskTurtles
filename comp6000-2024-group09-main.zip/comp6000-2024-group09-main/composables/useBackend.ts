import { TTBackend } from "~/api";

export const useBackend = () => {
	return new TTBackend();
};
