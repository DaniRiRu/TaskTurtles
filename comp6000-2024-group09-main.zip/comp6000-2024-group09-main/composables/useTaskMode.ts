import type { DocumentData } from "firebase/firestore";
import { ref, watch } from "vue";

export function useTaskMode(
	task: Ref<DocumentData | null>,
	isAddMode: Ref<boolean>,
) {
	const viewMode = ref<"view" | "edit" | "add">("view");
	const persistedTask = ref<DocumentData | null>(null);

	watch(
		() => task.value,
		(newTask) => {
			if (newTask) {
				persistedTask.value = newTask;
				viewMode.value = "view";
			}
		},
		{ immediate: true },
	);

	watch(
		() => isAddMode.value,
		(newMode) => {
			if (newMode) {
				viewMode.value = "add";
			}
		},
		{ immediate: true },
	);

	function resetState() {
		persistedTask.value = null;
		viewMode.value = "view";
	}

	const switchMode = (mode: "view" | "edit" | "add") => {
		if (viewMode.value !== mode) {
			viewMode.value = mode;
		}
	};

	return {
		switchMode,
		viewMode,
		persistedTask,
		resetState,
	};
}
