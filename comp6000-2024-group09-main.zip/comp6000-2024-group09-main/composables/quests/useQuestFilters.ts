import type { QuestFilters } from "~/types/quests/quests";

export const useQuestFilters = () => {
	const filters = ref<QuestFilters>({
		searchQuery: "",
		category: "",
		difficulty: null,
	});

	const filterQuests = <
		T extends { title: string; category: string; difficulty: string },
	>(
		quests: T[],
	) => {
		return quests.filter((quest) => {
			const matchesSearch = quest.title
				.toLowerCase()
				.includes(filters.value.searchQuery.toLowerCase());
			const matchesCategory =
				!filters.value.category || quest.category === filters.value.category;
			const matchesDifficulty =
				!filters.value.difficulty ||
				quest.difficulty === filters.value.difficulty;
			return matchesSearch && matchesCategory && matchesDifficulty;
		});
	};

	return {
		filters,
		filterQuests,
	};
};
