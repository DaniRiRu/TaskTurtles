export const useQuestPagination = (itemsPerPage: number) => {
	const page = ref(1);

	const getPaginatedItems = <T>(items: T[]) => {
		const start = (page.value - 1) * itemsPerPage;
		const end = start + itemsPerPage;
		return items.slice(start, end);
	};

	const getTotalPages = (totalItems: number) => {
		return Math.ceil(totalItems / itemsPerPage);
	};

	const setPage = (newPage: number) => {
		page.value = newPage;
	};

	return {
		page,
		getPaginatedItems,
		getTotalPages,
		setPage,
	};
};
