export const useQuestCarousel = <T>(
	initialItems: T[],
	cardsPerPage: number,
) => {
	const currentIndex = ref(0);
	const items = ref<T[]>(initialItems);

	const getDisplayedItems = () => {
		const totalItems = items.value.length;
		const totalPages = Math.ceil(totalItems / cardsPerPage);
		const lastPageItems = totalItems % cardsPerPage;

		console.log(totalItems, totalPages, lastPageItems);

		if (
			currentIndex.value === (totalPages - 1) * cardsPerPage &&
			lastPageItems > 0
		) {
			return items.value.slice(-lastPageItems);
		}

		const currItems = items.value.slice(
			currentIndex.value,
			Math.min(currentIndex.value + cardsPerPage, totalItems),
		);

		return currItems;
	};

	const canGoPrevious = computed(() => currentIndex.value > 0);

	const canGoNext = computed(() => {
		const nextPageStart = currentIndex.value + cardsPerPage;
		return nextPageStart < items.value.length;
	});

	const next = () => {
		if (canGoNext.value) {
			const totalItems = items.value.length;
			const remainingItems = totalItems - (currentIndex.value + cardsPerPage);

			if (remainingItems < cardsPerPage) {
				currentIndex.value = totalItems - remainingItems;
			} else {
				currentIndex.value += cardsPerPage;
			}
		}
	};

	const previous = () => {
		if (canGoPrevious.value) {
			currentIndex.value = Math.max(0, currentIndex.value - cardsPerPage);
		}
	};

	const totalPages = computed(() =>
		Math.ceil(items.value.length / cardsPerPage),
	);

	const currentPage = computed(
		() => Math.floor(currentIndex.value / cardsPerPage) + 1,
	);

	return {
		currentIndex,
		items,
		getDisplayedItems,
		canGoPrevious,
		canGoNext,
		next,
		previous,
		totalPages,
		currentPage,
	};
};
