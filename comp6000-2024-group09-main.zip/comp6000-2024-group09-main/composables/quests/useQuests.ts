import type { Quest, QuestDocument } from "~/types/quests/quests";

export const useQuests = () => {
	const backend = useBackend();
	const quests = ref<Quest[]>([]);
	const loading = ref(true);
	const error = ref<string | null>(null);
	const pendingOperations = ref(new Set<string>());
	const questDocument = ref<QuestDocument | null>(null);

	const loadQuests = async () => {
		try {
			loading.value = true;
			error.value = null;
			const response = (await backend.quests.retrieveQuests()) as QuestDocument;
			questDocument.value = response;
			quests.value = response.quests;
		} catch (err) {
			error.value = "Failed to load quests";
			console.error("Error loading quests:", err);
		} finally {
			loading.value = false;
		}
	};

	const activeQuests = computed(() => {
		return quests.value.filter((quest) => quest.isActive && !quest.completed);
	});

	const completedQuests = computed(() => {
		return quests.value.filter((quest) => quest.completed);
	});

	const activeIncompletedQuests = computed(() => {
		return quests.value.filter((quest) => quest.isActive && !quest.completed);
	});

	const isPending = (questId: number, operation: string) => {
		return pendingOperations.value.has(`${questId}-${operation}`);
	};

	const addPendingOperation = (questId: number, operation: string) => {
		pendingOperations.value.add(`${questId}-${operation}`);
	};

	const removePendingOperation = (questId: number, operation: string) => {
		pendingOperations.value.delete(`${questId}-${operation}`);
	};

	const saveQuests = async () => {
		try {
			await backend.quests.saveQuests(quests.value);
		} catch (err) {
			console.error("Error saving quests:", err);
			throw new Error("Failed to save quests");
		}
	};

	const toggleQuestActive = async (questId: number) => {
		if (isPending(questId, "toggle")) return;

		const quest = quests.value.find((q) => q.id === questId);
		if (!quest) return;

		const previousState = quest.isActive;
		quest.isActive = !quest.isActive;

		addPendingOperation(questId, "toggle");
		try {
			await backend.quests.toggleQuest(questId);
			await saveQuests();
		} catch (err) {
			quest.isActive = previousState;
			console.error("Error toggling quest:", err);
		} finally {
			removePendingOperation(questId, "toggle");
		}
	};

	const updateProgress = async (questId: number, newProgress: number) => {
		if (isPending(questId, "progress")) return;

		const quest = quests.value.find((q) => q.id === questId);
		if (!quest) return;

		const previousProgress = quest.progress.current;
		const clampedProgress = Math.min(Math.max(0, newProgress), 100);
		quest.progress.current = clampedProgress;

		addPendingOperation(questId, "progress");
		try {
			await backend.quests.updateProgress(questId, clampedProgress);
			await saveQuests();
		} catch (err) {
			quest.progress.current = previousProgress;
			console.error("Error updating progress:", err);
		} finally {
			removePendingOperation(questId, "progress");
		}
	};

	const completeQuest = async (questId: number) => {
		if (isPending(questId, "complete")) return;

		const quest = quests.value.find((q) => q.id === questId);
		if (!quest) return;

		const previousState = {
			completed: quest.completed,
			isActive: quest.isActive,
			progress: quest.progress.current,
		};

		quest.completed = true;
		quest.isActive = false;
		quest.progress.current = quest.progress.max;

		addPendingOperation(questId, "complete");
		try {
			await backend.quests.completeQuest(questId);
			await saveQuests();
		} catch (err) {
			quest.completed = previousState.completed;
			quest.isActive = previousState.isActive;
			quest.progress.current = previousState.progress;
			console.error("Error completing quest:", err);
		} finally {
			removePendingOperation(questId, "complete");
		}
	};

	const getFeaturedQuests = computed(() => {
		return quests.value
			.filter(
				(quest) =>
					(quest.difficulty === "medium" || quest.difficulty === "hard") &&
					!quest.completed,
			)
			.slice(0, 3);
	});

	const getQuestsByCategory = (category: string) => {
		return computed(() =>
			quests.value.filter(
				(quest) => quest.category === category && !quest.completed,
			),
		);
	};

	const getQuestsByDifficulty = (difficulty: string) => {
		return computed(() =>
			quests.value.filter(
				(quest) => quest.difficulty === difficulty && !quest.completed,
			),
		);
	};

	const getQuestProgress = (questId: number) => {
		const quest = quests.value.find((q) => q.id === questId);
		if (quest) {
			return (quest.progress.current / quest.progress.max) * 100;
		}
		return 0;
	};

	const getAvailableQuests = computed(() => {
		return quests.value.filter((quest) => !quest.isActive && !quest.completed);
	});

	const getCompletionStats = computed(() => {
		const total = quests.value.length;
		const completed = completedQuests.value.length;
		const active = activeQuests.value.length;
		const available = getAvailableQuests.value.length;

		return {
			total,
			completed,
			active,
			available,
			completionRate: total > 0 ? (completed / total) * 100 : 0,
		};
	});

	const resetQuestProgress = async (questId: number) => {
		if (isPending(questId, "reset")) return;

		const quest = quests.value.find((q) => q.id === questId);
		if (!quest) return;

		const previousState = {
			progress: quest.progress.current,
			completed: quest.completed,
		};

		quest.progress.current = 0;
		quest.completed = false;

		addPendingOperation(questId, "reset");
		try {
			await updateProgress(questId, 0);
			await saveQuests();
		} catch (err) {
			quest.progress.current = previousState.progress;
			quest.completed = previousState.completed;
			console.error("Error resetting quest progress:", err);
		} finally {
			removePendingOperation(questId, "reset");
		}
	};

	const archiveCompletedQuests = async () => {
		if (pendingOperations.value.has("archive")) return;

		const completedQuestsIds = completedQuests.value.map((q) => q.id);
		const previousQuests = [...quests.value];

		quests.value = quests.value.filter((q) => !q.completed);

		addPendingOperation(0, "archive");
		try {
			await backend.quests.archiveQuests(completedQuestsIds);
			await saveQuests();
		} catch (err) {
			quests.value = previousQuests;
			console.error("Error archiving completed quests:", err);
		} finally {
			removePendingOperation(0, "archive");
		}
	};

	onMounted(() => {
		loadQuests();
	});

	return {
		quests,
		questDocument,
		loading,
		error,
		activeQuests,
		completedQuests,
		activeIncompletedQuests,
		toggleQuestActive,
		updateProgress,
		completeQuest,
		getFeaturedQuests,
		getQuestsByCategory,
		getQuestsByDifficulty,
		getQuestProgress,
		getAvailableQuests,
		getCompletionStats,
		resetQuestProgress,
		archiveCompletedQuests,
		loadQuests,
		isPending,
	};
};
