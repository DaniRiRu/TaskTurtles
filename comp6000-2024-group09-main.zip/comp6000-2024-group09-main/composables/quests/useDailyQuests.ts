import type { QuestDocument } from "~/types/quests/quests";
import { useQuests } from "./useQuests";

export const useDailyQuests = () => {
	const { loadQuests } = useQuests();
	const backend = useBackend();
	const timeRemaining = ref(0);
	const isRefreshing = ref(false);
	const router = useRouter();

	const calculateTimeRemaining = (nextRefresh: string) => {
		const now = new Date().getTime();
		const refreshTime = new Date(nextRefresh).getTime();
		return Math.max(0, refreshTime - now);
	};

	const updateTimeRemaining = (nextRefresh: string) => {
		timeRemaining.value = calculateTimeRemaining(nextRefresh);

		if (timeRemaining.value > 0) {
			setTimeout(() => {
				updateTimeRemaining(nextRefresh);
			}, 1000);
		} else {
			handleRefresh();
		}
	};

	const handleRefresh = async () => {
		if (isRefreshing.value) return;

		try {
			isRefreshing.value = true;
			await refreshDailyQuests();
			await router.go(0);
		} catch (error) {
			console.error("Failed to refresh daily quests:", error);
		} finally {
			isRefreshing.value = false;
		}
	};

	const refreshDailyQuests = async () => {
		try {
			await backend.quests.refreshDaily();
			await loadQuests();

			const questDocument =
				(await backend.quests.retrieveQuests()) as QuestDocument;

			if (questDocument.nextDailyRefresh) {
				updateTimeRemaining(questDocument.nextDailyRefresh);
			}
		} catch (error) {
			console.error("Failed to refresh daily quests:", error);
		}
	};

	const formatTimeRemaining = computed(() => {
		const hours = Math.floor(timeRemaining.value / (1000 * 60 * 60));
		const minutes = Math.floor(
			(timeRemaining.value % (1000 * 60 * 60)) / (1000 * 60),
		);
		const seconds = Math.floor((timeRemaining.value % (1000 * 60)) / 1000);

		return {
			hours: hours.toString().padStart(2, "0"),
			minutes: minutes.toString().padStart(2, "0"),
			seconds: seconds.toString().padStart(2, "0"),
		};
	});

	onMounted(async () => {
		const questDocument =
			(await backend.quests.retrieveQuests()) as QuestDocument;
		if (questDocument.nextDailyRefresh) {
			updateTimeRemaining(questDocument.nextDailyRefresh);
		}
	});

	return {
		timeRemaining,
		formatTimeRemaining,
		refreshDailyQuests,
		isRefreshing,
	};
};
