import { AiContexts } from "~/types/ai-service/contexts";
import type { Message } from "~/types/chat";

export const useChat = () => {
	const messages = useState<Message[]>("chat-messages", () => []);
	const newMessage = ref("");
	const chatContainer = ref<HTMLElement | null>(null);
	const currentStreamingMessage = ref("");
	const backend = useBackend();

	const chatState = useState("chat-state", () => ({
		isLoading: false,
		isBotTyping: false,
		isResetting: false,
	}));

	const resetChat = async () => {
		if (chatState.value.isResetting || chatState.value.isBotTyping) return;

		try {
			chatState.value.isResetting = true;

			messages.value = [];
			newMessage.value = "";
			chatState.value.isLoading = false;
			chatState.value.isBotTyping = false;
			currentStreamingMessage.value = "";
		} catch (error) {
			console.error("Failed to reset chat:", error);
		} finally {
			chatState.value.isResetting = false;
		}
	};

	const detectAndCreateEmbeds = (content: string): Message["embeds"] => {
		if (!content) return undefined;

		const urlRegex = /https?:\/\/[^\s]+/g;
		const matches = content.matchAll(urlRegex);

		const embeds = Array.from(matches, (match) => ({
			type: match[0].match(/youtube\.com|youtu\.be/)
				? ("video" as const)
				: ("url" as const),
			url: match[0],
		}));

		return embeds.length ? embeds : undefined;
	};

	const appendMessage = (message: Partial<Message>) => {
		messages.value.push({
			content: "",
			isUser: false,
			timestamp: new Date(),
			isTyping: false,
			embeds: undefined,
			...message,
		});
	};

	const updateLatestMessage = (content: string) => {
		if (messages.value.length === 0) return;
		const lastMessage = messages.value[messages.value.length - 1];
		lastMessage.content = content;
		lastMessage.embeds = detectAndCreateEmbeds(content);
	};

	const sendMessage = async (content: string) => {
		if (
			!content.trim() ||
			chatState.value.isLoading ||
			chatState.value.isBotTyping
		)
			return;

		try {
			chatState.value.isLoading = true;
			currentStreamingMessage.value = "";

			appendMessage({
				content,
				isUser: true,
				embeds: detectAndCreateEmbeds(content),
			});

			appendMessage({
				content: "",
				isUser: false,
				isTyping: true,
			});

			chatState.value.isBotTyping = true;

			const abortController = new AbortController();

			const cleanup = () => {
				abortController.abort();
				chatState.value.isLoading = false;
				chatState.value.isBotTyping = false;
				if (messages.value.length > 0) {
					messages.value[messages.value.length - 1].isTyping = false;
				}
				currentStreamingMessage.value = "";
			};

			onBeforeUnmount(() => {
				cleanup();
			});

			await backend.ai.streamGenerate(
				{
					message: content,
					context: AiContexts.GENERAL,
					stream: true,
				},
				(chunk) => {
					if (abortController.signal.aborted) return;

					if (chunk.text) {
						currentStreamingMessage.value += chunk.text;
						updateLatestMessage(currentStreamingMessage.value);
					}

					if (chunk.error) {
						currentStreamingMessage.value += chunk.error;
						updateLatestMessage(chunk.error);
					}
				},
				() => {
					chatState.value.isLoading = false;
					chatState.value.isBotTyping = false;
					if (messages.value.length > 0) {
						messages.value[messages.value.length - 1].isTyping = false;
					}
				},
			);
		} catch (error) {
			console.error("Failed to send message:", error);
			messages.value.pop(); // Remove the bot's message if there was an error

			// Add error message
			appendMessage({
				content: "I'm sorry, I encountered an error. Please try again later.",
				isUser: false,
			});

			throw new Error("Failed to send message");
		} finally {
			chatState.value.isLoading = false;
			chatState.value.isBotTyping = false;
			if (messages.value.length > 0) {
				messages.value[messages.value.length - 1].isTyping = false;
			}
			currentStreamingMessage.value = "";
		}
	};

	const isProcessing = computed(
		() =>
			chatState.value.isLoading ||
			chatState.value.isBotTyping ||
			chatState.value.isResetting,
	);

	return {
		messages,
		newMessage,
		chatContainer,
		sendMessage,
		resetChat,
		isLoading: computed(() => chatState.value.isLoading),
		isBotTyping: computed(() => chatState.value.isBotTyping),
		isResetting: computed(() => chatState.value.isResetting),
		isProcessing,
	};
};
