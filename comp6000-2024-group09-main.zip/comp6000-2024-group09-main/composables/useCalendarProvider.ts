// composables/useCalendarProvider.ts
import { GoogleAuthProvider, signInWithPopup } from "firebase/auth";
import type {
	CalendarConnectionResponse,
	CalendarEventsResponse,
	CalendarProvider,
} from "~/types/backend/calendar/response";
import type { AnyCalendarEvent } from "~/types/calendar/events";

interface CalendarUserInfo {
	email: string | null;
	displayName: string | null;
	photoURL: string | null;
}

export const useCalendarProvider = (provider: CalendarProvider = "google") => {
	const config = useRuntimeConfig();
	const auth = useFirebaseAuth();
	const backend = useBackend();
	const calendarConnected = ref(false);
	const isLoading = ref(false);
	const error = ref<string | null>(null);
	const success = ref<string | null>(null);
	const accessToken = ref<string | null>(null);
	const lastSync = ref<Date | null>(null);
	const retryCount = ref(0);

	const SCOPES = [
		"https://www.googleapis.com/auth/calendar.readonly",
		"https://www.googleapis.com/auth/calendar.events.readonly",
		"https://www.googleapis.com/auth/calendar",
	];

	const cookieOptions = {
		maxAge: 3600,
		secure: process.env.NODE_ENV === "production",
	};

	const delay = (ms: number) =>
		new Promise((resolve) => setTimeout(resolve, ms));

	const checkConnection = async () => {
		try {
			if (isLoading.value) return false;

			isLoading.value = true;
			error.value = null;

			const response =
				await backend.calendar[provider].connection.getConnection();
			if (!response || typeof response !== "object") {
				calendarConnected.value = false;
				lastSync.value = null;
				return false;
			}

			const typedResponse = response as CalendarConnectionResponse;
			calendarConnected.value = typedResponse.isConnected || false;
			lastSync.value = typedResponse.lastSync
				? new Date(typedResponse.lastSync)
				: null;

			return calendarConnected.value;
		} catch (err) {
			if (err instanceof Error && err.message.includes("429")) {
				if (retryCount.value < 3) {
					retryCount.value++;
					await delay(1000 * retryCount.value);
					return checkConnection();
				}
			}
			console.error("[checkConnection] Error:", err);
			error.value = getErrorMessage(err);
			calendarConnected.value = false;
			lastSync.value = null;
			return false;
		} finally {
			isLoading.value = false;
		}
	};

	const updateConnection = async (connected: boolean, tokenOrUrl?: string) => {
		try {
			if (isLoading.value) return false;

			isLoading.value = true;
			error.value = null;

			if (connected) {
				const response =
					await backend.calendar[provider].connection.updateConnection(
						tokenOrUrl,
					);
				if (response && typeof response === "object") {
					const typedResponse = response as CalendarConnectionResponse;
					calendarConnected.value = typedResponse.isConnected;
					lastSync.value = typedResponse.lastSync
						? new Date(typedResponse.lastSync)
						: null;
				}
			} else {
				await backend.calendar[provider].connection.deleteConnection();
				calendarConnected.value = false;
				lastSync.value = null;
			}

			return calendarConnected.value;
		} catch (err) {
			if (err instanceof Error && err.message.includes("429")) {
				if (retryCount.value < 3) {
					retryCount.value++;
					await delay(1000 * retryCount.value);
					return updateConnection(connected, tokenOrUrl);
				}
			}
			console.error("[updateConnection] Error:", err);
			error.value = getErrorMessage(err);
			return false;
		} finally {
			isLoading.value = false;
		}
	};

	const connectCalendar = async (): Promise<boolean> => {
		if (isLoading.value) return false;

		isLoading.value = true;
		error.value = null;

		try {
			if (provider === "google") {
				const googleProvider = new GoogleAuthProvider();

				for (const scope of SCOPES) {
					googleProvider.addScope(scope);
				}

				googleProvider.setCustomParameters({
					prompt: "consent",
					client_id: config.public.vuefire.config.google.clientId as string,
				});

				if (!auth) {
					throw new Error("Firebase auth instance is not initialized");
				}

				const result = await signInWithPopup(auth, googleProvider);
				const credential = GoogleAuthProvider.credentialFromResult(result);

				if (!credential?.accessToken) {
					throw new Error("No access token received");
				}

				const userInfo: CalendarUserInfo = {
					email: result.user.email,
					displayName: result.user.displayName,
					photoURL: result.user.photoURL,
				};

				const tokenCookie = useCookie(
					`${provider}-calendar-token`,
					cookieOptions,
				);
				const userCookie = useCookie(
					`${provider}-calendar-user`,
					cookieOptions,
				);

				tokenCookie.value = credential.accessToken;
				userCookie.value = JSON.stringify(userInfo);
				accessToken.value = credential.accessToken;

				const connected = await updateConnection(true, credential.accessToken);
				if (connected) {
					success.value = `Successfully connected to ${provider} Calendar`;
				}
				return connected;
			}

			return false;
		} catch (err) {
			console.error("[connectCalendar] Error:", err);
			error.value = getErrorMessage(err);
			return false;
		} finally {
			isLoading.value = false;
		}
	};

	const fetchCalendarEvents = async (
		timeMin: Date,
		timeMax: Date,
	): Promise<AnyCalendarEvent[]> => {
		try {
			if (isLoading.value) return [];

			isLoading.value = true;
			error.value = null;

			const events = (await backend.calendar[provider].events.getEvents(
				timeMin,
				timeMax,
			)) as CalendarEventsResponse;
			return events?.events || [];
		} catch (err) {
			if (err instanceof Error && err.message.includes("429")) {
				if (retryCount.value < 3) {
					retryCount.value++;
					await delay(1000 * retryCount.value);
					return fetchCalendarEvents(timeMin, timeMax);
				}
			}
			console.error("[fetchCalendarEvents] Error:", err);
			error.value = getErrorMessage(err);
			return [];
		} finally {
			isLoading.value = false;
		}
	};

	const getCalendarEvents = async (
		timeMin: Date,
		timeMax: Date,
	): Promise<AnyCalendarEvent[]> => {
		try {
			if (isLoading.value) return [];

			isLoading.value = true;
			error.value = null;

			const isConnected = await checkConnection();
			if (!isConnected) {
				const connected = await connectCalendar();
				if (!connected) {
					throw new Error("Failed to connect to calendar");
				}
			}

			return await fetchCalendarEvents(timeMin, timeMax);
		} catch (err) {
			console.error("[getCalendarEvents] Error:", err);
			error.value = getErrorMessage(err);
			return [];
		} finally {
			isLoading.value = false;
		}
	};

	const disconnect = async () => {
		try {
			if (isLoading.value) return;

			isLoading.value = true;
			error.value = null;
			success.value = null;

			const tokenCookie = useCookie(
				`${provider}-calendar-token`,
				cookieOptions,
			);
			const userCookie = useCookie(`${provider}-calendar-user`, cookieOptions);

			tokenCookie.value = null;
			userCookie.value = null;
			accessToken.value = null;

			await updateConnection(false);
			success.value = `Successfully disconnected from ${provider} Calendar`;
		} catch (err) {
			console.error("[disconnect] Error:", err);
			error.value = getErrorMessage(err);
		} finally {
			isLoading.value = false;
		}
	};

	const getUserInfo = (): CalendarUserInfo | null => {
		try {
			const userCookie = useCookie(`${provider}-calendar-user`);
			if (!userCookie.value) return null;
			return JSON.parse(userCookie.value as string);
		} catch {
			return null;
		}
	};

	const refreshConnection = async () => {
		try {
			if (isLoading.value) return;

			isLoading.value = true;
			error.value = null;

			const tokenCookie = useCookie(`${provider}-calendar-token`);
			if (tokenCookie.value) {
				accessToken.value = tokenCookie.value;
				await checkConnection();
			}
		} catch (err) {
			console.error("[refreshConnection] Error:", err);
			error.value = getErrorMessage(err);
		} finally {
			isLoading.value = false;
		}
	};

	const getErrorMessage = (error: unknown): string => {
		if (error instanceof Error) {
			if (error.message.includes("429")) {
				return "Too many requests. Please try again later.";
			}
			if (error.message.includes("403")) {
				return "Calendar API access denied. Please check API permissions.";
			}
			if (error.message.includes("401")) {
				return "Session expired. Please reconnect to Calendar.";
			}
			return error.message;
		}
		return "An unknown error occurred";
	};

	onMounted(async () => {
		await refreshConnection();
	});

	watch(calendarConnected, (newValue) => {
		if (!newValue) {
			lastSync.value = null;
		}
	});

	return {
		calendarConnected: computed(() => calendarConnected.value),
		isLoading: computed(() => isLoading.value),
		error: computed(() => error.value),
		success: computed(() => success.value),
		lastSync: computed(() => lastSync.value),
		connectCalendar,
		getCalendarEvents,
		disconnect,
		refreshConnection,
		getUserInfo,
		checkConnection,
	};
};

export type CalendarProviderService = ReturnType<typeof useCalendarProvider>;
