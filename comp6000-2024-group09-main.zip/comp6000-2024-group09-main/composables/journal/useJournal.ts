import { computed, ref } from "vue";

export default function useJournal() {
	const selectedDate = ref(new Date());
	const showInsights = ref(false);
	const currentDate = ref(new Date());
	const dateDisplays = ref<
		Array<{
			date: Date;
			day: string;
			dateNum: number;
			isToday: boolean;
		}>
	>([]);

	const generateDays = (baseDate: Date) => {
		const result = [];
		const range = 15;

		for (let i = -range; i <= range; i++) {
			const date = new Date(baseDate);
			date.setDate(baseDate.getDate() + i);
			result.push({
				date: new Date(date),
				day: date.toLocaleDateString("en-US", { weekday: "short" }),
				dateNum: date.getDate(),
				isToday: i === 0,
			});
		}

		return result;
	};

	const initializeDays = () => {
		dateDisplays.value = generateDays(currentDate.value);
	};

	const isDateInFuture = (date: Date): boolean => {
		const now = new Date();
		now.setHours(0, 0, 0, 0);

		const compareDate = new Date(date);
		compareDate.setHours(0, 0, 0, 0);

		return compareDate > now;
	};

	const selectDate = (date: Date) => {
		const selectable = !isDateInFuture(date);
		if (selectable) {
			selectedDate.value = date;
		}
		currentDate.value = new Date(date);
		dateDisplays.value = generateDays(date);
	};

	const navigateLeft = () => {
		const newDate = new Date(currentDate.value);
		newDate.setDate(newDate.getDate() - 1);

		if (isDateInFuture(newDate)) {
			return;
		}

		dateDisplays.value = generateDays(newDate);
		selectDate(newDate);
	};

	const navigateRight = () => {
		const newDate = new Date(currentDate.value);
		newDate.setDate(newDate.getDate() + 1);

		if (isDateInFuture(newDate)) {
			return;
		}

		dateDisplays.value = generateDays(newDate);
		selectDate(newDate);
	};

	const toggleInsights = () => {
		showInsights.value = !showInsights.value;
	};

	const saveJournalEntry = () => {
		alert("Journal entry saved!");
	};

	const visibleCount = ref(5);

	const updateVisibleCount = () => {
		switch (true) {
			case window.innerWidth < 768:
				visibleCount.value = 5;
				break;
			case window.innerWidth < 1024:
				visibleCount.value = 7;
				break;
			case window.innerWidth < 1280:
				visibleCount.value = 9;
				break;
			case window.innerWidth < 1536:
				visibleCount.value = 12;
				break;
			default:
				visibleCount.value = 15;
				break;
		}
	};

	const days = computed(() => dateDisplays.value);

	const visibleDays = computed(() => {
		const halfVisible = Math.floor(visibleCount.value / 2);
		const centerIndex = days.value.findIndex(
			(day) => day.date.toDateString() === currentDate.value.toDateString(),
		);

		const start = Math.max(0, centerIndex - halfVisible);
		const end = Math.min(days.value.length, start + visibleCount.value);

		return days.value.slice(start, end);
	});

	const formattedDate = computed(() => {
		return selectedDate.value.toLocaleDateString("en-US", {
			weekday: "long",
			month: "long",
			day: "numeric",
			year: "numeric",
		});
	});

	return {
		selectedDate,
		showInsights,
		currentDate,
		dateDisplays,
		days,
		visibleDays,
		visibleCount,
		formattedDate,
		initializeDays,
		selectDate,
		navigateLeft,
		navigateRight,
		isDateInFuture,
		toggleInsights,
		saveJournalEntry,
		updateVisibleCount,
	};
}
