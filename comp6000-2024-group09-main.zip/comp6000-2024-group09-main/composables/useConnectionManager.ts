import { breakpointsTailwind, useBreakpoints } from "@vueuse/core";
import type { Skill } from "~/types/skills/skill";

const breakpoints = useBreakpoints(breakpointsTailwind);
const mobileMode = breakpoints.smaller("md");

export const useConnectionManager = (containerRef: Ref<HTMLElement | null>) => {
	const connections = ref<
		{ path: string; isUnlocked: boolean; level: number }[]
	>([]);
	const nodeRefs = ref<Map<string, HTMLElement>>(new Map());
	const svgViewBox = ref("0 0 1000 1000");
	let updateQueued = false;

	const getSkillDepth = (
		skill: Skill,
		skills: Skill[],
		visited = new Set<string>(),
	): number => {
		if (!skill.id || visited.has(skill.id)) return 0;
		visited.add(skill.id);
		if (skill.prerequisites.length === 0) return 0;
		return Math.max(
			...skill.prerequisites.map((prereqId) => {
				const prereq = skills.find((s) => s.id === prereqId);
				return prereq ? getSkillDepth(prereq, skills, visited) + 1 : 0;
			}),
		);
	};

	const createDesktopPath = (
		start: { x: number; y: number },
		end: { x: number; y: number },
		nodeHeight: number,
	) => {
		const midY = start.y + (end.y - start.y) / 2;
		return `
      M ${start.x} ${start.y}
      V ${midY}
      H ${end.x}
      V ${end.y}
    `;
	};

	const createMobilePath = (
		start: { x: number; y: number },
		end: { x: number; y: number },
		nodeWidth: number,
	) => {
		const spacing = nodeWidth / 2 + 20;
		return `
      M ${start.x} ${start.y}
      H ${start.x + spacing}
      V ${end.y}
      H ${end.x}
    `;
	};

	const updateConnections = (
		skills: Skill[],
		isSkillCompleted: (skill: Skill) => boolean,
	) => {
		if (!containerRef.value || nodeRefs.value.size === 0) return;

		const containerRect = containerRef.value.getBoundingClientRect();
		const newConnections: {
			path: string;
			isUnlocked: boolean;
			level: number;
		}[] = [];
		const skillMap = new Map(skills.map((skill) => [skill.id, skill]));
		const depthMap = new Map<string, number>();

		for (const skill of skills) {
			if (skill.id) {
				depthMap.set(skill.id, getSkillDepth(skill, skills));
			}
		}

		const connectionData: {
			from: string;
			to: string;
			fromDepth: number;
			toDepth: number;
		}[] = [];

		for (const skill of skills) {
			if (!skill.id || !skill.prerequisites?.length) continue;
			const skillDepth = depthMap.get(skill.id) || 0;

			for (const prereqId of skill.prerequisites) {
				const prereqDepth = depthMap.get(prereqId) || 0;
				if (skillDepth === prereqDepth) continue;

				connectionData.push({
					from: prereqId,
					to: skill.id,
					fromDepth: prereqDepth,
					toDepth: skillDepth,
				});
			}
		}

		connectionData.sort(
			(a, b) => b.toDepth - b.fromDepth - (a.toDepth - a.fromDepth),
		);

		for (const connection of connectionData) {
			const skillNode = nodeRefs.value.get(connection.to);
			const prereqNode = nodeRefs.value.get(connection.from);

			if (!skillNode || !prereqNode) continue;

			const skillRect = skillNode.getBoundingClientRect();
			const prereqRect = prereqNode.getBoundingClientRect();

			const skillCenter = {
				x: skillRect.left + skillRect.width / 2 - containerRect.left,
				y: skillRect.top + skillRect.height / 2 - containerRect.top,
			};

			const prereqCenter = {
				x: prereqRect.left + prereqRect.width / 2 - containerRect.left,
				y: prereqRect.top + prereqRect.height / 2 - containerRect.top,
			};

			const path = mobileMode.value
				? createMobilePath(prereqCenter, skillCenter, skillRect.width)
				: createDesktopPath(prereqCenter, skillCenter, skillRect.height);

			const prereq = skillMap.get(connection.from);
			const isUnlocked = prereq ? isSkillCompleted(prereq) : false;
			const level = connection.fromDepth;

			newConnections.push({ path, isUnlocked, level });
		}

		connections.value = newConnections;
		svgViewBox.value = `0 0 ${containerRect.width} ${containerRect.height}`;
	};

	const queueConnectionUpdate = (
		skills: Skill[],
		isSkillCompleted: (skill: Skill) => boolean,
	) => {
		if (!updateQueued) {
			updateQueued = true;
			requestAnimationFrame(() => {
				updateConnections(skills, isSkillCompleted);
				updateQueued = false;
			});
		}
	};

	const updateNodeRef = (el: HTMLElement | null, skillId: string) => {
		if (el) {
			nodeRefs.value.set(skillId, el);
		} else {
			nodeRefs.value.delete(skillId);
		}
	};

	watch(
		() => connections.value,
		() => {
			if (containerRef.value) {
				const rect = containerRef.value.getBoundingClientRect();
				svgViewBox.value = `0 0 ${rect.width} ${rect.height}`;
			}
		},
		{ deep: true },
	);

	onMounted(() => {
		const resizeObserver = new ResizeObserver(() => {
			if (containerRef.value) {
				const rect = containerRef.value.getBoundingClientRect();
				svgViewBox.value = `0 0 ${rect.width} ${rect.height}`;
				queueConnectionUpdate([], () => false);
			}
		});

		if (containerRef.value) {
			resizeObserver.observe(containerRef.value);
		}

		onUnmounted(() => {
			resizeObserver.disconnect();
			nodeRefs.value.clear();
		});
	});

	return {
		connections,
		svgViewBox,
		updateNodeRef,
		queueConnectionUpdate,
	};
};
