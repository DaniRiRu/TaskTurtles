import { ref } from "vue";
import CalendarImage from "~/assets/images/hero/calendar.webp";
import DashboardImage from "~/assets/images/hero/dashboard.webp";
import TasksImage from "~/assets/images/hero/tasks.webp";
import type {
	FAQ,
	Feature,
	HowItWorksStep,
	Page,
	PricingPlan,
} from "~/types/frontend/index";

export function useFeatures() {
	const features: Feature[] = [
		{
			title1: "Visualize Your",
			title2: "Progress",
			description:
				"Get a bird's eye view of your productivity with intuitive dashboards that show your daily, weekly, and monthly achievements.",
			pageIndex: 0,
		},
		{
			title1: "Track Your",
			title2: "Metrics",
			description:
				"Monitor your key performance indicators and watch your progress grow through beautiful, interactive charts.",
			pageIndex: 0,
		},
		{
			title1: "Organize Your",
			title2: "Tasks",
			description:
				"Efficiently manage your tasks with smart categorization, priority levels, and automated scheduling.",
			pageIndex: 1,
		},
		{
			title1: "Boost Your",
			title2: "Productivity",
			description:
				"Let our AI-powered system suggest the best times for different types of tasks based on your peak performance hours.",
			pageIndex: 1,
		},
		{
			title1: "Supercharge Your",
			title2: "Calendar",
			description:
				"Transform your schedule into productivity powerhouse. Seamlessly blend tasks, goals, and events in an intelligent calendar.",
			pageIndex: 2,
		},
		{
			title1: "Smart",
			title2: "Scheduling",
			description:
				"Experience intelligent time blocking and automated schedule optimization that adapts to your working style.",
			pageIndex: 2,
		},
	];

	const currentIndex = ref(0);

	return {
		features,
		currentIndex,
	};
}

export function usePages() {
	const pages: Page[] = [
		{
			url: "http://localhost:3000/dashboard",
			image: DashboardImage,
			title: "Dashboard",
		},
		{
			url: "http://localhost:3000/tasks",
			image: TasksImage,
			title: "Tasks",
		},
		{
			url: "http://localhost:3000/calendar",
			image: CalendarImage,
			title: "Calendar",
		},
	];

	return { pages };
}

export function useHowItWorks() {
	const steps: HowItWorksStep[] = [
		{
			number: "01",
			title: "Create Your Account",
			description:
				"Sign up in seconds and customise your workspace to match your style.",
		},
		{
			number: "02",
			title: "Set Your Goals",
			description:
				"Define your objectives and watch them transform into achievable milestones.",
		},
		{
			number: "03",
			title: "Track Progress",
			description:
				"Monitor your journey with intuitive visualizations and real-time updates.",
		},
	];

	return { steps };
}

export function usePricing() {
	const plans: PricingPlan[] = [
		{
			name: "Starter",
			price: 0,
			features: [
				{ included: true, text: "Basic Calendar" },
				{ included: true, text: "Simple Tasks" },
				{ included: true, text: "Limited Skill Trees" },
			],
			popular: false,
		},
		{
			name: "Pro",
			price: 9.99,
			features: [
				{ included: true, text: "Advanced Calendar" },
				{ included: true, text: "Unlimited Tasks" },
				{ included: true, text: "Full Skill Trees" },
				{ included: true, text: "Priority Support" },
			],
			popular: true,
		},
		{
			name: "Team",
			price: 29.99,
			features: [
				{ included: true, text: "Everything in Pro" },
				{ included: true, text: "Team Collaboration" },
				{ included: true, text: "Admin Controls" },
				{ included: true, text: "API Access" },
			],
			popular: false,
		},
	];

	return { plans };
}

export function useFAQs() {
	const faqs: FAQ[] = [
		{
			question: "How does the Skill Tree system work?",
			answer:
				"Our Skill Tree system helps you visualize and track your progress in different areas. As you complete tasks and achieve goals, you'll unlock new branches and levels.",
		},
		{
			question: "Can I switch plans at any time?",
			answer:
				"Yes, you can upgrade or downgrade your plan at any time. Your new plan will take effect immediately, and you'll be charged or credited the difference in price.",
		},
		{
			question: "Is my data secure and private?",
			answer:
				"Yes, we take data security and privacy very seriously. All data is encrypted, and we follow strict security protocols to protect your information.",
		},
		{
			question: "What kind of support do you offer?",
			answer:
				"We provide 24/7 email support for all users, with priority support for Pro and Team plan subscribers. Our knowledge base is also available for self-service support.",
		},
	];

	return { faqs };
}

export function useAllData() {
	const { features, currentIndex } = useFeatures();
	const { pages } = usePages();
	const { steps } = useHowItWorks();
	const { plans } = usePricing();
	const { faqs } = useFAQs();

	return {
		features,
		currentIndex,
		pages,
		steps,
		plans,
		faqs,
	};
}
