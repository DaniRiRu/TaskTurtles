import type { NavigationItem } from "~/types/onboarding";

export function useNavigation() {
	const navigation: NavigationItem[] = [
		{
			name: "Features",
			path: "#features",
		},
		{
			name: "How it Works",
			path: "#how-it-works",
		},
		{
			name: "Pricing",
			path: "#pricing",
		},
		{
			name: "FAQ",
			path: "#faq",
		},
	];

	const isActiveRoute = (path: string) => {
		const route = useRoute();
		return route.path.startsWith(path);
	};

	return {
		navigation,
		isActiveRoute,
	};
}
