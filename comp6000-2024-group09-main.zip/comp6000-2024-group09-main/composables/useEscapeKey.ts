export function useEscapeKey(callback: () => void) {
	const escapeListener = (e: KeyboardEvent) => {
		if (e.key === "Escape") {
			e.preventDefault();
			callback();
		}
	};

	onMounted(() => {
		window.addEventListener("keydown", escapeListener);
	});

	onUnmounted(() => {
		window.removeEventListener("keydown", escapeListener);
	});
}
