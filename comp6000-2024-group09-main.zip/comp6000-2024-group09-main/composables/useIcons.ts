import MdiTurtle from "~icons/mdi/turtle";

export const useIcons = () => {
	const iconMap = {
		"mdi-turtle": MdiTurtle,
	};

	return {
		iconMap,
	};
};
