import { ref } from "vue";

export const useCalendarSelection = () => {
	const selectedDate = ref<Date | null>(null);

	const selectDate = (date: Date) => {
		selectedDate.value = date;
	};

	return {
		selectedDate,
		selectDate,
	};
};
