import { useSessionStorage } from "@vueuse/core";
import type { CalendarEventsResponse } from "~/types/backend/calendar/response";
import type { AnyCalendarEvent } from "~/types/calendar/events";

export const useCalendarEvents = () => {
	const events = useSessionStorage<AnyCalendarEvent[]>("calendar-events", []);
	const lastFetch = useSessionStorage<number | null>(
		"calendar-last-fetch",
		null,
	);
	const backend = useBackend();

	const isStale = computed(() => {
		if (!lastFetch.value) return true;
		const now = Date.now();
		const fiveMinutes = 5 * 60 * 1000;
		return now - lastFetch.value > fiveMinutes;
	});

	const providers = ["google", "outlook", "ical", "custom"] as const;

	const fetchAllEvents = async () => {
		const events =
			(await backend.calendar.global.getEvents()) as CalendarEventsResponse;

		return events?.events || [];
	};

	const fetchEventsFromProvider = async (
		provider: (typeof providers)[number],
	) => {
		const start = new Date();
		start.setHours(0, 0, 0, 0);

		const end = new Date(start);
		end.setDate(end.getDate() + 30);

		try {
			const response = (await backend.calendar[provider].events.getEvents(
				start,
				end,
			)) as CalendarEventsResponse;
			return response?.events || [];
		} catch (error) {
			console.error(`Failed to fetch events from ${provider}:`, error);
			return [];
		}
	};

	const refreshEvents = async (force = false) => {
		if (!force && !isStale.value) {
			return events.value;
		}

		const allEvents: AnyCalendarEvent[] = await fetchAllEvents();

		// await Promise.all(
		// 	providers.map(async (provider) => {
		// 		const providerEvents = await fetchEventsFromProvider(provider);
		// 		allEvents.push(...providerEvents);
		// 	}),
		// );

		events.value = allEvents.sort((a, b) => {
			const dateA = new Date(a.start.dateTime || a.start.date || "");
			const dateB = new Date(b.start.dateTime || b.start.date || "");
			return dateA.getTime() - dateB.getTime();
		});

		lastFetch.value = Date.now();
		return events.value;
	};

	const clearCache = () => {
		events.value = [];
		lastFetch.value = null;
	};

	return {
		events,
		lastFetch,
		isStale,
		refreshEvents,
		clearCache,
	};
};
