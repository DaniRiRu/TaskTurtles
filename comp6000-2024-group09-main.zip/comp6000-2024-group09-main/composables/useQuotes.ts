export const useQuotes = () => {
	const quotes = [
		{
			quote: "Focus on being productive instead of busy.",
			author: "Tim Ferriss",
		},
		{
			quote: "Your mind is for having ideas, not holding them.",
			author: "David Allen",
		},
		{
			quote: "Do the hard jobs first. Easy jobs will take care of themselves.",
			author: "Dale Carnegie",
		},
		{
			quote: "Schedule your priorities, don't prioritize your schedule.",
			author: "Stephen Covey",
		},
		{
			quote: "Stop being busy. Start being productive.",
			author: "Robin Sharma",
		},
	];

	const getDailyQuote = () => {
		const today = new Date();
		const dayOfYear = Math.floor(
			(today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) /
				(1000 * 60 * 60 * 24),
		);
		const quoteIndex = dayOfYear % quotes.length;

		return {
			quote: quotes[quoteIndex].quote,
			author: quotes[quoteIndex].author,
			index: quoteIndex,
			formattedDate: today.toLocaleDateString("en-US", {
				month: "long",
				day: "numeric",
				year: "numeric",
			}),
		};
	};

	return {
		getDailyQuote,
	};
};
