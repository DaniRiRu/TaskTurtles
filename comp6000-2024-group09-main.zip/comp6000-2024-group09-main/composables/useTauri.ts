import { isTauri } from "@tauri-apps/api/core";

export const useTauri = () => {
	return computed(() => {
		try {
			if (import.meta.client) {
				return isTauri();
			}
		} catch {}

		return false;
	});
};
