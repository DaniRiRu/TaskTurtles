import type { Skill, SkillTreeData } from "~/types/skills/skill";

export const useSkillMetrics = () => {
	const getSkillCount = (tree: SkillTreeData) => {
		const skills = Object.values(tree.skills);

		const masteredSkills = skills.filter((skill) => {
			return skill.tasks?.every((task) => task.completed) ?? false;
		});

		const availableSkills = skills.filter((skill) => skill.revealed);

		const lockedSkills = skills.filter((skill) => !skill.revealed);

		return {
			mastered: masteredSkills.length,
			available: availableSkills.length,
			locked: lockedSkills.length,
		};
	};

	const getMasteryLevel = (completed: number): string => {
		if (completed >= 100) return "Grand Master";
		if (completed >= 75) return "Master";
		if (completed >= 50) return "Expert";
		if (completed >= 25) return "Adept";
		return "Beginner";
	};

	const calculateMasteryPercentage = (tree: SkillTreeData): number => {
		const skills = Object.values(tree.skills);
		if (skills.length === 0) return 0;

		const completedTasksCount = skills.reduce((acc, skill) => {
			const completedTasks =
				skill.tasks?.filter((task) => task.completed).length ?? 0;
			return acc + completedTasks;
		}, 0);

		const totalTasksCount = skills.reduce((acc, skill) => {
			return acc + (skill.tasks?.length ?? 0);
		}, 0);

		if (totalTasksCount === 0) return 0;
		return Math.round((completedTasksCount / totalTasksCount) * 100);
	};

	const getSkillProgress = (skill: Skill): number => {
		if (!skill.tasks || skill.tasks.length === 0) return 0;

		const completedTasks = skill.tasks.filter((task) => task.completed).length;
		return Math.round((completedTasks / skill.tasks.length) * 100);
	};

	const getTreeProgress = (tree: SkillTreeData): number => {
		const skills = Object.values(tree.skills);
		if (skills.length === 0) return 0;

		const totalProgress = skills.reduce((acc, skill) => {
			return acc + getSkillProgress(skill);
		}, 0);

		return Math.round(totalProgress / skills.length);
	};

	const getDifficultyDistribution = (tree: SkillTreeData) => {
		const skills = Object.values(tree.skills);
		const distribution = {
			1: 0,
			2: 0,
			3: 0,
			4: 0,
			5: 0,
		};

		for (const skill of skills) {
			if (!skill.tasks) continue;
			for (const task of skill.tasks) {
				distribution[task.difficulty as keyof typeof distribution]++;
			}
		}

		return distribution;
	};

	return {
		getSkillCount,
		getMasteryLevel,
		calculateMasteryPercentage,
		getSkillProgress,
		getTreeProgress,
		getDifficultyDistribution,
	};
};
