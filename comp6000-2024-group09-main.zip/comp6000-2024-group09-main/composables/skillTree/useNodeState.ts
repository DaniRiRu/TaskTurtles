import type { Skill } from "~/types/skills/skill";
import type { NodeState } from "~/types/skills/state";

export function useNodeState(
	skill: Skill,
	initialState: Partial<NodeState> = {},
) {
	const state = reactive<NodeState>({
		isAvailable: true,
		isUnlocked: false,
		isHovered: false,
		isCompleted: skill.tasks?.every((task) => task.completed) ?? false,
		...initialState,
	});

	const updateCompletionState = () => {
		state.isCompleted = skill.tasks?.every((task) => task.completed) ?? false;
	};

	return {
		state,
		updateCompletionState,
	};
}
