import { useSessionStorage } from "@vueuse/core";
import {
	collection,
	doc,
	getDocs,
	onSnapshot,
	query,
	updateDoc,
	where,
} from "firebase/firestore";
import { useFirestore } from "vuefire";
import type { Skill, SkillTreeData } from "~/types/skills/skill";

export const useSkillTrees = () => {
	const db = useFirestore();
	const trees = reactive<Record<string, SkillTreeData>>({});
	const cache = useSessionStorage<Record<string, SkillTreeData>>(
		"skillTrees",
		{},
	);
	const loadingState = reactive<Record<string, boolean>>({});
	const unsubscribes = new Map<string, () => void>();
	const pendingUpdates = new Map<string, Promise<void>>();

	const isLoading = computed(() => Object.values(loadingState).some((v) => v));
	const backend = useBackend();

	const user = useCurrentUser();

	const setLoadingState = (treeName: string | null, loading: boolean) => {
		if (treeName) {
			loadingState[treeName] = loading;
		} else {
			for (const key of Object.keys(loadingState)) {
				loadingState[key] = loading;
			}
		}
	};

	const getTreeIdByName = (treeName: string): string | undefined => {
		const tree = Object.entries(trees).find(
			([_, tree]) => tree.name === treeName,
		);
		return tree ? tree[0] : undefined;
	};

	const getTreeByName = (treeName: string) => {
		const existingTree = Object.values(trees).find(
			(tree) => tree.name === treeName,
		);
		if (!existingTree) {
			loadTreeByName(treeName);
		}
		return existingTree;
	};

	const setupTreeListener = async (treeId: string) => {
		if (!user.value) return;

		if (unsubscribes.has(treeId)) {
			unsubscribes.get(treeId)?.();
		}

		const treeRef = doc(db, "skillTrees", treeId);
		const unsubscribe = onSnapshot(treeRef, (snapshot) => {
			if (snapshot.exists()) {
				const treeData = snapshot.data() as SkillTreeData;
				if (treeData.userId === user.value?.uid) {
					trees[treeId] = treeData;
					cache.value[treeId] = treeData;
				}
			}
		});

		unsubscribes.set(treeId, unsubscribe);
	};

	const loadTrees = async () => {
		if (!user) return;

		setLoadingState(null, true);

		try {
			const treesCollection = collection(db, "skillTrees");
			const userTreesQuery = query(
				treesCollection,
				where("userId", "==", user.value?.uid),
			);

			const snapshot = await getDocs(userTreesQuery);

			for (const treeDoc of snapshot.docs) {
				trees[treeDoc.id] = treeDoc.data() as SkillTreeData;
				cache.value[treeDoc.id] = treeDoc.data() as SkillTreeData;
				await setupTreeListener(treeDoc.id);
			}
		} finally {
			setLoadingState(null, false);
		}
	};

	const loadTreeByName = async (treeName: string) => {
		if (!user) return;

		setLoadingState(treeName, true);

		try {
			const treeData = (await backend.skilltrees.data.getTreeFromName(
				treeName,
			)) as SkillTreeData;

			const id = treeData.id;

			if (treeData) {
				trees[id] = treeData;
				cache.value[id] = treeData;
				await setupTreeListener(id);
			}
		} catch (error) {
			console.error("Error updating tree details:", error);
			throw error;
		}
	};

	const getAllSkills = computed(() => {
		return Object.values(trees).flatMap((tree) => Object.values(tree.skills));
	});

	const getSkillsByTree = (treeName: string): Skill[] => {
		const tree = Object.values(trees).find((t) => t.name === treeName);
		return Object.values(tree?.skills || {});
	};

	const findSkillById = (
		treeName: string,
		skillId: string,
	): Skill | undefined => {
		const tree = Object.values(trees).find((t) => t.name === treeName);
		return tree?.skills[skillId];
	};

	const getPrerequisiteSkills = (
		treeName: string,
		skillId: string,
	): Skill[] => {
		const skill = findSkillById(treeName, skillId);
		if (!skill) return [];
		const tree = Object.values(trees).find((t) => t.name === treeName);
		if (!tree) return [];
		return skill.prerequisites
			.map((prereqId) => tree.skills[prereqId])
			.filter(Boolean);
	};

	const isSkillCompleted = (skill: Skill): boolean => {
		if (!skill.tasks?.length) return false;
		return skill.tasks.every((task) => task.completed);
	};

	const updateLocalTask = (
		treeName: string,
		skillId: string,
		taskId: string,
		completed: boolean,
	) => {
		const treeId = getTreeIdByName(treeName);
		if (!treeId || !trees[treeId]) return;

		const tree = trees[treeId];
		const skill = tree.skills[skillId];
		if (!skill?.tasks) return;

		const updatedTasks = skill.tasks.map((t) =>
			t.id === taskId ? { ...t, completed } : t,
		);

		trees[treeId] = {
			...tree,
			skills: {
				...tree.skills,
				[skillId]: {
					...skill,
					tasks: updatedTasks,
				},
			},
			updatedAt: new Date().toISOString(),
		};
	};

	const updateTaskCompletion = async (
		treeName: string,
		skillId: string,
		taskId: string,
		completed: boolean,
	) => {
		if (!user) return;

		const tree = getTreeByName(treeName);
		if (!tree) return;

		const skill = tree.skills[skillId];
		if (!skill?.tasks) return;

		const updateKey = `${treeName}-${skillId}-${taskId}`;

		updateLocalTask(treeName, skillId, taskId, completed);

		const updatePromise = (async () => {
			try {
				await updateDoc(doc(db, "skillTrees", tree.id), {
					[`skills.${skillId}.tasks`]: (skill.tasks ?? []).map((t) =>
						t.id === taskId ? { ...t, completed } : t,
					),
					updatedAt: new Date().toISOString(),
				});
			} catch (error) {
				console.error("Error updating task completion:", error);
				updateLocalTask(treeName, skillId, taskId, !completed);
			} finally {
				pendingUpdates.delete(updateKey);
			}
		})();

		pendingUpdates.set(updateKey, updatePromise);
	};

	const arePrerequisitesCompleted = (
		treeName: string,
		skillId: string,
	): boolean => {
		const prerequisites = getPrerequisiteSkills(treeName, skillId);
		return prerequisites.every((prereq) => isSkillCompleted(prereq));
	};

	const giveApplicableRewards = async (tree: SkillTreeData): Promise<void> => {
		const skills = Object.values(tree.skills);
		const completedSkills = skills.filter(
			(skill) => isSkillCompleted(skill) && !skill.completed,
		);
		for (const completedSkill of completedSkills) {
			await backend.skilltrees.skills.complete(tree.name, completedSkill.id!);
		}

		const allSkillsCompleted = skills.every((skill) => isSkillCompleted(skill));
		if (allSkillsCompleted && !tree.completed) {
			await backend.skilltrees.complete(tree.name);
		}
	};

	const getSkillCompletion = (treeName: string, skillId: string): number => {
		const skill = findSkillById(treeName, skillId);
		if (!skill?.tasks?.length) return 0;

		const completedTasks = skill.tasks.filter((task) => task.completed).length;
		return (completedTasks / skill.tasks.length) * 100;
	};

	const getTreeCompletion = (treeName: string): number => {
		const skills = getSkillsByTree(treeName);
		if (!skills.length) return 0;

		const totalCompletion = skills.reduce((acc, skill) => {
			if (!skill.id) return acc;
			return acc + getSkillCompletion(treeName, skill.id);
		}, 0);

		return totalCompletion / skills.length;
	};

	const getAvailableSkills = (treeName: string): Skill[] => {
		return getSkillsByTree(treeName).filter(
			(skill) =>
				!skill.prerequisites?.length ||
				(skill.id && arePrerequisitesCompleted(treeName, skill.id)),
		);
	};

	const getSkillPath = (treeName: string, skillId: string): Skill[] => {
		const skill = findSkillById(treeName, skillId);
		if (!skill) return [];

		const path: Skill[] = [];
		const addPrerequisites = (currentSkillId: string) => {
			const prereqs = getPrerequisiteSkills(treeName, currentSkillId);
			for (const prereq of prereqs) {
				if (!path.find((s) => s.id === prereq.id)) {
					path.unshift(prereq);
					if (prereq.id) {
						addPrerequisites(prereq.id);
					}
				}
			}
		};

		addPrerequisites(skillId);
		path.push(skill);
		return path;
	};

	onMounted(() => {
		loadTrees();
	});

	onUnmounted(() => {
		for (const unsubscribe of unsubscribes.values()) {
			unsubscribe();
		}
		unsubscribes.clear();
	});

	return {
		trees,
		getTreeByName,
		isLoading,
		loadTrees,
		loadTreeByName,
		getAllSkills,
		getSkillsByTree,
		findSkillById,
		getPrerequisiteSkills,
		updateTaskCompletion,
		arePrerequisitesCompleted,
		getSkillCompletion,
		getTreeCompletion,
		getAvailableSkills,
		getSkillPath,
		isSkillCompleted,
		giveApplicableRewards,
	};
};
