import type { ApiResponse } from "~/types/backend";
import type { Skill } from "~/types/skills/skill";
interface SkillGenerationState {
	loading: boolean;
	error: string | null;
	generatedSkill: Skill | null;
}

export const useSkillGeneration = () => {
	const config = useRuntimeConfig();
	const baseUrl = config.public.apiBase;
	const backend = useBackend();

	const state = reactive<SkillGenerationState>({
		loading: false,
		error: null,
		generatedSkill: null,
	});

	const generateUndefinedSkill = (): Partial<Skill> => {
		return {
			name: "???",
			description: "???",
			icon: "❓",
			tasks: [
				{
					id: crypto.randomUUID(),
					name: "???",
					description: "???",
					completed: false,
					difficulty: 1,
				},
			],
			revealed: false,
		};
	};

	const generateSkill = async (
		treeName: string,
		skillId: string,
	): Promise<Skill | null> => {
		try {
			state.loading = true;
			state.error = null;

			const generatedSkill: ApiResponse<Skill> =
				await backend.skilltrees.skills.creation.generate(treeName, skillId);

			if (generatedSkill instanceof Error) {
				throw new Error(generatedSkill.message);
			}

			state.generatedSkill = generatedSkill as Skill;

			return generatedSkill as Skill;
		} catch (error) {
			state.error =
				error instanceof Error ? error.message : "Unknown error occurred";
			return null;
		} finally {
			state.loading = false;
		}
	};

	return {
		...toRefs(state),
		generateSkill,
		generateUndefinedSkill,
	};
};
