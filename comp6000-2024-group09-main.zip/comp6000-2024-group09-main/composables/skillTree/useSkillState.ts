export const useSkillState = () => {
	const store = useSkillTreeStore();

	return {
		isCreateModalOpen: computed(() => store.isCreateModalOpen),
		currentTree: computed(() => store.currentTree),
		trees: computed(() => store.trees),
		isLoading: computed(() => store.isLoading),
		currentView: computed(() => store.currentView),
		setCreateModalOpen: store.setCreateModalOpen,
		setCurrentTree: store.setCurrentTree,
		setTrees: store.setTrees,
		setLoading: store.setLoading,
		setCurrentView: store.setCurrentView,
		createNewTree: store.createNewTree,
	};
};
