export const useRevealState = () => {
	const revealingSkills = useState<Set<string>>(
		"revealingSkills",
		() => new Set(),
	);

	const isRevealing = (skillId: string) => revealingSkills.value.has(skillId);
	const startRevealing = (skillId: string) =>
		revealingSkills.value.add(skillId);
	const stopRevealing = (skillId: string) =>
		revealingSkills.value.delete(skillId);
	const getRevealingCount = () => revealingSkills.value.size;

	return {
		isRevealing,
		startRevealing,
		stopRevealing,
		getRevealingCount,
	};
};
