import {
	collection,
	getDocs,
	query,
	where,
	writeBatch,
} from "firebase/firestore";
import type { SkillTreeData } from "~/types/skills/skill";
import { useRevealState } from "./useRevealState";
import { useSkillGeneration } from "./useSkillGeneration";

export const useSkillTreeManagement = () => {
	const db = useFirestore();
	const { generateSkill } = useSkillGeneration();
	const { isRevealing, startRevealing, stopRevealing, getRevealingCount } =
		useRevealState();

	const backend = useBackend();
	const user = useCurrentUser();

	const updateTreeDetails = async (
		treeName: string,
		updates: Partial<SkillTreeData>,
	) => {
		return await backend.skilltrees.details.updateTreeDetails(
			treeName,
			updates,
		);
	};

	const resetTreeProgress = async (treeName: string) => {
		return await backend.skilltrees.progress.reset(treeName);
	};

	const deleteSkillTree = async (treeName: string) => {
		return await backend.skilltrees.progress.delete(treeName);
	};

	const deleteAllSkillTrees = async () => {
		//EXPERIMENTAL: we're not going to use this in production, hence no endpoint to do this in the API
		if (!user) return;

		const treeRef = collection(db, "skillTrees");
		const skillTreeQuery = query(
			treeRef,
			where("userId", "==", user.value?.uid),
		);

		const snap = await getDocs(skillTreeQuery);
		if (snap.empty) return;

		const batch = writeBatch(db);
		for (const doc of snap.docs) {
			batch.delete(doc.ref);
		}

		await batch.commit();
	};

	const revealSkill = async (treeName: string, skillId: string) => {
		if (!user) return;

		const MAX_CONCURRENT_REVEALS = 1;

		try {
			if (isRevealing(skillId)) {
				throw new Error("Skill is already being revealed");
			}

			if (getRevealingCount() >= MAX_CONCURRENT_REVEALS) {
				throw new Error("Too many skills being revealed simultaneously");
			}

			startRevealing(skillId);

			const generatedSkill = await generateSkill(treeName, skillId);

			if (!generatedSkill) {
				console.error("Failed to generate skill");
				return;
			}

			return generatedSkill;
		} catch (error) {
			console.error("Error revealing skill:", error);
			throw error;
		} finally {
			stopRevealing(skillId);
		}
	};

	return {
		updateTreeDetails,
		resetTreeProgress,
		deleteSkillTree,
		revealSkill,
		deleteAllSkillTrees,
	};
};
