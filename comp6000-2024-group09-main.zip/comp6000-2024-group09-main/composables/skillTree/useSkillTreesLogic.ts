import type { Skill } from "~/types/skills/skill";

export const useSkillTreesLogic = (
	trees: Record<string, string>,
	searchQuery: Ref<string>,
	showCreateModal: Ref<boolean>,
	newTreeName: Ref<string>,
	getSkillsByTree: (treeName: string) => Skill[],
) => {
	const filteredTrees = computed(() => {
		const query = searchQuery.value.toLowerCase();
		return Object.entries(trees).filter(([treeName]) => {
			const skills = getSkillsByTree(treeName as string);
			return (
				treeName.toLowerCase().includes(query) ||
				skills.some(
					(skill) =>
						skill.name.toLowerCase().includes(query) ||
						skill.description.toLowerCase().includes(query),
				)
			);
		});
	});

	const navigateToTree = (treeName: string): void => {
		navigateTo(`/skills/${treeName}`);
	};

	const handleOpenCreate = () => {
		showCreateModal.value = true;
	};

	const handleCreateTree = () => {
		const trimmedName = newTreeName.value.trim();
		if (!trimmedName) return;

		showCreateModal.value = false;
		newTreeName.value = "";
	};

	return {
		filteredTrees,
		navigateToTree,
		handleOpenCreate,
		handleCreateTree,
	};
};
