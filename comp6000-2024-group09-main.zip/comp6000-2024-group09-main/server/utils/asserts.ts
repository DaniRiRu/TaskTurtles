import { type H3Event, createError } from "h3";
import { hash } from "./hash";
import { getRedis } from "./redis";

export const assertContentType = (
	event: H3Event,
	contentType: "application/json" /* | "others if needed" */,
) => {
	if (event.node.req.headers["content-type"] !== contentType) {
		throw createError({
			message: "invalid content type",
			status: 400,
		});
	}
};

/**
 * Rate limit
 *
 * @param event The H3 event
 * @param limit Number of requests allowed (default: 3)
 * @param window Time window in milliseconds (default: 500)
 * @param action Scope of the rate limit to limit across paths (default: api path)
 *
 * @example
 * ```ts
 * await assertRateLimit(event, 1, 500);
 * ```
 */
export const assertRateLimit = async (
	event: H3Event,
	limit = 3,
	window = 500,
	action?: string,
) => {
	const ip =
		event.node.req.headers["x-forwarded-for"] ||
		event.node.req.headers["cf-connecting-ip"] ||
		event.node.req.headers["x-real-ip"];

	const ipHash = await hash(ip?.toString() || "unknown");

	const actionKey = action || event.path.split("*").join(""); // prevent wildcard trickery

	const key = `rate-limit/${ipHash}/${actionKey}`;

	const redis = await getRedis();
	let count = await redis.get(key);

	if (count === null) {
		await redis.set(key, 1, "PX", window);
		count = "0";
	}

	if (Number.parseInt(count, 10) >= limit) {
		throw createError({
			message: `Rate limit exceeded for ${actionKey}`,
			status: 429,
		});
	}

	await redis.incr(key);
};
