import { subtle } from "uncrypto";

export async function hash(str: string): Promise<string> {
	const hash = await subtle.digest("SHA-256", new TextEncoder().encode(str));

	return Array.from(new Uint8Array(hash))
		.map((b) => b.toString(16).padStart(2, "0"))
		.join("");
}
