import type { Firestore } from "firebase-admin/firestore";
import {
	EMPTY_PROGRESS,
	type UserProgress,
} from "~/types/backend/meta/progress";
import type { WalletData } from "~/types/backend/meta/wallet";
import type { Reward, RewardType } from "~/types/backend/rewards/rewards";
import { REWARDS } from "~/types/backend/rewards/rewards";

export interface RewardResult {
	wallet: WalletData;
	progress: UserProgress;
	reward: Reward;
}

export async function getUserWallet(
	firestore: Firestore,
	userId: string,
): Promise<WalletData> {
	const walletRef = firestore.collection("wallets").doc(userId);
	const walletDoc = await walletRef.get();

	if (!walletDoc.exists) {
		const initialWallet: WalletData = { coins: 0, diamonds: 0 };
		await walletRef.set(initialWallet);
		return initialWallet;
	}

	return walletDoc.data() as WalletData;
}

export async function getUserProgress(
	firestore: Firestore,
	userId: string,
): Promise<UserProgress> {
	const progressRef = firestore.collection("progress").doc(userId);
	const progressDoc = await progressRef.get();

	if (!progressDoc.exists) {
		const initialProgress: UserProgress = EMPTY_PROGRESS;
		await progressRef.set(initialProgress);
		return initialProgress;
	}

	return progressDoc.data() as UserProgress;
}

export async function giveReward(
	firestore: Firestore,
	userId: string,
	rewardType: RewardType,
): Promise<RewardResult> {
	const reward = REWARDS[rewardType];

	if (!reward) {
		throw new Error(`Invalid reward type: ${rewardType}`);
	}

	const walletRef = firestore.collection("wallets").doc(userId);
	const progressRef = firestore.collection("progress").doc(userId);

	return firestore.runTransaction(async (transaction) => {
		const walletDoc = await transaction.get(walletRef);
		let wallet: WalletData;

		if (!walletDoc.exists) {
			wallet = { coins: 0, diamonds: 0 };
		} else {
			wallet = walletDoc.data() as WalletData;
		}

		const progressDoc = await transaction.get(progressRef);
		let progress: UserProgress;

		if (!progressDoc.exists) {
			progress = EMPTY_PROGRESS;
		} else {
			progress = progressDoc.data() as UserProgress;
		}

		const updatedWallet = {
			coins: (wallet.coins || 0) + reward.coins,
			diamonds: (wallet.diamonds || 0) + reward.diamonds,
		};

		const updatedProgress = {
			...progress,
			xp: (progress.xp || 0) + reward.xp,
			score: (progress.score || 0) + reward.score,
		};

		transaction.set(walletRef, updatedWallet);
		transaction.set(progressRef, updatedProgress);

		console.log(`${userId} - Reward given(${rewardType}):`, {
			reward,
			updatedWallet,
			updatedProgress,
		});

		return {
			wallet: updatedWallet,
			progress: updatedProgress,
			reward,
		};
	});
}

export async function giveCustomReward(
	firestore: Firestore,
	userId: string,
	xp: number,
	coins: number,
	diamonds: number,
	score: number,
): Promise<RewardResult> {
	const customReward: Reward = { xp, coins, diamonds, score };

	const walletRef = firestore.collection("wallets").doc(userId);
	const progressRef = firestore.collection("progress").doc(userId);

	return firestore.runTransaction(async (transaction) => {
		const walletDoc = await transaction.get(walletRef);
		let wallet: WalletData;

		if (!walletDoc.exists) {
			wallet = { coins: 0, diamonds: 0 };
		} else {
			wallet = walletDoc.data() as WalletData;
		}

		const progressDoc = await transaction.get(progressRef);
		let progress: UserProgress;

		if (!progressDoc.exists) {
			progress = EMPTY_PROGRESS;
		} else {
			progress = progressDoc.data() as UserProgress;
		}

		const updatedWallet = {
			coins: (wallet.coins || 0) + customReward.coins,
			diamonds: (wallet.diamonds || 0) + customReward.diamonds,
		};

		const updatedProgress = {
			...progress,
			xp: (progress.xp || 0) + customReward.xp,
			score: (progress.score || 0) + customReward.score,
		};

		transaction.set(walletRef, updatedWallet);
		transaction.set(progressRef, updatedProgress);

		return {
			wallet: updatedWallet,
			progress: updatedProgress,
			reward: customReward,
		};
	});
}
