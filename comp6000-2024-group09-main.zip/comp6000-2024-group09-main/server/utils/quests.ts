import type { Firestore } from "firebase-admin/firestore";
import { createModelHandler } from "~/server/utils/ai-service/modelHandler";
import { AiContexts } from "~/types/ai-service/contexts";
import type { Quest } from "~/types/quests/quests";

export const getNextRefreshTime = () => {
	const duration = 24 * 60 * 60 * 1000;

	const now = new Date().getTime();
	const nextRefresh = new Date(now + duration);

	return nextRefresh;
};

export const generateDailyQuests = async (
	firestore: Firestore,
	uid: string,
	amount = 3,
): Promise<Quest[]> => {
	const getRandomImage = () => {
		const randomId = Math.floor(Math.random() * 1000);
		return `https://picsum.photos/800/400?random=${randomId}`;
	};

	const modelHandler = createModelHandler(firestore, uid);

	const prompt = { amount };

	try {
		const response = await modelHandler.generate(
			JSON.stringify(prompt),
			AiContexts.DAILY_QUESTS,
			false,
			undefined,
			true,
		);

		const data = JSON.parse(response.text);

		if (!data.quests || !Array.isArray(data.quests)) {
			throw new Error("Invalid response format");
		}

		const dailyQuests: Quest[] = data.quests.map((quest: Partial<Quest>) => ({
			id: Date.now() + Math.floor(Math.random() * 1000),
			title: quest.title || `Daily Quest #${Math.floor(Math.random() * 100)}`,
			description:
				quest.description || "Complete a daily task for personal growth",
			reward: { xp: quest.reward?.xp || 100 },
			difficulty: (quest.difficulty as "easy" | "medium" | "hard") || "medium",
			category: quest.category,
			isActive: false,
			imageUrl: getRandomImage(),
			progress: { current: 0, max: 100 },
			formattedReward: `${quest.reward?.xp || 100} XP`,
			completed: false,
			type: "daily" as const,
			expires: new Date(new Date().setHours(24, 0, 0, 0)).toISOString(),
		}));

		return dailyQuests;
	} catch (error) {
		console.error("Failed to generate daily quests:", error);

		const fallbackQuests: Quest[] = [
			{
				id: Date.now() + Math.floor(Math.random() * 1000),
				title: "Mindful Morning Ritual",
				description:
					"Begin your day with 10 minutes of mindfulness meditation followed by writing three things you're grateful for.",
				reward: { xp: 100 },
				difficulty: "easy" as const,
				category: "wellness" as const,
				isActive: false,
				imageUrl: getRandomImage(),
				progress: { current: 0, max: 100 },
				formattedReward: "100 XP",
				completed: false,
				type: "daily" as const,
				expires: new Date(new Date().setHours(24, 0, 0, 0)).toISOString(),
			},
			{
				id: Date.now() + Math.floor(Math.random() * 1000),
				title: "Knowledge Expansion Challenge",
				description:
					"Learn a new concept in a field outside your expertise and explain it to someone else or write a summary.",
				reward: { xp: 150 },
				difficulty: "medium" as const,
				category: "education" as const,
				isActive: false,
				imageUrl: getRandomImage(),
				progress: { current: 0, max: 100 },
				formattedReward: "150 XP",
				completed: false,
				type: "daily",
				expires: new Date(new Date().setHours(24, 0, 0, 0)).toISOString(),
			},
			{
				id: Date.now() + Math.floor(Math.random() * 1000),
				title: "Deep Work Power Hour",
				description:
					"Complete 60 minutes of focused, distraction-free work on your most important project with all notifications turned off.",
				reward: { xp: 200 },
				difficulty: "hard" as const,
				category: "productivity" as const,
				isActive: false,
				imageUrl: getRandomImage(),
				progress: { current: 0, max: 100 },
				formattedReward: "200 XP",
				completed: false,
				type: "daily",
				expires: new Date(new Date().setHours(24, 0, 0, 0)).toISOString(),
			},
		];

		return fallbackQuests;
	}
};
