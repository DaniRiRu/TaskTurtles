import type { ICalendarEvent } from "~/types/calendar/events";

function parseICalDate(dateStr: string): Date {
	const year = Number.parseInt(dateStr.substr(0, 4));
	const month = Number.parseInt(dateStr.substr(4, 2)) - 1;
	const day = Number.parseInt(dateStr.substr(6, 2));
	const hour = Number.parseInt(dateStr.substr(9, 2));
	const minute = Number.parseInt(dateStr.substr(11, 2));
	const second = Number.parseInt(dateStr.substr(13, 2));

	return new Date(Date.UTC(year, month, day, hour, minute, second));
}

export function parseICalData(icalData: string): ICalendarEvent[] {
	const events: ICalendarEvent[] = [];
	const lines = icalData.split("\n");
	let currentEvent: Partial<ICalendarEvent> | null = null;

	for (let line of lines) {
		line = line.trim();

		if (line.startsWith("BEGIN:VEVENT")) {
			currentEvent = {
				provider: "ical",
				status: "confirmed",
				attendees: [],
			};
		} else if (line.startsWith("END:VEVENT") && currentEvent) {
			if (
				currentEvent.id &&
				currentEvent.summary &&
				currentEvent.start &&
				currentEvent.end
			) {
				events.push(currentEvent as ICalendarEvent);
			}
			currentEvent = null;
		} else if (currentEvent) {
			const [key, ...valueParts] = line.split(":");
			const value = valueParts.join(":");

			switch (key) {
				case "UID":
					currentEvent.id = value;
					currentEvent.uid = value;
					break;
				case "SUMMARY":
					currentEvent.summary = value;
					break;
				case "DESCRIPTION":
					currentEvent.description = value;
					break;
				case "LOCATION":
					currentEvent.location = value;
					break;
				case "DTSTART":
					currentEvent.start = {
						dateTime: parseICalDate(value).toISOString(),
						timeZone: "UTC",
					};
					break;
				case "DTEND":
					currentEvent.end = {
						dateTime: parseICalDate(value).toISOString(),
						timeZone: "UTC",
					};
					break;
				case "CREATED":
					currentEvent.createdAt = parseICalDate(value);
					break;
				case "LAST-MODIFIED":
					currentEvent.updatedAt = parseICalDate(value);
					break;
				case "STATUS":
					currentEvent.status = value.toLowerCase() as
						| "confirmed"
						| "tentative"
						| "cancelled";
					break;
			}
		}
	}

	return events;
}
