import { OpenAI } from "openai";
import type { AiContext } from "~/types/ai-service/contexts";
import { AI_MODELS } from "~/types/backend/ai-service/models";
import type {
	TokenUsage,
	WebSearchOptions,
} from "~/types/backend/ai-service/requests";
import { getContextPrompt } from "../contextProvider";
import {
	BaseModelHandler,
	type ModelResponse,
	type StreamHandler,
} from "./baseModelHandler";

const openai = new OpenAI({
	apiKey: process.env.OPENAI_API_KEY || "",
});

export class OpenAIModelHandler extends BaseModelHandler {
	async generate(
		message: string,
		context: AiContext,
		webSearch?: boolean,
		webSearchOptions?: WebSearchOptions,
		json?: boolean,
	): Promise<ModelResponse> {
		const contextPrompt = getContextPrompt(context);
		const modelObj = Object.values(AI_MODELS).find((m) => m.id === this.model);

		let modelToUse = this.model;
		let options = {};

		if (webSearch && modelObj?.supportsWebSearch) {
			if (webSearchOptions) {
				options = {
					web_search_options: {
						user_location: webSearchOptions.userLocation,
						search_context_size: webSearchOptions.searchContextSize || "medium",
					},
				};
			} else {
				options = { web_search_options: {} };
			}
		} else if (webSearch && !modelObj?.supportsWebSearch) {
			modelToUse = "gpt-4o-search-preview";

			if (webSearchOptions) {
				options = {
					web_search_options: {
						user_location: webSearchOptions.userLocation,
						search_context_size: webSearchOptions.searchContextSize || "medium",
					},
				};
			} else {
				options = { web_search_options: {} };
			}
		}

		const response = await openai.chat.completions.create({
			model: modelToUse,
			messages: [
				{ role: "system", content: contextPrompt },
				{ role: "user", content: message },
			],
			response_format: {
				type: json ? "json_object" : "text",
			},
			...options,
		});

		const tokenUsage = {
			prompt: response.usage?.prompt_tokens || 0,
			completion: response.usage?.completion_tokens || 0,
			total: response.usage?.total_tokens || 0,
		};

		await this.handleTokens(
			tokenUsage,
			context.toString(),
			message,
			!!webSearch,
		);

		return {
			text: response.choices[0]?.message?.content || "",
			tokenUsage,
		};
	}

	async generateStream(
		message: string,
		context: AiContext,
		webSearch?: boolean,
		webSearchOptions?: WebSearchOptions,
		onChunk?: StreamHandler,
		json?: boolean,
	): Promise<TokenUsage> {
		const contextPrompt = getContextPrompt(context);
		let totalCompletionTokens = 0;
		const modelObj = Object.values(AI_MODELS).find((m) => m.id === this.model);

		let modelToUse = this.model;
		let options = {};

		if (webSearch && modelObj?.supportsWebSearch) {
			if (webSearchOptions) {
				options = {
					web_search_options: {
						user_location: webSearchOptions.userLocation,
						search_context_size: webSearchOptions.searchContextSize || "medium",
					},
				};
			} else {
				options = { web_search_options: {} };
			}
		} else if (webSearch && !modelObj?.supportsWebSearch) {
			modelToUse = "gpt-4o-search-preview";

			if (webSearchOptions) {
				options = {
					web_search_options: {
						user_location: webSearchOptions.userLocation,
						search_context_size: webSearchOptions.searchContextSize || "medium",
					},
				};
			} else {
				options = { web_search_options: {} };
			}
		}

		const stream = await openai.chat.completions.create({
			model: modelToUse,
			messages: [
				{ role: "system", content: contextPrompt },
				{ role: "user", content: message },
			],
			stream: true,
			response_format: {
				type: json ? "json_object" : "text",
			},
			...options,
		});

		let fullText = "";

		for await (const chunk of stream) {
			const content = chunk.choices[0]?.delta?.content || "";

			if (content) {
				fullText += content;
				if (onChunk) {
					onChunk({
						text: content,
						done: false,
					});
				}
				totalCompletionTokens += 1;
			}
		}

		if (onChunk) {
			onChunk({ text: "", done: true });
		}

		const promptTokens = (contextPrompt.length + message.length) / 4;
		const tokenUsage = {
			prompt: Math.ceil(promptTokens),
			completion: totalCompletionTokens,
			total: Math.ceil(promptTokens) + totalCompletionTokens,
		};

		await this.handleTokens(
			tokenUsage,
			context.toString(),
			message,
			!!webSearch,
		);

		return tokenUsage;
	}
}
