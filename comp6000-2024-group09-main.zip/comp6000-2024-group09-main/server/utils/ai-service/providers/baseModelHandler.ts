import type { Firestore } from "firebase-admin/firestore";
import type { AiContext } from "~/types/ai-service/contexts";
import type { AIModel } from "~/types/backend/ai-service/models";
import type {
	Annotation,
	TokenUsage,
	WebSearchOptions,
} from "~/types/backend/ai-service/requests";
import { calculateAndDeductTokens } from "../tokenHandler";

export interface ModelResponse {
	text: string;
	tokenUsage: TokenUsage;
	annotations?: Annotation[];
}

export interface StreamChunk {
	text: string;
	done: boolean;
	annotations?: Annotation[];
}

export type StreamHandler = (chunk: StreamChunk) => void;

export abstract class BaseModelHandler {
	protected model: string;
	protected modelConfig: AIModel;
	protected firestore: Firestore | undefined;
	protected userId: string | undefined;

	constructor(
		modelId: string,
		modelConfig: AIModel,
		firestore: Firestore,
		userId: string,
	) {
		this.firestore = firestore;
		this.model = modelId;
		this.modelConfig = modelConfig;
		this.userId = userId;
	}

	protected async handleTokens(
		tokenUsage: TokenUsage,
		context: string,
		message: string,
		webSearch = false,
	): Promise<void> {
		if (this.firestore && this.userId) {
			await calculateAndDeductTokens(
				this.firestore,
				this.userId,
				this.modelConfig,
				tokenUsage,
				context,
				message,
				webSearch,
			);
		}
	}

	abstract generate(
		message: string,
		context: AiContext,
		webSearch?: boolean,
		webSearchOptions?: WebSearchOptions,
		json?: boolean,
	): Promise<ModelResponse>;

	abstract generateStream(
		message: string,
		context: AiContext,
		webSearch?: boolean,
		webSearchOptions?: WebSearchOptions,
		onChunk?: StreamHandler,
		json?: boolean,
	): Promise<TokenUsage>;
}
