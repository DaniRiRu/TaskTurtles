import { Anthropic } from "@anthropic-ai/sdk";
import type { AiContext } from "~/types/ai-service/contexts";
import type {
	TokenUsage,
	WebSearchOptions,
} from "~/types/backend/ai-service/requests";
import { getContextPrompt } from "../contextProvider";
import {
	BaseModelHandler,
	type ModelResponse,
	type StreamHandler,
} from "./baseModelHandler";

const anthropic = new Anthropic({
	apiKey: process.env.ANTHROPIC_API_KEY || "",
});

export class AnthropicModelHandler extends BaseModelHandler {
	async generate(
		message: string,
		context: AiContext,
		webSearch?: boolean,
		webSearchOptions?: WebSearchOptions,
		json?: boolean,
	): Promise<ModelResponse> {
		const contextPrompt = getContextPrompt(context);

		let adjustedMessage = message;
		if (webSearch) {
			adjustedMessage = `I need you to pretend you have access to the internet and can search for up-to-date information. Based on what you know, provide the most accurate answer to: ${message}`;
		}

		if (json) {
			adjustedMessage = `Please provide the response in JSON format with no addition text, or fomatting: ${message}`;
		}

		const response = await anthropic.messages.create({
			model: this.model,
			system: contextPrompt,
			messages: [{ role: "user", content: adjustedMessage }],
			max_tokens: 1000,
		});

		let responseText = "";
		if (response.content && response.content.length > 0) {
			const contentBlock = response.content[0];
			if (contentBlock.type === "text") {
				responseText = contentBlock.text;
			}
		}

		const tokenUsage = {
			prompt: response.usage.input_tokens,
			completion: response.usage.output_tokens,
			total: response.usage.input_tokens + response.usage.output_tokens,
		};

		await this.handleTokens(
			tokenUsage,
			context.toString(),
			message,
			!!webSearch,
		);

		return {
			text: responseText,
			tokenUsage,
		};
	}

	async generateStream(
		message: string,
		context: AiContext,
		webSearch?: boolean,
		webSearchOptions?: WebSearchOptions,
		onChunk?: StreamHandler,
	): Promise<TokenUsage> {
		const contextPrompt = getContextPrompt(context);

		let adjustedMessage = message;
		if (webSearch) {
			adjustedMessage = `I need you to pretend you have access to the internet and can search for up-to-date information. Based on what you know, provide the most accurate answer to: ${message}`;
		}

		const stream = await anthropic.messages.create({
			model: this.model,
			system: contextPrompt,
			messages: [{ role: "user", content: adjustedMessage }],
			max_tokens: 1000,
			stream: true,
		});

		let fullText = "";
		let inputTokens = 0;
		let outputTokens = 0;

		for await (const chunk of stream) {
			if (chunk.type === "message_start") {
				inputTokens = chunk.message.usage?.input_tokens || 0;
			} else if (chunk.type === "content_block_delta") {
				if (chunk.delta?.type === "text_delta") {
					const content = chunk.delta.text || "";
					if (content) {
						fullText += content;
						if (onChunk) {
							onChunk({ text: content, done: false });
						}
					}
				}
			} else if (chunk.type === "message_delta") {
				if (chunk.usage?.output_tokens) {
					outputTokens = chunk.usage.output_tokens;
				}
			}
		}

		if (onChunk) {
			onChunk({ text: "", done: true });
		}

		const tokenUsage = {
			prompt: inputTokens,
			completion: outputTokens,
			total: inputTokens + outputTokens,
		};

		await this.handleTokens(
			tokenUsage,
			context.toString(),
			message,
			!!webSearch,
		);

		return tokenUsage;
	}
}
