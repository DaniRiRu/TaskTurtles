import type { Firestore } from "firebase-admin/firestore";
import {
	AI_MODELS,
	ModelId,
	ModelProvider,
} from "~/types/backend/ai-service/models";
import { AnthropicModelHandler } from "./providers/anthropicModelHandler";
import { OpenAIModelHandler } from "./providers/openAiModelHandler";
import { checkTokenBalance } from "./tokenHandler";

export function createModelHandler(
	firestore: Firestore,
	userId: string,
	modelId: ModelId = ModelId.GPT_4O_MINI,
) {
	let handler: OpenAIModelHandler | AnthropicModelHandler;

	const model = AI_MODELS[modelId];

	if (model.provider === ModelProvider.OPENAI) {
		handler = new OpenAIModelHandler(model.id, model, firestore, userId);
	} else if (model.provider === ModelProvider.ANTHROPIC) {
		handler = new AnthropicModelHandler(model.id, model, firestore, userId);
	} else {
		throw new Error(`Unsupported provider: ${model.provider}`);
	}

	return handler;
}

export async function verifyTokenBalance(
	firestore: Firestore,
	userId: string,
	estimatedTokens: number,
): Promise<boolean> {
	const balance = await checkTokenBalance(firestore, userId);
	console.log(
		`${userId}: has ${balance} tokens, estimated cost ${estimatedTokens}`,
	);
	return balance >= estimatedTokens;
}
