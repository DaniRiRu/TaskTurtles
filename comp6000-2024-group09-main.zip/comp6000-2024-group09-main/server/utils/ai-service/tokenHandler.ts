import type { Firestore } from "firebase-admin/firestore";
import {
	type AIModel,
	AI_MODELS,
	type ModelId,
} from "~/types/backend/ai-service/models";
import type { TokenUsage } from "~/types/backend/ai-service/requests";

export interface TokenCostResult {
	cost: number;
	updatedBalance: number;
}

export interface TokenEstimateResult {
	estimatedCost: number;
	estimatedTokens: number;
}

export async function calculateAndDeductTokens(
	firestore: Firestore,
	userId: string,
	model: AIModel,
	tokenUsage: TokenUsage,
	context: string,
	message: string,
	webSearch = false,
): Promise<TokenCostResult> {
	const userTokensRef = firestore.collection("ai_tokens").doc(userId);
	const userTokensDoc = await userTokensRef.get();

	if (!userTokensDoc.exists) {
		await userTokensRef.set({
			balance: 10000,
			usageHistory: [],
			createdAt: new Date().toISOString(),
		});
	}

	const userData = userTokensDoc.data();
	if (!userData) {
		throw new Error("User data not found");
	}

	const inputCost = model.costPerInputToken * tokenUsage.prompt;
	const outputCost = model.costPerOutputToken * tokenUsage.completion;
	const cost = inputCost + outputCost;

	const updatedBalance = userData.balance - cost;

	console.log(
		`${userId}: has consumed ${cost} tokens, remaining balance ${
			updatedBalance
		} context - ${context}`,
	);

	await userTokensRef.update({
		balance: Math.max(0, updatedBalance),
		usageHistory: [
			...(userData.usageHistory || []),
			{
				date: new Date().toISOString(),
				tokensUsed: cost,
				model: model.name,
				context: context,
				message:
					message.substring(0, 100) + (message.length > 100 ? "..." : ""),
				webSearch: webSearch,
			},
		],
	});

	return {
		cost,
		updatedBalance,
	};
}

export async function checkTokenBalance(
	firestore: Firestore,
	userId: string,
): Promise<number> {
	const userTokensRef = firestore.collection("ai_tokens").doc(userId);
	const userTokensDoc = await userTokensRef.get();

	if (!userTokensDoc.exists) {
		await userTokensRef.set({
			balance: 10000,
			usageHistory: [],
			createdAt: new Date().toISOString(),
		});
		return 10000;
	}

	const userData = userTokensDoc.data();
	if (!userData) {
		throw new Error("User data not found");
	}

	return userData.balance;
}

export function estimateTokenCost(
	text: string,
	modelId: ModelId,
): TokenEstimateResult {
	const model = AI_MODELS[modelId];

	const avgTokensPerChar = 0.25;
	const estimatedInputTokens = Math.ceil(text.length * avgTokensPerChar);
	const estimatedOutputTokens = Math.ceil(estimatedInputTokens * 1.5);

	const inputCost = model.costPerInputToken * estimatedInputTokens;
	const outputCost = model.costPerOutputToken * estimatedOutputTokens;
	const totalEstimatedCost = inputCost + outputCost;

	return {
		estimatedCost: totalEstimatedCost,
		estimatedTokens: estimatedInputTokens + estimatedOutputTokens,
	};
}
