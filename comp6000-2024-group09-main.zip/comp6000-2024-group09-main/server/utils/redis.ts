import type Redis from "ioredis";
import type { Constructor } from "ioredis-mock";

let redisClient: Constructor | null = null;

const importRedisClient = async () => {
	if (process.env.NODE_ENV !== "production" || process.env.BUILD_TEST) {
		return (await import("ioredis-mock")).default;
	}

	return (await import("ioredis")).default;
};

const getRedisClient = async () => {
	if (redisClient === null) {
		redisClient = await importRedisClient();
	}

	return redisClient;
};

let redisCache: Redis | null = null;

export const getRedis = async () => {
	const Redis = await getRedisClient();

	if (redisCache === null) {
		redisCache = new Redis({
			host: process.env.REDIS_HOST,
			port: Number.parseInt(process.env.REDIS_PORT || "6379", 10),
		});
	}

	return redisCache;
};
