import type { Firestore } from "firebase-admin/firestore";
import type { TokenUse } from "~/types/token";

const DAILY_LIMIT = 1000;

// Function to return entry from the database via userID
export async function getUserTokenData(
	firestore: Firestore,
	userId: string,
): Promise<TokenUse> {
	const docRef = firestore.collection("tokenUsage").doc(userId);
	const doc = await docRef.get();

	if (!doc.exists) {
		// Create a database entry if it doesn't exist
		const initialData = {
			tokensUsed: 0,
			tokensLeft: DAILY_LIMIT,
		};
		await docRef.set(initialData);
		return initialData;
	}

	return doc.data() as TokenUse;
}

// Function to update tokens based on request
export async function updateUserToken(
	firestore: Firestore,
	userId: string,
	tokensToDeduct: number,
): Promise<void> {
	const docRef = firestore.collection("tokenUsage").doc(userId);
	const doc = await docRef.get();

	if (!doc.exists) {
		throw new Error("User data does not exist.");
	}

	const userData = doc.data() as TokenUse;

	if (userData.tokensLeft < tokensToDeduct) {
		throw new Error("Daily token limit reached.");
	}

	await docRef.update({
		tokensUsed: userData.tokensUsed + tokensToDeduct,
		tokensLeft: userData.tokensLeft - tokensToDeduct,
	});
}
