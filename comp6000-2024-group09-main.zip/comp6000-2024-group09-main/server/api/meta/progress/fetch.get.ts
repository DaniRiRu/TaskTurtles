import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import {
	EMPTY_PROGRESS,
	type UserProgress,
} from "~/types/backend/meta/progress";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<UserProgress>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "GET");
	await assertRateLimit(event, 1, 100);

	const progressRef = firestore.collection("progress").doc(user.uid);
	const progressDoc = await progressRef.get();

	if (!progressDoc.exists) {
		const initialProgress: UserProgress = EMPTY_PROGRESS;
		await progressRef.set(initialProgress);
		return initialProgress;
	}

	const currentProgress = progressDoc.data() as UserProgress;
	const updatedProgress: UserProgress = {
		...EMPTY_PROGRESS,
		...currentProgress,
	};

	if (JSON.stringify(currentProgress) !== JSON.stringify(updatedProgress)) {
		await progressRef.update({ ...updatedProgress });
	}

	return updatedProgress;
});
