import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import {
	EMPTY_PROGRESS,
	type UserProgress,
} from "~/types/backend/meta/progress";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<UserProgress>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "POST");
	await assertRateLimit(event, 1, 100);

	const progressRef = firestore.collection("progress").doc(user.uid);
	const progressDoc = await progressRef.get();

	const body = await readBody(event);

	if (!progressDoc.exists) {
		const initialProgress: UserProgress = EMPTY_PROGRESS;
		await progressRef.set(initialProgress);
		return initialProgress;
	}

	const currentProgress = progressDoc.data() as UserProgress;
	const updatedProgress: UserProgress = {
		...currentProgress,
		...Object.keys(body).reduce(
			(acc, key) => {
				if (body[key] !== undefined) {
					acc[key as keyof UserProgress] = body[key];
				}
				return acc;
			},
			{} as Partial<UserProgress>,
		),
	};

	await progressRef.update({
		...updatedProgress,
	});

	return updatedProgress;
});
