import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type { WalletData } from "~/types/backend/meta/wallet";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<WalletData>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "POST");
	await assertRateLimit(event, 1, 100);

	const body = await readBody(event);
	const { coins, diamonds } = body;

	const walletRef = firestore.collection("wallets").doc(user.uid);
	const walletDoc = await walletRef.get();

	if (!walletDoc.exists) {
		const initialWallet: WalletData = {
			coins: Number(coins) || 0,
			diamonds: Number(diamonds) || 0,
		};
		await walletRef.set(initialWallet);
		return initialWallet;
	}

	const updatedWallet: WalletData = {
		coins: Number(coins),
		diamonds: Number(diamonds),
	};

	await walletRef.update({
		coins: updatedWallet.coins,
		diamonds: updatedWallet.diamonds,
	});

	return updatedWallet;
});
