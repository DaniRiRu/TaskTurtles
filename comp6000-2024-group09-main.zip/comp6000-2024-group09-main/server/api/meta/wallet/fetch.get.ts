import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type { WalletData } from "~/types/backend/meta/wallet";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<WalletData>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "GET");
	await assertRateLimit(event, 1, 100);

	const walletRef = firestore.collection("wallets").doc(user.uid);
	const walletDoc = await walletRef.get();

	if (!walletDoc.exists) {
		const initialWallet: WalletData = { coins: 0, diamonds: 0 };
		await walletRef.set(initialWallet);
		return initialWallet;
	}

	return walletDoc.data() as WalletData;
});
