import randomTrees from "assets/data/random_tree_titles.json";
import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type { AiSuggestionPrompt } from "~/types/skills/suggestions";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<AiSuggestionPrompt>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "GET");
	await assertRateLimit(event, 1, 500);

	if (!user) {
		throw createError({
			statusCode: 401,
			message: "Unauthorized",
		});
	}

	const query = getQuery(event);
	const userProvidedTitle = query.title as string | undefined;

	let selectedTree: AiSuggestionPrompt;
	if (userProvidedTitle) {
		selectedTree = {
			name: userProvidedTitle,
			description: `Custom skill tree based on "${userProvidedTitle}"`,
		};
	} else {
		const randomIndex = Math.floor(Math.random() * randomTrees.trees.length);
		selectedTree = randomTrees.trees[randomIndex];
	}

	return {
		success: true,
		name: selectedTree.name,
		description: selectedTree.description,
	};
});
