import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import { RewardType } from "~/types/backend/rewards/rewards";
import type { Skill, SkillTreeData } from "~/types/skills/skill";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<void>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "POST");
	await assertRateLimit(event, 1, 500);

	if (!user) {
		throw createError({
			statusCode: 401,
			message: "Unauthorized",
		});
	}

	const treeName = decodeURIComponent(event.context.params!.treeName);

	if (!treeName) {
		throw createError({
			statusCode: 400,
			message: "Tree name is required",
		});
	}

	try {
		const skillTreesCollection = firestore.collection("skillTrees");
		const walletCollection = firestore.collection("wallets");

		const treeSnapshot = await skillTreesCollection
			.where("userId", "==", user.uid)
			.where("name", "==", treeName)
			.get();

		if (treeSnapshot.empty) {
			throw createError({
				statusCode: 404,
				message: "Skill tree not found",
			});
		}

		const treeDoc = treeSnapshot.docs[0];
		const treeData = treeDoc.data() as SkillTreeData;

		const skills: Record<string, Skill> = treeData.skills;

		if (treeData.completed) {
			throw createError({
				statusCode: 400,
				message: "Skill tree already completed",
			});
		}

		const allSkillsCompleted = Object.values(skills).every((skill) => {
			if (!skill.revealed) return false;

			if (skill.tasks && skill.tasks.length > 0) {
				return skill.tasks.every((task) => task.completed);
			}

			return true;
		});

		if (!allSkillsCompleted) {
			throw createError({
				statusCode: 400,
				message: "Not all skills are completed",
			});
		}

		await skillTreesCollection.doc(treeDoc.id).update({
			completed: true,
			completedAt: new Date().toISOString(),
			updatedAt: new Date().toISOString(),
		});

		giveReward(firestore, user.uid, RewardType.SKILL_TREE_COMPLETE);
	} catch (error) {
		console.error("Error completing skill tree:", error);
		throw createError({
			statusCode: 500,
			message:
				error instanceof Error
					? error.message
					: "Failed to complete skill tree",
		});
	}
});
