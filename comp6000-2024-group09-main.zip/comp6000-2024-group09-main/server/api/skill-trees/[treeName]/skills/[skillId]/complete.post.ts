import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import { RewardType } from "~/types/backend/rewards/rewards";
import type { SkillTreeData } from "~/types/skills/skill";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<void>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "POST");
	await assertRateLimit(event, 1, 500);

	if (!user) {
		throw createError({
			statusCode: 401,
			message: "Unauthorized",
		});
	}

	const treeName = decodeURIComponent(event.context.params!.treeName);
	const skillId = decodeURIComponent(event.context.params!.skillId);

	if (!treeName || !skillId) {
		throw createError({
			statusCode: 400,
			message: "Tree name and skill ID are required",
		});
	}

	try {
		const skillTreesCollection = firestore.collection("skillTrees");
		const walletCollection = firestore.collection("wallets");

		const treeSnapshot = await skillTreesCollection
			.where("userId", "==", user.uid)
			.where("name", "==", treeName)
			.get();

		if (treeSnapshot.empty) {
			throw createError({
				statusCode: 404,
				message: "Skill tree not found",
			});
		}

		const treeDoc = treeSnapshot.docs[0];
		const treeData = treeDoc.data() as SkillTreeData;

		if (!treeData.skills[skillId]) {
			throw createError({
				statusCode: 404,
				message: "Skill not found in the tree",
			});
		}

		const skill = treeData.skills[skillId];

		if (skill.completed) {
			throw createError({
				statusCode: 400,
				message: "Skill already completed",
			});
		}

		if (skill.tasks && skill.tasks.length > 0) {
			const allTasksCompleted = skill.tasks.every((task) => task.completed);
			if (!allTasksCompleted) {
				throw createError({
					statusCode: 400,
					message: "Not all tasks for this skill are completed",
				});
			}
		}

		skill.completed = true;

		const newSkillsRevealed: string[] = [];

		for (const otherSkill of Object.values(treeData.skills)) {
			if (!otherSkill.revealed && !otherSkill.completed) {
				if (otherSkill.prerequisites.includes(skillId)) {
					const allPrerequisitesCompleted = otherSkill.prerequisites.every(
						(prereqId) => treeData.skills[prereqId]?.completed,
					);

					if (allPrerequisitesCompleted && otherSkill.id) {
						otherSkill.revealed = true;
						newSkillsRevealed.push(otherSkill.id);
					}
				}
			}
		}

		await skillTreesCollection.doc(treeDoc.id).update({
			skills: treeData.skills,
			updatedAt: new Date().toISOString(),
		});

		giveReward(firestore, user.uid, RewardType.SKILL_COMPLETE);
	} catch (error) {
		console.error("Error completing skill:", error);
		throw createError({
			statusCode: 500,
			message:
				error instanceof Error ? error.message : "Failed to complete skill",
		});
	}
});
