import type { EventHandlerRequest } from "h3";
import { createModelHandler } from "~/server/utils/ai-service/modelHandler";
import { assertRateLimit } from "~/server/utils/asserts";
import { AiContexts } from "~/types/ai-service/contexts";
import type { ApiResponse } from "~/types/backend";
import { ModelId } from "~/types/backend/ai-service/models";
import type { Skill, SkillTask, SkillTreeData } from "~/types/skills/skill";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<Skill>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "GET");
	await assertRateLimit(event, 1, 500);

	if (!user) {
		throw createError({
			statusCode: 401,
			message: "Unauthorized",
		});
	}

	const treeName = decodeURIComponent(event.context.params!.treeName);
	const skillId = decodeURIComponent(event.context.params!.skillId);

	if (!skillId || !treeName) {
		throw createError({
			statusCode: 400,
			message: "Tree name and Skill ID are required",
		});
	}

	try {
		const docRef = firestore.collection("skillTrees");
		const snapshot = await docRef
			.where("userId", "==", user.uid)
			.where("name", "==", treeName)
			.get();

		if (snapshot.empty) {
			throw createError({
				statusCode: 404,
				message: "Skill tree not found",
			});
		}

		const treeData = snapshot.docs[0].data() as SkillTreeData;
		const currentSkill = treeData.skills[skillId];

		if (!currentSkill) {
			throw createError({
				statusCode: 404,
				message: "Skill not found in tree",
			});
		}

		const position = currentSkill.position;
		const description = treeData.description;
		const revealedSkills = Object.values(treeData.skills)
			.filter((skill) => skill.revealed)
			.map((skill) => `${skill.name} position: ${skill.position}`);
		const totalSkills = Object.keys(treeData.skills).length;
		const parents = currentSkill.prerequisites;

		const skillNames = Object.values(treeData.skills).filter(
			(skill) => skill.id && parents.includes(skill.id),
		);

		const parentsNames = skillNames.map(
			(skill) =>
				`(${skill.name} description: ${skill.description} tasks: {${skill.tasks?.map(
					(task) => `${task.name} description: (${task.description})}`,
				)})`,
		);

		const percentageTowardsCompletion = Math.floor(
			(position / totalSkills) * 100,
		);

		const modelHandler = createModelHandler(
			firestore,
			user.uid,
			ModelId.GPT_4O_MINI,
		);

		const prompt = {
			treeName,
			description,
			percentageTowardsCompletion: `${percentageTowardsCompletion}%`,
			position: `this skill is at position ${position} of ${totalSkills} skills`,
			totalSkills,
			phase:
				percentageTowardsCompletion <= 30
					? "foundation"
					: percentageTowardsCompletion <= 70
						? "development"
						: "refinement",
			parents: parentsNames,
			revealedSkills: `all the skills revealed so far [${revealedSkills}]`,
			revealedSkillsCount: revealedSkills.length,
		};

		const response = await modelHandler.generate(
			JSON.stringify(prompt),
			AiContexts.SKILL_TREE,
			false,
			undefined,
			true,
		);

		const generatedSkill = JSON.parse(response.text);

		if (!generatedSkill.name) {
			throw createError({
				statusCode: 500,
				message: "Failed to generate valid skill data",
			});
		}

		const newSkill: Skill = {
			id: skillId,
			name: generatedSkill.name,
			description: generatedSkill.description,
			prerequisites: parents,
			revealed: true,
			position: position,
			tasks: generatedSkill.tasks.map((task: SkillTask) => ({
				...task,
				id: crypto.randomUUID(),
				completed: false,
			})),
			icon: generatedSkill.icon,
			completed: false,
		};

		const latestSnapshot = await docRef
			.where("userId", "==", user.uid)
			.where("name", "==", treeName)
			.get();

		if (latestSnapshot.empty) {
			throw createError({
				statusCode: 404,
				message: "Skill tree no longer exists",
			});
		}

		const updatedTreeData = latestSnapshot.docs[0].data() as SkillTreeData;
		const currentTreeSkill = updatedTreeData.skills[skillId];

		if (!currentTreeSkill) {
			throw createError({
				statusCode: 409,
				message: "Skill no longer exists in tree",
			});
		}

		if (currentTreeSkill.revealed) {
			throw createError({
				statusCode: 409,
				message: "Skill has already been revealed",
			});
		}

		if (
			JSON.stringify(currentTreeSkill.prerequisites) !== JSON.stringify(parents)
		) {
			throw createError({
				statusCode: 409,
				message: "Skill prerequisites have changed",
			});
		}

		const updatedSkills = { ...updatedTreeData.skills, [skillId]: newSkill };

		await docRef.doc(treeData.id).update({
			skills: updatedSkills,
			updatedAt: new Date().toISOString(),
		});

		return {
			success: true,
			...newSkill,
		};
	} catch (error) {
		console.error("Error generating skill:", error);
		throw createError({
			statusCode: 500,
			message:
				error instanceof Error ? error.message : "Failed to generate skill",
		});
	}
});
