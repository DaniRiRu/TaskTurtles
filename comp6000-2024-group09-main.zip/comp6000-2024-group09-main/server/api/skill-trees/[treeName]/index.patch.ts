import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type { SkillTreeUpdateResponse } from "~/types/backend/skill-tree/update";
import type { SkillTreeData } from "~/types/skills/skill";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<SkillTreeUpdateResponse>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "PATCH");
	await assertRateLimit(event, 1, 500);

	if (!user) {
		throw createError({
			statusCode: 401,
			message: "Unauthorized",
		});
	}

	const treeName = decodeURIComponent(event.context.params!.treeName);
	const updates: Partial<SkillTreeData> = await readBody(event);

	if (!treeName) {
		throw createError({
			statusCode: 400,
			message: "Tree name is required",
		});
	}

	try {
		const docRef = firestore.collection("skillTrees");
		const snapshot = await docRef
			.where("userId", "==", user.uid)
			.where("name", "==", treeName)
			.get();

		if (snapshot.empty) {
			throw createError({
				statusCode: 404,
				message: "Skill tree not found",
			});
		}

		const treeData = snapshot.docs[0].data() as SkillTreeData;

		const updatedData: SkillTreeData = {
			...treeData,
			...updates,
			updatedAt: new Date().toISOString(),
		};

		await docRef.doc(snapshot.docs[0].id).update({ ...updatedData });

		const response: SkillTreeUpdateResponse = {
			oldTree: treeData,
			newTree: updatedData,
		};

		return {
			success: true,
			...response,
		};
	} catch (error) {
		console.error("Error updating skill tree:", error);
		throw createError({
			statusCode: 500,
			message:
				error instanceof Error ? error.message : "Failed to update skill tree",
		});
	}
});
