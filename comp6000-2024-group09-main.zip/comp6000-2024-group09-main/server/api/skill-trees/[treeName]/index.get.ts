import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type { SkillTreeData } from "~/types/skills/skill";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<SkillTreeData>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "GET");
	await assertRateLimit(event, 5, 1000);

	if (!user) {
		throw createError({
			statusCode: 401,
			message: "Unauthorized",
		});
	}

	const treeName = decodeURIComponent(event.context.params!.treeName);

	if (!treeName) {
		throw createError({
			statusCode: 400,
			message: "Tree name is required",
		});
	}

	try {
		const docRef = firestore.collection("skillTrees");
		const snapshot = await docRef
			.where("userId", "==", user.uid)
			.where("name", "==", treeName)
			.get();

		if (snapshot.empty) {
			throw createError({
				statusCode: 404,
				message: "Skill tree not found",
			});
		}

		const treeData = snapshot.docs[0].data() as SkillTreeData;

		return {
			success: true,
			...treeData,
		};
	} catch (error) {
		console.error("Error fetching skill tree:", error);
		throw createError({
			statusCode: 500,
			message:
				error instanceof Error ? error.message : "Failed to fetch skill tree",
		});
	}
});
