import { getFirestore } from "firebase-admin/firestore";
import { createError } from "h3";
import useFirebaseServer from "~/server/utils/useFirebaseApp";

export default defineEventHandler(async (event) => {
	try {
		const userId = event.context.firebase.user.uid;
		const treeName = decodeURIComponent(event.context.params!.treeName);

		if (!userId) {
			throw createError({
				statusCode: 400,
				message: "User ID is required",
			});
		}

		if (!treeName) {
			throw createError({
				statusCode: 400,
				message: "Tree Name is required",
			});
		}

		const app = useFirebaseServer();
		const firestore = getFirestore(app);

		const docRef = firestore.collection("skillTrees");

		const snapshot = await docRef
			.where("userId", "==", userId)
			.where("name", "==", treeName)
			.get();

		if (snapshot.empty) {
			throw createError({
				statusCode: 404,
				message: "Skill tree not found",
			});
		}

		const success = await docRef.doc(snapshot.docs[0].id).delete();

		return { success: success };
	} catch (error) {
		console.error("Server error:", error);
		throw createError({
			statusCode: 500,
			message: error instanceof Error ? error.message : "Internal server error",
		});
	}
});
