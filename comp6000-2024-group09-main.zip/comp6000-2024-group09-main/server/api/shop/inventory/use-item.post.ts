import type { EventHandlerRequest } from "h3";
import type { ItemConsume } from "~/types/shop/consume";
import { executeItemEffect } from "../effects/registry";

export default defineEventHandler<EventHandlerRequest, Promise<ItemConsume>>(
	async (event) => {
		const { firestore, user } = event.context.firebase;

		assertMethod(event, "POST");
		await assertRateLimit(event, 1, 100);

		const body = await readBody(event);
		const { itemId } = body;

		const inventoryRef = firestore.collection("inventories").doc(user.uid);
		const inventoryDoc = await inventoryRef.get();

		if (!inventoryDoc.exists) {
			throw createError({
				statusCode: 404,
				message: "Inventory not found",
			});
		}

		try {
			const result = (await executeItemEffect(
				{
					userId: user.uid,
					firestore,
				},
				itemId,
				inventoryDoc,
			)) as ItemConsume;

			return result;
		} catch (e) {
			const errorMessage =
				e instanceof Error ? e.message : "An unknown error occurred";
			throw createError({
				statusCode: 400,
				message: errorMessage,
			});
		}
	},
);
