import type { EventHandlerRequest } from "h3";
import type { InventoryItem } from "~/types/backend/shop/item";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<InventoryItem[]>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "GET");
	await assertRateLimit(event, 1, 500);

	const inventoryRef = firestore.collection("inventories").doc(user.uid);
	const inventoryDoc = await inventoryRef.get();

	if (!inventoryDoc.exists) {
		await inventoryRef.set({ items: [] });
		return [];
	}

	return inventoryDoc.data()?.items || [];
});
