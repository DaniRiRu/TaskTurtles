import type { EventHandlerRequest } from "h3";
import {
	defaultShopItems,
	getSortedDefaultItems,
} from "~/server/data/shop/defaultShopItems";
import type { ShopItem } from "~/types/backend/shop/item";

export default defineEventHandler<EventHandlerRequest, Promise<ShopItem[]>>(
	async (event) => {
		const { firestore } = event.context.firebase;

		assertMethod(event, "GET");
		await assertRateLimit(event, 1, 500);

		const shopRef = firestore.collection("shop").doc("items");
		const shopDoc = await shopRef.get();
		const TESTING = true;

		if (!shopDoc.exists || TESTING) {
			await shopRef.set({ items: defaultShopItems });
			return getSortedDefaultItems();
		}

		return shopDoc.data()?.items || [];
	},
);
