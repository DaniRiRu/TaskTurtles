import type { EventHandlerRequest } from "h3";
import type { WalletData } from "~/types/backend/meta/wallet";
import type { ShopItem } from "~/types/backend/shop/item";

export default defineEventHandler<EventHandlerRequest, Promise<ShopItem>>(
	async (event) => {
		const { firestore, user } = event.context.firebase;

		assertMethod(event, "POST");
		await assertRateLimit(event, 1, 500);

		const body = await readBody(event);
		const { itemId, quantity = 1 } = body;

		const shopRef = firestore.collection("shop").doc("items");
		const walletRef = firestore.collection("wallets").doc(user.uid);
		const inventoryRef = firestore.collection("inventories").doc(user.uid);

		const [shopDoc, walletDoc] = await Promise.all([
			shopRef.get(),
			walletRef.get(),
		]);

		const items = shopDoc.data()?.items || [];
		const item = items.find((i: ShopItem) => i.id === itemId);

		if (!item) {
			throw createError({
				statusCode: 404,
				message: "Item not found",
			});
		}

		const wallet = walletDoc.data() as WalletData;
		if (!wallet) {
			throw createError({
				statusCode: 404,
				message: "Wallet not found",
			});
		}

		const totalCoinCost = (item.price.coins || 0) * quantity;
		const totalDiamondCost = (item.price.diamonds || 0) * quantity;

		if (
			(totalCoinCost > 0 && wallet.coins < totalCoinCost) ||
			(totalDiamondCost > 0 && wallet.diamonds < totalDiamondCost)
		) {
			throw createError({
				statusCode: 400,
				message: "Insufficient currency",
			});
		}

		const batch = firestore.batch();

		batch.update(walletRef, {
			coins: totalCoinCost > 0 ? wallet.coins - totalCoinCost : wallet.coins,
			diamonds:
				totalDiamondCost > 0
					? wallet.diamonds - totalDiamondCost
					: wallet.diamonds,
		});

		const purchasedItem = {
			...item,
			quantity,
		};

		const inventoryDoc = await inventoryRef.get();
		if (!inventoryDoc.exists) {
			batch.set(inventoryRef, { items: [purchasedItem] });
		} else {
			const currentItems = inventoryDoc.data()?.items || [];
			const existingItemIndex = currentItems.findIndex(
				(i: ShopItem) => i.id === itemId,
			);

			if (existingItemIndex > -1) {
				currentItems[existingItemIndex].quantity += quantity;
			} else {
				currentItems.push(purchasedItem);
			}

			batch.update(inventoryRef, { items: currentItems });
		}

		const transactionsRef = firestore.collection("transactions").doc();
		batch.set(transactionsRef, {
			id: transactionsRef.id,
			itemId,
			quantity,
			totalPrice: totalCoinCost || totalDiamondCost,
			currency: totalCoinCost > 0 ? "coins" : "diamonds",
			type: "purchase",
		});

		await batch.commit();

		return purchasedItem;
	},
);
