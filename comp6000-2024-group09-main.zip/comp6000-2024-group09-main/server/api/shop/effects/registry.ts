// server/api/shop/effects/registry.ts

import type { InventoryItem } from "~/types/backend/shop/item";
import type { ItemConsume } from "~/types/shop/consume";
import type { EffectContext, ItemEffect } from "~/types/shop/effects";

const effectRegistry = new Map<string, ItemEffect>();

effectRegistry.set("xpBoost", async (context) => {
	const progressRef = context.firestore
		.collection("progress")
		.doc(context.userId);
	const progressDoc = await progressRef.get();
	const progress = progressDoc.data();

	await progressRef.update({
		xp: (progress?.xp || 0) + 100,
	});

	return {
		message: "Applied XP boost of 100",
	};
});

effectRegistry.set("moneyBack", async (context) => {
	const walletRef = context.firestore.collection("wallets").doc(context.userId);
	const walletDoc = await walletRef.get();

	await walletRef.update({
		coins: (walletDoc.data()?.coins || 0) + 100,
	});

	return {
		message: "Refunded 100 coins",
	};
});

effectRegistry.set("applyTheme", async (context) => {
	const userRef = context.firestore.collection("users").doc(context.userId);
	const inventoryRef = context.firestore
		.collection("inventories")
		.doc(context.userId);
	const inventoryDoc = await inventoryRef.get();
	const currentItems = inventoryDoc.data()?.items || [];
	const themeItem = currentItems.find(
		(item: InventoryItem) => item.type === "theme",
	);

	if (!themeItem) {
		throw createError({
			statusCode: 400,
			message: "Invalid theme",
		});
	}

	await userRef.update({
		theme: themeItem.id,
	});

	return {
		message: `Applied theme: ${themeItem.id}`,
	};
});

effectRegistry.set("applyCursor", async (context) => {
	const userRef = context.firestore.collection("users").doc(context.userId);
	const inventoryRef = context.firestore
		.collection("inventories")
		.doc(context.userId);
	const inventoryDoc = await inventoryRef.get();
	const currentItems = inventoryDoc.data()?.items || [];
	const cursorItem = currentItems.find(
		(item: InventoryItem) => item.type === "cursor",
	);

	if (!cursorItem) {
		throw createError({
			statusCode: 400,
			message: "Invalid cursor",
		});
	}

	await userRef.update({
		cursor: cursorItem.id,
	});

	return {
		message: `Applied cursor: ${cursorItem.id}`,
	};
});

export const registerEffect = (id: string, effect: ItemEffect) => {
	effectRegistry.set(id, effect);
};

export const getEffect = (id: string): ItemEffect | undefined => {
	return effectRegistry.get(id);
};

export const executeItemEffect = async (
	context: EffectContext,
	itemId: string,
	inventoryDoc: FirebaseFirestore.DocumentSnapshot,
): Promise<ItemConsume> => {
	const currentItems = inventoryDoc.data()?.items || [];
	const itemIndex = currentItems.findIndex(
		(i: InventoryItem) => i.id === itemId,
	);
	const item = currentItems[itemIndex];

	if (itemIndex === -1 || item.quantity < 1) {
		console.log("Item not available in inventory");
		throw createError({
			statusCode: 400,
			message: "Item not available in inventory",
		});
	}

	if (!item.useFunction) {
		console.log("Item cannot be used");
		throw createError({
			statusCode: 400,
			message: "Item cannot be used",
		});
	}

	const effect = getEffect(item.useFunction);

	if (!effect) {
		console.log("Invalid item effect");
		throw createError({
			statusCode: 400,
			message: "Invalid item effect",
		});
	}

	const result = await effect(context);

	item.quantity -= 1;
	if (item.quantity === 0) {
		currentItems.splice(itemIndex, 1);
	}

	await context.firestore
		.collection("inventories")
		.doc(context.userId)
		.update({ items: currentItems });

	return {
		message: result.message,
		updatedItems: currentItems,
	};
};
