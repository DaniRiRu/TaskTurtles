import type { EventHandlerRequest } from "h3";
import {
	createModelHandler,
	verifyTokenBalance,
} from "~/server/utils/ai-service/modelHandler";
import {
	type TokenEstimateResult,
	estimateTokenCost,
} from "~/server/utils/ai-service/tokenHandler";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type { AI_MODELS } from "~/types/backend/ai-service/models";
import { FALLBACK_AI_MODEL } from "~/types/backend/ai-service/models";
import {
	type GenerateRequest,
	type GenerateResponse,
	INSUFFICIENT_TOKENS,
} from "~/types/backend/ai-service/requests";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<GenerateResponse>>
>(async (event): Promise<ApiResponse<GenerateResponse>> => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "POST");
	await assertRateLimit(event, 1, 500);

	if (!user) {
		throw createError({
			statusCode: 401,
			message: "Unauthorized",
		});
	}

	const body = await readBody<GenerateRequest>(event);

	if (!body.message) {
		throw createError({
			statusCode: 400,
			message: "Message is required",
		});
	}

	if (!body.context) {
		throw createError({
			statusCode: 400,
			message: "Context is required",
		});
	}

	try {
		const modelId = (body.model ??
			FALLBACK_AI_MODEL.id) as keyof typeof AI_MODELS;

		const firestore = event.context.firebase.firestore;

		const estimateCost = estimateTokenCost(
			body.message + body.context,
			modelId,
		) as TokenEstimateResult;

		const hasTokens = await verifyTokenBalance(
			firestore,
			user.uid,
			estimateCost.estimatedCost,
		);

		const emptyResponse = {
			text: "",
			model: "",
			tokenUsage: {
				total: 0,
				prompt: 0,
				completion: 0,
			},
			error: INSUFFICIENT_TOKENS,
		};

		if (!hasTokens && !body.stream) {
			return emptyResponse;
		}

		const modelHandler = createModelHandler(firestore, user.uid, modelId);

		if (body.stream) {
			setResponseHeader(event, "Content-Type", "text/event-stream");
			setResponseHeader(event, "Cache-Control", "no-cache");
			setResponseHeader(event, "Connection", "keep-alive");

			const stream = event.node.res;

			if (!hasTokens) {
				stream.write(
					`data: ${JSON.stringify({
						error: INSUFFICIENT_TOKENS,
					})}\n\n`,
				);
				stream.write("data: [DONE]\n\n");
				stream.end();
				return emptyResponse;
			}
			await modelHandler
				.generateStream(
					body.message,
					body.context,
					body.webSearch,
					body.webSearchOptions,
					(chunk) => {
						if (chunk.done) {
							stream.write("data: [DONE]\n\n");
						} else {
							stream.write(
								`data: ${JSON.stringify({
									text: chunk.text,
									annotations: chunk.annotations,
								})}\n\n`,
							);
						}
					},
				)
				.then(() => {
					stream.end();
				});

			return {
				text: "",
				model: "",
				tokenUsage: {
					total: 0,
					prompt: 0,
					completion: 0,
				},
			};
		}

		const response = await modelHandler.generate(
			body.message,
			body.context,
			body.webSearch,
			body.webSearchOptions,
			body.json,
		);
		return {
			text: response.text,
			model: modelId,
			tokenUsage: response.tokenUsage,
			annotations: response.annotations,
		};
	} catch (error) {
		console.error("Error generating AI response:", error);
		if (error instanceof Error) {
			throw createError({
				statusCode: 500,
				message: `${error.message}`,
			});
		}

		throw createError({
			statusCode: 500,
			message: "Unknown error",
		});
	}
});
