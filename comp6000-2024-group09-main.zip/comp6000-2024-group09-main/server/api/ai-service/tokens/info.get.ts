import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type { TokenInfoResponse } from "~/types/backend/ai-service/requests";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<TokenInfoResponse>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "GET");
	await assertRateLimit(event, 5, 1000);

	if (!user) {
		throw createError({
			statusCode: 401,
			message: "Unauthorized",
		});
	}

	try {
		const userTokensRef = firestore.collection("ai_tokens").doc(user.uid);
		const userTokensDoc = await userTokensRef.get();

		if (!userTokensDoc.exists) {
			const defaultTokens = {
				balance: 10000,
				usageHistory: [],
				createdAt: new Date().toISOString(),
				dailyLimit: 5000,
				resetDate: new Date(
					new Date().setDate(new Date().getDate() + 30),
				).toISOString(),
			};

			await userTokensRef.set(defaultTokens);

			return {
				balance: defaultTokens.balance,
				usageHistory: [],
				dailyLimit: defaultTokens.dailyLimit,
				resetDate: defaultTokens.resetDate,
				maxTokens: 10000,
			};
		}

		const userData = userTokensDoc.data() || {};

		return {
			balance: userData.balance || 0,
			usageHistory: userData.usageHistory || [],
			dailyLimit: userData.dailyLimit || 5000,
			resetDate:
				userData.resetDate ||
				new Date(new Date().setDate(new Date().getDate() + 30)).toISOString(),
			maxTokens: 10000,
		};
	} catch (error) {
		console.error("Error fetching token information:", error);
		throw createError({
			statusCode: 500,
			message: "Failed to fetch token information",
		});
	}
});
