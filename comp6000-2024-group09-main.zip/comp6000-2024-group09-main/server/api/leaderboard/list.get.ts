import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type {
	LeaderboardEntry,
	LeaderboardResults,
} from "~/types/backend/leaderboard/leaderboard";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<LeaderboardResults>>
>(async (event) => {
	const { firestore, auth, user } = event.context.firebase;

	assertMethod(event, "GET");
	await assertRateLimit(event, 1, 100);

	const progressCollection = firestore.collection("progress");
	await progressCollection.get();

	const progressSnapshot = await progressCollection.get();

	if (progressSnapshot.empty) {
		const leaderboardResults = {
			leaderboard: [],
			totalEntries: 0,
			userRank: 0,
			userScore: 0,
		} as LeaderboardResults;

		return leaderboardResults;
	}

	const userScores = progressSnapshot.docs.map((doc) => {
		const data = doc.data();
		return {
			userId: doc.id,
			score: data.score || 0,
		};
	});

	const sortedScores = userScores
		.sort((a, b) => b.score - a.score)
		.slice(0, 10);

	const leaderboardPromises = sortedScores.map(async (score) => {
		const userRecord = await auth.getUser(score.userId);

		const entry: LeaderboardEntry = {
			userId: score.userId,
			displayName: userRecord.displayName || "Anonymous",
			score: score.score,
			avatar: userRecord.photoURL || undefined,
			rank: 0,
		};

		return entry;
	});

	const leaderboardData = (await Promise.all(
		leaderboardPromises,
	)) as LeaderboardEntry[];

	const image = "https://api.dicebear.com/6.x/bottts/svg?seed=1";

	if (leaderboardData.length < 10) {
		for (let i = leaderboardData.length; i < 10; i++) {
			leaderboardData.push({
				userId: `dummyUser${i}`,
				displayName: `Dummy User ${i}`,
				score: Math.floor(Math.random() * 10),
				avatar: image,
				rank: 0,
			});
		}
	}

	leaderboardData.sort((a, b) => b.score - a.score);
	leaderboardData.forEach((entry, index) => {
		entry.rank = index + 1;
	});

	const userRank = leaderboardData.findIndex(
		(entry) => entry.userId === user?.uid,
	);

	const userScore = userScores.find((entry) => entry.userId === user?.uid);

	const leaderboardResults: LeaderboardResults = {
		leaderboard: leaderboardData.slice(0, 10),
		totalEntries: userScores.length,
		userRank: userRank !== -1 ? userRank + 1 : -1,
		userScore: userScore ? userScore.score : 0,
	};

	return leaderboardResults;
});
