import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type { PriorityAddResponse } from "~/types/backend/priorities/add";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<PriorityAddResponse>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "POST");
	await assertRateLimit(event, 1, 500);

	const { priority } = await readBody(event, {
		strict: true,
	});

	const id = priority.id;

	await firestore
		.collection("priorities")
		.doc(id)
		.update({
			...priority,
			updatedAt: new Date().toISOString(),
		});

	return {
		success: true,
	};
});
