import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type { PriorityAddResponse } from "~/types/backend/priorities/add";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<PriorityAddResponse>>
>(async (event) => {
	const firestore = event.context.firebase.firestore;

	assertMethod(event, "POST");
	await assertRateLimit(event, 1, 500);

	const { priority } = await readBody(event, {
		strict: true,
	});

	const id = priority.id;

	const tasksRef = firestore.collection("tasks");
	const tasksWithPriority = await tasksRef.where("priority", "==", id).get();

	const batch = firestore.batch();

	for (const doc of tasksWithPriority.docs) {
		const taskRef = tasksRef.doc(doc.id);
		batch.update(taskRef, {
			priority: null,
		});
	}

	batch.delete(firestore.collection("priorities").doc(id));
	await batch.commit();

	return {
		success: true,
	};
});
