import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type { PriorityListResponse } from "~/types/backend/priorities/list";
import type { Priority } from "~/types/core/priority";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<PriorityListResponse>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "GET");
	await assertRateLimit(event, 1, 500);

	const prioritiesCollection = await firestore
		.collection("priorities")
		.where("userId", "==", user.uid)
		.get();

	const priorities = prioritiesCollection.docs.map((doc) => {
		return {
			id: doc.id,
			...doc.data(),
		} as Priority;
	});

	return {
		priorities,
	};
});
