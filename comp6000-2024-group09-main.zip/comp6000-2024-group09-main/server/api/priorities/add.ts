import type { EventHandlerRequest } from "h3";
import z, { type ZodError } from "zod";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type { PriorityAddResponse } from "~/types/backend/priorities/add";

export const PriorityAddRequest = z.object({
	priority: z.object({
		title: z.string().min(1).max(100),
		color: z.string().regex(/^#[0-9A-Fa-f]{6}$/),
		int: z.number().int().min(0),
	}),
});

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<PriorityAddResponse>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "POST");
	await assertRateLimit(event, 1, 500);

	const body = await readBody(event, {
		strict: true,
	});

	const validatedBody = await PriorityAddRequest.parseAsync(body).catch(
		(error: ZodError) => {
			return {
				error,
			};
		},
	);

	if ("error" in validatedBody) {
		setResponseStatus(event, 400);

		return {
			error: validatedBody.error.toString(),
		};
	}

	await firestore.collection("priorities").add({
		...validatedBody.priority,
		userId: user.uid,
		createdAt: new Date().toISOString(),
	});

	return {
		success: true,
	};
});
