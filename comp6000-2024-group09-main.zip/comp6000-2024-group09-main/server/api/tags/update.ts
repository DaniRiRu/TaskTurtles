import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type { TagAddResponse } from "~/types/backend/tags/add";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<TagAddResponse>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "POST");
	await assertRateLimit(event, 1, 500);

	const { tag } = await readBody(event, {
		strict: true,
	});

	const id = tag.id;

	await firestore
		.collection("tags")
		.doc(id)
		.update({
			...tag,
			updatedAt: new Date().toISOString(),
		});

	return {
		success: true,
	};
});
