import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type { TagAddResponse } from "~/types/backend/tags/add";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<TagAddResponse>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "POST");
	await assertRateLimit(event, 1, 500);

	const body = await readBody(event, {
		strict: true,
	});

	await firestore.collection("tags").add({
		...body.tag,
		userId: user.uid,
		createdAt: new Date().toISOString(),
	});

	return {
		success: true,
	};
});
