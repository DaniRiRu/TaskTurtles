import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type { TagAddResponse } from "~/types/backend/tags/add";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<TagAddResponse>>
>(async (event) => {
	const firestore = event.context.firebase.firestore;

	assertMethod(event, "POST");
	await assertRateLimit(event, 1, 500);

	const { tag } = await readBody(event, {
		strict: true,
	});

	const id = tag.id;

	const tasksRef = firestore.collection("tasks");
	const tasksWithTag = await tasksRef.where("tags", "array-contains", id).get();

	const batch = firestore.batch();

	for (const doc of tasksWithTag.docs) {
		const taskRef = tasksRef.doc(doc.id);
		const currentTags = doc.data().tags || [];
		batch.update(taskRef, {
			tags: currentTags.filter((tagId: string) => tagId !== id),
		});
	}

	batch.delete(firestore.collection("tags").doc(id));
	await batch.commit();

	return {
		success: true,
	};
});
