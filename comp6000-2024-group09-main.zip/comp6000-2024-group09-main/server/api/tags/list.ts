import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type { TagListResponse } from "~/types/backend/tags/list";
import type { Tag } from "~/types/core/tag";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<TagListResponse>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "GET");
	await assertRateLimit(event, 1, 500);

	const tagsCollection = await firestore
		.collection("tags")
		.where("userId", "==", user.uid)
		.get();

	const tags = tagsCollection.docs.map((doc) => {
		return {
			id: doc.id,
			...doc.data(),
		} as Tag;
	});

	return {
		tags,
	};
});
