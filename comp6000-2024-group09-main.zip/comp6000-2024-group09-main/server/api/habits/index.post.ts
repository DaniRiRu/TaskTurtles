import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import { HABITS_COLLECTION, type HabitData } from "~/types/habits/habits";

import type { HabitsCreateResponse } from "~/types/backend/habits/response";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<HabitsCreateResponse>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "POST");
	await assertRateLimit(event, 1, 500);

	const userId = user.uid;

	if (!userId) {
		throw createError({
			statusCode: 401,
			message: "Unauthorized",
		});
	}

	const body = await readBody(event);
	const now = new Date().toISOString();

	const habitData: Omit<HabitData, "id"> = {
		...body,
		userId,
		createdAt: now,
		updatedAt: now,
		streak: 0,
		totalCompletions: 0,
		completionHistory: [],
		isArchived: false,
	};

	const userRef = firestore.collection(HABITS_COLLECTION).doc(userId);
	const userDoc = await userRef.get();

	if (!userDoc.exists) {
		await userRef.set({
			userId,
			createdAt: now,
		});
	}

	const docRef = await userRef.collection("habits").add(habitData);
	return { id: docRef.id, ...habitData };
});
