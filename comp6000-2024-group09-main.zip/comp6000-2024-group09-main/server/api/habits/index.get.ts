import { HABITS_COLLECTION, type HabitData } from "~/types/habits/habits";

import type { EventHandlerRequest } from "h3";
import type { ApiResponse } from "~/types/backend";
import type { HabitsGetResponse } from "~/types/backend/habits/response";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<HabitsGetResponse>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "GET");
	await assertRateLimit(event, 1, 500);

	const userId = user.uid;

	if (!userId) {
		throw createError({
			statusCode: 401,
			message: "Unauthorized",
		});
	}

	const userHabitsRef = firestore
		.collection(HABITS_COLLECTION)
		.doc(userId)
		.collection("habits");
	const snapshot = await userHabitsRef.get();

	const habits: HabitData[] = [];
	for (const doc of snapshot.docs) {
		habits.push({ id: doc.id, ...doc.data() } as HabitData);
	}

	return habits;
});
