import { HABITS_COLLECTION, type HabitData } from "~/types/habits/habits";

import type { EventHandlerRequest } from "h3";
import type { ApiResponse } from "~/types/backend";
import type { HabitGetResponse } from "~/types/backend/habits/response";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<HabitGetResponse>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "GET");
	await assertRateLimit(event, 1, 500);

	if (!event.context.params) {
		throw createError({
			statusCode: 400,
			message: "Missing habit ID parameter",
		});
	}

	const habitId = event.context.params.habitId;
	const userId = user.uid;

	if (!userId) {
		throw createError({
			statusCode: 401,
			message: "Unauthorized",
		});
	}

	const habitRef = firestore
		.collection(HABITS_COLLECTION)
		.doc(userId)
		.collection("habits")
		.doc(habitId);

	const habitDoc = await habitRef.get();

	if (!habitDoc.exists) {
		throw createError({
			statusCode: 404,
			message: "Habit not found",
		});
	}

	const habitData = habitDoc.data() as HabitData;

	return { habitData: { ...habitData, id: habitId } };
});
