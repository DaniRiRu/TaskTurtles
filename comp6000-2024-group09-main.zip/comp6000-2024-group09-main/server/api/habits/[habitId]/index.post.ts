import { HABITS_COLLECTION, type HabitData } from "~/types/habits/habits";

import type { EventHandlerRequest } from "h3";
import type { ApiResponse } from "~/types/backend";
import type { HabitUpdateResponse } from "~/types/backend/habits/response";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<HabitUpdateResponse>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "POST");
	await assertRateLimit(event, 1, 500);

	if (!event.context.params) {
		throw createError({
			statusCode: 400,
			message: "Missing habit ID parameter",
		});
	}

	const habitId = event.context.params.habitId;
	const userId = user.uid;

	if (!userId) {
		throw createError({
			statusCode: 401,
			message: "Unauthorized",
		});
	}

	const habitRef = firestore
		.collection(HABITS_COLLECTION)
		.doc(userId)
		.collection("habits")
		.doc(habitId);

	const habitDoc = await habitRef.get();

	if (!habitDoc.exists) {
		throw createError({
			statusCode: 404,
			message: "Habit not found",
		});
	}

	const habitData = habitDoc.data() as HabitData;

	const body = await readBody(event);
	const updatedData = {
		...body,
		updatedAt: new Date().toISOString(),
	};

	await habitRef.update(updatedData);
	return { habitData: { ...habitData, ...updatedData, id: habitId } };
});
