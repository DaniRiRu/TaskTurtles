import type { EventHandlerRequest } from "h3";
import type { ApiResponse } from "~/types/backend";
import type { HabitCompleteResponse } from "~/types/backend/habits/response";
import {
	HABITS_COLLECTION,
	HABIT_COMPLETIONS_COLLECTION,
	type HabitCompletion,
	type HabitData,
} from "~/types/habits/habits";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<HabitCompleteResponse>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "POST");
	await assertRateLimit(event, 1, 500);

	if (!event.context.params) {
		throw createError({
			statusCode: 400,
			message: "Missing habit ID parameter",
		});
	}

	const habitId = event.context.params.habitId;
	const userId = user.uid;

	if (!userId) {
		throw createError({
			statusCode: 401,
			message: "Unauthorized",
		});
	}

	const habitDoc = await firestore
		.collection(HABITS_COLLECTION)
		.doc(userId)
		.collection("habits")
		.doc(habitId)
		.get();

	if (!habitDoc.exists) {
		throw createError({
			statusCode: 404,
			message: "Habit not found",
		});
	}

	const habitData = habitDoc.data() as HabitData;

	const body = await readBody(event);
	const now = new Date().toISOString();

	const completionId = crypto.randomUUID();
	const completion: HabitCompletion = {
		id: completionId,
		habitId,
		userId,
		completedAt: now,
		note: body.note || "",
		mood: body.mood || 0,
	};

	const userCompletionsRef = firestore
		.collection(HABIT_COMPLETIONS_COLLECTION)
		.doc(userId);

	const completionRef = userCompletionsRef
		.collection("completions")
		.doc(completionId);

	const habitRef = firestore
		.collection(HABITS_COLLECTION)
		.doc(userId)
		.collection("habits")
		.doc(habitId);

	const updatedHabitData: HabitData = {
		...habitData,
		id: habitId,
		lastCompletedAt: now,
		totalCompletions: (habitData.totalCompletions || 0) + 1,
		completionHistory: [...(habitData.completionHistory || []), completion],
	};

	try {
		await firestore.runTransaction(async (transaction) => {
			const userCompletionsDoc = await userCompletionsRef.get();
			if (!userCompletionsDoc.exists) {
				transaction.set(userCompletionsRef, {
					userId,
					createdAt: now,
				});
			}

			transaction.set(completionRef, completion);
			transaction.update(habitRef, {
				lastCompletedAt: updatedHabitData.lastCompletedAt,
				totalCompletions: updatedHabitData.totalCompletions,
				completionHistory: updatedHabitData.completionHistory,
			});
		});

		return {
			completion,
			habitData: updatedHabitData,
		};
	} catch (error) {
		throw createError({
			statusCode: 500,
			message: "Failed to complete habit",
		});
	}
});
