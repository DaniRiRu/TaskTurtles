import type { EventHandlerRequest } from "h3";
import type { ApiResponse } from "~/types/backend";
import type { HabitDeleteResponse } from "~/types/backend/habits/response";
import { HABITS_COLLECTION } from "~/types/habits/habits";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<HabitDeleteResponse>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "DELETE");
	await assertRateLimit(event, 1, 500);

	if (!event.context.params) {
		throw createError({
			statusCode: 400,
			message: "Missing habit ID parameter",
		});
	}

	const habitId = event.context.params.habitId;
	const userId = user.uid;

	if (!userId) {
		throw createError({
			statusCode: 401,
			message: "Unauthorized",
		});
	}

	const habitRef = firestore
		.collection(HABITS_COLLECTION)
		.doc(userId)
		.collection("habits")
		.doc(habitId);

	const habitDoc = await habitRef.get();

	if (!habitDoc.exists) {
		throw createError({
			statusCode: 404,
			message: "Habit not found",
		});
	}

	await habitRef.delete();
	return { message: "Habit deleted successfully" };
});
