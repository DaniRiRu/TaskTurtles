import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import {
	EMPTY_PROGRESS,
	type UserProgress,
} from "~/types/backend/meta/progress";
import { type Reward, RewardType } from "~/types/backend/rewards/rewards";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<Reward>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "POST");
	await assertRateLimit(event, 1, 100);

	const progressRef = firestore.collection("progress").doc(user.uid);
	const progressDoc = await progressRef.get();

	if (!progressDoc.exists) {
		const initialProgress: UserProgress = EMPTY_PROGRESS;
		await progressRef.set(initialProgress);
	}

	const progress = progressDoc.data() as UserProgress;

	const now = new Date().toISOString().split("T")[0];
	const lastClaimedGift = progress.lastClaimedGift || now;
	const lastClaimedDate = new Date(lastClaimedGift);
	const currentDate = new Date(now);
	const diffTime = Math.abs(currentDate.getTime() - lastClaimedDate.getTime());
	const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

	if (diffDays < 1) {
		const result = (await giveReward(
			firestore,
			user.uid,
			RewardType.DAILY_LOGIN_STREAK,
		)) as RewardResult;

		progressRef.update({
			lastClaimedGift: now,
		});

		console.log(result);

		return result.reward as Reward;
	}

	return {
		error: "true",
		message: "You have already claimed your daily reward today.",
		code: 400,
	};
});
