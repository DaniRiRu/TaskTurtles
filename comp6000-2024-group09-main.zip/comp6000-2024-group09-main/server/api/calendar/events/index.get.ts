import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import { parseICalData } from "~/server/utils/parseICalData";
import type { ApiResponse } from "~/types/backend";
import type { CalendarProvider } from "~/types/backend/calendar/response";
import type { AnyCalendarEvent } from "~/types/calendar/events";
interface GetAllCalendarEventsResponse {
	events: AnyCalendarEvent[];
}

const SUPPORTED_PROVIDERS: CalendarProvider[] = [
	"google",
	"outlook",
	"ical",
	"custom",
];

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<GetAllCalendarEventsResponse>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "GET");
	await assertRateLimit(event, 50, 1000);

	const userRef = firestore.doc(`users/${user.uid}`);
	const userDoc = await userRef.get();

	if (!userDoc.exists) {
		await userRef.set({
			createdAt: new Date(),
			updatedAt: new Date(),
		});
	}

	const allEvents: AnyCalendarEvent[] = [];

	for (const provider of SUPPORTED_PROVIDERS) {
		const eventsRef = firestore.collection(
			`users/${user.uid}/calendar/${provider}/events`,
		);

		const snapshot = await eventsRef.get();

		const providerEvents = snapshot.docs.map((doc) => ({
			id: doc.id,
			...doc.data(),
			provider,
		})) as AnyCalendarEvent[];

		allEvents.push(...providerEvents);
	}

	try {
		const icalResponse = await fetch(
			"https://www.kent.ac.uk/timetabling/ical/220705.ics",
		);

		if (!icalResponse.ok) {
			throw new Error(`Failed to fetch iCal: ${icalResponse.statusText}`);
		}

		const icalData = await icalResponse.text();
		const icalEvents = parseICalData(icalData);
		allEvents.push(...icalEvents);
	} catch (error) {
		console.error("Failed to fetch or parse iCal events:", error);
	}

	const sortedEvents = allEvents.sort((a, b) => {
		const dateA = new Date(a.start.dateTime || a.start.date || "");
		const dateB = new Date(b.start.dateTime || b.start.date || "");
		return dateA.getTime() - dateB.getTime();
	});

	return {
		events: sortedEvents,
	};
});
