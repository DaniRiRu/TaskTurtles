import type { EventHandlerRequest } from "h3";
import z from "zod";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type {
	CalendarProvider,
	CalendarSyncResponse,
} from "~/types/backend/calendar/response";
import type { AnyCalendarEvent } from "~/types/calendar/events";

const CalendarEventSchema = z.object({
	id: z.string(),
	summary: z.string(),
	description: z.string().optional(),
	start: z.object({
		dateTime: z.string().optional(),
		date: z.string().optional(),
		timeZone: z.string().optional(),
	}),
	end: z.object({
		dateTime: z.string().optional(),
		date: z.string().optional(),
		timeZone: z.string().optional(),
	}),
	status: z.string(),
	htmlLink: z.string().optional(),
	provider: z.string().optional(),
	recurrence: z.array(z.string()).optional(),
	recurringEventId: z.string().optional(),
	originalStartTime: z
		.object({
			dateTime: z.string().optional(),
			date: z.string().optional(),
			timeZone: z.string().optional(),
		})
		.optional(),
});

const SyncEventsSchema = z.object({
	events: z.array(CalendarEventSchema),
});

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<CalendarSyncResponse>>
>(async (event) => {
	console.log("[Calendar Sync] Starting calendar sync");
	const { firestore, user } = event.context.firebase;
	const provider = getRouterParam(event, "provider") as CalendarProvider;

	console.log(`[Calendar Sync] Provider: ${provider}`);
	console.log(`[Calendar Sync] User ID: ${user.uid}`);

	assertMethod(event, "POST");
	await assertRateLimit(event, 2, 1000);

	if (!provider) {
		console.error("[Calendar Sync] No provider specified");
		throw createError({
			statusCode: 400,
			message: "Provider is required",
		});
	}

	console.log("[Calendar Sync] Reading request body");
	const body = await readBody(event);

	console.log("[Calendar Sync] Validating request body");
	const validatedBody = await SyncEventsSchema.parseAsync(body).catch(
		(error: z.ZodError) => ({
			error,
		}),
	);

	if ("error" in validatedBody) {
		console.error("[Calendar Sync] Validation error:", validatedBody.error);
		throw createError({
			statusCode: 400,
			message: validatedBody.error.toString(),
		});
	}

	console.log(
		`[Calendar Sync] Processing ${validatedBody.events.length} events`,
	);

	const userRef = firestore.doc(`users/${user.uid}`);
	console.log("[Calendar Sync] Checking user document");
	const userDoc = await userRef.get();

	if (!userDoc.exists) {
		console.log("[Calendar Sync] Creating new user document");
		await userRef.set({
			createdAt: new Date(),
			updatedAt: new Date(),
		});
	}

	console.log(
		`[Calendar Sync] Processing ${validatedBody.events.length} events`,
	);

	const batch = firestore.batch();
	const eventsCollectionRef = firestore.collection(
		`users/${user.uid}/calendar/${provider}/events`,
	);

	console.log("[Calendar Sync] Starting batch write");
	const events = validatedBody.events as AnyCalendarEvent[];
	for (const event of events) {
		console.log(`[Calendar Sync] Processing event: ${event.id}`);
		const eventRef = eventsCollectionRef.doc(event.id);
		batch.set(
			eventRef,
			{
				...event,
				provider,
				updatedAt: new Date(),
				syncedAt: new Date(),
			},
			{ merge: true },
		);
	}

	console.log("[Calendar Sync] Committing batch");
	await batch.commit();

	console.log("[Calendar Sync] Sync completed successfully");
	return {
		count: events.length,
	};
});
