import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type { CalendarProvider } from "~/types/backend/calendar/response";
import type { AnyCalendarEvent } from "~/types/calendar/events";

interface GetCalendarEventsResponse {
	events: AnyCalendarEvent[];
}

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<GetCalendarEventsResponse>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;
	const provider = getRouterParam(event, "provider") as CalendarProvider;

	assertMethod(event, "GET");
	await assertRateLimit(event, 50, 1000);

	const userRef = firestore.doc(`users/${user.uid}`);
	const userDoc = await userRef.get();

	if (!userDoc.exists) {
		await userRef.set({
			createdAt: new Date(),
			updatedAt: new Date(),
		});
	}

	const eventsRef = firestore.collection(
		`users/${user.uid}/calendar/${provider}/events`,
	);
	const snapshot = await eventsRef.get();

	const events = snapshot.docs.map((doc) => ({
		id: doc.id,
		...doc.data(),
		provider,
	})) as AnyCalendarEvent[];

	return {
		events,
	};
});
