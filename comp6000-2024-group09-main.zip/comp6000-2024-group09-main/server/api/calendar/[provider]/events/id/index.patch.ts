import type { EventHandlerRequest } from "h3";
import z from "zod";
import { assertContentType, assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type {
	CalendarEventResponse,
	CalendarProvider,
} from "~/types/backend/calendar/response";

const UpdateEventSchema = z.object({
	updates: z.object({
		summary: z.string().optional(),
		description: z.string().optional(),
		start: z
			.object({
				dateTime: z.string(),
				timeZone: z.string().optional(),
			})
			.optional(),
		end: z
			.object({
				dateTime: z.string(),
				timeZone: z.string().optional(),
			})
			.optional(),
		status: z.string().optional(),
	}),
});

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<CalendarEventResponse>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;
	const provider = getRouterParam(event, "provider") as CalendarProvider;
	const eventId = getRouterParam(event, "id");

	assertMethod(event, "PATCH");
	assertContentType(event, "application/json");
	await assertRateLimit(event, 5, 1000);

	if (!eventId) {
		throw createError({
			statusCode: 400,
			message: "Event ID is required",
		});
	}

	const body = await readBody(event);
	const validatedBody = await UpdateEventSchema.parseAsync(body).catch(
		(error: z.ZodError) => ({
			error,
		}),
	);

	if ("error" in validatedBody) {
		throw createError({
			statusCode: 400,
			message: validatedBody.error.toString(),
		});
	}

	const eventRef = firestore.doc(
		`users/${user.uid}/${provider}/events/${eventId}`,
	);
	await eventRef.update({
		...validatedBody.updates,
		updatedAt: new Date(),
	});

	return {
		eventId,
	};
});
