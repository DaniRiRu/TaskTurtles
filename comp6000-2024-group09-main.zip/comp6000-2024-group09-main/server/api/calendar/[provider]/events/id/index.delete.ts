import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type {
	CalendarEventResponse,
	CalendarProvider,
} from "~/types/backend/calendar/response";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<CalendarEventResponse>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;
	const provider = getRouterParam(event, "provider") as CalendarProvider;
	const eventId = getRouterParam(event, "id");

	assertMethod(event, "DELETE");
	await assertRateLimit(event, 5, 1000);

	if (!eventId) {
		throw createError({
			statusCode: 400,
			message: "Event ID is required",
		});
	}

	const eventRef = firestore.doc(
		`users/${user.uid}/${provider}/events/${eventId}`,
	);
	await eventRef.delete();

	return {
		eventId,
	};
});
