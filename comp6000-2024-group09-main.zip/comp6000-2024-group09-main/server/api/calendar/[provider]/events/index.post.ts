import type { EventHandlerRequest } from "h3";
import z from "zod";
import { assertContentType, assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type {
	CalendarEventResponse,
	CalendarProvider,
} from "~/types/backend/calendar/response";

const CalendarEventDateTimeSchema = z
	.object({
		dateTime: z.string().optional(),
		date: z.string().optional(),
		timeZone: z.string().optional(),
	})
	.refine((data) => data.dateTime || data.date, {
		message: "Either dateTime or date must be provided",
	});

const CalendarAttendeeSchema = z.object({
	email: z.string().email(),
	displayName: z.string().optional(),
	responseStatus: z
		.enum(["accepted", "tentative", "declined", "needsAction"])
		.optional(),
});

const CalendarEventSchema = z.object({
	event: z
		.object({
			id: z.string(),
			provider: z.enum(["google", "outlook", "ical", "custom"]),
			summary: z.string(),
			description: z.string().optional(),
			start: CalendarEventDateTimeSchema,
			end: CalendarEventDateTimeSchema,
			status: z.enum(["confirmed", "tentative", "cancelled"]),
			location: z.string().optional(),
			url: z.string().optional(),
			attendees: z.array(CalendarAttendeeSchema).optional(),
			createdAt: z
				.string()
				.transform((str) => new Date(str))
				.optional(),
			updatedAt: z
				.string()
				.transform((str) => new Date(str))
				.optional(),
			syncedAt: z
				.string()
				.transform((str) => new Date(str))
				.optional(),
			htmlLink: z.string().optional(),
			webLink: z.string().optional(),
			uid: z.string().optional(),
		})
		.refine(
			(data) => {
				if (data.provider === "google" && !data.htmlLink) {
					return false;
				}
				if (data.provider === "outlook" && !data.webLink) {
					return false;
				}
				if (data.provider === "ical" && !data.uid) {
					return false;
				}
				return true;
			},
			{
				message: "Provider-specific fields are required",
			},
		),
});

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<CalendarEventResponse>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;
	const provider = getRouterParam(event, "provider") as CalendarProvider;

	assertMethod(event, "POST");
	assertContentType(event, "application/json");
	await assertRateLimit(event, 5, 1000);

	const userRef = firestore.doc(`users/${user.uid}`);
	const userDoc = await userRef.get();

	if (!userDoc.exists) {
		await userRef.set({
			createdAt: new Date(),
			updatedAt: new Date(),
		});
	}

	console.log(`[Calendar Event] Provider: ${provider}`);
	const body = await readBody(event);
	console.log("[Calendar Event] Reading request body: ", body);
	const validatedBody = await CalendarEventSchema.parseAsync(body).catch(
		(error: z.ZodError) => ({
			error,
		}),
	);
	console.log("[Calendar Event] Validating request body: ", validatedBody);

	if ("error" in validatedBody) {
		throw createError({
			statusCode: 400,
			message: validatedBody.error.toString(),
		});
	}

	console.log("[Calendar Event] Writing event to database");

	if (validatedBody.event.provider !== provider) {
		throw createError({
			statusCode: 400,
			message: "Event provider does not match endpoint provider",
		});
	}

	const now = new Date();
	const eventRef = firestore.doc(
		`users/${user.uid}/calendar/${provider}/events/${validatedBody.event.id}`,
	);

	await eventRef.set({
		...validatedBody.event,
		createdAt: validatedBody.event.createdAt || now,
		updatedAt: now,
		syncedAt: validatedBody.event.syncedAt || now,
	});

	return {
		eventId: validatedBody.event.id,
	};
});
