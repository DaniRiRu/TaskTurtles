import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type {
	CalendarConnectionResponse,
	CalendarConnectionsResponse,
	CalendarProvider,
} from "~/types/backend/calendar/response";

const SUPPORTED_PROVIDERS: CalendarProvider[] = ["google", "outlook", "ical"];

const createDefaultConnections = (): CalendarConnectionsResponse => {
	const connections = {} as CalendarConnectionsResponse;
	SUPPORTED_PROVIDERS.map((provider) => {
		connections[provider] = {
			isConnected: false,
			lastSync: null,
			connectionUrl: null,
		};
	});
	return connections;
};

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<CalendarConnectionResponse>>
>(async (event) => {
	console.log("[Calendar Connection Create] Starting connection creation");
	const { firestore, user } = event.context.firebase;
	const provider = getRouterParam(event, "provider") as CalendarProvider;
	const body = await readBody(event);

	console.log(`[Calendar Connection Create] Provider: ${provider}`);
	console.log(`[Calendar Connection Create] User ID: ${user.uid}`);

	assertMethod(event, "POST");
	await assertRateLimit(event, 5, 1000);

	const userRef = firestore.doc(`users/${user.uid}`);
	const connectionsRef = firestore.doc(
		`users/${user.uid}/calendar/connections`,
	);

	console.log("[Calendar Connection Create] Checking user document");
	const userDoc = await userRef.get();
	if (!userDoc.exists) {
		console.log("[Calendar Connection Create] Creating new user document");
		await userRef.set({
			createdAt: new Date(),
			updatedAt: new Date(),
		});
	}

	console.log("[Calendar Connection Create] Fetching existing connections");
	const connectionsDoc = await connectionsRef.get();
	const connections: CalendarConnectionsResponse = connectionsDoc.exists
		? (connectionsDoc.data() as CalendarConnectionsResponse)
		: createDefaultConnections();

	console.log("[Calendar Connection Create] Creating new connection");
	const newConnection: CalendarConnectionResponse = {
		isConnected: true,
		lastSync: new Date(),
		connectionUrl: body.connectionUrl || null,
	};

	console.log("[Calendar Connection Create] Saving new connection");
	connections[provider] = newConnection;

	console.log("[Calendar Connection Create] Saving updated connections");
	await connectionsRef.set(connections);

	console.log("[Calendar Connection Create] Connection created successfully");
	return newConnection;
});
