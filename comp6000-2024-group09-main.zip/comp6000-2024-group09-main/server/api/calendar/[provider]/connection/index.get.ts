import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type {
	CalendarConnectionResponse,
	CalendarConnectionsResponse,
	CalendarProvider,
} from "~/types/backend/calendar/response";

const SUPPORTED_PROVIDERS: CalendarProvider[] = ["google", "outlook", "ical"];

const createDefaultConnection = (): CalendarConnectionResponse => ({
	isConnected: false,
	lastSync: null,
	connectionUrl: null,
});

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<CalendarConnectionResponse>>
>(async (event) => {
	console.log("[Calendar Connection Get] Starting connection fetch");
	const { firestore, user } = event.context.firebase;
	const provider = getRouterParam(event, "provider") as CalendarProvider;

	console.log(`[Calendar Connection Get] Provider: ${provider}`);
	console.log(`[Calendar Connection Get] User ID: ${user.uid}`);

	assertMethod(event, "GET");
	await assertRateLimit(event, 10, 1000);

	const userRef = firestore.doc(`users/${user.uid}`);
	const connectionsRef = firestore.doc(
		`users/${user.uid}/calendar/connections`,
	);

	console.log("[Calendar Connection Get] Checking user document");
	const userDoc = await userRef.get();
	if (!userDoc.exists) {
		console.log("[Calendar Connection Get] Creating new user document");
		await userRef.set({
			createdAt: new Date(),
			updatedAt: new Date(),
		});
	}

	console.log("[Calendar Connection Get] Fetching connections");
	const connectionsDoc = await connectionsRef.get();
	if (!connectionsDoc.exists) {
		console.log(
			"[Calendar Connection Get] No connections found, returning default",
		);
		return createDefaultConnection();
	}

	const connections = connectionsDoc.data() as CalendarConnectionsResponse;
	console.log("[Calendar Connection Get] Connection retrieved successfully");
	return connections[provider] || createDefaultConnection();
});
