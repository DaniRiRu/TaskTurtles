import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type {
	CalendarConnectionResponse,
	CalendarConnectionsResponse,
	CalendarProvider,
} from "~/types/backend/calendar/response";

const SUPPORTED_PROVIDERS: CalendarProvider[] = [
	"google",
	"outlook",
	"ical",
	"custom",
];

const createDefaultConnection = (): CalendarConnectionResponse => ({
	isConnected: false,
	lastSync: null,
	connectionUrl: null,
});

const createDefaultConnections = (): CalendarConnectionsResponse => {
	const connections = {} as CalendarConnectionsResponse;
	SUPPORTED_PROVIDERS.map((provider) => {
		connections[provider] = createDefaultConnection();
	});
	return connections;
};

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<CalendarConnectionResponse>>
>(async (event) => {
	console.log("[Calendar Connection Delete] Starting connection deletion");
	const { firestore, user } = event.context.firebase;
	const provider = getRouterParam(event, "provider") as CalendarProvider;

	console.log(`[Calendar Connection Delete] Provider: ${provider}`);
	console.log(`[Calendar Connection Delete] User ID: ${user.uid}`);

	assertMethod(event, "DELETE");
	await assertRateLimit(event, 5, 1000);

	const userRef = firestore.doc(`users/${user.uid}`);
	const connectionsRef = firestore.doc(
		`users/${user.uid}/calendar/connections`,
	);

	console.log("[Calendar Connection Delete] Checking user document");
	const userDoc = await userRef.get();
	if (!userDoc.exists) {
		console.log("[Calendar Connection Delete] Creating new user document");
		await userRef.set({
			createdAt: new Date(),
			updatedAt: new Date(),
		});
	}

	console.log("[Calendar Connection Delete] Fetching connections");
	const connectionsDoc = await connectionsRef.get();
	if (connectionsDoc.exists) {
		console.log("[Calendar Connection Delete] Updating connections");
		const connections = connectionsDoc.data() as CalendarConnectionsResponse;
		connections[provider] = createDefaultConnection();
		await connectionsRef.set(connections);
	} else {
		console.log(
			"[Calendar Connection Delete] No connections found, creating default",
		);
		await connectionsRef.set(createDefaultConnections());
	}

	console.log("[Calendar Connection Delete] Connection deleted successfully");
	return createDefaultConnection();
});
