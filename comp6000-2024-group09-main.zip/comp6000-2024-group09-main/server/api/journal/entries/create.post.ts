import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type {
	JournalCreateRequest,
	JournalCreateResponse,
} from "~/types/backend/journal/create";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<JournalCreateResponse>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	console.log("Creating journal entry for user:", user.uid);

	assertMethod(event, "POST");
	await assertRateLimit(event, 1, 500);

	const body = await readBody<JournalCreateRequest>(event);

	const userCollection = firestore.collection("users").doc(user.uid);

	if (!userCollection) {
		await firestore.collection("users").doc(user.uid).set({});
	}

	const journalCollection = userCollection.collection("journal");
	if (!journalCollection) {
		await userCollection.collection("journal").doc(body.entry.date).set({});
	}

	const journalEntry = journalCollection.doc(body.entry.date);
	if (!journalEntry) {
		await journalCollection.doc(body.entry.date).set({});
	}

	await journalEntry.set({
		content: body.entry.content,
		ideas: body.entry.ideas,
		goals: body.entry.goals,
		actionItems: body.entry.actionItems,
	});

	return {
		success: true,
	};
});
