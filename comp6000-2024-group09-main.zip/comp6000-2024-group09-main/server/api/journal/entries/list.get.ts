import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type { JournalListResponse } from "~/types/backend/journal/list";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<JournalListResponse>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "GET");
	await assertRateLimit(event, 1, 500);

	const userCollection = firestore.collection("users").doc(user.uid);

	if (!userCollection) {
		await firestore.collection("users").doc(user.uid).set({});
	}

	const journalCollection = userCollection.collection("journal");
	if (!journalCollection) {
		await userCollection.collection("journal").doc("initial").set({});
	}

	const journalSnapshot = await journalCollection.get();

	const entries = journalSnapshot.docs.map((doc) => ({
		id: doc.id,
		date: doc.id,
		content: doc.data().content || "",
		ideas: doc.data().ideas || [],
		goals: doc.data().goals || [],
		actionItems: doc.data().actionItems || [],
	}));

	return { entries } as JournalListResponse;
});
