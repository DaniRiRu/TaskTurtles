import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { StoredUser } from "~/types/core/user";

export default defineEventHandler<EventHandlerRequest>(
	async (event): Promise<StoredUser> => {
		const { firestore, user } = event.context.firebase;

		assertMethod(event, "GET");
		await assertRateLimit(event, 1, 500);

		if (!user) {
			throw createError({ statusCode: 401, message: "Unauthorized" });
		}

		const userRef = firestore.collection("users").doc(user.uid);
		const userDoc = await userRef.get();

		if (!userDoc.exists) {
			throw createError({ statusCode: 404, message: "User profile not found" });
		}

		const userProfile: StoredUser = userDoc.data() as StoredUser;
		return userProfile;
	},
);
