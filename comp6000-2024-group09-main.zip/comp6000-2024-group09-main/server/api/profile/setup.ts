import type { EventHandlerRequest } from "h3";
import z, { type ZodError, type ZodType } from "zod";
import { assertContentType, assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type { ProfileSetupResponse } from "~/types/backend/profile/setup";
import type { StoredUser } from "~/types/core/user";

const GenderEnum = z.enum(["Male", "Female", "Other"]);

export const ProfileSetupRequest = z.object({
	user: z.object({
		name: z.string().min(3).max(64),
		username: z.string().min(3).max(32),
		gender: GenderEnum,
		pronouns: z.string().min(1).max(32),
		dob: z.date({
			coerce: true,
		}),
		occupation: z.string().min(1).max(64),
		weeklyHours: z.number().int().min(0).max(168),
		banner: z.string().min(0).max(100).optional(),
	}) satisfies ZodType<StoredUser>,
});

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<ProfileSetupResponse>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "POST");
	assertContentType(event, "application/json");
	await assertRateLimit(event, 1, 1000);

	const body = await readBody(event, {
		strict: true,
	});

	const validatedBody = await ProfileSetupRequest.parseAsync(body).catch(
		(error: ZodError) => {
			return {
				error,
			};
		},
	);

	if ("error" in validatedBody) {
		setResponseStatus(event, 400);

		return {
			error: validatedBody.error.toString(),
		};
	}

	const doc = firestore.doc(`profile/${user.uid}`);

	await doc.set(validatedBody.user);

	return {
		success: true,
	};
});
