import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type { TaskListResponse } from "~/types/backend/tasks/list";
import type { Priority } from "~/types/core/priority";
import type { Tag } from "~/types/core/tag";
import type { TaskStatus } from "~/types/core/task";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<TaskListResponse>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;
	assertMethod(event, "GET");
	await assertRateLimit(event, 1, 500);

	const [tasks, tags, priorities] = await Promise.all([
		firestore.collection("tasks").where("userId", "==", user.uid).get(),
		firestore.collection("tags").where("userId", "==", user.uid).get(),
		firestore.collection("priorities").where("userId", "==", user.uid).get(),
	]);

	const tagMap = new Map(
		tags.docs.map(
			(doc) => [doc.id, { id: doc.id, ...doc.data() }] as [string, Tag],
		),
	);

	const priorityMap = new Map(
		priorities.docs.map(
			(doc) => [doc.id, { id: doc.id, ...doc.data() }] as [string, Priority],
		),
	);

	const result = new Array(tasks.size);

	for (let i = 0; i < tasks.size; i++) {
		const doc = tasks.docs[i];
		const data = doc.data();
		const priorityId = data.priority?.split("/").pop();
		const mappedTags = [];

		if (data.tags) {
			for (const ref of data.tags) {
				if (!ref) continue;
				const tag = tagMap.get(ref.split("/").pop()!);
				if (tag) mappedTags.push(tag);
			}
		}

		result[i] = {
			id: doc.id,
			title: data.title,
			description: data.description,
			dueDate: data.dueDate,
			status: data.status as TaskStatus,
			priority: priorityId ? priorityMap.get(priorityId) : undefined,
			tags: mappedTags,
		};
	}

	return { tasks: result };
});
