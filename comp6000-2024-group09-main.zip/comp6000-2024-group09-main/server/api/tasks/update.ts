import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type { TaskAddResponse } from "~/types/backend/tasks/add";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<TaskAddResponse>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "POST");
	await assertRateLimit(event, 1, 500);

	const { task } = await readBody(event, {
		strict: true,
	});

	const id = task.id;

	await firestore
		.collection("tasks")
		.doc(id)
		.update({
			...task,
			updatedAt: new Date().toISOString(),
		});

	return {
		success: true,
	};
});
