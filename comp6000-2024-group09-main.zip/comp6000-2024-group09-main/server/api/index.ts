import type { EventHandlerRequest } from "h3";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<{
		hello: string;
	}>
>(async () => {
	return {
		hello: "world",
	};
});
