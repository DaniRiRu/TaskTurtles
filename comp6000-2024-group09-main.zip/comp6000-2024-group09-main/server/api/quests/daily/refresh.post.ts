import type { EventHandlerRequest } from "h3";
import { generateDailyQuests, getNextRefreshTime } from "~/server/utils/quests";
import type { ApiResponse } from "~/types/backend";
import type { QuestDocument } from "~/types/quests/quests";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<void>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "POST");
	await assertRateLimit(event, 5, 100);

	const questsRef = firestore.collection("quests").doc(user.uid);

	const doc = await questsRef.get();
	if (!doc.exists) {
		throw createError({
			status: 404,
			message: "Quests document not found",
		});
	}

	const data = doc.data() as QuestDocument;

	const nextRefresh = getNextRefreshTime();

	const filteredQuests = data.quests.filter((quest) => quest.type !== "daily");
	const newDailyQuests = generateDailyQuests(firestore, user.uid);

	const newQuests = [...filteredQuests, ...(await newDailyQuests)];

	console.log(newQuests);

	await questsRef.update({
		quests: newQuests,
		dailyRefreshedAt: new Date().toISOString(),
		nextDailyRefresh: nextRefresh.toISOString(),
		lastUpdated: new Date().toISOString(),
	});
});
