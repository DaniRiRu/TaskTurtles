import type { EventHandlerRequest } from "h3";
import type { ApiResponse } from "~/types/backend";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<void>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "POST");
	await assertRateLimit(event, 5, 100);

	const body = await readBody(event);
	const questsRef = firestore.collection("quests").doc(user.uid);

	const doc = await questsRef.get();
	const existingData = doc.exists ? doc.data() : {};

	await questsRef.set({
		...existingData,
		quests: body.quests,
		lastUpdated: new Date().toISOString(),
	});
});
