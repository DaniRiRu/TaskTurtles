import type { EventHandlerRequest } from "h3";
import type { ApiResponse } from "~/types/backend";
import type { QuestDocument } from "~/types/quests/quests";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<QuestDocument>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "GET");
	await assertRateLimit(event, 10, 1000);

	const archivedQuestsRef = firestore
		.collection("archived_quests")
		.doc(user.uid);
	const doc = await archivedQuestsRef.get();

	if (!doc.exists) {
		return {
			quests: [],
			lastUpdated: new Date().toISOString(),
		} as QuestDocument;
	}

	return doc.data() as QuestDocument;
});
