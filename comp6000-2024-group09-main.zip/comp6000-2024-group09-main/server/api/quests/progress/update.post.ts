import type { EventHandlerRequest } from "h3";
import type { ApiResponse } from "~/types/backend";
import type { QuestDocument } from "~/types/quests/quests";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<void>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "POST");
	await assertRateLimit(event, 20, 1000);

	const { questId, progress } = await readBody(event);

	if (typeof progress !== "number" || progress < 0 || progress > 100) {
		throw createError({
			status: 400,
			message: "Progress must be a number between 0 and 100",
		});
	}

	const questsRef = firestore.collection("quests").doc(user.uid);

	const doc = await questsRef.get();
	if (!doc.exists) {
		throw createError({
			status: 404,
			message: "Quests document not found",
		});
	}

	const data = doc.data() as QuestDocument;
	const questIndex = data.quests.findIndex((q) => q.id === questId);

	if (questIndex === -1) {
		throw createError({
			status: 404,
			message: "Quest not found",
		});
	}

	data.quests[questIndex].progress.current = progress;
	data.lastUpdated = new Date().toISOString();

	await questsRef.update({
		quests: data.quests,
		lastUpdated: data.lastUpdated,
	});
});
