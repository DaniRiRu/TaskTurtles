import type { EventHandlerRequest } from "h3";
import type { ApiResponse } from "~/types/backend";
import type { QuestDocument } from "~/types/quests/quests";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<void>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "POST");
	await assertRateLimit(event, 5, 1000);

	const { questIds } = await readBody(event);

	if (!Array.isArray(questIds)) {
		throw createError({
			status: 400,
			message: "Quest IDs must be provided as an array",
		});
	}

	const questsRef = firestore.collection("quests").doc(user.uid);
	const archivedQuestsRef = firestore
		.collection("archived_quests")
		.doc(user.uid);

	await firestore.runTransaction(async (transaction) => {
		// Get current quests
		const questsDoc = await transaction.get(questsRef);
		if (!questsDoc.exists) {
			throw createError({
				status: 404,
				message: "Quests document not found",
			});
		}

		const questsData = questsDoc.data() as QuestDocument;
		const questsToArchive = questsData.quests.filter((q) =>
			questIds.includes(q.id),
		);
		const remainingQuests = questsData.quests.filter(
			(q) => !questIds.includes(q.id),
		);

		const archivedDoc = await transaction.get(archivedQuestsRef);
		const archivedQuests = archivedDoc.exists
			? (archivedDoc.data() as QuestDocument)
			: { quests: [], lastUpdated: new Date().toISOString() };

		transaction.update(questsRef, {
			quests: remainingQuests,
			lastUpdated: new Date().toISOString(),
		});

		transaction.set(archivedQuestsRef, {
			quests: [...archivedQuests.quests, ...questsToArchive],
			lastUpdated: new Date().toISOString(),
		});
	});
});
