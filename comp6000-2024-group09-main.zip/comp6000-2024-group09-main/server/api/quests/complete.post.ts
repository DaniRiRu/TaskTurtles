import type { EventHandlerRequest } from "h3";
import { giveReward } from "~/server/utils/rewards";
import type { ApiResponse } from "~/types/backend";
import { RewardType } from "~/types/backend/rewards/rewards";
import type { Quest, QuestDocument } from "~/types/quests/quests";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<void>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "POST");
	await assertRateLimit(event, 5, 100);

	const { questId } = await readBody(event);
	const questsRef = firestore.collection("quests").doc(user.uid);

	const doc = await questsRef.get();
	if (!doc.exists)
		throw createError({ status: 404, message: "Quests not found" });

	const data = doc.data() as QuestDocument;
	const questIndex = data.quests.findIndex((q) => q.id === questId);

	if (questIndex === -1)
		throw createError({ status: 404, message: "Quest not found" });

	const quest = data.quests[questIndex] as Quest;

	quest.completed = true;
	quest.isActive = false;
	quest.progress.current = quest.progress.max;
	data.lastUpdated = new Date().toISOString();

	if (quest.type === "daily") {
		await giveReward(firestore, user.uid, RewardType.QUEST_COMPLETION_DAILY);
	}

	if (quest.type === "standard") {
		switch (quest.difficulty) {
			case "easy":
				await giveReward(
					firestore,
					user.uid,
					RewardType.QUEST_COMPLETION_NORMAL,
				);
				break;
			case "medium":
				await giveReward(
					firestore,
					user.uid,
					RewardType.QUEST_COMPLETION_MEDIUM,
				);
				break;
			case "hard":
				await giveReward(firestore, user.uid, RewardType.QUEST_COMPLETION_HARD);
				break;
		}
	}

	await questsRef.update({
		quests: data.quests,
		lastUpdated: data.lastUpdated,
		dailyRefreshedAt: data.dailyRefreshedAt,
		nextDailyRefresh: data.nextDailyRefresh,
	});
});
