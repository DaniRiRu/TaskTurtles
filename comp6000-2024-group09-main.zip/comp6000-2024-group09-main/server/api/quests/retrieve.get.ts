import type { EventHandlerRequest } from "h3";
import { generateDailyQuests, getNextRefreshTime } from "~/server/utils/quests";
import type { ApiResponse } from "~/types/backend";
import type { QuestDocument } from "~/types/quests/quests";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<QuestDocument>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "GET");
	await assertRateLimit(event, 10, 100);

	const questsCollection = firestore.collection("quests");
	const userQuestsRef = questsCollection.doc(user.uid);
	const doc = await userQuestsRef.get();

	if (!doc.exists) {
		const nextRefresh = getNextRefreshTime();

		const defaultQuestDocument: QuestDocument = {
			quests: [...(await generateDailyQuests(firestore, user.uid))],
			lastUpdated: new Date().toISOString(),
			dailyRefreshedAt: new Date().toISOString(),
			nextDailyRefresh: nextRefresh.toISOString(),
		};

		await userQuestsRef.set(defaultQuestDocument);
		return defaultQuestDocument;
	}

	return doc.data() as QuestDocument;
});
