import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type { StoredUser } from "~/types/core/user";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<StoredUser>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "GET");
	await assertRateLimit(event, 1, 100);
	const doc = firestore.doc(`profile/${user.uid}`);

	const snapshot = await doc.get();

	if (!snapshot.exists) {
		setResponseStatus(event, 404);
		return {
			error: "Profile not found",
		};
	}

	const userdata = snapshot.data() as StoredUser;

	return {
		...userdata,
	};
});
