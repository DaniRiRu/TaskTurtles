import type { EventHandlerRequest } from "h3";
import { createError } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type { AccountDeleteResponse } from "~/types/backend/account/delete";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<AccountDeleteResponse>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	if (!user) {
		throw createError({ statusCode: 401, message: "Unauthorized" });
	}

	assertMethod(event, "DELETE");
	await assertRateLimit(event, 1, 10000);
	const doc = firestore.doc(`profile/${user.uid}`);

	const snapshot = await doc.get();

	if (!snapshot.exists) {
		setResponseStatus(event, 404);
		return {
			error: "Profile not found",
		};
	}
	await doc.delete();

	return {
		success: true,
		message: "Profile deleted successfully",
	};
});
