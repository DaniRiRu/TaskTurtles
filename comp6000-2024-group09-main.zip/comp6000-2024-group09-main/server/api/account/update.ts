import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type { StoredUser } from "~/types/core/user";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<StoredUser>>
>(async (event) => {
	const { firestore, user } = event.context.firebase;

	assertMethod(event, "PATCH");
	await assertRateLimit(event, 1, 100);

	const body = await readBody(event);
	const doc = firestore.doc(`profile/${user.uid}`);
	await doc.update(body);

	const snapshot = await doc.get();
	if (!snapshot.exists) {
		setResponseStatus(event, 404);
		return { error: "User profile not found after update" };
	}

	const userdata = snapshot.data() as StoredUser;
	const data = { ...userdata };
	return data;
});
