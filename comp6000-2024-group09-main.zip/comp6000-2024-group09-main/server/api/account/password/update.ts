import { getAuth } from "firebase-admin/auth";
import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type { UpdatePasswordResponse } from "~/types/backend/auth/password";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<UpdatePasswordResponse>>
>(async (event) => {
	const { user } = event.context.firebase;
	const auth = getAuth();

	assertMethod(event, "POST");
	await assertRateLimit(event, 1, 1000);

	const body = await readBody(event);
	const { newPassword } = body;

	try {
		await auth.updateUser(user.uid, {
			password: newPassword,
		});

		return {
			success: true,
		};
	} catch (error) {
		throw createError({
			statusCode: 400,
			message: "Failed to update password",
		});
	}
});
