import type { EventHandlerRequest } from "h3";
import { assertRateLimit } from "~/server/utils/asserts";
import type { ApiResponse } from "~/types/backend";
import type { SendPasswordResetResponse } from "~/types/backend/auth/passwordreset";

export default defineEventHandler<
	EventHandlerRequest,
	Promise<ApiResponse<SendPasswordResetResponse>>
>(async (event) => {
	const { auth, user } = event.context.firebase;

	assertMethod(event, "POST");
	await assertRateLimit(event, 1, 5000);

	if (!user?.email) {
		throw createError({ statusCode: 401, message: "No email found for user" });
	}

	const url = await auth.generatePasswordResetLink(user.email);

	return {
		success: true,
		url,
	};
});
