import type { Skill } from "~/types/skills/skill";

export abstract class BaseSkillTree {
	protected abstract readonly treeName: string;
	protected abstract skills: Omit<Skill, "tree">[];
	getSkills(): Skill[] {
		return this.skills.map((skill) => ({
			...skill,
			tree: this.treeName,
		}));
	}

	findSkillById(id: string): Skill | undefined {
		return this.getSkills().find((skill) => skill.id === id);
	}

	getPrerequisiteSkills(skillId: string): Skill[] {
		const skill = this.findSkillById(skillId);
		if (!skill) return [];

		return skill.prerequisites
			.map((prereqId) => this.findSkillById(prereqId))
			.filter((skill): skill is Skill => skill !== undefined);
	}
}
