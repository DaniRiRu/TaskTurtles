import type { App } from "firebase-admin/app";
import {
	type Auth,
	type DecodedIdToken,
	getAuth as getAdminAuth,
} from "firebase-admin/auth";
import { type Firestore, getFirestore } from "firebase-admin/firestore";
import { ensureAdminApp } from "vuefire/server";

export default defineEventHandler(async (event) => {
	if (event.path.startsWith("/api") && event.path !== "/api/__session") {
		// Global rate limit of 20 requests per second
		await assertRateLimit(event, 1, 20, "global");

		const runtimeConfig = useRuntimeConfig();
		const token = getCookie(event, "__session");

		if (!token) {
			setResponseStatus(event, 403);

			return {
				error: "no token",
			};
		}

		const adminApp = ensureAdminApp(
			{
				projectId: runtimeConfig.public.vuefire!.config!.projectId,
			},
			"session-verification",
		);

		const adminAuth = getAdminAuth(adminApp);
		const adminFirestore = getFirestore(adminApp);

		try {
			const verifiedIdToken = await adminAuth.verifySessionCookie(token, true);

			event.context.firebase = {
				app: adminApp,
				auth: adminAuth,
				firestore: adminFirestore,
				user: verifiedIdToken,
			};
		} catch {
			setResponseStatus(event, 403);

			return {
				error: "invalid token",
			};
		}
	}
});

declare module "h3" {
	interface H3EventContext {
		firebase: {
			app: App;
			auth: Auth;
			firestore: Firestore;
			user: DecodedIdToken;
		};
	}
}
