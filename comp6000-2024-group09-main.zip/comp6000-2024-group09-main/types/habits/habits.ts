export interface HabitData {
	id: string;
	userId: string;
	name: string;
	description: string;
	icon: string;
	frequency: HabitFrequency;
	totalCompletions: number;
	difficulty: 1 | 2 | 3 | 4 | 5;
	tags: string[];
	createdAt: string;
	updatedAt: string;
	lastCompletedAt?: string;
	reminderTime?: string;
	completionHistory: HabitCompletion[];
	isArchived: boolean;
	color?: string;
}

export interface HabitFrequency {
	type: "recurring" | "flexible";
	recurring?: RecurringFrequency;
	flexible?: FlexibleFrequency;
}

export interface RecurringFrequency {
	every: number;
	period: "day" | "week" | "month" | "year";
	specificDays?: number[];
	specificMonths?: number[];
	timeOfDay?: TimeOfDay[];
}

export interface FlexibleFrequency {
	times: number;
	withinPeriod: number;
	periodUnit: "day" | "week" | "month" | "year";
}

export interface TimeOfDay {
	hour: number;
	minute: number;
}

export interface HabitCompletion {
	id: string;
	completedAt: string;
	userId: string;
	habitId: string;
	note?: string;
	mood?: 1 | 2 | 3 | 4 | 5;
}

export interface HabitStats {
	currentStreak: number;
	longestStreak: number;
	completionRate: number;
	completionsThisPeriod: number;
	requiredCompletionsThisPeriod: number;
	nextDueDate?: string;
}

export const HABITS_COLLECTION = "habits";
export const HABIT_COMPLETIONS_COLLECTION = "habitCompletions";

export interface FirebaseStructure {
	[HABITS_COLLECTION]: {
		[habitId: string]: HabitData;
	};
	[HABIT_COMPLETIONS_COLLECTION]: {
		[completionId: string]: HabitCompletion;
	};
}

export type FrequencyPeriod = "day" | "week" | "month" | "year";

export interface HabitFrequencyDisplay {
	text: string;
	nextDue?: string;
	progress: {
		current: number;
		required: number;
	};
}

export interface HabitValidation {
	isValid: boolean;
	errors: string[];
}

export interface HabitReminder {
	id: string;
	habitId: string;
	userId: string;
	time: TimeOfDay;
	enabled: boolean;
	days: number[];
}

export interface HabitFilter {
	tags?: string[];
	difficulty?: number[];
	frequency?: FrequencyPeriod[];
	completed?: boolean;
	archived?: boolean;
}

export interface HabitSort {
	field: "name" | "createdAt" | "streak" | "difficulty" | "completionRate";
	direction: "asc" | "desc";
}
