export type Embed = {
	type: "video" | "url";
	url: string;
};
