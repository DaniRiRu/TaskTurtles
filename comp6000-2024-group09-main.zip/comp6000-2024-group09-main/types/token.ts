export interface TokenUse {
	tokensUsed: number;
	tokensLeft: number;
}
