export enum CalendarView {
	DAILY = "daily",
	WEEKLY = "weekly",
	MONTHLY = "monthly",
	SCHEDULE = "schedule",
}
