// types/calendar/events.ts

export interface CalendarEventDateTime {
	dateTime?: string;
	date?: string;
	timeZone?: string;
}

export interface CalendarAttendee {
	email: string;
	displayName?: string;
	responseStatus?: "accepted" | "tentative" | "declined" | "needsAction";
}

export interface CalendarEvent {
	id: string;
	provider: "google" | "outlook" | "ical" | "custom";
	summary: string;
	description?: string;
	start: CalendarEventDateTime;
	end: CalendarEventDateTime;
	status: "confirmed" | "tentative" | "cancelled";
	location?: string;
	url?: string;
	attendees?: CalendarAttendee[];
	createdAt?: Date;
	updatedAt?: Date;
	syncedAt?: Date;
}

export interface GoogleCalendarEvent extends CalendarEvent {
	provider: "google";
	htmlLink: string;
}

export interface OutlookCalendarEvent extends CalendarEvent {
	provider: "outlook";
	webLink: string;
}

export interface ICalendarEvent extends CalendarEvent {
	provider: "ical";
	uid: string;
}

export interface CustomCalendarEvent extends CalendarEvent {
	provider: "custom";
}

export type AnyCalendarEvent =
	| GoogleCalendarEvent
	| OutlookCalendarEvent
	| ICalendarEvent
	| CustomCalendarEvent;
