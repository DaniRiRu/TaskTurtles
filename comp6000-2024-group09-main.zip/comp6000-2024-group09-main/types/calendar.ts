export interface CalendarDate {
	date: Date;
	isCurrentMonth: boolean;
	isToday: boolean;
	isSelected: boolean;
}

export interface CalendarHour {
	time: string;
	isCurrentHour: boolean;
	isSelected: boolean;
}
