export interface Feature {
	title1: string;
	title2: string;
	description: string;
	pageIndex: number;
}

export interface Page {
	url: string;
	image: string;
	title: string;
}

export interface HowItWorksStep {
	number: string;
	title: string;
	description: string;
}

export interface PricingPlan {
	name: string;
	price: number;
	features: { included: boolean; text: string }[];
	popular: boolean;
}

export interface FAQ {
	question: string;
	answer: string;
}
