export interface NavItem {
	label: string;
	icon: Component;
	selectedIcon: Component;
	to: string;
}
