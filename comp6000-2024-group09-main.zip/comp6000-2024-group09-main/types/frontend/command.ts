export interface Command {
	id: string | number;
	title: string;
	icon: Component;
	path?: string;
	action?: () => void;
}
