export interface Achievement {
	id: string;
	title: string;
	description: string;
	progress: number;
	maxProgress: number;
	reward: string;
	unlocked: boolean;
	unlockedAt: string;
}
