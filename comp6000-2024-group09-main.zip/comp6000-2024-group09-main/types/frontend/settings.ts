export interface FormField {
	label: string;
	key: string;
	type: string;
	placeholder: string;
}
