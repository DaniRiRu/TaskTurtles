import type { InventoryItem } from "../backend/shop/item";

export type ItemConsume = { message: string; updatedItems: InventoryItem[] };
