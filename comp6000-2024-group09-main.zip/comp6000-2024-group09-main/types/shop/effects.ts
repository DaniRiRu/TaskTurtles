import type { Firestore } from "firebase-admin/firestore";

export type EffectContext = {
	userId: string;
	firestore: Firestore;
};

export type EffectResult = {
	message: string;
};

export type ItemEffect = (context: EffectContext) => Promise<EffectResult>;
