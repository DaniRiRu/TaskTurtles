export interface AnalysisResult {
	mood: {
		primary: string;
		description: string;
		intensity: number;
		suggestion?: string;
	};
	topics: string[];
	keyInsights: string[];
	patterns: {
		recurring: string[];
		improvement: string[];
	};
	suggestions: string[];
	analysis: {
		strength: string[];
		growth: string[];
		reflection: string;
	};
}
