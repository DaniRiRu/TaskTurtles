import type { AIThread } from "./response";

export interface UserData {
	id: string;
	email: string;
	displayName: string;
	photoURL?: string;
	createdAt: Date;
	lastActiveAt: Date;
	aiThreads: Record<string, AIThread>;
	lastThreadId?: string;
	settings?: {
		theme: "light" | "dark" | "system";
		notifications: boolean;
	};
}

export const USERS_COLLECTION = "users";

export interface FirebaseUserStructure {
	[USERS_COLLECTION]: {
		[userId: string]: UserData;
	};
}
