export interface AIThread {
	id: string;
	createdAt: Date;
	title: string;
	lastUpdated: Date;
}

export interface UserAIData {
	aiThreads: Record<string, AIThread>;
}
