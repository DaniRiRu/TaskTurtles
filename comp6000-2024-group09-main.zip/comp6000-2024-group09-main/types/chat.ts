export interface Message {
	content: string;
	isUser: boolean;
	timestamp: Date;
	isTyping: boolean;
	embeds?: {
		type: "url" | "video";
		url: string;
		title?: string;
		description?: string;
		thumbnail?: string;
	}[];
}

export interface ChatState {
	isLoading: boolean;
	isBotTyping: boolean;
	isResetting: boolean;
}
