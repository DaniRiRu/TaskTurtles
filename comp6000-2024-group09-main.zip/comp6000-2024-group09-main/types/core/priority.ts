export type Priority = {
	id: string | undefined;
	int: number;
	title: string;
	color: string;
};
