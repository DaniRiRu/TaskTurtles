import type { Priority } from "./priority";
import type { Tag } from "./tag";

export enum TaskStatus {
	Todo = "todo",
	InProgress = "in-progress",
	Done = "done",
}

export type Task = {
	id: string;
	title: string;
	description: string;
	dueDate: Date;
	priority: Priority | string | undefined;
	tags: Tag[];
	status: TaskStatus;
};
