export interface StoredUser {
	name: string;
	gender: string;
	pronouns: string;
	username: string;
	dob: Date;
	occupation: string;
	weeklyHours: number;
	banner?: string;
	bio?: string;
	bannerColor?: string;
	avatarUrl?: string;
	badges?: string[];
	profileEffect?: string;
}
