export type Tag = {
	id: string | undefined;
	title: string;
	color: string;
};
