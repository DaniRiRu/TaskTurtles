export interface AiSuggestion {
	name: string;
	objectives: string[];
}

export interface AiSuggestionPrompt {
	name: string;
	description: string;
}
