export interface NodeState {
	isAvailable: boolean;
	isUnlocked: boolean;
	isHovered: boolean;
	isCompleted: boolean;
}
