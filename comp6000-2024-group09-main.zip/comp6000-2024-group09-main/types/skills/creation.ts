export interface TreeGenerationConfig {
	totalStartingSkills: number;
	maxLevels: number;
	minSkillsPerLevel: number;
	maxSkillsPerLevel: number;
	minDependencies: number;
	maxDependencies: number;
	maxDependentsPerSkill: number;
}
