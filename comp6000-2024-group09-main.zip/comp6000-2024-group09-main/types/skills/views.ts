export type ViewType = "grid" | "list" | "compact" | "timeline" | "compactcard";
