export interface SkillColour {
	primary: string;
	secondary: string;
	text: string;
	hover: string;
	highlight: string;
	available: string;
	locked: string;
	connection: {
		active: string;
		inactive: string;
	};
}
