export interface SkillTreeData {
	id: string;
	name: string;
	description: string;
	icon: string;
	skills: Record<string, Skill>;
	userId: string;
	createdAt: string;
	updatedAt: string;
	completed: boolean;
}

export interface Skill {
	id?: string;
	name: string;
	description: string;
	icon?: string;
	tasks?: SkillTask[];
	prerequisites: string[];
	position: number;
	revealed: boolean;
	completed: boolean;
}

export interface SkillTask {
	id: string;
	name: string;
	description: string;
	completed: boolean;
	difficulty: number;
}

export interface SkillCount {
	mastered: number;
	available: number;
	locked: number;
}

export const SKILL_TREES_COLLECTION = "skillTrees";

export interface FirebaseStructure {
	[SKILL_TREES_COLLECTION]: {
		[treeId: string]: SkillTreeData;
	};
}
