import z from "zod";

export const genderOptions = [
	"Male",
	"Female",
	"Other",
	"Prefer not to say",
] as const;

export const GenderEnum = z.enum(genderOptions);

export const PhoneRegex =
	/^([+]?\d{1,2}[-\s]?)?(?:\d{3}[-\s]?\d{3}[-\s]?\d{4}|\(\d{3}\)\s*\d{3}[-\s]?\d{4}|\d{10})$/;

export const UserDataRequest = z.object({
	user: z
		.object({
			name: z
				.string()
				.min(2, "Name must be at least 2 characters")
				.max(100, "Name cannot exceed 100 characters")
				.regex(
					/^[a-zA-Z\s-']+$/,
					"Name can only contain letters, spaces, hyphens, and apostrophes",
				)
				.transform((str) => str.trim())
				.optional(),

			gender: GenderEnum.optional(),

			pronouns: z
				.union([
					z.literal("he/him"),
					z.literal("she/her"),
					z.string().min(1).max(50),
				])
				.optional(),

			dob: z
				.date({ coerce: true })
				.refine((date) => {
					const age = new Date().getFullYear() - date.getFullYear();
					return age >= 13 && age <= 120;
				}, "Age must be between 13 and 120 years")
				.optional(),

			occupation: z
				.string()
				.min(1, "Occupation must not be empty")
				.max(100, "Occupation cannot exceed 100 characters")
				.transform((str) => str.trim())
				.optional(),

			weeklyHours: z
				.number()
				.int("Weekly hours must be a whole number")
				.min(0, "Weekly hours cannot be negative")
				.max(168, "Weekly hours cannot exceed 168")
				.optional(),

			mobileNumber: z
				.string()
				.regex(PhoneRegex, "Invalid phone number format")
				.transform((str) => str.replace(/\s+/g, ""))
				.optional(),

			timezone: z
				.string()
				.refine(
					(tz) => Intl.DateTimeFormat.supportedLocalesOf(tz).length > 0,
					"Invalid timezone",
				)
				.optional(),

			language: z
				.string()
				.refine(
					(lang) => Intl.DateTimeFormat.supportedLocalesOf(lang).length > 0,
					"Invalid language code",
				)
				.default("en-US"),

			emailNotifications: z
				.object({
					dailyDigest: z.boolean().default(true),
					weeklyReport: z.boolean().default(true),
					taskReminders: z.boolean().default(true),
					systemUpdates: z.boolean().default(true),
				})
				.optional(),

			profileVisibility: z
				.enum(["public", "private", "friends_only"])
				.default("public"),

			skills: z
				.array(z.string().min(1).max(50))
				.max(20, "Cannot have more than 20 skills")
				.optional(),

			bio: z
				.string()
				.min(10, "Bio must be at least 10 characters")
				.max(500, "Bio cannot exceed 500 characters")
				.optional(),

			socialLinks: z
				.object({
					linkedin: z.string().url().optional(),
					twitter: z.string().url().optional(),
					github: z.string().url().optional(),
					website: z.string().url().optional(),
				})
				.optional(),

			preferences: z
				.object({
					theme: z.enum(["light", "dark", "system"]).default("system"),
					colorScheme: z
						.enum(["default", "classic", "modern", "contrast"])
						.default("default"),
					compactView: z.boolean().default(false),
					enableSounds: z.boolean().default(true),
					enableAnimations: z.boolean().default(true),
				})
				.optional(),
		})
		.partial(),
});

export type UserDataRequestType = z.infer<typeof UserDataRequest>;
export type GenderType = z.infer<typeof GenderEnum>;
