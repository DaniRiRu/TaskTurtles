export interface Reward {
	xp: number;
	coins: number;
	diamonds: number;
}
