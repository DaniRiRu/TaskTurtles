export interface LeaderboardEntry {
	userId: string;
	displayName: string;
	score: number;
	avatar?: string;
	rank: number;
}

export interface LeaderboardResults {
	leaderboard: LeaderboardEntry[];
	totalEntries: number;
	userRank: number;
	userScore: number;
}
