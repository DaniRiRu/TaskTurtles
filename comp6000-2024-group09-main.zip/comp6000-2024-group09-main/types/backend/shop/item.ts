import type { Timestamp } from "firebase-admin/firestore";

export interface InventoryItem {
	id: string;
	name: string;
	description: string;
	quantity: number;
	type: "consumable" | "permanent" | "cosmetic" | "theme" | "cursor";
	useFunction?: string;
	cursorAssets?: {
		default: string;
	};
}

export interface ShopItem extends Omit<InventoryItem, "quantity"> {
	price: {
		coins?: number;
		diamonds?: number;
	};
	available: boolean;
	limitedTime?: {
		start: Date;
		end: Date;
	};
	image: string;
	category: string;
}

export type ShopTransaction = {
	id: string;
	itemId: string;
	quantity: number;
	totalPrice: number;
	currency: "coins" | "diamonds";
	type: "purchase" | "use";
	createdAt: Timestamp;
	updatedAt: Timestamp;
};
