import type { AnyCalendarEvent } from "~/types/calendar/events";

export type CalendarProvider = "google" | "outlook" | "ical" | "custom";

export interface CalendarConnectionResponse {
	isConnected: boolean;
	lastSync: Date | null;
	connectionUrl: string | null;
}

export interface CalendarConnectionsResponse {
	google: CalendarConnectionResponse;
	outlook: CalendarConnectionResponse;
	ical: CalendarConnectionResponse;
	custom: CalendarConnectionResponse;
}

export interface CalendarEventsResponse {
	events: AnyCalendarEvent[];
}

export interface CalendarEventResponse {
	eventId: string;
}

export interface CalendarSyncResponse {
	count: number;
}
