export type ApiRequestSuccesful = {
	success: true;
};
