export type AccountDeleteResponse = {
	success: boolean;
	message: string;
};
