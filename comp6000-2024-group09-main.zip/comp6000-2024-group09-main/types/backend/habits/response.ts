import type {
	HabitCompletion,
	HabitData,
	HabitReminder,
	HabitStats,
	HabitValidation,
} from "~/types/habits/habits";

export type HabitsGetResponse = HabitData[];

export type HabitsCreateResponse = HabitData;

export type HabitGetResponse = {
	habitData: HabitData;
};

export type HabitUpdateResponse = {
	habitData: HabitData;
};

export type HabitDeleteResponse = {
	message: string;
};

export type HabitCompleteResponse = {
	completion: HabitCompletion;
	habitData: HabitData;
};

export type HabitStatsResponse = {
	stats: HabitStats;
};

export type HabitRemindersResponse = {
	reminders: HabitReminder[];
};

export type HabitReminderCreateResponse = HabitReminder;

export type HabitValidationResponse = {
	validation: HabitValidation;
};

export type HabitTagsResponse = {
	tags: string[];
};

export type HabitFilteredResponse = {
	habits: HabitData[];
	total: number;
};
