export type RewardStatusResponse = {
	success: true;
};
