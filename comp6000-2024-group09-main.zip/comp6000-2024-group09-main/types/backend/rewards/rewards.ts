export interface Reward {
	xp: number;
	coins: number;
	diamonds: number;
	score: number;
}

export enum RewardType {
	DAILY_LOGIN_STREAK = "daily_login",
	QUEST_COMPLETION_DAILY = "quest_completion_daily",
	QUEST_COMPLETION_NORMAL = "quest_completion_normal",
	QUEST_COMPLETION_MEDIUM = "quest_completion_medium",
	QUEST_COMPLETION_HARD = "quest_completion_hard",
	SKILL_TREE_COMPLETE = "skill_tree_complete",
	SKILL_COMPLETE = "skill_complete",
	DAILY_JOURNAL = "daily_journal",
	DAILY_TASKS_COMPLETED = "daily_tasks_completed",
}

export const REWARDS: Record<RewardType, Reward> = {
	[RewardType.DAILY_LOGIN_STREAK]: {
		xp: 20,
		coins: 10,
		diamonds: 1,
		score: 1,
	},
	[RewardType.QUEST_COMPLETION_DAILY]: {
		xp: 15,
		coins: 10,
		diamonds: 0,
		score: 1,
	},
	[RewardType.QUEST_COMPLETION_NORMAL]: {
		xp: 25,
		coins: 15,
		diamonds: 0,
		score: 0,
	},
	[RewardType.QUEST_COMPLETION_MEDIUM]: {
		xp: 50,
		coins: 30,
		diamonds: 0,
		score: 0,
	},
	[RewardType.QUEST_COMPLETION_HARD]: {
		xp: 100,
		coins: 50,
		diamonds: 0,
		score: 0,
	},
	[RewardType.SKILL_TREE_COMPLETE]: {
		xp: 200,
		coins: 100,
		diamonds: 0,
		score: 0,
	},
	[RewardType.SKILL_COMPLETE]: {
		xp: 40,
		coins: 20,
		diamonds: 0,
		score: 0,
	},
	[RewardType.DAILY_JOURNAL]: {
		xp: 15,
		coins: 10,
		diamonds: 1,
		score: 1,
	},
	[RewardType.DAILY_TASKS_COMPLETED]: {
		xp: 30,
		coins: 20,
		diamonds: 1,
		score: 0,
	},
};
