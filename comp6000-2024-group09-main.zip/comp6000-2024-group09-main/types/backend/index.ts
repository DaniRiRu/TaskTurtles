export type ApiError = {
	error: string;
};

export type ApiResponse<T> = T | ApiError;
