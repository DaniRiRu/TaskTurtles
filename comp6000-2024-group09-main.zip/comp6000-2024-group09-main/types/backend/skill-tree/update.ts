import type { SkillTreeData } from "~/types/skills/skill";

export type SkillTreeUpdateResponse = {
	oldTree: SkillTreeData;
	newTree: SkillTreeData;
};
