// types/backend/ai-service/requests.ts

import type { AiContext } from "~/types/ai-service/contexts";
import type { ModelId } from "./models";

export interface WebSearchOptions {
	userLocation?: {
		type: "approximate";
		approximate: {
			country?: string;
			city?: string;
			region?: string;
			timezone?: string;
		};
	};
	searchContextSize?: "low" | "medium" | "high";
}

export interface UrlCitation {
	startIndex: number;
	endIndex: number;
	title: string;
	url: string;
}

export interface Annotation {
	type: string;
	urlCitation?: UrlCitation;
}

export interface GenerateRequest {
	message: string;
	model?: ModelId;
	context: AiContext;
	stream?: boolean;
	webSearch?: boolean;
	webSearchOptions?: WebSearchOptions;
	json?: boolean;
}

export interface TokenUsage {
	prompt: number;
	completion: number;
	total: number;
}

export interface GenerateResponse {
	text: string;
	model: string;
	tokenUsage: TokenUsage;
	annotations?: Annotation[];
	error?: string;
}

export interface TokenInfoResponse {
	balance: number;
	usageHistory: {
		date: string;
		tokensUsed: number;
		model: string;
		context: AiContext;
		webSearch?: boolean;
	}[];
	dailyLimit: number;
	resetDate: string;
	maxTokens: number;
}

export const INSUFFICIENT_TOKENS = "Insufficient token balance";
