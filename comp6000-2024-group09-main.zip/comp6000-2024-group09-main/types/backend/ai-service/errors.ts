import { INSUFFICIENT_TOKENS } from "./requests";

export class InsufficientTokenError extends Error {
	constructor() {
		super(INSUFFICIENT_TOKENS);
	}
}
