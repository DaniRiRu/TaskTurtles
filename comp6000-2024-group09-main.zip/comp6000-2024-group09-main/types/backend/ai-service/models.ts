export enum ModelId {
	GPT_4O = "gpt-4o",
	GPT_4O_MINI = "gpt-4o-mini",
	GPT_4O_SEARCH = "gpt-4o-search-preview",
	GPT_4O_MINI_SEARCH = "gpt-4o-mini-search-preview",
	CLAUDE_3_5_HAIKU = "claude-3-haiku-20240307",
}

export enum ModelProvider {
	OPENAI = "openai",
	ANTHROPIC = "anthropic",
}

export interface AIModel {
	id: string;
	name: string;
	provider: ModelProvider;
	maxTokens: number;
	costPerInputToken: number;
	costPerOutputToken: number;
	capabilities: string[];
	contextWindow: number;
	supportsWebSearch?: boolean;
}

export const AI_MODELS: Record<ModelId, AIModel> = {
	[ModelId.GPT_4O]: {
		id: ModelId.GPT_4O,
		name: "GPT-4o",
		provider: ModelProvider.OPENAI,
		maxTokens: 32768,
		costPerInputToken: 0.00001,
		costPerOutputToken: 0.00003,
		capabilities: [
			"text generation",
			"structured output",
			"function calling",
			"advanced reasoning",
			"multimodal processing",
			"code generation and analysis",
		],
		contextWindow: 128000,
	},
	[ModelId.GPT_4O_MINI]: {
		id: ModelId.GPT_4O_MINI,
		name: "GPT-4o mini",
		provider: ModelProvider.OPENAI,
		maxTokens: 32768,
		costPerInputToken: 0.00000015,
		costPerOutputToken: 0.0000006,
		capabilities: [
			"text generation",
			"structured output",
			"function calling",
			"multimodal processing",
			"code generation",
		],
		contextWindow: 128000,
	},
	[ModelId.GPT_4O_SEARCH]: {
		id: ModelId.GPT_4O_SEARCH,
		name: "GPT-4o with Web Search",
		provider: ModelProvider.OPENAI,
		maxTokens: 32768,
		costPerInputToken: 0.00001,
		costPerOutputToken: 0.00003,
		capabilities: [
			"text generation",
			"web search",
			"advanced reasoning",
			"current information",
		],
		contextWindow: 128000,
		supportsWebSearch: true,
	},
	[ModelId.GPT_4O_MINI_SEARCH]: {
		id: ModelId.GPT_4O_MINI_SEARCH,
		name: "GPT-4o mini with Web Search",
		provider: ModelProvider.OPENAI,
		maxTokens: 32768,
		costPerInputToken: 0.00000015,
		costPerOutputToken: 0.0000006,
		capabilities: ["text generation", "web search", "current information"],
		contextWindow: 128000,
		supportsWebSearch: true,
	},
	[ModelId.CLAUDE_3_5_HAIKU]: {
		id: ModelId.CLAUDE_3_5_HAIKU,
		name: "Claude 3.5 Haiku",
		provider: ModelProvider.ANTHROPIC,
		maxTokens: 8192,
		costPerInputToken: 0.0000008,
		costPerOutputToken: 0.000004,
		capabilities: [
			"text generation",
			"rapid response",
			"code suggestions",
			"data processing",
		],
		contextWindow: 200000,
	},
};

export const FALLBACK_AI_MODEL: AIModel = AI_MODELS[ModelId.GPT_4O_MINI];
