export type TagAddResponse = {
	success: boolean;
};
