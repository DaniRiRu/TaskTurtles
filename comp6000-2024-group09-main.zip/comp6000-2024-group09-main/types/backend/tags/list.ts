import type { Tag } from "../../core/tag";

export type TagListResponse = {
	tags: Tag[];
};
