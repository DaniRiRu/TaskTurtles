export type AiListResponse = {
	data: AiAssistant[];
};

export type AiAssistant = {
	name: string;
	id: string;
};
