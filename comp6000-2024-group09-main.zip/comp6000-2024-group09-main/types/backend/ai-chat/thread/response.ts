export type AiThreadResponse = {
	threadId: string;
};
