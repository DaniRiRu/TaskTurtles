export type AiMessageError = {
	message: string;
};
