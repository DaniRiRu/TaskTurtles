export interface ChatHistory {
	messages: ChatMessage[];
}

export interface ChatMessage {
	id: string;
	role: "user" | "assistant";
	content: string;
	createdAt: number;
}

export interface HistoryResponse {
	data: ChatHistory;
	error: string;
}
