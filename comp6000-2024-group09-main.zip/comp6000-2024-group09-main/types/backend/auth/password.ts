export interface UpdatePasswordResponse {
	success: boolean;
}
