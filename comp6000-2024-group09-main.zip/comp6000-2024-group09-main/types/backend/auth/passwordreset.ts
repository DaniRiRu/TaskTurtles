export interface SendPasswordResetResponse {
	success: boolean;
	url: string;
}
