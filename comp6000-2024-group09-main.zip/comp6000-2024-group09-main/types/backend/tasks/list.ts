import type { Task } from "../../core/task";

export type TaskListResponse = {
	tasks: Task[];
};
