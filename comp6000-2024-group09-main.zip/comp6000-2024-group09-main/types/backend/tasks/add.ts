export type TaskAddResponse = {
	success: boolean;
};
