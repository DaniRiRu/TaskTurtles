export interface JournalEntry {
	date: string;
	content: string;
	ideas: string[];
	goals: string[];
	actionItems: Array<{
		text: string;
		completed: boolean;
	}>;
}

export interface JournalCreateRequest {
	entry: JournalEntry;
}

export interface JournalCreateResponse {
	success: boolean;
}
