import type { JournalEntry } from "./create";

export interface JournalListResponse {
	entries: JournalEntry[];
}
