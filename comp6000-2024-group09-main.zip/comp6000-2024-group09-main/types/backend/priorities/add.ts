export type PriorityAddResponse = {
	success: boolean;
};
