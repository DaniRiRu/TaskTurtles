import type { Priority } from "../../core/priority";

export type PriorityListResponse = {
	priorities: Priority[];
};
