export type ProfileSetupResponse = {
	success: true;
};
