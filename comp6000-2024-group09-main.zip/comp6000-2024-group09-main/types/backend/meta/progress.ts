export interface UserProgress {
	xp: number;
	loginHistory: LoginData[];
	lastClaimedGift: string | null;
	score: number;
}

export interface LoginData {
	date: string;
}

export const EMPTY_PROGRESS: UserProgress = {
	xp: 0,
	loginHistory: [],
	lastClaimedGift: null,
	score: 0,
};
