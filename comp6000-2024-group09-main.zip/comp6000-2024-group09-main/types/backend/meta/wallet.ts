export interface WalletData {
	coins: number;
	diamonds: number;
}
