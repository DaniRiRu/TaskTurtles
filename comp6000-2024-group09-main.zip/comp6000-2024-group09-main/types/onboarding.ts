export interface NavigationItem {
	name: string;
	path: string;
}
