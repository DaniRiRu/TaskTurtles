export interface QuestProgress {
	current: number;
	max: number;
}

export interface QuestReward {
	xp: number;
}

export interface Quest {
	id: number;
	title: string;
	description: string;
	reward: {
		xp: number;
	};
	difficulty: string;
	category: string;
	isActive: boolean;
	imageUrl: string;
	progress: {
		current: number;
		max: number;
	};
	formattedReward: string;
	completed: boolean;
	type?: "daily" | "standard";
	expires?: string;
}

export interface QuestDocument {
	quests: Quest[];
	lastUpdated: string;
	dailyRefreshedAt?: string;
	nextDailyRefresh?: string;
}
export interface QuestDocument {
	quests: Quest[];
	lastUpdated: string;
}

export type QuestDifficulty = "easy" | "medium" | "hard" | null;

export interface QuestFilters {
	searchQuery: string;
	category: string;
	difficulty: QuestDifficulty;
}
