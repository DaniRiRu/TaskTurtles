import {
	defineConfig,
	presetTypography,
	presetUno,
	presetWebFonts,
} from "unocss";
import { presetDaisy } from "unocss-preset-daisyui-next";
import { allThemes } from "./utils/themes";

export default defineConfig({
	presets: [
		presetUno(),
		presetDaisy({
			themes: allThemes,
			// biome-ignore lint/suspicious/noExplicitAny: not sure how to fix this
		}) as any,
		presetWebFonts({
			provider: "bunny",
			fonts: {
				base: "Inter:400,500,600,700,800,900",
			},
		}),
		presetTypography(),
	],
});
