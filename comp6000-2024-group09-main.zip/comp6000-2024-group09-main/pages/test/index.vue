<script setup lang="ts">
import { AiContexts } from "~/types/ai-service/contexts";
import { AI_MODELS, ModelId } from "~/types/backend/ai-service/models";

const backend = useBackend();

const message = ref("");
const context = ref(AiContexts.GENERAL);
const selectedModel = ref(ModelId.GPT_4O_MINI);
const isStreaming = ref(true);
const isLoading = ref(false);
const error = ref("");

// AI response
const response = ref("");
const tokenUsage = ref({
	prompt: 0,
	completion: 0,
	total: 0,
});

// Token info
import type { TokenInfoResponse } from "~/types/backend/ai-service/requests";

const tokenInfo = ref<TokenInfoResponse>({
	balance: 0,
	usageHistory: [],
	dailyLimit: 0,
	resetDate: "",
	maxTokens: 0,
});

// Available contexts
const availableContexts = Object.entries(AiContexts).map(([key, value]) => ({
	label: key,
	value,
}));

// Available models
const availableModels = Object.entries(AI_MODELS).map(([key, model]) => ({
	label: `${model.name} (${model.provider})`,
	value: key,
}));

// Fetch token info on page load
onMounted(async () => {
	try {
		tokenInfo.value = await backend.ai.getTokenInfo();
	} catch (err) {
		error.value = "Failed to fetch token information";
		console.error(err);
	}
});

// Send message to AI
async function sendMessage() {
	if (!message.value.trim()) {
		error.value = "Please enter a message";
		return;
	}

	error.value = "";
	isLoading.value = true;
	response.value = "";

	try {
		if (isStreaming.value) {
			// Stream the response
			await backend.ai.streamGenerate(
				{
					message: message.value,
					context: context.value,
					model: selectedModel.value,
					stream: true,
				},
				(chunk) => {
					response.value += chunk.text;
				},
				async () => {
					isLoading.value = false;
					// Refresh token info after streaming completes
					tokenInfo.value = await backend.ai.getTokenInfo();
				},
			);
		} else {
			// Get complete response
			const result = await backend.ai.generate({
				message: message.value,
				context: context.value,
				model: selectedModel.value,
				stream: false,
			});

			response.value = result.text;
			tokenUsage.value = result.tokenUsage;
			isLoading.value = false;

			// Refresh token info
			tokenInfo.value = await backend.ai.getTokenInfo();
		}
	} catch (err) {
		error.value = "Failed to generate response";
		console.error(err);
		isLoading.value = false;
	}
}

// Format the date
function formatDate(dateString: string) {
	return new Date(dateString).toLocaleDateString();
}

// Format token numbers
function formatNumber(num: number) {
	return new Intl.NumberFormat().format(num);
}
</script>

<template>
  <div class="container mx-auto p-4 max-w-5xl">
    <!-- Header -->
    <div class="mb-8">
      <h1 class="text-3xl font-bold mb-2">AI Service Test</h1>
      <p class="text-lg">Test the AI generation capabilities with different contexts and models</p>
    </div>

    <!-- Token Information -->
    <div class="card bg-base-200 shadow-xl mb-8">
      <div class="card-body">
        <h2 class="card-title">Token Information</h2>
        <div class="stats shadow mt-2">
          <div class="stat">
            <div class="stat-title">Balance</div>
            <div class="stat-value">{{ formatNumber(tokenInfo.balance) }}</div>
            <div class="stat-desc">Available tokens</div>
          </div>
          <div class="stat">
            <div class="stat-title">Daily Limit</div>
            <div class="stat-value">{{ formatNumber(tokenInfo.dailyLimit) }}</div>
            <div class="stat-desc">Max tokens per day</div>
          </div>
          <div class="stat">
            <div class="stat-title">Reset Date</div>
            <div class="stat-value">{{ formatDate(tokenInfo.resetDate) }}</div>
            <div class="stat-desc">Token refresh date</div>
          </div>
        </div>
      </div>
    </div>

    <!-- Request Form -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
      <!-- Input Form -->
      <div class="card bg-base-200 shadow-xl">
        <div class="card-body">
          <h2 class="card-title mb-4">Generate AI Response</h2>
          
          <!-- Context Selector -->
          <div class="form-control mb-4">
            <label class="label">
              <span class="label-text">Context</span>
            </label>
            <select v-model="context" class="select select-bordered w-full">
              <option v-for="ctx in availableContexts" :key="ctx.value" :value="ctx.value">
                {{ ctx.label }}
              </option>
            </select>
            <label class="label">
              <span class="label-text-alt">Select the context for your message</span>
            </label>
          </div>
          
          <!-- Model Selector -->
          <div class="form-control mb-4">
            <label class="label">
              <span class="label-text">AI Model</span>
            </label>
            <select v-model="selectedModel" class="select select-bordered w-full">
              <option v-for="model in availableModels" :key="model.value" :value="model.value">
                {{ model.label }}
              </option>
            </select>
            <label class="label">
              <span class="label-text-alt">Select which AI model to use</span>
            </label>
          </div>
          
          <!-- Streaming Toggle -->
          <div class="form-control mb-4">
            <label class="label cursor-pointer">
              <span class="label-text">Stream Response</span>
              <input type="checkbox" v-model="isStreaming" class="toggle toggle-primary" />
            </label>
            <label class="label">
              <span class="label-text-alt">Get responses word by word instead of all at once</span>
            </label>
          </div>
          
          <!-- Message Input -->
          <div class="form-control mb-4">
            <label class="label">
              <span class="label-text">Your Message</span>
            </label>
            <textarea 
              v-model="message" 
              class="textarea textarea-bordered h-32" 
              placeholder="Type your message here..."
            ></textarea>
          </div>
          
          <!-- Error Alert -->
          <div v-if="error" class="alert alert-error mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" class="stroke-current shrink-0 h-6 w-6" fill="none" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span>{{ error }}</span>
          </div>
          
          <!-- Submit Button -->
          <button 
            @click="sendMessage" 
            class="btn btn-primary w-full" 
            :disabled="isLoading || !message.trim()"
          >
            <span v-if="isLoading">
              <span class="loading loading-spinner"></span>
              Processing...
            </span>
            <span v-else>Send Message</span>
          </button>
        </div>
      </div>
      
      <!-- Response Display -->
      <div class="card bg-base-200 shadow-xl">
        <div class="card-body">
          <h2 class="card-title mb-4">AI Response</h2>
          
          <div v-if="isLoading && !response" class="flex items-center justify-center h-64">
            <span class="loading loading-dots loading-lg"></span>
          </div>
          
          <div v-else-if="response" class="bg-base-100 p-4 rounded-box mb-4 prose max-w-none overflow-auto h-64">
            {{ response }}
          </div>
          
          <div v-else class="flex items-center justify-center h-64 text-base-content/50">
            <p>AI response will appear here</p>
          </div>
          
          <!-- Token Usage Stats -->
          <div v-if="!isStreaming && tokenUsage.total > 0" class="stats shadow mt-4">
            <div class="stat">
              <div class="stat-title">Input Tokens</div>
              <div class="stat-value text-lg">{{ formatNumber(tokenUsage.prompt) }}</div>
            </div>
            <div class="stat">
              <div class="stat-title">Output Tokens</div>
              <div class="stat-value text-lg">{{ formatNumber(tokenUsage.completion) }}</div>
            </div>
            <div class="stat">
              <div class="stat-title">Total Tokens</div>
              <div class="stat-value text-lg">{{ formatNumber(tokenUsage.total) }}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <!-- Usage History -->
    <div class="card bg-base-200 shadow-xl">
      <div class="card-body">
        <h2 class="card-title mb-4">Recent Usage History</h2>
        
        <div v-if="tokenInfo.usageHistory && tokenInfo.usageHistory.length > 0">
          <div class="overflow-x-auto">
            <table class="table table-zebra">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Context</th>
                  <th>Model</th>
                  <th>Query</th>
                  <th>Tokens Used</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(item, index) in tokenInfo.usageHistory.slice(0, 10)" :key="index">
                  <td>{{ formatDate(item.date) }}</td>
                  <td>{{ item.context }}</td>
                  <td>{{ item.model }}</td>
                  <td class="max-w-xs truncate">{{ item.context }}</td>
                  <td>{{ formatNumber(item.tokensUsed) }}</td>
                </tr>
              </tbody>
            </table>
          </div>
          <div v-if="tokenInfo.usageHistory.length > 10" class="mt-4 text-center text-base-content/70">
            Showing 10 most recent entries out of {{ tokenInfo.usageHistory.length }}
          </div>
        </div>
        
        <div v-else class="text-center py-8 text-base-content/50">
          No usage history yet
        </div>
      </div>
    </div>
  </div>
</template>