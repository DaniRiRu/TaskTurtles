<script lang="ts" setup>
import { breakpointsTailwind, useBreakpoints } from "@vueuse/core";
import { ModalType } from "~/enums/frontend/tasks/ModalType";
import { ViewMode } from "~/enums/frontend/tasks/ViewMode";
import { useTaskStore } from "~/stores/tasks";
import type { Task } from "~/types/core/task";
import MaterialSymbolsTaskAltRounded from "~icons/material-symbols/task-alt-rounded";

const backend = useBackend();

const fetchData = () => taskStore.fetchData(backend);

definePageMeta({
	layout: "dashboard",
	// middleware: ["prefetch-tasks"],
});

const taskStore = useTaskStore();
const breakpoints = useBreakpoints(breakpointsTailwind);

const previousViewMode = ref(taskStore.viewMode);

function getColumnLayoutClass(tasksLength: number) {
	if (taskStore.viewMode !== ViewMode.Horizontal) {
		return "flex flex-col gap-3";
	}

	switch (tasksLength) {
		case 1:
			return "grid grid-cols-1 gap-3";
		case 2:
			return "grid grid-cols-1 lg:grid-cols-2 gap-3";
		default:
			return "grid grid-cols-1 lg:grid-cols-2 2xl:grid-cols-3 gap-3";
	}
}

function closeTaskSidebar() {
	taskStore.setSelectedTask(null);
	taskStore.setAddMode(false);
	// fetchData();
}

function openTaskSidebarForAdd() {
	taskStore.setSelectedTask(null);
	taskStore.setAddMode(true);
}

function openTaskSidebarForView(task: Task) {
	taskStore.setAddMode(false);
	taskStore.setSelectedTask(task);
}

function closeModal() {
	taskStore.setModalType(ModalType.None);
}

await fetchData();

watch(breakpoints.smallerOrEqual("lg"), (md) => {
	if (md) {
		previousViewMode.value = taskStore.viewMode;
		taskStore.setViewMode(ViewMode.List);
	} else {
		taskStore.setViewMode(previousViewMode.value);
	}
});
</script>

<template class="h-full w-full">
	<div
		class="transition-all duration-300 ease-in-out fixed top-0 h-38 left-0 w-full bg-gradient-to-b from-base-200 from-70% z-2">
	</div>
	<div class="rounded-btn top-20 sticky flex justify-between mb-8 z-5">
		<div class="flex flex-row join bg-base-100 shadow-sm">
			<TaskDropdownView v-model:viewMode="taskStore.viewMode" />
			<TaskDropdownSort v-model:sortType="taskStore.sortType" v-model:sortOrder="taskStore.sortOrder" />
			<TaskDropdownManage @update:modalType="taskStore.setModalType($event)" />
		</div>
		<button class="btn btn-ghost min-w-12 max-w-12 p-0 bg-base-100 shadow-sm" @click="openTaskSidebarForAdd">
			<MaterialSymbolsAdd class="h-6 w-6" />
		</button>
	</div>

	<TaskSidebarTags :isOpen="taskStore.modalType === 'tags'" @close="closeModal()" :refresh="fetchData"
		:tags="taskStore.tags" />
	<TaskSidebarPriorities :isOpen="taskStore.modalType === 'priorities'" @close="closeModal()"
		:refresh="fetchData" :priorities="taskStore.priorities" />

	<div>
		<div v-if="taskStore.tasks.length === 0" class="h-80vh w-full">
			<ContentUnavailable :image="MaterialSymbolsTaskAltRounded" title="No tasks"
				description="You don't have any tasks. Click the button below to get started." actionName="Add task"
				:action="openTaskSidebarForAdd" />
		</div>
		<div v-else :class="{
			'lg:grid-cols-2 2xl:grid-cols-3': taskStore.viewMode === ViewMode.Vertical,
		}" class="w-full grid grid-cols-1 gap-3">
			<div v-for="column in taskStore.taskColumns" :key="column.id" class="space-y-2">
				<div class="flex items-center justify-between px-2">
					<h2 class="text-lg font-semibold">{{ column.title }}</h2>
					<span class="px-2.5 py-0.5 rounded-full text-sm font-medium" :class="column.badgeColor">
						{{ column.tasks?.length }}
					</span>
				</div>
				<div class="hover:scale-101 transition-all duration-200" v-if="column.tasks?.length === 0">
					<button
						class="bg-base-100 rounded-box shadow-sm hover:shadow-lg p-4 flex justify-between font-medium w-full transition-all duration-200"
						@click="openTaskSidebarForAdd">
						No tasks
						<MaterialSymbolsAdd class="h-5 w-5" />
					</button>
				</div>
				<div v-else :class="getColumnLayoutClass(column.tasks.length)">
					<Task v-for="task in column.tasks" @click="openTaskSidebarForView(task)" :key="task.id"
						:task="task" />
				</div>
			</div>
		</div>
	</div>

	<TaskSidebar :task="taskStore.selectedTask" :isAddMode="taskStore.isAddMode" @close="closeTaskSidebar" @refresh="fetchData"
		:tags="taskStore.tags" :priorities="taskStore.priorities" />
</template>