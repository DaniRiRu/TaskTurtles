<script setup lang="ts">
import { useQuestFilters } from "~/composables/quests/useQuestFilters";
import { useQuests } from "~/composables/quests/useQuests";
import LucideArchive from "~icons/lucide/archive";
import LucideCheck from "~icons/lucide/check";
import LucideGauge from "~icons/lucide/gauge";
import LucideGoal from "~icons/lucide/goal";
import LucideTarget from "~icons/lucide/target";

definePageMeta({
	layout: "dashboard",
});

const route = useRoute();
const isArchive = computed(() => route.query.view === "archive");

const {
	quests,
	activeQuests,
	completedQuests,
	toggleQuestActive,
	updateProgress,
	completeQuest,
	resetQuestProgress,
	getFeaturedQuests,
} = useQuests();

const { filters, filterQuests } = useQuestFilters();

const activeFilteredQuests = computed(() =>
	filterQuests(activeQuests.value.filter((quest) => !quest.completed)),
);

const availableQuests = computed(() =>
	filterQuests(
		quests.value.filter((quest) => !quest.completed && !quest.isActive),
	),
);

const archivedQuests = computed(() => filterQuests(completedQuests.value));

const displayedFeaturedQuests = computed(() => {
	const featuredQuests = getFeaturedQuests.value;
	const dailyQuests = quests.value.filter(
		(q) => q.type === "daily" && !q.completed,
	);

	const combined = [...featuredQuests, ...dailyQuests];
	const uniqueIds = new Set();
	const uniqueQuests = combined.filter((quest) => {
		if (uniqueIds.has(quest.id)) return false;
		uniqueIds.add(quest.id);
		return true;
	});

	return uniqueQuests;
});

const shouldShowFeaturedQuests = computed(() => {
	return displayedFeaturedQuests.value.length > 0;
});
</script>

<template>
<div
		class="transition-all duration-300 ease-in-out fixed top-0 h-22 left-0 w-full bg-gradient-to-b from-base-200 from-70% z-2">
	</div>
  <div class="space-y-12 my-8">
    <div class="max-w-3xl mx-auto mb-6">
      <div
        class="rounded-box shadow-lg bg-base-100 transition-all duration-300 hover:shadow-xl border border-base-content/10 hover:border-primary/30">
        <div class="flex flex-col sm:flex-row items-stretch sm:items-center">
          <div class="flex-1 flex items-center">
            <input v-model="filters.searchQuery" type="text"
              :placeholder="isArchive ? 'Search archived quests...' : 'Search quests...'"
              class="input max-md:h-16 ring-none border-none bg-transparent w-full sm:h-10 text-base placeholder:text-base-content/40 focus:outline-none"
              @input="filters = { ...filters }" />
          </div>

          <div class="flex items-center justify-between gap-1 max-sm:px-2 max-sm:mb-2">
            <div class="hidden max-sm:flex items-center gap-1">
              <NuxtLink :to="{ query: {} }"
                class="btn rounded-box border-none h-12 overflow-hidden transition-all duration-200" :class="[
                  !isArchive ? 'btn-primary text-primary-content' : 'btn-ghost',
                  !isArchive ? 'w-[140px]' : 'w-12'
                ]" data-tip="Quest Board">
                <div class="flex items-center gap-2 whitespace-nowrap">
                  <LucideTarget class="w-6 h-6 shrink-0" />
                  <span class="hidden max-sm:inline" v-if="!isArchive">Quest Board</span>
                </div>
              </NuxtLink>

              <div class="relative">
                <NuxtLink :to="{ query: { view: 'archive' } }"
                  class="btn rounded-box border-none h-12 overflow-show transition-all duration-200 relative" :class="[
                    isArchive ? 'btn-primary' : 'btn-ghost',
                    isArchive ? 'w-[120px]' : 'w-12'
                  ]" data-tip="Archive">
                  <div class="flex items-center gap-2 whitespace-nowrap">
                    <LucideArchive class="w-6 h-6 shrink-0" />
                    <span class="hidden max-sm:inline max-xs:hidden" v-if="isArchive">Archive</span>
                  </div>
                </NuxtLink>
                <div v-if="archivedQuests.length > 0 && !isArchive"
                  class="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-secondary text-xs flex items-center justify-center font-bold text-neutral">
                  {{ archivedQuests.length }}
                </div>
              </div>
            </div>
            <div class="flex items-center gap-1">
              <div class="dropdown max-sm:hidden">
                <label tabindex="0"
                  class="btn btn-square rounded-box border-none p-0 btn-ghost flex items-center justify-center">
                  <LucideTarget class="w-6 h-6 text-primary" v-if="!isArchive" />
                  <LucideArchive class="w-6 h-6 text-primary" v-else />
                </label>
                <ul tabindex="0"
                  class="dropdown-content rounded-box z-[1] menu p-2 shadow-lg bg-base-200/80 backdrop-blur-xl w-52 border border-base-content/10 translate-x-[-45%]">
                  <li>
                    <NuxtLink :to="{ query: {} }" class="hover:bg-primary/20 flex items-center pl-3 pr-2 gap-3">
                      <LucideTarget class="w-6 h-6 text-primary" />
                      Quest Board
                    </NuxtLink>
                  </li>
                  <li>
                    <NuxtLink :to="{ query: { view: 'archive' } }"
                      class="hover:bg-primary/20 flex justify-between items-center pl-3 pr-2"
                      :class="{ 'bg-primary/10': isArchive }">
                      <div class="flex items-center gap-3">
                        <LucideArchive class="w-6 h-6 text-primary" />
                        Archive
                      </div>
                      <div v-if="archivedQuests.length > 0"
                        class="w-5 h-5 rounded-full bg-secondary text-xs flex items-center justify-center font-bold text-neutral">
                        {{ archivedQuests.length }}
                      </div>
                    </NuxtLink>
                  </li>
                </ul>
              </div>

              <div class="dropdown">
                <label tabindex="0"
                  class="btn btn-square rounded-box border-none p-0 btn-ghost flex items-center justify-center">
                  <LucideGauge class="w-6 h-6 text-primary" />
                </label>
                <ul tabindex="0"
                  class="dropdown-content z-[1] menu p-2 shadow-lg bg-base-200/80 backdrop-blur-xl rounded-box w-52 border border-base-content/10 translate-x-[-45%]">
                  <li>
                    <a @click="filters.difficulty = null; filters = { ...filters }" class="hover:bg-primary/20">
                      All Difficulties
                    </a>
                  </li>
                  <li>
                    <a @click="filters.difficulty = 'easy'; filters = { ...filters }" class="hover:bg-primary/20">
                      Easy
                    </a>
                  </li>
                  <li>
                    <a @click="filters.difficulty = 'medium'; filters = { ...filters }" class="hover:bg-primary/20">
                      Medium
                    </a>
                  </li>
                  <li>
                    <a @click="filters.difficulty = 'hard'; filters = { ...filters }" class="hover:bg-primary/20">
                      Hard
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <template v-if="!isArchive">
      <QuestsActiveQuests v-if="activeFilteredQuests.length > 0" :quests="activeFilteredQuests"
        @update-progress="updateProgress" @toggle-active="toggleQuestActive" @complete-quest="completeQuest" />

     <div v-if="shouldShowFeaturedQuests" class="flex flex-col gap-6">
        <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <span class="font-semibold tracking-widest text-primary text-sm uppercase block mb-1">Featured Quests</span>
            <div class="flex items-center gap-4">
              <h2 class="text-2xl font-extrabold drop-shadow-md">Your Next Adventure Awaits</h2>
              <QuestsDailyQuestTimer />
            </div>
          </div>
        </div>
        
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          <div v-for="quest in displayedFeaturedQuests" :key="quest.id"
            class="shadow-lg !rounded-box border border-secondary/10 border-2 hover:border-secondary/20 bg-base-100 hover:shadow-xl hover:scale-102 transition-all duration-300">
            <figure class="h-52">
              <img :src="quest.imageUrl" :alt="quest.title" class="w-full h-full object-cover bg-base-200 rounded-t-box" />
            </figure>
            <div class="p-5 flex flex-col gap-3">
              <div class="flex items-center justify-between">
                <h2 class="text-xl font-semibold">{{ quest.title }}</h2>
                <div class="flex items-center gap-2 p-2 flex-wrap justify-end">
                  <div v-if="quest.type === 'daily'" 
                    class="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-primary/20 to-primary/10 border border-primary/20 rounded-full">
                    <LucideStar class="w-3.5 h-3.5 text-primary animate-pulse" />
                    <span class="text-xs font-bold text-primary uppercase tracking-wider">Daily</span>
                  </div>
                  <div
                    class="px-2 py-1 bg-secondary/40 font-medium rounded-full text-base-secondary text-xs uppercase items-center justify-center break-words text-center">
                    {{ quest.category }}
                  </div>
                </div>
              </div>
              <p class="opacity-80">{{ quest.description }}</p>
              <div class="flex items-center justify-between mt-4">
                <GameIconsSwordsEmblem class="text-primary w-8 h-8" />
                <button class="btn btn-md" @click="toggleQuestActive(quest.id)"
                  :class="quest.isActive ? 'btn-error' : 'btn-success'">
                  {{ quest.isActive ? "Abandon Quest" : "Accept Quest" }}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <QuestsQuestBoard v-if="availableQuests.length > 0" :quests="availableQuests"
        @toggle-active="toggleQuestActive" />

      <div v-if="availableQuests.length === 0 && activeFilteredQuests.length === 0"
        class="flex items-center justify-center transform translate-y-0 opacity-100 transition-all duration-300">
        <ContentUnavailable :image="LucideGoal" title="No quests found"
          description="Looks like there are no quests matching your search query. Try a different one!" />
      </div>
    </template>

    <template v-else>
      <div v-if="archivedQuests.length === 0"
        class="flex items-center justify-center transform translate-y-0 opacity-100 transition-all duration-300">
        <ContentUnavailable :image="LucideGoal" title="No completed quests"
          description="You haven't completed any quests yet. Keep up the good work!" />
      </div>

      <div v-else class="grid grid-cols-[repeat(auto-fill,minmax(400px,1fr))] gap-6">
        <div v-for="quest in archivedQuests" :key="quest.id"
          class="rounded-xl border border-base-300 bg-base-100 p-6 flex flex-col justify-between gap-4 transition-all duration-300 hover:shadow-xl hover:border-primary/20 transform translate-y-0 opacity-100">
          <div class="flex flex-col gap-3">
            <div class="flex justify-between items-start">
              <div class="flex flex-col gap-1">
                <div class="font-bold text-lg text-base-content">{{ quest.title }}</div>
                <div class="text-xs text-base-content/60">Completed Quest</div>
              </div>
              <div class="badge !px-3 py-2.5 border-none" :class="{
                'bg-success text-success-content': quest.difficulty === 'easy',
                'bg-warning text-warning-content': quest.difficulty === 'medium',
                'bg-error text-error-content': quest.difficulty === 'hard',
              }">
                {{ quest.difficulty.charAt(0).toUpperCase() + quest.difficulty.slice(1) }}
              </div>
            </div>
            <div class="text-sm text-base-content/70 leading-relaxed">{{ quest.description }}</div>
          </div>

          <div class="flex items-center gap-2 mt-1 flex-wrap">
            <div class="badge badge-primary badge-outline !px-3 py-2.5">{{ quest.formattedReward }}</div>
            <div class="badge badge-success gap-2">
              <LucideCheck class="w-6 h-6" />
              Completed
            </div>
          </div>

          <div class="flex flex-col gap-4 mt-2">
            <div class="flex items-center gap-2">
              <div class="flex-1">
                <div class="flex items-center gap-2 mb-1">
                  <progress class="progress progress-success h-3 flex-1" :value="100" :max="100" />
                  <span class="text-sm font-medium text-base-content/80 w-10 text-right">
                    100%
                  </span>
                </div>
                <div class="text-xs text-base-content/60">
                  Quest Completed
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </template>
  </div>
</template>