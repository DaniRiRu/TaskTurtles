<script lang="ts" setup>
import { useHabits } from "~/composables/habits/useHabits";
import type { HabitData } from "~/types/habits/habits";
import MingcuteLeafLine from "~icons/mingcute/leaf-line";

definePageMeta({
	layout: "dashboard",
});

const { habits, loading, deleteHabit, completeHabit, updateHabit, getStreak } =
	useHabits();
const newHabitName = ref("");
const showModal = ref(false);
const searchQuery = ref("");
const editingHabit = ref<HabitData | null>(null);

const handleComplete = async (habit: HabitData) => {
	await completeHabit(habit.id, {
		mood: "4",
	});
};

const handleUpdate = async (habit: HabitData, increment: number) => {
	await updateHabit(habit.id, {
		...habit,
	});
};

const handleDelete = async (habitId: string) => {
	await deleteHabit(habitId);
};

const filteredHabits = computed(() => {
	if (!searchQuery.value) return habits.value;
	return habits.value.filter((habit) =>
		habit.name.toLowerCase().includes(searchQuery.value.toLowerCase()),
	);
});

const getDifficultyColor = (difficulty: number) => {
	const colors = {
		1: "bg-success text-success-content",
		2: "bg-info text-info-content",
		3: "bg-warning text-warning-content",
		4: "bg-error text-error-content",
		5: "bg-purple-500 text-purple-500-content",
	};
	return colors[difficulty as keyof typeof colors] || "text-base-content";
};
</script>

<template>
  <div v-if="!loading && habits.length" class="mb-12">
    <div class="max-w-2xl mx-auto relative flex items-center pt-2">
      <input
        v-model="searchQuery"
        type="text"
        placeholder="Search habits..."
        class="input input-bordered rounded-3xl w-full pl-4 pr-32 h-14 text-lg shadow-md"
      />
      <div class="absolute right-3 flex items-center gap-2">
        <button class="btn btn-primary btn-sm rounded-xl" @click="showModal = true">New habit</button>
      </div>
    </div>
  </div>

  <div v-if="loading" class="flex justify-center py-12">
    <div class="loading loading-spinner loading-lg text-primary" />
  </div>

  <div v-else>
    <ContentUnavailable
      v-if="!habits.length"
      :image="MingcuteLeafLine"
      title="No Active Habit"
      description="Your habit log is empty. Create a new habit to start tracking your progress."
      actionName="Create your first habit"
      :action="() => (showModal = true)"
    />

    <div
      v-else
      class="grid grid-cols-[repeat(auto-fill,minmax(350px,1fr))] gap-6"
    >
      <HabitsHabitCard
        v-for="habit in filteredHabits"
        :key="habit.id"
        :habit="habit"
        @complete="handleComplete"
        @update="handleUpdate"
        @delete="handleDelete"
      />
    </div>
  </div>

    <HabitsHabitModal
      v-model:showModal="showModal"
      v-model:newHabitName="newHabitName"
    />

  <HabitsHabitModal v-model:showModal="showModal" v-model:newHabitName="newHabitName" />
</template>
