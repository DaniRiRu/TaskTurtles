<script setup lang="ts">
import { signInWithEmailAndPassword } from "firebase/auth";
import { signIn } from "~/composables/account/useAuthPopup";

const auth = useFirebaseAuth();
const router = useRouter();
const error = ref<string | null>(null);
const isLoading = ref(false);

const email = ref("");
const password = ref("");

const [providers, providerInstances] = useFirebaseAuthProviders();

async function signInWithProvider(providerId: keyof typeof providerInstances) {
	if (!auth) return;

	isLoading.value = true;
	error.value = null;

	try {
		signIn(auth, providerInstances[providerId]);
	} catch (err) {
		error.value = (err as Error).message;
		isLoading.value = false;
	}
}

const login = async () => {
	if (!auth) return;

	isLoading.value = true;
	error.value = null;

	try {
		await signInWithEmailAndPassword(auth, email.value, password.value);
		navigateTo("/dashboard");
	} catch (err) {
		error.value = (err as Error).message;
	} finally {
		isLoading.value = false;
	}
};
</script>

<template>
  <div class="min-h-dvh flex items-center justify-center bg-base-200 w-full">
    <div class="lg:max-w-4xl xl:max-w-5xl w-full">
      <div class="flex bg-base-100 shadow-md max-lg:h-dvh lg:rounded-2xl overflow-hidden lg:m-4 max-lg:justify-center max-lg:items-center">
        <div class="w-1/2 bg-base-200 my-2 lg:ml-2 lg:rounded-l-xl lg:rounded-r-lg lg:shadow overflow-hidden lg:min-h-60vh max-lg:hidden">
          <div class="h-full p-8 flex flex-col justify-between">
            <div class="mb-4 flex justify-between items-center">
              <div class="text-2xl font-bold tracking-tight">TaskTurtles</div>
            </div>
            <div class="mt-auto max-lg:hidden">
              <h2 class="text-2xl font-bold mb-1 tracking-tight">Level Up Your Productivity</h2>
              <h2 class="text-2xl font-bold tracking-tight">With TaskTurtles</h2>
            </div>
          </div>
        </div>

        <div class="w-full lg:w-1/2 flex flex-col max-lg:max-w-xl">
          <form @submit.prevent="login" class="card-body space-y-4 p-8 justify-between flex h-full">
            <div class="space-y-4">
              <div class="flex flex-col">
                <h2 class="text-3xl font-medium text-base-content tracking-tight">Welcome Back</h2>
                <p class="text-base-content/60 text-md">Sign in to your account</p>
              </div>
              
              <div v-if="error" class="bg-error/10 text-error p-4 text-sm rounded-xl border border-error/20">
                {{ error }}
              </div>
            </div>

            <div class="space-y-3">
              <input v-model="email" type="email" placeholder="Email" required
                class="input bg-base-200 hover:bg-base-300 border-none w-full" />
              <input v-model="password" type="password" placeholder="Password" required
                class="input bg-base-200 hover:bg-base-300 border-none w-full" />
              <button type="submit"
                :disabled="isLoading || !email || !password"
                class="btn w-full border-0"
                :class="{ 'btn-primary hover:border-2 hover:border-primary hover:bg-primary/10 hover:text-base-content': !(isLoading || !email || !password)}">
                {{ isLoading ? "Signing in..." : "Sign in" }}
              </button>
            </div>

            <div class="w-full flex flex-col">
              <div class="divider max-lg:pb-4 text-sm">Or sign in with</div>

              <div class="grid grid-cols-3 gap-3">
                <button v-for="provider in providers" :key="provider.id"
                  @click="signInWithProvider(provider.id)" :disabled="isLoading"
                  class="btn gap-2 normal-case hover:border-2 hover:border-secondary hover:bg-secondary/10 hover:text-base-content">
                  <component :is="provider.icon" class="w-5 h-5" />
                  {{ provider.name }}
                </button>
              </div>

              <a href="/signup" class="btn hover:border-2 hover:border-secondary hover:bg-secondary/10 hover:text-base-content normal-case justify-between mt-4">
                <span class="text-base-content/60">Don't have an account?</span>
                <span class="text-secondary font-semibold">Sign up</span>
              </a>

              <div class="flex items-center justify-center text-xs text-base-content/60 pt-6 text-center lg:hidden">
                By signing in, you agree to our terms and privacy policy
              </div>
            </div>
          </form>
        </div>
      </div>

      <div class="flex items-center justify-center text-xs text-base-content/60 pt-4 text-center max-lg:hidden">
        By signing in, you agree to our terms and privacy policy
      </div>
    </div>
  </div>
</template>

<style scoped>
.input, .btn {
  border-radius: 0.75rem;
}
</style>