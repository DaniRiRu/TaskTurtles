<script lang="ts" setup>
import { useCurrentUser } from "vuefire";
import {
	EMPTY_PROGRESS,
	type UserProgress,
} from "~/types/backend/meta/progress";
import type { WalletData } from "~/types/backend/meta/wallet";
import type { Reward } from "~/types/rewards/rewards";

definePageMeta({
	layout: "dashboard",
});

const user = useCurrentUser();
const backend = useBackend();
const isClaimingReward = ref(false);
const rewardClaimed = ref(false);
const claimError = ref("");
const rewardResponse = ref<Reward | null>(null);
const isLoading = ref(true);

const progress = ref<UserProgress>(EMPTY_PROGRESS);
const wallet = ref({
	coins: 0,
	diamonds: 0,
});

const joinDate = computed(() => {
	if (!user.value?.metadata?.creationTime) return "";
	return new Date(user.value.metadata.creationTime).toLocaleDateString();
});

const shouldClaimDailyReward = (userProgress: UserProgress): boolean => {
	console.log(userProgress.lastClaimedGift);

	if (!userProgress.lastClaimedGift) return true;

	const lastClaimed = new Date(userProgress.lastClaimedGift);
	const now = new Date();

	const todayUTC = new Date(
		now.getUTCFullYear(),
		now.getUTCMonth(),
		now.getUTCDate(),
	);

	const lastClaimedUTC = new Date(
		lastClaimed.getUTCFullYear(),
		lastClaimed.getUTCMonth(),
		lastClaimed.getUTCDate(),
	);

	return lastClaimedUTC.getTime() !== todayUTC.getTime();
};

const claimDailyReward = async () => {
	try {
		isClaimingReward.value = true;
		claimError.value = "";

		const response = await backend.progress.claimDailyReward();

		if (!response) {
			claimError.value = "Failed to claim daily reward";
			return;
		}

		if ("error" in response) {
			return;
		}

		rewardResponse.value = response;
		rewardClaimed.value = true;

		if (response.coins) {
			wallet.value.coins += response.coins;
		}
		if (response.diamonds) {
			wallet.value.diamonds += response.diamonds;
		}
		if (response.xp) {
			progress.value.xp += response.xp;
		}

		progress.value.lastClaimedGift = new Date().toISOString();
	} catch (error) {
		claimError.value =
			typeof error === "string"
				? error
				: "An error occurred while claiming your daily reward";
	} finally {
		isClaimingReward.value = false;
	}
};

const handleDismissReward = () => {
	rewardClaimed.value = false;
};

const handleDismissError = () => {
	claimError.value = "";
};

const initialize = async () => {
	try {
		const [progressResponse, walletResponse] = await Promise.all([
			backend.progress.fetchProgress() as Promise<UserProgress>,
			backend.progress.fetchWallet() as Promise<WalletData>,
		]);

		if (!progressResponse || !walletResponse) {
			throw new Error("Failed to fetch initial data");
		}

		progress.value = progressResponse;
		wallet.value = walletResponse;

		if (shouldClaimDailyReward(progressResponse)) {
			await claimDailyReward();
		}
	} catch (error) {
		console.error("Error initializing:", error);
		throw error;
	} finally {
		isLoading.value = false;
	}
};

onMounted(() => {
	initialize();
});
</script>

<template>
  <div v-if="isLoading" class="min-h-screen flex items-center justify-center">
    <span class="loading loading-spinner loading-lg"></span>
  </div>
  <div v-else class="min-h-screen transition-all duration-300 pb-4">
    <DashboardProfileBanner
      :userPhotoURL="user?.photoURL ?? null"
      :userDisplayName="user?.displayName ?? null"
      :joinDate="joinDate"
      :totalProjects="0"
      :totalTasks="0"
      :completionRate="0"
      :progress="progress"
      :wallet="wallet"
      :isLoading="isLoading"
      class="w-full mb-4"
    />
    
    <div class="w-full px-4" v-if="rewardClaimed && rewardResponse">
      <DashboardRewardNotification
        :reward="rewardResponse"
        @dismiss="handleDismissReward"
        class="w-full mb-4"
      />
    </div>

    <div v-if="claimError" class="container mx-auto px-4 mb-4">
      <div class="alert alert-error shadow-lg">
        <div>
          <svg xmlns="http://www.w3.org/2000/svg" class="stroke-current flex-shrink-0 h-6 w-6" fill="none" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <span>{{ claimError }}</span>
        </div>
        <button class="btn btn-sm" @click="handleDismissError">Dismiss</button>
      </div>
    </div>
    
    <div class="container mx-auto px-4 w-full max-w-full grid gap-4">
      <div class="grid grid-cols-1 lg:grid-cols-4 gap-4">
        <div class="lg:col-span-3 grid gap-4">
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <DashboardTasksSection 
              class="w-full min-h-[180px] rounded-xl bg-base-100 shadow-lg"
            />
            <DashboardQuestSection 
              class="w-full min-h-[180px] rounded-xl bg-base-100 shadow-lg"
            />
          </div>
          <DashboardProgressionSection 
            class="w-full min-h-[200px] rounded-xl bg-base-100 shadow-lg"
          />
        </div>
        
        <DashboardFriendsSection
          class="w-full min-h-[200px] lg:min-h-[480px] rounded-xl bg-base-100 shadow-lg"
        />
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-3 3xl:grid-cols-5 gap-4">
        <DashboardCalendarSection 
          class="w-full min-h-[180px] rounded-xl bg-base-100 shadow-lg"
        />
        <DashboardAchievementsSection 
          class="w-full min-h-[180px] rounded-xl bg-base-100 shadow-lg"
        />
        <DashboardShopSection 
          class="w-full min-h-[180px] rounded-xl bg-base-100 shadow-lg"
        />
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4 3xl:grid-cols-5 gap-4">
        <DashboardInventorySection 
          class="w-full sm:col-span-2 lg:col-span-2 2xl:col-span-3 3xl:col-span-4 min-h-[160px] rounded-xl bg-base-100 shadow-lg"
        />
        <DashboardJournalSection 
          class="w-full min-h-[160px] rounded-xl bg-base-100 shadow-lg"
        />
      </div>
    </div>
  </div>
</template>