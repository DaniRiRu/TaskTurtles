<script lang="ts" setup>
import MaterialSymbolsCreditCard from "~icons/material-symbols/credit-card";
import MaterialSymbolsEdit from "~icons/material-symbols/edit";
import MaterialSymbolsKey from "~icons/material-symbols/key";
import MaterialSymbolsPalette from "~icons/material-symbols/palette";
import MaterialSymbolsPerson from "~icons/material-symbols/person";

definePageMeta({
	layout: "dashboard",
});

const selectedTab = ref("account");

const tabs = [
	{ name: "account", icon: MaterialSymbolsPerson },
	{ name: "edit Profile", icon: MaterialSymbolsEdit },
	{ name: "password", icon: MaterialSymbolsKey },
	{ name: "appearance", icon: MaterialSymbolsPalette },
	{ name: "billing", icon: MaterialSymbolsCreditCard },
];

const changeTab = (tab: string) => {
	console.log("Selected tab: ", tab);
	selectedTab.value = tab;
};
</script>

<template>
	<div class="w-full h-full">
		<div
			class="transition-all duration-300 ease-in-out fixed top-0 h-38 left-0 w-full bg-gradient-to-b from-base-200 from-70% z-2">
		</div>
		<div class="sticky flex justify-between mb-8 shadow-sm rounded-btn top-20 bg-base-100 z-5">
			<div class="join">
				<div v-for="tab in tabs" :key="tab.name">
					<button class="border-none btn btn-ghost join-item" :class="{
              'btn-active': selectedTab === tab.name
            }" @click="changeTab(tab.name)">
						<component :is="tab.icon" class="w-5 h-5" />
						{{ tab.name.charAt(0).toUpperCase() + tab.name.slice(1) }}
					</button>
				</div>
			</div>
		</div>

		<div class="flex flex-col h-full">
			<div v-if="selectedTab === 'account'">
				<SettingsAccount />
			</div>
			<div v-else-if="selectedTab === 'edit Profile'">
				<SettingsEditProfile />
			</div>
			<div v-else-if="selectedTab === 'password'">
				<SettingsPassword />
			</div>
			<div v-else-if="selectedTab === 'appearance'">
				<SettingsAppearance />
			</div>
			<div v-else-if="selectedTab === 'billing'">
				<SettingsBilling />
			</div>
		</div>
	</div>
</template>