<script setup lang="ts">
definePageMeta({
	layout: "settings",
	middleware: ["auth", "settings"],
});
</script>

<template>
	<SettingsSecurity />
</template>