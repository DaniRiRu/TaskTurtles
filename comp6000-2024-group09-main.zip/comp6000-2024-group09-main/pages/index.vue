<script setup lang="ts">
definePageMeta({
	title: "Home",
	middleware: ["redirect-if-authenticated"],
});
</script>
<template>
  <div class="relative min-h-dvh overflow-x-hidden bg-base-100 pb-8">
    <nav class="fixed flex justify-center top-4 z-50 w-full">
      <CoreOnboardingNavbar />
    </nav>

    <div class="w-full max-w-7xl mx-auto px-6">
      <HeroMainSection />

      <div class="flex flex-col gap-12 my-8 mt-12">
        <HeroHowItWorksSection />
        <HeroPricingSection />
        <HeroFAQSection />
      </div>

      <HeroFooter />
    </div>
  </div>
</template>
