<script setup>
definePageMeta({
	layout: "dashboard",
});
</script>

<template>
  <div class="overflow-y-hidden overflow-hidden">
    <div class="fixed top-0 left-0 w-full h-24 bg-gradient-to-b from-base-200/80 from-70% to-transparent backdrop-blur-sm z-10" />
    <Leaderboard />
  </div>
</template>