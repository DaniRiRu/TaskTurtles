<script lang="ts" setup>
import { useCurrentUser } from "vuefire";
import { useSkillState } from "~/composables/skillTree/useSkillState";
import { useSkillTrees } from "~/composables/skillTree/useSkillTree";
import type { SkillTreeData } from "~/types/skills/skill";
import type { ViewType } from "~/types/skills/views";

definePageMeta({
	layout: "dashboard",
	middleware: ["auth"],
});

const searchQuery = ref("");
const skillStore = useSkillState();
const currentView = computed({
	get: () => skillStore.currentView.value,
	set: (value: ViewType) => skillStore.setCurrentView(value),
});

const { trees, loadTrees, isLoading } = useSkillTrees();
const currentUser = useCurrentUser();

interface TreeWithId extends SkillTreeData {
	id: string;
}

const filteredTrees = computed<TreeWithId[]>(() => {
	return Object.entries(trees)
		.filter(([_, tree]) => tree.name && tree.description)
		.map(([id, tree]) => ({
			...tree,
			id,
		}))
		.filter((tree) => {
			const query = searchQuery.value.toLowerCase();
			const nameMatch = tree.name.toLowerCase().includes(query);
			const descMatch = tree.description.toLowerCase().includes(query);
			return nameMatch || descMatch;
		});
});

const isInitialLoad = ref(true);

watch(skillStore.isCreateModalOpen, async (newValue) => {
	if (!newValue) {
		await loadTrees();
	}
});

const initializeTrees = async () => {
	if (!currentUser.value) return;
	try {
		await loadTrees();
	} finally {
		isInitialLoad.value = false;
	}
};

watch(
	() => currentUser.value,
	async (newUser, oldUser) => {
		if (newUser && (!oldUser || isInitialLoad.value)) {
			await initializeTrees();
		}
	},
	{ immediate: true },
);

useHead({
	title: "Skill Trees",
	meta: [
		{
			name: "description",
			content: "View and manage your skill development trees",
		},
	],
});
</script>

<template>
  <div
    class="fixed z-2 top-0 left-0 w-full h-26 bg-gradient-to-b from-base-200 from-70% transition-all duration-300 ease-in-out">
  </div>

  <div class="mx-auto px-4 py-8 container">
    <SkillTreeHeader v-if="!isLoading && !isInitialLoad && filteredTrees.length > 0" :search-query="searchQuery"
      :current-view="currentView" @update:search-query="searchQuery = $event"
      @update:current-view="currentView = $event" />

    <div v-if="isLoading || isInitialLoad" class="flex justify-center items-center min-h-[80vh]">
      <span class="loading loading-spinner loading-lg text-primary" />
    </div>

    <template v-else>
      <Transition enter-active-class="transition-all duration-300 ease-out" enter-from-class="opacity-0 translate-y-4"
        enter-to-class="opacity-100 translate-y-0" leave-active-class="transition-all duration-200 ease-in"
        leave-from-class="opacity-100 translate-y-0" leave-to-class="opacity-0 translate-y-4" mode="out-in">
        <div v-if="filteredTrees.length > 0" class="space-y-6">
          <SkillTreeList :key="`tree-list-${currentView}`" :current-view="currentView" :trees="filteredTrees" />
        </div>
        <SkillTreeEmptyState v-else />
      </Transition>
    </template>
  </div>

  <SkillTreeCreateTreeModal v-model="skillStore.isCreateModalOpen.value" treeName="" treeDescription="" />
</template>