<script lang="ts" setup>
import { useSkillTrees } from "~/composables/skillTree/useSkillTree";
import type { Skill } from "~/types/skills/skill";
import SolarSettingsBold from "~icons/solar/settings-bold";

const { getSkillsByTree, loadTreeByName } = useSkillTrees();

definePageMeta({
	layout: "dashboard",
	validate: () => true,
});

const route = useRoute();
const treeName = computed(() => route.params.name as string);
const selectedSkill = ref<Skill | null>(null);
const isSideMenuOpen = ref(false);
const isSettingsOpen = ref(false);

onBeforeMount(async () => {
	await loadTreeByName(treeName.value);
});

const skills = computed(() => getSkillsByTree(treeName.value) as Skill[]);

const handleSkillClick = (skill: Skill) => {
	selectedSkill.value = skill;
	isSideMenuOpen.value = true;
};

const handleSideMenuClose = () => {
	isSideMenuOpen.value = false;
	selectedSkill.value = null;
};

const handleSettingsClick = () => {
	isSettingsOpen.value = true;
};

const handleSettingsClose = () => {
	isSettingsOpen.value = false;
};
</script>

<template>
  <div class="relative flex flex-col">
    <div
      class="transition-all duration-300 ease-in-out fixed top-0 h-24 left-0 w-full bg-gradient-to-b from-base-200 from-70% z-2" />

    <div class="rounded-btn top-20 sticky flex justify-between z-5">
      <div class="flex flex-row join shadow-sm" />
      <button class="btn btn-ghost min-w-12 max-w-12 p-0 shadow-sm" @click="handleSettingsClick">
        <SolarSettingsBold class="h-6 w-6" />
      </button>
    </div>

    <SkillTreeSkillTreeCanvasBetterCanvas :treeName="treeName" :skills="skills" :on-skill-click="handleSkillClick" />

    <Teleport to="body">
      <div v-if="isSideMenuOpen" class="fixed inset-0 bg-black bg-opacity-50 z-40" @click="handleSideMenuClose" />
      <SkillTreeSkillTreeCanvasSkillsDetailsPanel v-model="isSideMenuOpen" :tree-id="treeName"
        :selected-skill="selectedSkill" @close="handleSideMenuClose" />
    </Teleport>

    <SkillTreeSkillTreeCanvasSettingsPanel v-model="isSettingsOpen" :tree-name="treeName"
      @close="handleSettingsClose" />
  </div>
</template>