<script lang="ts" setup>
import type { Achievement } from "~/types/frontend/achievement";
import MaterialSymbolsTrophy from "~icons/material-symbols/trophy";

definePageMeta({
	layout: "dashboard",
});

// const backend = useBackend()

const achievements = ref<Achievement[]>([
	{
		id: "1",
		title: "Newbie",
		description: "Create your first task",
		progress: 100,
		maxProgress: 100,
		reward: "200 XP",
		unlocked: true,
		unlockedAt: "2 hours ago",
	},
	{
		id: "2",
		title: "Beginner's Luck",
		description: "Complete your first task",
		progress: 0,
		maxProgress: 1,
		reward: "500 XP",
		unlocked: false,
		unlockedAt: "",
	},
	{
		id: "3",
		title: "Task Master",
		description: "Complete 10 tasks",
		progress: 10,
		maxProgress: 10,
		reward: "1000 XP",
		unlocked: true,
		unlockedAt: "1 week ago",
	},
	{
		id: "4",
		title: "Social Butterfly",
		description: "Add 10 friends",
		progress: 7,
		maxProgress: 10,
		reward: "500 XP",
		unlocked: false,
		unlockedAt: "",
	},
	{
		id: "5",
		title: "Shopaholic",
		description: "Buy something from the shop",
		progress: 0,
		maxProgress: 1,
		reward: "500 XP",
		unlocked: false,
		unlockedAt: "",
	},
	{
		id: "6",
		title: "Calendar Keeper",
		description: "Connect your calendar",
		progress: 0,
		maxProgress: 1,
		reward: "500 XP",
		unlocked: false,
		unlockedAt: "",
	},
	{
		id: "7",
		title: "Locked in",
		description: "Maintain a streak for 7 days",
		progress: 3,
		maxProgress: 7,
		reward: "500 XP",
		unlocked: false,
		unlockedAt: "",
	},
]);

const unlockedAchievements = computed(() =>
	achievements.value?.filter((achievement) => achievement.unlocked),
);

const lockedAchievements = computed(() =>
	achievements.value?.filter((achievement) => !achievement.unlocked),
);

const viewMode = ref("all");

const filteredAchievements = computed(() => {
	if (viewMode.value === "locked") {
		return lockedAchievements.value;
	}
	if (viewMode.value === "unlocked") {
		return unlockedAchievements.value;
	}
	return achievements.value;
});
const noAchievementsDescription = computed(() => {
	if (achievements.value.length === 0) {
		return "No achievements available or unable to fetch. Please try again later.";
	}
	if (unlockedAchievements.value.length === achievements.value.length) {
		return "Congratulations! You've unlocked all achievements. Keep up the good work!";
	}
	return "You haven't earned any achievements. Use TaskTurtles to start unlocking them!";
});
</script>

<template>
	<div class="h-full w-full">
		<div
			class="transition-all duration-300 ease-in-out fixed top-0 h-38 left-0 w-full bg-gradient-to-b from-base-200 from-70% z-2">
		</div>

		<div class="sticky top-20 bg-base-100 shadow-sm z-5 rounded-btn mb-8">
			<div class="flex items-center justify-between">
				<div class="dropdown dropdown-start">
					<label tabindex="0" class="btn btn-ghost">
						<MaterialSymbolsTrophy class="h-5 w-5" />
						{{ viewMode.charAt(0).toUpperCase() + viewMode.slice(1) }}
						<MaterialSymbolsArrowDropDown class="h-5 w-5" />
					</label>
					<ul tabindex="0" class="dropdown-content menu p-2 mt-2 shadow bg-base-100 rounded-box w-52">
						<li><a @click="viewMode = 'all'">All</a></li>
						<li><a @click="viewMode = 'locked'">Locked</a></li>
						<li><a @click="viewMode = 'unlocked'">Unlocked</a></li>
					</ul>
				</div>
			</div>
		</div>

		<div>
			<div v-if="filteredAchievements?.length">
				<template v-for="[title, list, badgeColor] in [
					['Locked', lockedAchievements, 'red'],
					['Unlocked', unlockedAchievements, 'green']
				] as [string, Achievement[], string][]">
					<div v-if="list.length && (viewMode === 'all' || viewMode === title.toLowerCase())" class="mb-3">
						<div class="flex items-center justify-between px-2 mb-2">
							<h2 class="text-lg font-semibold">{{ title }}</h2>
							<span :class="`px-2.5 py-0.5 rounded-full text-sm font-medium bg-${badgeColor}-100 text-${badgeColor}-800`">
								{{ list.length }}
							</span>
						</div>
						<div class="grid gap-3 grid-cols-[repeat(auto-fit,minmax(250px,1fr))] md:grid-cols-[repeat(auto-fit,minmax(500px,1fr))] gap-3">
							<Achievement v-for="achievement in list" :key="achievement.id"
								:achievement="achievement" :show-unlock="title === 'Locked'" />
						</div>
					</div>
				</template>
			</div>

			<ContentUnavailable :image="MaterialSymbolsTrophy" title="No achievements"
				:description="noAchievementsDescription" v-if="filteredAchievements.length === 0" />
		</div>
	</div>
</template>