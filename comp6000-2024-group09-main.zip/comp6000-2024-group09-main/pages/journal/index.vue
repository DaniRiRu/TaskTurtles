<script lang="ts" setup>
import JournalContentContainer from "~/components/Journal/JournalContent/JournalContentContainer.vue";
import useJournal from "~/composables/journal/useJournal";

definePageMeta({
	layout: "dashboard",
});

const journal = useJournal();

onMounted(() => {
	journal.initializeDays();
	journal.updateVisibleCount();
	window.addEventListener("resize", journal.updateVisibleCount);
});

onUnmounted(() => {
	window.removeEventListener("resize", journal.updateVisibleCount);
});
</script>

<template>
  <div class="h-full w-full mb-10 overflow-hidden">
    <div class="transition-all duration-300 ease-in-out fixed top-0 h-25 left-0 w-full bg-gradient-to-b from-base-200 from-70% z-10"></div>
    
    <!-- <JournalHeader 
      :selected-date="journal.selectedDate.value" 
      :show-insights="journal.showInsights.value" 
      :visible-days="journal.visibleDays.value"
      :current-date="journal.currentDate.value"
      @navigate:left="journal.navigateLeft()"
      @navigate:right="journal.navigateRight()"
    /> -->
    
    <JournalContentContainer 
      :show-insights="journal.showInsights.value" 
      :formatted-date="journal.formattedDate.value"
      @save-entry="journal.saveJournalEntry"
      class="relative z-0 mt-8"
    />
  </div>
</template>