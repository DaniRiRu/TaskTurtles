<script lang="ts" setup>
definePageMeta({
	layout: "dashboard",
});
</script>
<template>
    <Shop />
</template>