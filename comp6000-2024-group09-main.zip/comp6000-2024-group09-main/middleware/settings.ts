export default defineNuxtRouteMiddleware(async (to, from) => {
	const accountStore = useAccountStore();

	try {
		await accountStore.fetchAccountData();
	} catch (error) {
		console.error("Failed to fetch account data:", error);
		return navigateTo("/error");
	}
});
